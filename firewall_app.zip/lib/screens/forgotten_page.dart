import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';
import '../widgets/usage_access.dart';

String _fmtBytes(num b) {
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
  return '${(b / 1073741824).toStringAsFixed(2)} GB';
}

/// ৩০ দিন খোলা হয়নি অথচ ডেটা খাচ্ছে এমন অ্যাপের তালিকা, এক ট্যাপে ব্লক
class ForgottenPage extends StatefulWidget {
  const ForgottenPage({super.key});

  @override
  State<ForgottenPage> createState() => _ForgottenPageState();
}

class _ForgottenPageState extends State<ForgottenPage> with WidgetsBindingObserver {
  bool? access;
  bool running = true;
  List<Map<String, dynamic>>? list;
  final Set<String> blocked = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // Usage access দিয়ে ফিরলে আবার দেখি
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && access != true) _load();
  }

  Future<void> _load() async {
    final a = await VpnChannel.hasUsageAccess();
    final r = await VpnChannel.isRunning();
    if (!mounted) return;
    if (!a) {
      setState(() {
        access = false;
        running = r;
      });
      return;
    }
    setState(() {
      access = true;
      running = r;
      list = null;
    });
    List<Map<String, dynamic>> l = [];
    try {
      l = await VpnChannel.scanForgotten();
    } catch (_) {}
    if (!mounted) return;
    setState(() => list = l);
  }

  void _block(String pkg) {
    store.setRule(pkg, wifi: true, mobile: true);
    store.cfg.allowed.remove(pkg);
    setState(() => blocked.add(pkg));
  }

  void _blockAll() {
    for (final m in list ?? const <Map<String, dynamic>>[]) {
      final p = m['pkg'] as String;
      if (!blocked.contains(p)) _block(p);
    }
  }

  String _when(Map<String, dynamic> m) {
    final d = (m['days'] as num).toInt();
    return m['never'] == true
        ? 'ইনস্টলের পর কখনো খোলা হয়নি ($d দিন আগে ইনস্টল)'
        : '$d দিন ধরে খোলা হয়নি';
  }

  @override
  Widget build(BuildContext context) {
    if (access == false) {
      return Scaffold(
          appBar: AppBar(title: const Text('ভুলে যাওয়া অ্যাপ')),
          body: const UsageAccessPrompt());
    }
    final l = list;
    return Scaffold(
      appBar: AppBar(title: const Text('ভুলে যাওয়া অ্যাপ'), actions: [
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh), tooltip: 'আবার দেখুন'),
      ]),
      body: l == null
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.all(16), children: [
                Text(
                    'গত ৩০ দিনে একবারও খোলা হয়নি, অথচ ইন্টারনেটে ডেটা খরচ করেছে (১ MB-র বেশি)। বেশিরভাগ সময় এগুলো বিজ্ঞাপন বা ট্র্যাকিংয়ের জন্য চুপচাপ চলে।',
                    style: Theme.of(context).textTheme.bodySmall),
                if (!running)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: AppCard(
                        child: Row(children: [
                      Icon(Icons.info_outline, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(width: 12),
                      const Expanded(
                          child: Text('ফায়ারওয়াল এখন বন্ধ। ব্লক সেভ হবে, কিন্তু ফায়ারওয়াল চালু না করলে কাজ করবে না।')),
                    ])),
                  ),
                const SizedBox(height: 12),
                if (l.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 40),
                    child: Center(
                        child: Text('ভুলে যাওয়া কোনো অ্যাপ পাওয়া যায়নি।\nসবগুলো সম্প্রতি খোলা হয়েছে।',
                            textAlign: TextAlign.center)),
                  )
                else ...[
                  FilledButton.icon(
                      onPressed: blocked.length == l.length ? null : _blockAll,
                      icon: const Icon(Icons.block),
                      label: Text('সবগুলো ব্লক করুন (${l.length}টি)')),
                  const SizedBox(height: 12),
                  for (final m in l)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: AppCard(
                        padding: const EdgeInsets.all(12),
                        child: Row(children: [
                          AppIcon(m['pkg'] as String, size: 40),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(m['name'] as String,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                              Text('৩০ দিনে ${_fmtBytes(m['bytes'] as num)} ডেটা খরচ',
                                  style: Theme.of(context).textTheme.bodySmall),
                              Text(_when(m), style: Theme.of(context).textTheme.bodySmall),
                            ]),
                          ),
                          const SizedBox(width: 8),
                          blocked.contains(m['pkg'])
                              ? const Icon(Icons.check_circle, color: Colors.green)
                              : OutlinedButton(
                                  onPressed: () => _block(m['pkg'] as String),
                                  child: const Text('ব্লক')),
                        ]),
                      ),
                    ),
                ],
              ]),
            ),
    );
  }
}
