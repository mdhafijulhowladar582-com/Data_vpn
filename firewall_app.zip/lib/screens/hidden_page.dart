import 'package:flutter/material.dart';
import '../models/rule.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';

bool _hiddenActive = false; // একসাথে দুইবার না খোলার জন্য

/// লুকানো অ্যাপ এলাকায় ঢোকার একমাত্র দরজা। অ্যাপস ট্যাবের বাটন আর পিঞ্চ, দুটোই এটা ডাকে।
/// পিন না থাকলে আগে চালু করায়। ঢোকার সময় সবসময় পিন চায় (২ মিনিটের ছাড় ধরে না)।
Future<void> openHiddenArea(BuildContext context) async {
  if (_hiddenActive) return;
  _hiddenActive = true;
  try {
    if (await Lock.guestBlocks(context)) return;
    if (!context.mounted) return;
    var justSet = false;
    if (!Lock.hasPin) {
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('আগে পিন চালু করুন'),
          content: const Text('লুকানো অ্যাপ এলাকা পিন দিয়ে সুরক্ষিত থাকে। এখনো পিন চালু নেই।'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('থাক')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('পিন দিন')),
          ],
        ),
      );
      if (go != true || !context.mounted) return;
      if (!await setPinFlow(context)) return;
      justSet = true;
    }
    if (!context.mounted) return;
    var g = Gate.real;
    if (!justSet) {
      g = await Lock.gate(context, reason: 'লুকানো অ্যাপ খুলতে পিন দিন');
      if (g == Gate.denied) return;
    }
    if (!context.mounted) return;
    final decoy = g == Gate.decoy; // নকল পিন: আলাদা ভুয়া তালিকা, আসল তালিকা ছোঁয়াই হয় না
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => HiddenPage(decoy: decoy)));
  } finally {
    _hiddenActive = false;
  }
}

/// দুই আঙুল দূর থেকে কাছে আনলে (পিঞ্চ) onPinch চলে।
/// Listener ব্যবহার করেছি, তাই স্ক্রল বা ট্যাপের সাথে গোলমাল হয় না।
class PinchGate extends StatefulWidget {
  final Widget child;
  final VoidCallback onPinch;
  const PinchGate({super.key, required this.child, required this.onPinch});

  @override
  State<PinchGate> createState() => _PinchGateState();
}

class _PinchGateState extends State<PinchGate> {
  final Map<int, Offset> _p = {};
  double _start = 0;
  bool _fired = false;

  double _dist() {
    final v = _p.values.toList();
    return (v[0] - v[1]).distance;
  }

  void _down(PointerDownEvent e) {
    _p[e.pointer] = e.position;
    if (_p.length == 2) {
      _start = _dist();
      _fired = false;
    }
  }

  void _move(PointerMoveEvent e) {
    if (!_p.containsKey(e.pointer)) return;
    _p[e.pointer] = e.position;
    // শুরুতে আঙুল অন্তত ১৪০ পিক্সেল দূরে, শেষে অর্ধেকের কাছাকাছি
    if (_p.length == 2 && !_fired && _start > 140 && _dist() < _start * 0.55) {
      _fired = true;
      widget.onPinch();
    }
  }

  void _up(PointerEvent e) {
    _p.remove(e.pointer);
    if (_p.length < 2) _start = 0;
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: _down,
        onPointerMove: _move,
        onPointerUp: _up,
        onPointerCancel: _up,
        child: widget.child,
      );
}

/// লুকানো অ্যাপের তালিকা: Launch (অ্যাপ খোলে), আনহাইড (তালিকা থেকে সরায়), যোগ করুন
class HiddenPage extends StatefulWidget {
  final bool decoy; // নকল পিনে খোলা: ভুয়া তালিকা দেখায়
  const HiddenPage({super.key, this.decoy = false});

  @override
  State<HiddenPage> createState() => _HiddenPageState();
}

class _HiddenPageState extends State<HiddenPage> {
  Map<String, String> names = {};

  Config get c => store.cfg;

  Set<String> get _set => widget.decoy ? c.decoyApps : c.hiddenApps;

  @override
  void initState() {
    super.initState();
    VpnChannel.setSecure(true); // স্ক্রিনশট ও Recent প্রিভিউ ফাঁকা
    _load();
  }

  @override
  void dispose() {
    VpnChannel.setSecure(false);
    super.dispose();
  }

  Future<void> _load() async {
    final apps = await store.loadApps();
    if (!mounted) return;
    setState(() => names = {for (final a in apps) a.pkg: a.name});
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  void _snack(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _launch(String pkg) async {
    bool ok = false;
    try {
      ok = await VpnChannel.launchApp(pkg);
    } catch (_) {}
    if (!ok && mounted) _snack('অ্যাপটা খোলা গেল না (ইনস্টল নেই বা বন্ধ করা আছে)');
  }

  Future<void> _unhide(String pkg) async {
    _set.remove(pkg);
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final r = await pickApps(context, title: 'যে অ্যাপগুলো লুকানো থাকবে', selected: _set);
    if (r == null) return;
    if (widget.decoy) {
      c.decoyApps = r.toSet();
    } else {
      c.hiddenApps = r.toSet();
    }
    await store.save();
    if (mounted) setState(() {});
  }

  Widget _card(String pkg) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: AppCard(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            Row(children: [
              AppIcon(pkg, size: 40),
              const SizedBox(width: 12),
              Expanded(
                  child: Text(_name(pkg),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                  child: FilledButton.icon(
                      onPressed: () => _launch(pkg),
                      icon: const Icon(Icons.open_in_new, size: 18),
                      label: const Text('Launch'))),
              const SizedBox(width: 8),
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: () => _unhide(pkg),
                      icon: const Icon(Icons.visibility_outlined, size: 18),
                      label: const Text('আনহাইড'))),
            ]),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final list = _set.toList()
      ..sort((a, b) => _name(a).toLowerCase().compareTo(_name(b).toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: Text('লুকানো অ্যাপ (${list.length})')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (list.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 32),
                child: Center(
                    child: Text('এখনো কোনো অ্যাপ লুকানো নেই।\nনিচের বাটন দিয়ে যোগ করুন।',
                        textAlign: TextAlign.center)),
              ),
            for (final p in list) _card(p),
            const SizedBox(height: 4),
            OutlinedButton.icon(
                onPressed: _add,
                icon: const Icon(Icons.add),
                label: const Text('অ্যাপ যোগ করুন')),
            const SizedBox(height: 8),
            Text(
                'এখানে যোগ করা অ্যাপ ফায়ারওয়ালের অ্যাপস তালিকা থেকে আড়াল থাকে, ব্লকের নিয়ম আগের মতোই চলে। ফোনের হোম স্ক্রিন থেকে আইকন লুকানো এই পেজ করে না; যেসব অ্যাপ ফোনের নিজের Hide apps-এ লুকানো, সেগুলোও এখান থেকে যোগ করে Launch করা যায়।',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
