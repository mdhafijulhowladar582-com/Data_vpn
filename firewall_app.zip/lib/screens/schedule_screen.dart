import 'package:flutter/material.dart';
import '../services/rules_storage.dart';

String fmt(int m) =>
    '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';

class ScheduleScreen extends StatelessWidget {
  const ScheduleScreen({super.key});

  Future<void> _pick(BuildContext context, bool start) async {
    final cur = start ? store.cfg.schStart : store.cfg.schEnd;
    final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    final m = t.hour * 60 + t.minute;
    if (start) {
      store.cfg.schStart = m;
    } else {
      store.cfg.schEnd = m;
    }
    await store.save();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('শিডিউল')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final c = store.cfg;
          return ListView(children: [
            SwitchListTile(
              title: const Text('শিডিউল চালু'),
              subtitle: const Text('এই সময়ে সব অ্যাপ ব্লক (ফায়ারওয়াল চালু থাকলে)'),
              value: c.scheduleEnabled,
              onChanged: (v) {
                c.scheduleEnabled = v;
                store.save();
              },
            ),
            ListTile(
              title: const Text('শুরু'),
              trailing: Text(fmt(c.schStart), style: const TextStyle(fontSize: 18)),
              onTap: () => _pick(context, true),
            ),
            ListTile(
              title: const Text('শেষ'),
              trailing: Text(fmt(c.schEnd), style: const TextStyle(fontSize: 18)),
              onTap: () => _pick(context, false),
            ),
          ]);
        },
      ),
    );
  }
}
