import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';

const _stdHost = 'dns.adguard-dns.com';
const _famHost = 'family.adguard-dns.com';
// পুরনো হোস্টনেমও AdGuard-এর, তাই এগুলোকে "সঠিক" ধরা হবে
const _adguardHosts = {
  _stdHost,
  _famHost,
  'unfiltered.adguard-dns.com',
  'dns.adguard.com',
  'dns-family.adguard.com',
};

/// ফোনের Private DNS-এ AdGuard বসানোর গাইড ও যাচাই
class PrivateDnsPage extends StatefulWidget {
  const PrivateDnsPage({super.key});

  @override
  State<PrivateDnsPage> createState() => _PrivateDnsPageState();
}

class _PrivateDnsPageState extends State<PrivateDnsPage> with WidgetsBindingObserver {
  Map<String, dynamic>? st;
  bool checking = true;
  int pick = 0; // 0 স্ট্যান্ডার্ড, 1 ফ্যামিলি, 2 নিজের ঠিকানা
  final custom = TextEditingController();

  bool get family => pick == 1;

  String get _customHost => custom.text.trim().toLowerCase();

  bool get _customOk =>
      RegExp(r'^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$')
          .hasMatch(_customHost);

  String get host => pick == 2 ? _customHost : (family ? _famHost : _stdHost);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    custom.dispose();
    super.dispose();
  }

  // সেটিংস থেকে ফিরে এলে নিজে থেকেই আবার যাচাই
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    setState(() => checking = true);
    Map<String, dynamic> r;
    try {
      r = await VpnChannel.getPrivateDns();
    } catch (_) {
      r = {};
    }
    if (!mounted) return;
    setState(() {
      st = r;
      checking = false;
    });
  }

  void _copy(String text, String msg) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  /// (আইকন, রং-কোড: 0 ভালো / 1 সতর্ক / 2 খারাপ, শিরোনাম, ব্যাখ্যা)
  (IconData, int, String, String) _status() {
    final s = st;
    if (s == null || s.isEmpty) {
      return (Icons.help_outline, 1, 'যাচাই করা যায়নি', 'আবার যাচাই চাপুন');
    }
    if (s['supported'] != true) {
      return (Icons.block, 2, 'এই ফোনে সাপোর্ট নেই',
          'Private DNS-এর জন্য অ্যান্ড্রয়েড ৯ বা তার উপরে লাগবে');
    }
    if (s['found'] != true) {
      return (Icons.wifi_off, 1, 'নেটওয়ার্ক পাওয়া যায়নি',
          'ওয়াইফাই বা মোবাইল ডেটা চালু করে আবার যাচাই করুন');
    }
    final h = ((s['host'] as String?) ?? '').toLowerCase();
    if (h.isNotEmpty && (_adguardHosts.contains(h) || h.endsWith('.adguard-dns.com'))) {
      return (Icons.check_circle, 0, 'AdGuard বসানো আছে', h);
    }
    if (h.isNotEmpty) {
      return (Icons.warning_amber_rounded, 1, 'অন্য সার্ভার বসানো আছে', h);
    }
    if (s['active'] == true) {
      return (Icons.warning_amber_rounded, 1, 'অটোমেটিক মোড চালু',
          'এটা AdGuard নয়, তাই বিজ্ঞাপন আটকাবে না। নিচের ধাপে হোস্টনেম বসান');
    }
    return (Icons.cancel, 2, 'Private DNS বন্ধ', 'নিচের ধাপ মেনে চালু করুন');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final (icon, level, title, sub) = _status();
    final color = level == 0 ? Colors.green : (level == 1 ? Colors.orange : cs.error);
    return Scaffold(
      appBar: AppBar(title: const Text('প্রাইভেট DNS')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Row(children: [
                checking
                    ? const SizedBox(
                        width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3))
                    : Icon(icon, color: color, size: 30),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(checking ? 'যাচাই চলছে…' : title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    if (!checking)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(sub, style: TextStyle(fontSize: 12.5, color: cs.outline)),
                      ),
                  ]),
                ),
                IconButton(
                  icon: const Icon(Icons.refresh),
                  tooltip: 'আবার যাচাই',
                  onPressed: checking ? null : _check,
                ),
              ]),
            ),
            const SizedBox(height: 16),
            const Text('এটা কী', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              'ফোনের একটা সেটিংয়ে AdGuard-এর ঠিকানা বসালে ফোন নিজেই বেশির ভাগ বিজ্ঞাপন ও '
              'ট্র্যাকারের ঠিকানা আটকে দেয়, সব অ্যাপেই। আলাদা অ্যাপ বা ব্যাটারি লাগে না, '
              'আর ফায়ারওয়ালের ব্লকে কিছু বদলায় না।',
              style: TextStyle(fontSize: 13, color: cs.outline, height: 1.45),
            ),
            const SizedBox(height: 16),
            const Text('সার্ভার বাছুন', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('স্ট্যান্ডার্ড')),
                ButtonSegment(value: 1, label: Text('ফ্যামিলি')),
                ButtonSegment(value: 2, label: Text('নিজের')),
              ],
              selected: {pick},
              onSelectionChanged: (v) => setState(() => pick = v.first),
            ),
            const SizedBox(height: 4),
            Text(
              pick == 2
                  ? 'AdGuard-এর বিনামূল্যের অ্যাকাউন্টের নিজের ঠিকানা। অ্যাকাউন্টে নিজের ডোমেইন তালিকা বানালে সেটাও কাজ করবে'
                  : (family
                      ? 'বিজ্ঞাপন ও ট্র্যাকারের সাথে অ্যাডাল্ট সাইটও আটকায়'
                      : 'বিজ্ঞাপন ও ট্র্যাকার আটকায়'),
              style: TextStyle(fontSize: 12.5, color: cs.outline),
            ),
            const SizedBox(height: 10),
            if (pick == 2) ...[
              TextField(
                controller: custom,
                autocorrect: false,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  labelText: 'আপনার-আইডি.d.adguard-dns.com',
                  errorText: custom.text.trim().isNotEmpty && !_customOk
                      ? 'ঠিকানাটা ঠিক মনে হচ্ছে না (https:// ছাড়া শুধু হোস্টনেম)'
                      : null,
                ),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 10),
            ],
            if (pick != 2 || _customOk)
              AppCard(
                padding: const EdgeInsets.fromLTRB(16, 4, 4, 4),
                child: Row(children: [
                  Expanded(
                    child: SelectableText(host,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.copy),
                    tooltip: 'কপি',
                    onPressed: () => _copy(host, 'হোস্টনেম কপি হয়েছে'),
                  ),
                ]),
              ),
            const SizedBox(height: 16),
            const Text('চালু করার ধাপ', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            _step('১', 'উপরের হোস্টনেম কপি করুন'),
            _step('২', 'নিচের বাটনে ফোনের নেটওয়ার্ক সেটিংস খুলুন'),
            _step('৩', 'Advanced / আরও সেটিংস খুলে Private DNS (বা Private DNS provider) এ যান'),
            _step('৪', '"Private DNS provider hostname" বাছুন, কপি করা হোস্টনেম বসিয়ে Save চাপুন'),
            _step('৫', 'এই পেজে ফিরে আসুন, নিজে থেকেই যাচাই হবে'),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: VpnChannel.openNetworkSettings,
              icon: const Icon(Icons.settings_outlined),
              label: const Text('ফোনের নেটওয়ার্ক সেটিংস খুলুন'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _copy('test.adguard.com', 'ঠিকানা কপি হয়েছে, ব্রাউজারে বসান'),
              icon: const Icon(Icons.copy),
              label: const Text('ঠিকমতো চলছে কিনা দেখতে: test.adguard.com কপি'),
            ),
            const SizedBox(height: 16),
            Text(
              'মনে রাখবেন: DNS প্রশ্নগুলো AdGuard-এর কাছে যায়। কিছু অ্যাপ নিজের আলাদা DNS চালায়, '
              'তাদের বিজ্ঞাপন এতে আটকাবে না। যাচাই শুধু ফোনের সেটিং দেখে বলে, '
              'আসল চলা দেখতে ওপরের টেস্ট সাইট খুলুন।',
              style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }

  Widget _step(String n, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 22, child: Text(n, style: const TextStyle(fontWeight: FontWeight.w700))),
          Expanded(child: Text(t, style: const TextStyle(fontSize: 13.5, height: 1.4))),
        ]),
      );
}
