import 'dart:async';
import 'package:flutter/material.dart';
import '../services/focus_service.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/screen_time_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';
import '../widgets/data_limit_section.dart';
import '../widgets/fx.dart';
import '../widgets/limit_sheet.dart';
import '../widgets/shell_actions.dart';
import '../widgets/usage_access.dart';
import 'settings_tab.dart' show fmtMin;

class FocusTab extends StatefulWidget {
  const FocusTab({super.key});

  @override
  State<FocusTab> createState() => _FocusTabState();
}

class _FocusTabState extends State<FocusTab> with WidgetsBindingObserver {
  FocusInfo? info;
  bool running = false;
  bool? has;
  ScreenTimeData? st;
  Map<String, String> names = {};
  Timer? _t;
  bool _wasActive = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final act = info?.active ?? false;
      if (act) setState(() {});
      if (_wasActive && !act) _load();
      _wasActive = act;
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    await store.load();
    final f = await FocusService.get();
    final r = await VpnChannel.isRunning();
    final h = await VpnChannel.hasUsageAccess();
    final apps = await store.loadApps();
    final s = h ? await ScreenTimeService.fetch(force: true) : null;
    if (!mounted) return;
    setState(() {
      info = f;
      running = r;
      has = h;
      st = s;
      names = {for (final a in apps) a.pkg: a.name};
      _wasActive = f.active;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  // ---------- ফোকাস ----------

  Future<void> _start(int min) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$min মিনিট ফোকাস শুরু করবেন?'),
        content: Text(
            'ফায়ারওয়াল চালু হবে এবং বেছে নেওয়া ${store.cfg.focusAllowed.length}টি অ্যাপ ছাড়া সবার ইন্টারনেট বন্ধ থাকবে। '
            'এই সময়ে ফায়ারওয়াল বন্ধ করা যাবে না (আগে শেষ করতে পিন লাগবে)।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('শুরু')),
        ],
      ),
    );
    if (ok != true) return;
    if (!running) {
      final vpn = await VpnChannel.start();
      if (!vpn) {
        if (mounted) _snack('VPN অনুমতি না দিলে ফোকাস চলবে না');
        return;
      }
    }
    final started = await VpnChannel.startFocus(min);
    if (!started && mounted) _snack('ফোকাস শুরু করা যায়নি');
    await _load();
  }

  Future<void> _endEarly() async {
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ফোকাস আগেই শেষ করবেন?'),
        content: const Text('একটু ধৈর্য ধরলে লক্ষ্য পূরণ হবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('চালিয়ে যাই')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('শেষ করুন')),
        ],
      ),
    );
    if (sure != true || !mounted) return;
    if (!await Lock.ask(context, reason: 'ফোকাস আগেই শেষ করতে যাচাই করুন')) return;
    await VpnChannel.endFocus();
    await _load();
  }

  Future<void> _pickAllowed() async {
    final r = await pickApps(context,
        title: 'ফোকাসে ইন্টারনেট পাবে যারা', selected: store.cfg.focusAllowed);
    if (r == null) return;
    await store.setFocusAllowed(r.toSet());
    if (mounted) setState(() {});
  }

  Widget _focusCard(FocusInfo f) {
    final white = FilledButton.styleFrom(
        backgroundColor: Colors.white, foregroundColor: const Color(0xFFE11D48));
    if (f.active) {
      final progress = (1 - f.leftMs / f.totalMs).clamp(0.0, 1.0).toDouble();
      return GradientCard(
        colors: focusGradient,
        child: Column(children: [
          const Text('ফোকাস চলছে', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          SizedBox(
            width: 190,
            height: 190,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 190,
                height: 190,
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: progress),
                  duration: const Duration(milliseconds: 900),
                  builder: (_, v, __) => CircularProgressIndicator(
                      value: v,
                      strokeWidth: 12,
                      strokeCap: StrokeCap.round,
                      backgroundColor: Colors.white24,
                      color: Colors.white),
                ),
              ),
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text(fmtMmSs(f.leftMs),
                    style: const TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.w800)),
                const Text('বাকি', style: TextStyle(color: Colors.white70)),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          const GlassChip(Icons.wifi_off, 'অনুমতিপ্রাপ্ত ছাড়া সবার ইন্টারনেট বন্ধ'),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _endEarly,
            style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)),
            child: const Text('আগেই শেষ করুন'),
          ),
        ]),
      );
    }
    return GradientCard(
      colors: focusGradient,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Icon(Icons.self_improvement, color: Colors.white, size: 30),
          SizedBox(width: 10),
          Text('ফোকাস মোড',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 8),
        const Text('বিভ্রান্তি কমান: বেছে নেওয়া অ্যাপ ছাড়া সবার ইন্টারনেট বন্ধ।',
            style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: FilledButton(style: white, onPressed: () => _start(25), child: const Text('২৫ মিনিট'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton(style: white, onPressed: () => _start(50), child: const Text('৫০ মিনিট'))),
        ]),
        const SizedBox(height: 12),
        InkWell(
          onTap: _pickAllowed,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(children: [
              const Icon(Icons.apps, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Expanded(
                  child: Text('ইন্টারনেট পাবে: ${store.cfg.focusAllowed.length}টি অ্যাপ',
                      style: const TextStyle(color: Colors.white))),
              const Icon(Icons.chevron_right, color: Colors.white),
            ]),
          ),
        ),
        Text('এই সপ্তাহে: ${f.weekSessions} সেশন • ${f.weekMinutes} মিনিট',
            style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ]),
    );
  }

  // ---------- টাইম লিমিট ----------

  Widget _limits() {
    final cs = Theme.of(context).colorScheme;
    final entries = store.cfg.limits.entries.toList()
      ..sort((a, b) => _name(a.key).toLowerCase().compareTo(_name(b.key).toLowerCase()));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionLabel('অ্যাপ টাইম লিমিট'),
      if (!running)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: AppCard(
            color: cs.errorContainer,
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Icon(Icons.warning_amber, color: cs.onErrorContainer),
              const SizedBox(width: 10),
              Expanded(
                  child: Text('ফায়ারওয়াল বন্ধ, তাই লিমিট কাজ করবে না। হোমে গিয়ে চালু করুন।',
                      style: TextStyle(fontSize: 12, color: cs.onErrorContainer))),
            ]),
          ),
        ),
      if (has == false)
        const Padding(padding: EdgeInsets.only(bottom: 8), child: UsageAccessPrompt(compact: true)),
      for (final e in entries)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: _limitRow(e.key, e.value),
        ),
      OutlinedButton.icon(
        onPressed: () async {
          final r = await pickApps(context, title: 'কোন অ্যাপে লিমিট দেবেন?', multi: false);
          if (r == null || r.isEmpty || !mounted) return;
          await showLimitSheet(context, r.first, _name(r.first));
          if (mounted) setState(() {});
        },
        icon: const Icon(Icons.add),
        label: const Text('লিমিট যোগ করুন'),
      ),
    ]);
  }

  Widget _limitRow(String pkg, int min) {
    final cs = Theme.of(context).colorScheme;
    final used = st?.todayOf(pkg) ?? 0;
    final lim = min * 60000;
    final p = lim == 0 ? 1.0 : (used / lim).clamp(0.0, 1.0).toDouble();
    final over = used >= lim;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () async {
        await showLimitSheet(context, pkg, _name(pkg));
        if (mounted) setState(() {});
      },
      child: AppCard(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          AppIcon(pkg, size: 38),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                    child: Text(_name(pkg),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600))),
                Text(over ? 'শেষ' : '${fmtDur(lim - used)} বাকি',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, color: over ? cs.error : cs.primary)),
              ]),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: p),
                  duration: const Duration(milliseconds: 700),
                  builder: (_, v, __) => LinearProgressIndicator(
                      value: v, minHeight: 8, color: over ? cs.error : const Color(0xFF22C55E)),
                ),
              ),
              const SizedBox(height: 3),
              Text('আজ ${fmtDur(used)} / ${fmtDur(lim)}',
                  style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ]),
      ),
    );
  }

  // ---------- ঘুম ----------

  Future<void> _pickSleep() async {
    if (!await Lock.ask(context, reason: 'ঘুমের সময় বদলাতে যাচাই করুন')) return;
    if (!mounted) return;
    final c = store.cfg;
    final s = await showTimePicker(
        context: context,
        helpText: 'ঘুমানোর সময়',
        initialTime: TimeOfDay(hour: c.schStart ~/ 60, minute: c.schStart % 60));
    if (s == null || !mounted) return;
    final e = await showTimePicker(
        context: context,
        helpText: 'ওঠার সময়',
        initialTime: TimeOfDay(hour: c.schEnd ~/ 60, minute: c.schEnd % 60));
    if (e == null) return;
    c.schStart = s.hour * 60 + s.minute;
    c.schEnd = e.hour * 60 + e.minute;
    await store.save();
    await _load();
  }

  Widget _sleep() {
    final c = store.cfg;
    final d = st;
    Widget report = const SizedBox.shrink();
    if (has == false) {
      report = const UsageAccessPrompt(compact: true);
    } else if (d != null) {
      final last = d.days - 2; // গত রাত (গতকাল শুরু)
      final ms = d.night[last];
      final until = d.nightLast[last];
      final labels = <String>[];
      for (var i = d.days - 7; i < d.days; i++) {
        labels.add(weekdayNames[DateTime.fromMillisecondsSinceEpoch(d.starts[i]).weekday - 1]);
      }
      final String msg = ms >= 5 * 60000 && until > 0
          ? 'গত রাতে ${fmtClock(until)} পর্যন্ত ফোন চালিয়েছেন (মোট ${fmtDur(ms)})'
          : 'গত রাতে ঘুমের সময় ফোন প্রায় ব্যবহার করেননি 🎉';
      report = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 12),
        Text(msg, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        BarChart(
          values: d.night.sublist(d.days - 7),
          labels: labels,
          selected: 5, // গত রাত
          color: const Color(0xFF6366F1),
        ),
        Text('প্রতিটা বার = ওই দিনে শুরু হওয়া রাতে ফোন চালানোর সময়',
            style: Theme.of(context).textTheme.bodySmall),
      ]);
    }
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bedtime_outlined),
          const SizedBox(width: 10),
          Expanded(
              child: Text('${fmtMin(c.schStart)} – ${fmtMin(c.schEnd)}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
          TextButton(onPressed: _pickSleep, child: const Text('বদলান')),
        ]),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('এই সময়ে ইন্টারনেটও বন্ধ'),
          subtitle: const Text('আগের শিডিউলের সাথে একই (ফায়ারওয়াল চালু থাকলে)'),
          value: c.scheduleEnabled,
          onChanged: (v) async {
            if (!v && !await Lock.ask(context, reason: 'শিডিউল বন্ধ করতে যাচাই করুন')) return;
            c.scheduleEnabled = v;
            await store.save();
            if (mounted) setState(() {});
          },
        ),
        report,
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final f = info;
    return Scaffold(
      appBar: AppBar(
        title: const Text('ফোকাস'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load), ...shellActions(context)],
      ),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: Centered(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _focusCard(f),
                    _limits(),
                    DataLimitSection(running: running, hasUsage: has == true),
                    const SectionLabel('ঘুমের সময় ও রিপোর্ট'),
                    _sleep(),
                  ],
                ),
              ),
            ),
    );
  }
}
