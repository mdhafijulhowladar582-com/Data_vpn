import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';
import '../widgets/shell_actions.dart';

class DataTab extends StatefulWidget {
  const DataTab({super.key});

  @override
  State<DataTab> createState() => _DataTabState();
}

class _DataTabState extends State<DataTab> with WidgetsBindingObserver {
  bool? has;
  bool loading = false;
  int range = 0;
  List<UsageEntry> data = [];
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load(); // অনুমতি দিয়ে ফিরলে
  }

  Future<void> _load() async {
    final h = await VpnChannel.hasUsageAccess();
    if (!mounted) return;
    if (!h) {
      setState(() => has = false);
      return;
    }
    setState(() {
      has = true;
      loading = true;
    });
    final apps = await store.loadApps();
    final d = await UsageService.fetch(range);
    if (!mounted) return;
    setState(() {
      names = {for (final a in apps) a.pkg: a.name};
      data = d;
      loading = false;
    });
  }

  Widget _noAccess(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget step(int n, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 12, child: Text('$n', style: const TextStyle(fontSize: 12))),
            const SizedBox(width: 12),
            Expanded(child: Text(t)),
          ]),
        );
    return Centered(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const SizedBox(height: 12),
        Icon(Icons.data_usage_rounded, size: 64, color: cs.primary),
        const SizedBox(height: 12),
        const Text('কে কত ডেটা খেল দেখতে অনুমতি লাগবে',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('সুইচ ধূসর হয়ে থাকলে (Restricted Setting):',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            step(1, 'নিচের "অ্যাপ সেটিংস খুলুন" বাটনে চাপুন'),
            step(2, 'উপরে ডানে ⋮ (তিন ডট) চাপুন'),
            step(3, '"Allow restricted settings" চাপুন, তারপর PIN/ফিঙ্গারপ্রিন্ট দিন'),
            step(4, 'ফিরে এসে "Usage access" খুলে Firewall চালু করুন'),
          ]),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
            onPressed: VpnChannel.openAppSettings,
            icon: const Icon(Icons.settings),
            label: const Text('অ্যাপ সেটিংস খুলুন')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
            onPressed: VpnChannel.openUsageAccess,
            icon: const Icon(Icons.key),
            label: const Text('Usage access খুলুন')),
      ]),
    );
  }

  Widget _total(BuildContext context, int wifi, int mob) {
    final cs = Theme.of(context).colorScheme;
    final total = wifi + mob;
    Widget leg(Color c, IconData i, String l, int v) => Expanded(
          child: Row(children: [
            Container(
                width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
            const SizedBox(width: 6),
            Icon(i, size: 16),
            const SizedBox(width: 4),
            Flexible(
                child: Text('$l ${UsageService.fmt(v)}',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12))),
          ]),
        );
    return AppCard(
      child: Column(children: [
        Text('মোট ${UsageService.fmt(total)}',
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            height: 12,
            child: total == 0
                ? ColoredBox(color: cs.outlineVariant)
                : Row(children: [
                    if (wifi > 0) Expanded(flex: wifi, child: ColoredBox(color: cs.primary)),
                    if (mob > 0) Expanded(flex: mob, child: ColoredBox(color: cs.tertiary)),
                  ]),
          ),
        ),
        const SizedBox(height: 12),
        Row(children: [
          leg(cs.primary, Icons.wifi, 'Wi-Fi', wifi),
          leg(cs.tertiary, Icons.signal_cellular_alt, 'ডেটা', mob),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (has == false) {
      return Scaffold(
          appBar: AppBar(title: const Text('ডেটা ব্যবহার'), actions: shellActions(context)),
          body: _noAccess(context));
    }
    if (has == null) {
      return Scaffold(
          appBar: AppBar(title: const Text('ডেটা ব্যবহার'), actions: shellActions(context)),
          body: const Center(child: CircularProgressIndicator()));
    }

    final wifi = data.fold<int>(0, (a, e) => a + e.wifi);
    final mob = data.fold<int>(0, (a, e) => a + e.mobile);
    final maxT = data.isEmpty ? 1 : data.first.total;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ডেটা ব্যবহার'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load), ...shellActions(context)],
      ),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('আজ')),
                ButtonSegment(value: 1, label: Text('৭ দিন')),
                ButtonSegment(value: 2, label: Text('৩০ দিন')),
              ],
              selected: {range},
              onSelectionChanged: (s) {
                setState(() => range = s.first);
                _load();
              },
            ),
            const SizedBox(height: 12),
            _total(context, wifi, mob),
            const SectionLabel('টপ অ্যাপ'),
            if (loading)
              const Padding(
                  padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
            else if (data.isEmpty)
              const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: Text('এই সময়ে কোনো ডেটা ব্যবহার নেই')))
            else
              for (final e in data)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: AppCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      AppIcon(e.pkg, size: 36),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Expanded(
                                child: Text(names[e.pkg] ?? e.pkg,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w600))),
                            Text(UsageService.fmt(e.total),
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                          ]),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                                value: e.total / maxT, minHeight: 6, color: cs.primary),
                          ),
                          const SizedBox(height: 4),
                          Text(
                              'Wi-Fi ${UsageService.fmt(e.wifi)} • ডেটা ${UsageService.fmt(e.mobile)}',
                              style: Theme.of(context).textTheme.bodySmall),
                        ]),
                      ),
                    ]),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}
