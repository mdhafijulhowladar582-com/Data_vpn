import 'dart:async';
import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';
import '../widgets/shell_actions.dart';

class AppsTab extends StatefulWidget {
  const AppsTab({super.key});

  @override
  State<AppsTab> createState() => _AppsTabState();
}

class _AppsTabState extends State<AppsTab> {
  List<AppInfo> apps = [];
  bool loading = true;
  String q = '';
  int filter = 0; // 0 সব, 1 ইউজার, 2 সিস্টেম, 3 বন্ধ করা
  int sort = 0; // 0 নাম, 1 বেশি ডেটা খরচ
  Map<String, int> usage = {};

  // সুইচ ধরার পর অ্যাপ সাথে সাথে লাফিয়ে সরে না, ~১ সেকেন্ড পর সরে
  // (যাতে পরপর অনেকগুলো সুইচ চাপা যায়)
  final Map<String, bool> _disp = {}; // pkg -> যে ভাগে এখন দেখানো হচ্ছে (true = ব্লক)
  String _dispMode = '';
  Timer? _settle;

  @override
  void dispose() {
    _settle?.cancel();
    super.dispose();
  }

  /// এই অ্যাপ এখন কোন ভাগে দেখাব
  bool _shownBlocked(AppInfo a) {
    final real = _blocked(a);
    final d = _disp[a.pkg];
    if (d == null) {
      _disp[a.pkg] = real;
      return real;
    }
    return d;
  }

  void _syncSettle(List<AppInfo> list) {
    if (_dispMode != store.cfg.mode) {
      // মোড বদলালে অর্থ পুরো বদলে যায়, দেরি ছাড়াই সাজাই
      _dispMode = store.cfg.mode;
      _disp.clear();
      return;
    }
    var lag = false;
    for (final a in list) {
      final d = _disp[a.pkg];
      if (d != null && d != _blocked(a)) {
        lag = true;
        break;
      }
    }
    if (lag) {
      _settle?.cancel();
      _settle = Timer(const Duration(milliseconds: 1000), () {
        if (mounted) setState(_disp.clear);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    store.loadApps().then((a) {
      if (mounted) {
        setState(() {
          apps = List.of(a);
          loading = false;
        });
      }
    });
  }

  Future<void> _setSort(int s) async {
    if (s == 1) {
      final has = await VpnChannel.hasUsageAccess();
      if (!has) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('আগে "ডেটা" ট্যাবে গিয়ে Usage access অনুমতি দিন')));
        }
        return;
      }
      final u = await UsageService.fetch(1);
      usage = {for (final e in u) e.pkg: e.total};
    }
    if (mounted) setState(() => sort = s);
  }

  bool _blocked(AppInfo a) => store.cfg.mode == 'whitelist'
      ? !store.cfg.allowed.contains(a.pkg)
      : store.ruleOf(a.pkg).any;

  List<AppInfo> _shown() {
    final l = apps.where((a) {
      if (store.cfg.hiddenApps.contains(a.pkg)) return false;
      final okF = filter == 0 ||
          (filter == 1 && !a.system) ||
          (filter == 2 && a.system) ||
          (filter == 3 && _blocked(a));
      final okQ = q.isEmpty || a.name.toLowerCase().contains(q) || a.pkg.contains(q);
      return okF && okQ;
    }).toList();
    if (sort == 1) {
      l.sort((a, b) => (usage[b.pkg] ?? 0).compareTo(usage[a.pkg] ?? 0));
    } else {
      l.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    }
    return l;
  }

  /// allow = true হলে ইন্টারনেট পাবে
  Future<void> _bulk(List<AppInfo> list, bool allow) async {
    if (allow && !await Lock.ask(context, reason: 'ব্লক তুলতে যাচাই করুন')) return;
    for (final a in list) {
      if (store.cfg.mode == 'whitelist') {
        store.setAllowed(a.pkg, allow);
      } else {
        store.setRule(a.pkg, wifi: !allow, mobile: !allow);
      }
    }
  }

  List<Widget> _section(BuildContext context, List<AppInfo> items, String title, IconData icon,
      Color color, bool wl, bool wide) {
    if (items.isEmpty) return const [];
    return [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
        sliver: SliverToBoxAdapter(
          child: Row(children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 8),
            Text('$title (${items.length})',
                style: TextStyle(fontWeight: FontWeight.w700, color: color)),
          ]),
        ),
      ),
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        sliver: SliverGrid(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: wide ? 2 : 1,
            mainAxisExtent: 84,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
          ),
          delegate: SliverChildBuilderDelegate(
            (c, i) {
              final a = items[i];
              // নতুন ভাগে ঢুকলে আস্তে ভেসে ওঠে
              return TweenAnimationBuilder<double>(
                key: ValueKey('${a.pkg}-$title'),
                tween: Tween(begin: 0.0, end: 1.0),
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOut,
                builder: (_, t, child) => Opacity(
                  opacity: t,
                  child: Transform.translate(offset: Offset(0, (1 - t) * 12), child: child),
                ),
                child: AppTile(
                  app: a,
                  rule: store.ruleOf(a.pkg),
                  whitelist: wl,
                  allowed: store.cfg.allowed.contains(a.pkg),
                  extra: _extra(a),
                  onWifi: (v) => _rule(a.pkg, wifi: !v),
                  onMobile: (v) => _rule(a.pkg, mobile: !v),
                  onAllow: (v) => _allow(a.pkg, v),
                ),
              );
            },
            childCount: items.length,
          ),
        ),
      ),
    ];
  }

  /// ব্লক তোলা (ইন্টারনেট দেওয়া) = ঢিলে করা, তাই লক থাকলে যাচাই
  Future<void> _rule(String pkg, {bool? wifi, bool? mobile}) async {
    final loosening = wifi == false || mobile == false;
    if (loosening && !await Lock.ask(context, reason: 'ব্লক তুলতে যাচাই করুন')) return;
    store.setRule(pkg, wifi: wifi, mobile: mobile);
  }

  Future<void> _allow(String pkg, bool v) async {
    if (v && !await Lock.ask(context, reason: 'ইন্টারনেট দিতে যাচাই করুন')) return;
    store.setAllowed(pkg, v);
  }

  String? _extra(AppInfo a) {
    final p = <String>[];
    if (sort == 1 && (usage[a.pkg] ?? 0) > 0) p.add(UsageService.fmt(usage[a.pkg]!));
    final lim = store.cfg.limits[a.pkg];
    if (lim != null) p.add('⏱ লিমিট $lim মি');
    return p.isEmpty ? null : p.join(' • ');
  }

  @override
  Widget build(BuildContext context) {
    final wide = isWide(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('অ্যাপস'),
        actions: [
          PopupMenuButton<int>(
            icon: const Icon(Icons.sort),
            tooltip: 'সাজান',
            onSelected: _setSort,
            itemBuilder: (_) => [
              CheckedPopupMenuItem(value: 0, checked: sort == 0, child: const Text('নাম অনুযায়ী')),
              CheckedPopupMenuItem(
                  value: 1, checked: sort == 1, child: const Text('বেশি ডেটা খরচ (৭ দিন)')),
            ],
          ),
          PopupMenuButton<int>(
            onSelected: (v) => _bulk(_shown(), v == 1),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 0, child: Text('দেখানো সব ব্লক')),
              PopupMenuItem(value: 1, child: Text('দেখানো সবাইকে ইন্টারনেট দিন')),
            ],
          ),
          ...shellActions(context),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: TextField(
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'অ্যাপ খুঁজুন',
                      filled: true,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(28),
                          borderSide: BorderSide.none),
                    ),
                    onChanged: (v) => setState(() => q = v.toLowerCase()),
                  ),
                ),
                SizedBox(
                  height: 52,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    children: [
                      for (final e in {0: 'সব', 1: 'ইউজার', 2: 'সিস্টেম', 3: 'বন্ধ করা'}.entries)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(e.value),
                            selected: filter == e.key,
                            onSelected: (_) => setState(() => filter = e.key),
                          ),
                        ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListenableBuilder(
                    listenable: store,
                    builder: (context, _) {
                      final wl = store.cfg.mode == 'whitelist';
                      final list = _shown();
                      _syncSettle(list);
                      final on = list.where((a) => !_shownBlocked(a)).toList();
                      final off = list.where(_shownBlocked).toList();
                      return Column(children: [
                        if (store.cfg.blockAll)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                            child: AppCard(
                              color: Theme.of(context).colorScheme.errorContainer,
                              padding: const EdgeInsets.all(12),
                              child: Row(children: [
                                Icon(Icons.warning_amber,
                                    color: Theme.of(context).colorScheme.onErrorContainer),
                                const SizedBox(width: 10),
                                Expanded(
                                    child: Text(
                                        '"সব ব্লক" চালু আছে, তাই নিচের সুইচ এখন কাজ করছে না',
                                        style: TextStyle(
                                            fontSize: 12,
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onErrorContainer))),
                              ]),
                            ),
                          ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 6),
                          child: Row(children: [
                            Text('${list.length}টি অ্যাপ',
                                style: Theme.of(context).textTheme.bodySmall),
                            const Spacer(),
                            Text(
                                wl
                                    ? 'সুইচ চালু = ইন্টারনেট পাবে'
                                    : 'সুইচ চালু = ইন্টারনেট পাবে • বন্ধ = ব্লক',
                                style: Theme.of(context).textTheme.bodySmall),
                          ]),
                        ),
                        Expanded(
                          child: CustomScrollView(slivers: [
                            ..._section(context, on, 'ইন্টারনেট পাচ্ছে', Icons.public,
                                const Color(0xFF22C55E), wl, wide),
                            ..._section(context, off, 'ব্লক করা', Icons.block,
                                Theme.of(context).colorScheme.error, wl, wide),
                            const SliverToBoxAdapter(child: SizedBox(height: 16)),
                          ]),
                        ),
                      ]);
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
