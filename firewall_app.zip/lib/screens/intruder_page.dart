import 'dart:io';
import 'package:flutter/material.dart';
import '../services/lock_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';

/// ভুল পিনের ইতিহাস: কতবার, কখন, কোন স্ক্রিনে ভুল হলো, আর চোরের ছবি।
/// ছবি ভল্টে এনক্রিপ্ট থাকে, এখানে দেখানোর সময় অস্থায়ী কপি বানিয়ে দেখায় (পেজ বন্ধ হলে মুছে যায়)।
class IntruderPage extends StatefulWidget {
  const IntruderPage({super.key});

  @override
  State<IntruderPage> createState() => _IntruderPageState();
}

class _IntruderPageState extends State<IntruderPage> {
  List<Map<String, dynamic>>? items;
  final Map<String, Future<String?>> _photos = {};

  @override
  void initState() {
    super.initState();
    VpnChannel.setSecure(true); // স্ক্রিনশট ও Recent প্রিভিউ ফাঁকা
    _load();
  }

  @override
  void dispose() {
    VpnChannel.setSecure(false);
    VpnChannel.vaultClean().catchError((_) {});
    super.dispose();
  }

  Future<void> _load() async {
    List<Map<String, dynamic>> l;
    try {
      l = await VpnChannel.intruderList();
    } catch (_) {
      l = [];
    }
    if (!mounted) return;
    setState(() => items = l);
  }

  String _when(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String t(int n) => n.toString().padLeft(2, '0');
    return '${t(d.day)}/${t(d.month)}/${d.year}  ${t(d.hour)}:${t(d.minute)}:${t(d.second)}';
  }

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সব মুছবেন?'),
        content: const Text('ইতিহাস আর ভল্টে রাখা চোরের সব ছবি চিরতরে মুছে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (!await Lock.ask(context, reason: 'ইতিহাস মুছতে যাচাই করুন', force: true)) return;
    try {
      await VpnChannel.intruderClear();
    } catch (_) {}
    _photos.clear();
    await _load();
  }

  void _zoom(String path) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.all(8),
        child: InteractiveViewer(child: Image.file(File(path), fit: BoxFit.contain)),
      ),
    );
  }

  Widget _photo(String vid) {
    final f = _photos.putIfAbsent(vid, () => VpnChannel.intruderPhoto(vid));
    return FutureBuilder<String?>(
      future: f,
      builder: (ctx, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const SizedBox(height: 120, child: Center(child: CircularProgressIndicator()));
        }
        final path = snap.data;
        if (path == null) {
          return const Padding(
              padding: EdgeInsets.symmetric(vertical: 12), child: Text('ছবি খোলা যায়নি'));
        }
        return GestureDetector(
          onTap: () => _zoom(path),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(File(path),
                height: 240,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12), child: Text('ছবি খোলা যায়নি'))),
          ),
        );
      },
    );
  }

  Widget _card(Map<String, dynamic> e) {
    final t = (e['t'] as num?)?.toInt() ?? 0;
    final n = (e['n'] as num?)?.toInt() ?? 0;
    final where = (e['where'] as String?) ?? '';
    final vid = (e['vid'] as String?) ?? '';
    final photo = e['photo'] == true && vid.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(photo ? Icons.photo_camera_outlined : Icons.lock_outline, size: 20),
            const SizedBox(width: 8),
            Expanded(
                child: Text('পরপর $n নম্বর ভুল',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15))),
          ]),
          const SizedBox(height: 4),
          Text(_when(t), style: Theme.of(context).textTheme.bodySmall),
          if (where.isNotEmpty) Text('কোথায়: $where', style: Theme.of(context).textTheme.bodySmall),
          if (photo) ...[const SizedBox(height: 8), _photo(vid)],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = items;
    final photos = l == null ? 0 : l.where((e) => e['photo'] == true).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('ভুল পিনের ইতিহাস'),
        actions: [
          if (l != null && l.isNotEmpty)
            IconButton(tooltip: 'সব মুছুন', onPressed: _clear, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: l == null
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.all(16), children: [
                if (l.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 40),
                    child: Center(child: Text('এখনো কেউ ভুল পিন দেয়নি।')),
                  )
                else ...[
                  Text('মোট ${l.length}টি ভুল পিন, $photosটি ছবি',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  for (final e in l) _card(e),
                ],
                const SizedBox(height: 8),
                Text(
                    'সঠিক পিন দিলে গোনা শূন্য হয়, কিন্তু এই ইতিহাস থেকে যায়। ছবি শুধু তখনই ওঠে যখন "চোরের ছবি" সুইচ চালু, ক্যামেরার অনুমতি দেওয়া, আর ভুলটা ৩, ৬, ৯... নম্বর।',
                    style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
    );
  }
}
