import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';
import '../services/lock_service.dart';
import 'app_lock_page.dart';
import 'vault_page.dart';

String fmtMin(int m) =>
    '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Future<void> _setPin(BuildContext context) async {
    // আগে থেকে পিন থাকলে পুরনোটা যাচাই
    if (!await Lock.ask(context, reason: 'পিন বদলাতে যাচাই করুন')) return;
    if (!context.mounted) return;
    final c = TextEditingController();
    final c2 = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('নতুন পিন (কমপক্ষে ৪ সংখ্যা)'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: c,
              obscureText: true,
              autofocus: true,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'নতুন পিন')),
          TextField(
              controller: c2,
              obscureText: true,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'আবার লিখুন')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('সেভ')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    if (c.text.length < 4 || c.text != c2.text) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('পিন কমপক্ষে ৪ সংখ্যা ও দুইবার একই হতে হবে')));
      return;
    }
    store.cfg.pinHash = hashPin(c.text);
    await store.save();
    Lock.grace();
  }

  Future<void> _removePin(BuildContext context) async {
    if (!await Lock.ask(context, reason: 'পিন বাদ দিতে যাচাই করুন')) return;
    store.cfg.pinHash = '';
    store.cfg.bio = false;
    await store.save();
  }

  Future<void> _toggleBio(BuildContext context, bool v) async {
    if (!v) {
      if (!await Lock.ask(context, reason: 'ফিঙ্গারপ্রিন্ট বন্ধ করতে যাচাই করুন')) return;
      store.cfg.bio = false;
      await store.save();
      return;
    }
    final ok = await Lock.bioAvailable() && await Lock.bioRaw('ফিঙ্গারপ্রিন্ট চালু করতে স্পর্শ করুন');
    if (!context.mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('ফিঙ্গারপ্রিন্ট পাওয়া যায়নি, ফোনের সেটিংসে আগে ফিঙ্গারপ্রিন্ট যোগ করুন')));
      return;
    }
    store.cfg.bio = true;
    await store.save();
  }

  /// ঢিলে করার কাজে (বন্ধ/সময় বদল) যাচাই
  Future<bool> _ok(BuildContext context) => Lock.ask(context, reason: 'সেটিংস বদলাতে যাচাই করুন');

  Future<void> _pickTime(BuildContext context, bool start) async {
    if (!await Lock.ask(context, reason: 'শিডিউল বদলাতে যাচাই করুন')) return;
    if (!context.mounted) return;
    final cur = start ? store.cfg.schStart : store.cfg.schEnd;
    final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    final m = t.hour * 60 + t.minute;
    if (start) {
      store.cfg.schStart = m;
    } else {
      store.cfg.schEnd = m;
    }
    await store.save();
  }

  Widget _group(List<Widget> children) => AppCard(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final c = store.cfg;
          return Centered(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const SectionLabel('শিডিউল'),
                _group([
                  SwitchListTile(
                    title: const Text('শিডিউল চালু'),
                    subtitle: const Text('এই সময়ে সব অ্যাপ ব্লক (ফায়ারওয়াল চালু থাকলে)'),
                    value: c.scheduleEnabled,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.scheduleEnabled = v;
                      store.save();
                    },
                  ),
                  ListTile(
                    enabled: c.scheduleEnabled,
                    leading: const Icon(Icons.bedtime_outlined),
                    title: const Text('শুরু'),
                    trailing: Text(fmtMin(c.schStart), style: const TextStyle(fontSize: 18)),
                    onTap: () => _pickTime(context, true),
                  ),
                  ListTile(
                    enabled: c.scheduleEnabled,
                    leading: const Icon(Icons.wb_sunny_outlined),
                    title: const Text('শেষ'),
                    trailing: Text(fmtMin(c.schEnd), style: const TextStyle(fontSize: 18)),
                    onTap: () => _pickTime(context, false),
                  ),
                ]),
                const SectionLabel('ব্লকিং'),
                _group([
                  SwitchListTile(
                    title: const Text('স্ক্রিন বন্ধ হলে সব ব্লক'),
                    subtitle: const Text('সাবধান: স্ক্রিন অফে মেসেজ/অ্যালার্ট নেটও বন্ধ'),
                    value: c.screenOffBlock,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.screenOffBlock = v;
                      store.save();
                    },
                  ),
                  SwitchListTile(
                    title: const Text('নতুন অ্যাপ ইনস্টল হলে ডিফল্টে ব্লক'),
                    subtitle: const Text('ব্লকলিস্ট মোডে কাজ করে (হোয়াইটলিস্টে এমনিতেই ব্লক)'),
                    value: c.blockNew,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.blockNew = v;
                      store.save();
                    },
                  ),
                ]),
                const SectionLabel('নিরাপত্তা'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: Text(c.pinHash.isEmpty ? 'অ্যাপ লক (পিন) সেট করুন' : 'পিন বদলান'),
                    onTap: () => _setPin(context),
                    trailing: c.pinHash.isEmpty
                        ? const Icon(Icons.chevron_right)
                        : TextButton(
                            onPressed: () => _removePin(context),
                            child: const Text('পিন বাদ')),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.fingerprint),
                    title: const Text('ফিঙ্গারপ্রিন্ট দিয়ে খুলুন'),
                    subtitle: Text(c.pinHash.isEmpty
                        ? 'আগে পিন সেট করুন (পিন ফলব্যাক হিসেবে থাকবে)'
                        : 'ভুলে গেলে পিন দিয়েও খোলা যাবে'),
                    value: c.bio && c.pinHash.isNotEmpty,
                    onChanged: c.pinHash.isEmpty ? null : (v) => _toggleBio(context, v),
                  ),
                ]),
                const SectionLabel('থিম'),
                AppCard(
                  child: SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(
                            value: 'system',
                            icon: Icon(Icons.brightness_auto),
                            label: Text('সিস্টেম')),
                        ButtonSegment(
                            value: 'light',
                            icon: Icon(Icons.light_mode_outlined),
                            label: Text('লাইট')),
                        ButtonSegment(
                            value: 'dark',
                            icon: Icon(Icons.dark_mode_outlined),
                            label: Text('ডার্ক')),
                      ],
                      selected: {c.theme},
                      onSelectionChanged: (s) {
                        c.theme = s.first;
                        store.save();
                      },
                    ),
                  ),
                ),
                const SectionLabel('অ্যাপ গার্ড'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.lock_person_outlined),
                    title: const Text('অ্যাপ লক'),
                    subtitle: Text(
                        '${c.lockedApps.length}টি লক, ${c.hiddenApps.length}টি আড়াল'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const AppLockPage())),
                  ),
                  ListTile(
                    leading: const Icon(Icons.enhanced_encryption_outlined),
                    title: const Text('ফাইল ভল্ট'),
                    subtitle: const Text('ফাইল এনক্রিপ্ট করে লুকিয়ে রাখুন'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      if (!Lock.hasPin) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('আগে এখানে পিন দিন, তারপর ভল্ট খুলবে')));
                        return;
                      }
                      if (!await Lock.ask(context, reason: 'ভল্ট খুলতে যাচাই করুন')) return;
                      if (!context.mounted) return;
                      Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => const VaultPage()));
                    },
                  ),
                ]),
                const SectionLabel('পারমিশন শর্টকাট'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.data_usage),
                    title: const Text('Usage access'),
                    subtitle: const Text('কে কত ডেটা খেল দেখার জন্য'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: VpnChannel.openUsageAccess,
                  ),
                  ListTile(
                    leading: const Icon(Icons.settings_applications_outlined),
                    title: const Text('অ্যাপ সেটিংস'),
                    subtitle: const Text('Restricted settings ছাড়ানোর জন্য'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: VpnChannel.openAppSettings,
                  ),
                ]),
              ],
            ),
          );
        },
      ),
    );
  }
}
