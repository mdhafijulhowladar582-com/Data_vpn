import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/rule.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';
import '../services/lock_service.dart';
import '../widgets/app_picker.dart';
import 'app_lock_page.dart';
import 'engine_page.dart';
import 'private_dns_page.dart';
import 'report_page.dart';
import 'safety_page.dart';
import 'vault_page.dart';

/// সেটিংস ও আনইনস্টলের স্ক্রিন: এগুলো পিন দিয়ে লক থাকলে ফায়ারওয়াল বন্ধ বা মুছে ফেলা কঠিন
const _protectPkgs = [
  'com.android.settings',
  'com.android.packageinstaller',
  'com.google.android.packageinstaller',
  'com.samsung.android.packageinstaller',
  'com.miui.packageinstaller',
];

String fmtMin(int m) =>
    '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Future<void> _setPin(BuildContext context) async {
    await setPinFlow(context);
  }

  Future<void> _removePin(BuildContext context) async {
    if (!await Lock.ask(context, reason: 'পিন বাদ দিতে যাচাই করুন')) return;
    try {
      await VpnChannel.guestSet(false); // পিন ছাড়া গেস্ট মোড থেকে বেরোনো যায় না
    } catch (_) {}
    store.cfg.pinHash = '';
    store.cfg.decoyHash = '';
    store.cfg.bio = false;
    await store.save();
  }

  Future<void> _toggleBio(BuildContext context, bool v) async {
    if (!v) {
      if (!await Lock.ask(context, reason: 'ফিঙ্গারপ্রিন্ট বন্ধ করতে যাচাই করুন')) return;
      store.cfg.bio = false;
      await store.save();
      return;
    }
    final ok = await Lock.bioAvailable() && await Lock.bioRaw('ফিঙ্গারপ্রিন্ট চালু করতে স্পর্শ করুন');
    if (!context.mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('ফিঙ্গারপ্রিন্ট পাওয়া যায়নি, ফোনের সেটিংসে আগে ফিঙ্গারপ্রিন্ট যোগ করুন')));
      return;
    }
    store.cfg.bio = true;
    await store.save();
  }

  /// ঢিলে করার কাজে (বন্ধ/সময় বদল) যাচাই
  /// সব নিয়ম একটা ফাইলে সেভ। পিনের হ্যাশ ফাইলে যায় না (ফাইল হারালেও পিন নিরাপদ)
  Future<void> _backup(BuildContext context) async {
    final m = store.cfg.toJson();
    for (final k in ['pinHash', 'decoyHash', 'bio', 'enabled', 'focusUntil']) {
      m.remove(k);
    }
    final name = 'firewall_backup_${DateTime.now().toIso8601String().substring(0, 10)}.json';
    final ok = await VpnChannel.backupExport(jsonEncode({'app': 'firewall', 'v': 1, 'cfg': m}), name);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(ok ? 'ব্যাকআপ সেভ হয়েছে' : 'ব্যাকআপ সেভ হয়নি')));
  }

  Future<void> _restore(BuildContext context) async {
    if (!await Lock.ask(context, reason: 'ব্যাকআপ ফেরাতে যাচাই করুন')) return;
    final s = await VpnChannel.backupImport();
    if (!context.mounted || s == null) return;
    Config n;
    try {
      final j = jsonDecode(s) as Map<String, dynamic>;
      if (j['app'] != 'firewall' || j['cfg'] is! Map) throw const FormatException('bad');
      n = Config.fromJson(Map<String, dynamic>.from(j['cfg'] as Map));
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('এটা ফায়ারওয়ালের ব্যাকআপ ফাইল না')));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ব্যাকআপ ফেরাবেন?'),
        content: const Text('এখনকার সব নিয়ম মুছে ব্যাকআপের নিয়ম বসবে। পিন আগের মতোই থাকবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ফেরান')),
        ],
      ),
    );
    if (ok != true) return;
    final o = store.cfg;
    n.pinHash = o.pinHash;
    n.decoyHash = o.decoyHash;
    n.bio = o.bio;
    n.enabled = o.enabled;
    n.focusUntil = o.focusUntil;
    store.cfg = n;
    await store.save();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ব্যাকআপ ফেরানো হয়েছে')));
  }

  Future<void> _protect(BuildContext context, bool v) async {
    final c = store.cfg;
    final msg = ScaffoldMessenger.of(context);
    if (!Lock.hasPin) {
      msg.showSnackBar(const SnackBar(content: Text('আগে এখানে পিন দিন, তারপর এটা চালু হবে')));
      return;
    }
    if (!v && !await Lock.ask(context, reason: 'সুরক্ষা বন্ধ করতে যাচাই করুন')) return;
    final have = (await store.loadApps()).map((a) => a.pkg).toSet();
    final pk = _protectPkgs.where(have.contains);
    if (v) {
      c.lockedApps = {...c.lockedApps, ...pk};
    } else {
      c.lockedApps = c.lockedApps.where((p) => !_protectPkgs.contains(p)).toSet();
    }
    store.save();
    if (v && !await VpnChannel.isGuardEnabled()) {
      msg.showSnackBar(const SnackBar(
          content: Text('অ্যাপ গার্ড (Accessibility) চালু না থাকলে এই লক কাজ করবে না')));
    }
  }

  Future<bool> _ok(BuildContext context) => Lock.ask(context, reason: 'সেটিংস বদলাতে যাচাই করুন');

  Future<void> _pickTime(BuildContext context, bool start) async {
    if (!await Lock.ask(context, reason: 'শিডিউল বদলাতে যাচাই করুন')) return;
    if (!context.mounted) return;
    final cur = start ? store.cfg.schStart : store.cfg.schEnd;
    final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null) return;
    final m = t.hour * 60 + t.minute;
    if (start) {
      store.cfg.schStart = m;
    } else {
      store.cfg.schEnd = m;
    }
    await store.save();
  }

  Widget _group(List<Widget> children) => AppCard(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final c = store.cfg;
          return Centered(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                const SectionLabel('শিডিউল'),
                _group([
                  SwitchListTile(
                    title: const Text('শিডিউল চালু'),
                    subtitle: const Text('এই সময়ে সব অ্যাপ ব্লক (ফায়ারওয়াল চালু থাকলে)'),
                    value: c.scheduleEnabled,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.scheduleEnabled = v;
                      store.save();
                    },
                  ),
                  ListTile(
                    enabled: c.scheduleEnabled,
                    leading: const Icon(Icons.bedtime_outlined),
                    title: const Text('শুরু'),
                    trailing: Text(fmtMin(c.schStart), style: const TextStyle(fontSize: 18)),
                    onTap: () => _pickTime(context, true),
                  ),
                  ListTile(
                    enabled: c.scheduleEnabled,
                    leading: const Icon(Icons.wb_sunny_outlined),
                    title: const Text('শেষ'),
                    trailing: Text(fmtMin(c.schEnd), style: const TextStyle(fontSize: 18)),
                    onTap: () => _pickTime(context, false),
                  ),
                ]),
                const SectionLabel('ব্লকিং'),
                _group([
                  SwitchListTile(
                    title: const Text('স্ক্রিন বন্ধ হলে সব ব্লক'),
                    subtitle: const Text('সাবধান: স্ক্রিন অফে মেসেজ/অ্যালার্ট নেটও বন্ধ'),
                    value: c.screenOffBlock,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.screenOffBlock = v;
                      store.save();
                    },
                  ),
                  SwitchListTile(
                    title: const Text('নতুন অ্যাপ ইনস্টল হলে ডিফল্টে ব্লক'),
                    subtitle: const Text('ব্লকলিস্ট মোডে কাজ করে (হোয়াইটলিস্টে এমনিতেই ব্লক)'),
                    value: c.blockNew,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.blockNew = v;
                      store.save();
                    },
                  ),
                ]),
                const SectionLabel('বিজ্ঞাপন ব্লক'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.dns_outlined),
                    title: const Text('প্রাইভেট DNS'),
                    subtitle: const Text('সব অ্যাপের বিজ্ঞাপন ও ট্র্যাকার আটকানোর গাইড'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const PrivateDnsPage())),
                  ),
                  ListTile(
                    leading: const Icon(Icons.shield_outlined),
                    title: const Text('নিজস্ব ইঞ্জিন'),
                    subtitle: Text(c.engineOn
                        ? 'চালু, ${c.engineApps.length}টি অ্যাপ'
                        : 'বাছা অ্যাপের বিজ্ঞাপন ডোমেইন আটকায় (বন্ধ)'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const EnginePage())),
                  ),
                ]),
                const SectionLabel('নিরাপত্তা'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: Text(c.pinHash.isEmpty ? 'অ্যাপ লক (পিন) সেট করুন' : 'পিন বদলান'),
                    onTap: () => _setPin(context),
                    trailing: c.pinHash.isEmpty
                        ? const Icon(Icons.chevron_right)
                        : TextButton(
                            onPressed: () => _removePin(context),
                            child: const Text('পিন বাদ')),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.fingerprint),
                    title: const Text('ফিঙ্গারপ্রিন্ট দিয়ে খুলুন'),
                    subtitle: Text(c.pinHash.isEmpty
                        ? 'আগে পিন সেট করুন (পিন ফলব্যাক হিসেবে থাকবে)'
                        : 'ভুলে গেলে পিন দিয়েও খোলা যাবে'),
                    value: c.bio && c.pinHash.isNotEmpty,
                    onChanged: c.pinHash.isEmpty ? null : (v) => _toggleBio(context, v),
                  ),
                ]),
                const SectionLabel('থিম'),
                AppCard(
                  child: SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(
                            value: 'system',
                            icon: Icon(Icons.brightness_auto),
                            label: Text('সিস্টেম')),
                        ButtonSegment(
                            value: 'light',
                            icon: Icon(Icons.light_mode_outlined),
                            label: Text('লাইট')),
                        ButtonSegment(
                            value: 'dark',
                            icon: Icon(Icons.dark_mode_outlined),
                            label: Text('ডার্ক')),
                      ],
                      selected: {c.theme},
                      onSelectionChanged: (s) {
                        c.theme = s.first;
                        store.save();
                      },
                    ),
                  ),
                ),
                const SectionLabel('নজরদারি'),
                _group([
                  SwitchListTile(
                    secondary: const Icon(Icons.speed),
                    title: const Text('নোটিফিকেশনে লাইভ স্পিড'),
                    subtitle: const Text('স্পিড আর আজকের ডেটা (আনুমানিক, স্ক্রিন চালু থাকলে)'),
                    value: c.liveStat,
                    onChanged: (v) {
                      c.liveStat = v;
                      store.save();
                    },
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.notifications_active_outlined),
                    title: const Text('সাপ্তাহিক রিপোর্টের নোটিফিকেশন'),
                    subtitle: const Text('প্রতি শুক্রবার রাত ৮টার পর একটা ছোট সারাংশ আসবে'),
                    value: c.weeklyOn,
                    onChanged: (v) {
                      c.weeklyOn = v;
                      store.save();
                    },
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.report_gmailerrorred_outlined),
                    title: const Text('সন্দেহজনক চেষ্টার সতর্কতা'),
                    subtitle: const Text(
                        'ব্লক অ্যাপ হঠাৎ আগের গড়ের ৫ গুণ (অন্তত ২০ বার) চেষ্টা করলে দিনে একবার জানাবে'),
                    value: c.anomalyOn,
                    onChanged: (v) {
                      c.anomalyOn = v;
                      store.save();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.bar_chart),
                    title: const Text('সাপ্তাহিক রিপোর্ট'),
                    subtitle: const Text('৭ দিনে কে কত ডেটা খেল, কে কতবার ব্লকে ঠেকল'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const ReportPage())),
                  ),
                ]),
                const SectionLabel('স্বয়ংক্রিয় নিয়ম'),
                _group([
                  SwitchListTile(
                    secondary: const Icon(Icons.wifi),
                    title: const Text('Wi-Fi-তে সব খোলা'),
                    subtitle: const Text(
                        'Wi-Fi-তে অ্যাপ-ভিত্তিক ব্লক চলবে না, মোবাইল ডেটায় আগের নিয়মই থাকবে (লিমিট আর মোড এর ব্যতিক্রম)'),
                    value: c.wifiOpen,
                    onChanged: (v) async {
                      if (v && !await _ok(context)) return; // ঢিলে করা
                      c.wifiOpen = v;
                      store.save();
                    },
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.public_off_outlined),
                    title: const Text('রোমিংয়ে ইন্টারনেট বন্ধ'),
                    subtitle: const Text(
                        'রোমিংয়ে মোবাইল ডেটা বন্ধ (জরুরি অ্যাপ ছাড়া)। Wi-Fi-তে কিছু হয় না'),
                    value: c.roamBlock,
                    onChanged: (v) async {
                      if (!v && !await _ok(context)) return;
                      c.roamBlock = v;
                      store.save();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.nights_stay_outlined),
                    title: const Text('ব্যাকগ্রাউন্ডে ইন্টারনেট বন্ধ'),
                    subtitle: Text(
                        '${c.bgBlock.length}টি অ্যাপ: খোলা না থাকলে নেট পাবে না (অ্যাপ গার্ড চালু থাকতে হবে)'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      final r = await pickApps(context,
                          title: 'ব্যাকগ্রাউন্ডে বন্ধ থাকবে যাদের', selected: c.bgBlock);
                      if (r == null || !context.mounted) return;
                      final next = r.toSet();
                      if (c.bgBlock.difference(next).isNotEmpty && !await _ok(context)) return;
                      c.bgBlock = next;
                      store.save();
                    },
                  ),
                ]),
                const SectionLabel('ইন্টারনেট বন্ধের খবর'),
                _group([
                  SwitchListTile(
                    secondary: const Icon(Icons.notifications_active_outlined),
                    title: const Text('ব্লক হলে জানান'),
                    subtitle: const Text(
                        'ব্লক থাকা অ্যাপ খুললে কারণ আর "১৫ মিনিট চালু" বোতাম দেখাবে (অ্যাপ গার্ড চালু থাকতে হবে)'),
                    value: c.noticeOn,
                    onChanged: (v) {
                      c.noticeOn = v;
                      store.save();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.health_and_safety_outlined),
                    title: const Text('জরুরি অ্যাপ'),
                    subtitle: Text(
                        'কখনো ব্লক হয় না: ${c.emergency.length}টি (ডায়ালার ও মেসেজ নিজে থেকেই)'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      final r = await pickApps(context,
                          title: 'জরুরি অ্যাপ (ব্যাংক, OTP)', selected: c.emergency);
                      if (r == null) return;
                      c.emergency = r.toSet();
                      store.save();
                    },
                  ),
                ]),
                const SectionLabel('অ্যাপ গার্ড'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.lock_person_outlined),
                    title: const Text('অ্যাপ লক'),
                    subtitle: Text(
                        '${c.lockedApps.length}টি লক, ${c.hiddenApps.length}টি আড়াল'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const AppLockPage())),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.shield_outlined),
                    title: const Text('ফায়ারওয়াল সুরক্ষা'),
                    subtitle: const Text(
                        'সেটিংস আর আনইনস্টল স্ক্রিন পিন দিয়ে লক। অন্য কেউ ফায়ারওয়াল বন্ধ বা মুছতে পারবে না (Wi-Fi সেটিংসেও পিন লাগবে)'),
                    value: c.lockedApps.contains('com.android.settings'),
                    onChanged: (v) => _protect(context, v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.enhanced_encryption_outlined),
                    title: const Text('ফাইল ভল্ট'),
                    subtitle: const Text('ফাইল এনক্রিপ্ট করে লুকিয়ে রাখুন'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      if (!Lock.hasPin) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('আগে এখানে পিন দিন, তারপর ভল্ট খুলবে')));
                        return;
                      }
                      if (await Lock.guestBlocks(context)) return;
                      if (!context.mounted) return;
                      final g = await Lock.gate(context, reason: 'ভল্ট খুলতে যাচাই করুন');
                      if (g == Gate.denied || !context.mounted) return;
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => VaultPage(decoy: g == Gate.decoy)));
                    },
                  ),
                ]),
                const SectionLabel('নিরাপত্তা সরঞ্জাম'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.crisis_alert_outlined),
                    title: const Text('প্যানিক, নজরদারি ও সতর্কতা'),
                    subtitle: const Text(
                        'প্যানিক বাটন, ভুলে যাওয়া অ্যাপ, স্ক্রিন বন্ধে ডেটা পাহারা, নতুন অ্যাপ ও নতুন পারমিশনের সতর্কতা'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const SafetyPage())),
                  ),
                ]),
                const SectionLabel('ব্যাকআপ'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.upload_file_outlined),
                    title: const Text('নিয়মগুলো ফাইলে সেভ করুন'),
                    subtitle: const Text('ব্লক, লিমিট, শিডিউল সব। ফোন রিসেট বা অ্যাপ মুছলেও ফিরে পাবেন'),
                    onTap: () => _backup(context),
                  ),
                  ListTile(
                    leading: const Icon(Icons.download_outlined),
                    title: const Text('ফাইল থেকে ফেরান'),
                    subtitle: const Text('আগে সেভ করা ব্যাকআপ ফাইল বাছুন'),
                    onTap: () => _restore(context),
                  ),
                ]),
                const SectionLabel('পারমিশন শর্টকাট'),
                _group([
                  ListTile(
                    leading: const Icon(Icons.data_usage),
                    title: const Text('Usage access'),
                    subtitle: const Text('কে কত ডেটা খেল দেখার জন্য'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: VpnChannel.openUsageAccess,
                  ),
                  ListTile(
                    leading: const Icon(Icons.settings_applications_outlined),
                    title: const Text('অ্যাপ সেটিংস'),
                    subtitle: const Text('Restricted settings ছাড়ানোর জন্য'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: VpnChannel.openAppSettings,
                  ),
                ]),
              ],
            ),
          );
        },
      ),
    );
  }
}
