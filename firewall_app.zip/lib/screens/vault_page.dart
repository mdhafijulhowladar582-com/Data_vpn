import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/lock_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';

/// ফাইল ভল্ট: ফাইল এনক্রিপ্ট (AES-256-GCM) হয়ে অ্যাপের ভেতরে থাকে।
/// চাবি Android Keystore-এ। ব্যাকআপ কী দিয়ে চাবি ফেরত আনা যায়।
class VaultPage extends StatefulWidget {
  const VaultPage({super.key});

  @override
  State<VaultPage> createState() => _VaultPageState();
}

class _VaultPageState extends State<VaultPage> with WidgetsBindingObserver {
  String? status; // null = লোড হচ্ছে
  List<Map<String, dynamic>> files = [];
  bool busy = false;
  bool delOrig = false;
  final _restore = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    VpnChannel.setSecure(true);
    VpnChannel.vaultClean();
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    VpnChannel.setSecure(false);
    VpnChannel.vaultClean();
    _restore.dispose();
    super.dispose();
  }

  /// অন্য অ্যাপ (ভিউয়ার) থেকে ফিরলে অস্থায়ী কপি মুছে ফেলি
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) VpnChannel.vaultClean();
  }

  Future<void> _load() async {
    final st = await VpnChannel.vaultStatus();
    final l = st == 'ready' ? await VpnChannel.vaultList() : <Map<String, dynamic>>[];
    if (!mounted) return;
    setState(() {
      status = st;
      files = l;
    });
  }

  void _snack(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    if (b < 1024 * 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
    return '${(b / 1073741824).toStringAsFixed(2)} GB';
  }

  String _date(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String t(int n) => n.toString().padLeft(2, '0');
    return '${t(d.day)}/${t(d.month)}/${d.year}';
  }

  IconData _icon(String mime) {
    if (mime.startsWith('image/')) return Icons.image_outlined;
    if (mime.startsWith('video/')) return Icons.movie_outlined;
    if (mime.startsWith('audio/')) return Icons.audiotrack_outlined;
    if (mime == 'application/pdf') return Icons.picture_as_pdf_outlined;
    return Icons.insert_drive_file_outlined;
  }

  // ---------- কাজ ----------

  Future<void> _add() async {
    setState(() => busy = true);
    Map<String, dynamic>? r;
    try {
      r = await VpnChannel.vaultPick(delOrig);
    } catch (_) {
      r = null;
    }
    if (!mounted) return;
    setState(() => busy = false);
    if (r == null) return;
    await _load();
    final added = (r['added'] as num?)?.toInt() ?? 0;
    final failed = (r['failed'] as num?)?.toInt() ?? 0;
    final deleted = (r['deleted'] as num?)?.toInt() ?? 0;
    var msg = '$addedটি ফাইল ভল্টে গেছে';
    if (failed > 0) msg += ', $failedটি ব্যর্থ';
    if (delOrig && added > deleted) {
      msg += '। মূল ফাইল মোছা যায়নি (${added - deleted}টি), নিজে মুছে ফেলুন';
    } else if (!delOrig && added > 0) {
      msg += '। মূল ফাইল এখনও আগের জায়গায় আছে';
    }
    _snack(msg);
  }

  Future<void> _openOrShare(Map<String, dynamic> f, {required bool share}) async {
    setState(() => busy = true);
    String r;
    try {
      final id = f['id'] as String;
      r = share ? await VpnChannel.vaultShare(id) : await VpnChannel.vaultOpen(id);
    } catch (_) {
      r = 'error';
    }
    if (!mounted) return;
    setState(() => busy = false);
    if (r == 'no_app') {
      _snack('এই ধরনের ফাইল খোলার অ্যাপ নেই। "সেভ / শেয়ার" চেষ্টা করুন');
    } else if (r != 'ok') {
      _snack('ফাইল খোলা যায়নি');
    }
  }

  Future<void> _delete(Map<String, dynamic> f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ভল্ট থেকে মুছবেন?'),
        content: Text('"${f['name']}" চিরতরে মুছে যাবে, ফেরত আনা যাবে না।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (!await Lock.ask(context, reason: 'ফাইল মুছতে যাচাই করুন')) return;
    final done = await VpnChannel.vaultDelete(f['id'] as String);
    await _load();
    _snack(done ? 'মুছে ফেলা হয়েছে' : 'মোছা যায়নি');
  }

  Future<void> _showBackupKey() async {
    if (!await Lock.ask(context, reason: 'ব্যাকআপ কী দেখতে যাচাই করুন')) return;
    final key = await VpnChannel.vaultBackupKey();
    if (!mounted) return;
    if (key.isEmpty) {
      _snack('কী পাওয়া যায়নি');
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ব্যাকআপ কী'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
              'এই কী দিয়ে ভল্টের সব ফাইল খোলা যায়। এটা নিরাপদ জায়গায় রাখুন (পাসওয়ার্ড ম্যানেজার বা কাগজে)। '
              'কারও হাতে গেলে সে আপনার ভল্ট খুলতে পারবে।',
              style: TextStyle(fontSize: 13)),
          const SizedBox(height: 12),
          SelectableText(key, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        ]),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: key));
              _snack('কপি হয়েছে। কাজ শেষে ক্লিপবোর্ড থেকে সরিয়ে দিন');
            },
            child: const Text('কপি'),
          ),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('বন্ধ')),
        ],
      ),
    );
  }

  Future<void> _restoreKey() async {
    final k = _restore.text.trim();
    if (k.isEmpty) return;
    setState(() => busy = true);
    final ok = await VpnChannel.vaultRestoreKey(k);
    if (!mounted) return;
    setState(() => busy = false);
    if (ok) {
      _restore.clear();
      _snack('কী ফেরত এসেছে');
      await _load();
    } else {
      _snack('কী ভুল, বা এই ভল্টের নয়');
    }
  }

  // ---------- UI ----------

  Widget _info() {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.shield_outlined, color: cs.primary),
          const SizedBox(width: 10),
          const Expanded(
              child: Text('ফাইল এনক্রিপ্ট হয়ে শুধু এই অ্যাপের ভেতরে থাকে। ফোনের ফাইল ম্যানেজারে দেখা যায় না।',
                  style: TextStyle(fontSize: 13))),
        ]),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: const Text('যোগ করার পর মূল ফাইল মুছুন'),
          subtitle: const Text('সব ফোনে কাজ নাও করতে পারে', style: TextStyle(fontSize: 11)),
          value: delOrig,
          onChanged: (v) => setState(() => delOrig = v),
        ),
      ]),
    );
  }

  Widget _tile(Map<String, dynamic> f) {
    final size = (f['size'] as num?)?.toInt() ?? 0;
    final added = (f['added'] as num?)?.toInt() ?? 0;
    return ListTile(
      leading: Icon(_icon((f['mime'] as String?) ?? '')),
      title: Text('${f['name']}', maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${_size(size)} · ${_date(added)}'),
      onTap: busy ? null : () => _openOrShare(f, share: false),
      trailing: PopupMenuButton<String>(
        onSelected: (v) {
          if (v == 'open') _openOrShare(f, share: false);
          if (v == 'share') _openOrShare(f, share: true);
          if (v == 'del') _delete(f);
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'open', child: Text('খুলুন')),
          PopupMenuItem(value: 'share', child: Text('সেভ / শেয়ার')),
          PopupMenuItem(value: 'del', child: Text('মুছুন')),
        ],
      ),
    );
  }

  Widget _restoreCard() {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      color: cs.errorContainer,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('ভল্টের চাবি পাওয়া যাচ্ছে না',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: cs.onErrorContainer)),
        const SizedBox(height: 8),
        Text(
            'ফোন বদলানো বা ব্যাকআপ থেকে রিস্টোরের পর এমন হতে পারে। আগে সেভ করা ব্যাকআপ কী (FVK1-...) এখানে দিন। '
            'কী না থাকলে এই ফাইলগুলো আর খোলা যাবে না।',
            style: TextStyle(fontSize: 13, color: cs.onErrorContainer)),
        const SizedBox(height: 12),
        TextField(
          controller: _restore,
          decoration: const InputDecoration(labelText: 'ব্যাকআপ কী', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        FilledButton(onPressed: busy ? null : _restoreKey, child: const Text('ফেরত আনুন')),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ready = status == 'ready';
    return Scaffold(
      appBar: AppBar(
        title: const Text('ফাইল ভল্ট'),
        actions: [
          if (ready)
            IconButton(
                tooltip: 'ব্যাকআপ কী',
                onPressed: busy ? null : _showBackupKey,
                icon: const Icon(Icons.key_outlined)),
        ],
        bottom: busy
            ? const PreferredSize(
                preferredSize: Size.fromHeight(3), child: LinearProgressIndicator(minHeight: 3))
            : null,
      ),
      floatingActionButton: ready
          ? FloatingActionButton.extended(
              onPressed: busy ? null : _add,
              icon: const Icon(Icons.add),
              label: const Text('ফাইল যোগ'),
            )
          : null,
      body: status == null
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
                children: [
                  if (status == 'unsupported')
                    const AppCard(child: Text('এই ফোনে (Android ৬-এর আগে) ভল্ট চলবে না।'))
                  else if (status == 'restore')
                    _restoreCard()
                  else ...[
                    _info(),
                    const SizedBox(height: 12),
                    if (files.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(child: Text('ভল্ট খালি। নিচের "ফাইল যোগ" চাপুন।')),
                      )
                    else
                      for (final f in files) _tile(f),
                  ],
                ],
              ),
            ),
    );
  }
}
