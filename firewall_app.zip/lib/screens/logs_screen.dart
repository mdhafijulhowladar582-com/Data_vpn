import 'package:flutter/material.dart';
import '../services/log_service.dart';
import '../services/rules_storage.dart';

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key});

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  List<LogEntry> logs = [];
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final apps = await store.loadApps();
    final l = await LogService.fetch();
    if (!mounted) return;
    setState(() {
      names = {for (final a in apps) a.pkg: a.name};
      logs = l;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  @override
  Widget build(BuildContext context) {
    final counts = <String, int>{};
    for (final e in logs) {
      counts[e.pkg] = (counts[e.pkg] ?? 0) + 1;
    }
    final top = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Scaffold(
      appBar: AppBar(
        title: Text('ব্লক লগ (${logs.length})'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              await LogService.clear();
              _load();
            },
          ),
        ],
      ),
      body: logs.isEmpty
          ? const Center(child: Text('এখনো কোনো ব্লক চেষ্টা নেই'))
          : Column(children: [
              Padding(
                padding: const EdgeInsets.all(8),
                child: Wrap(spacing: 6, runSpacing: 6, children: [
                  for (final e in top.take(6))
                    Chip(label: Text('${_name(e.key)}: ${e.value}')),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: logs.length,
                  itemBuilder: (c, i) {
                    final e = logs[i];
                    return ListTile(
                      dense: true,
                      title: Text(_name(e.pkg)),
                      subtitle: Text('${e.proto} → ${e.dst}'),
                      trailing: Text(LogService.hms(e.time)),
                    );
                  },
                ),
              ),
            ]),
    );
  }
}
