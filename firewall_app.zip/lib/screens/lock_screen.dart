import 'package:flutter/material.dart';
import '../services/rules_storage.dart';

String hashPin(String p) {
  var h = 7;
  for (final c in p.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return h.toString();
}

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _c = TextEditingController();
  bool _err = false;

  void _check() {
    if (hashPin(_c.text) == store.cfg.pinHash) {
      widget.onUnlock();
    } else {
      setState(() => _err = true);
      _c.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock, size: 64),
              const SizedBox(height: 24),
              TextField(
                controller: _c,
                obscureText: true,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                onSubmitted: (_) => _check(),
                decoration: InputDecoration(
                  labelText: 'পিন দিন',
                  errorText: _err ? 'ভুল পিন' : null,
                ),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _check, child: const Text('খুলুন')),
            ],
          ),
        ),
      ),
    );
  }
}
