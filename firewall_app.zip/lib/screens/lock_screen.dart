import 'package:flutter/material.dart';
import '../services/lock_service.dart';

export '../services/lock_service.dart' show hashPin;

class LockScreen extends StatelessWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: PinEntry(
                reason: 'অ্যাপ খুলতে যাচাই করুন',
                autoBio: true,
                onOk: onUnlock,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
