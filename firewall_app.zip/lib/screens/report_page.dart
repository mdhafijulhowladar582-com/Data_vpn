import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';
import '../widgets/usage_access.dart';

/// ৭ দিনের রিপোর্ট: ডেটা খরচ (অ্যাপ ধরে) ও ব্লক চেষ্টা
class ReportPage extends StatefulWidget {
  const ReportPage({super.key});

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  bool loading = true;
  bool usageOk = false;
  List<UsageEntry> usage = [];
  List<Map<String, dynamic>> days = [];
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    bool ok = false;
    List<UsageEntry> u = [];
    List<Map<String, dynamic>> d = [];
    Map<String, String> n = {};
    try {
      final apps = await store.loadApps();
      n = {for (final a in apps) a.pkg: a.name};
    } catch (_) {}
    try {
      ok = await VpnChannel.hasUsageAccess();
      if (ok) u = await UsageService.fetch(1);
    } catch (_) {}
    try {
      d = await VpnChannel.getAttempts();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      usageOk = ok;
      usage = u;
      days = d;
      names = n;
      loading = false;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  /// রিপোর্টের তথ্য একটা ফাইলে সেভ (ব্যাকআপের মতো, বেছে নেওয়া জায়গায়)
  Future<void> _export() async {
    final out = {
      'app': 'firewall-report',
      'v': 1,
      'time': DateTime.now().toIso8601String(),
      'attempts': [
        for (final d in days)
          {
            'day': d['day'],
            'apps': [
              for (final a in (d['apps'] as List))
                {
                  ...Map<String, dynamic>.from(a as Map),
                  'name': _name((a as Map)['pkg'] as String),
                }
            ],
          }
      ],
      'data7days': [
        for (final e in usage)
          {'pkg': e.pkg, 'name': _name(e.pkg), 'wifi': e.wifi, 'mobile': e.mobile}
      ],
    };
    final now = DateTime.now();
    final name =
        'firewall_report_${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}.json';
    final ok = await VpnChannel.backupExport(jsonEncode(out), name);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(ok ? 'রিপোর্ট সেভ হয়েছে' : 'রিপোর্ট সেভ হয়নি')));
  }

  int _dayTotal(Map<String, dynamic> d) {
    var t = 0;
    for (final a in (d['apps'] as List)) {
      final m = Map<String, dynamic>.from(a as Map);
      if (m['pkg'] != '?') t += (m['n'] as num).toInt();
    }
    return t;
  }

  Widget _row(String left, String right) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(left, maxLines: 1, overflow: TextOverflow.ellipsis)),
          const SizedBox(width: 8),
          Text(right, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      );

  Widget _dataCard() {
    if (!usageOk) return const UsageAccessPrompt(compact: true);
    final wifi = usage.fold<int>(0, (a, e) => a + e.wifi);
    final mob = usage.fold<int>(0, (a, e) => a + e.mobile);
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(UsageService.fmt(wifi + mob),
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text('মোবাইল ${UsageService.fmt(mob)} • Wi-Fi ${UsageService.fmt(wifi)}',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 12),
        const Text('শীর্ষ ৫ অ্যাপ', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        if (usage.isEmpty) const Text('কোনো তথ্য নেই'),
        for (final e in usage.take(5)) _row(_name(e.pkg), UsageService.fmt(e.total)),
      ]),
    );
  }

  // ---------- সাহায্যকারী ----------

  static const _reasonNames = {
    'all': 'সব ব্লক চালু',
    'sched': 'ব্লকের সময়সূচি',
    'roam': 'রোমিং ব্লক',
    'data': 'ফোনের ডেটা লিমিট',
    'applimit': 'অ্যাপের লিমিট শেষ',
    'focus': 'ফোকাস মোড',
    'profile': 'প্রোফাইল/মোড',
    'whitelist': 'হোয়াইটলিস্ট মোড',
    'rule': 'ব্লকলিস্টে আছে',
    'other': 'অন্য',
  };

  String _bn(num n) {
    const d = '০১২৩৪৫৬৭৮৯';
    return n.toString().split('').map((c) {
      final u = c.codeUnitAt(0);
      return (u >= 48 && u <= 57) ? d[u - 48] : c;
    }).join();
  }

  String _hourName(int h) {
    final h12 = h % 12 == 0 ? 12 : h % 12;
    final p = h < 4
        ? 'রাত'
        : h < 6
            ? 'ভোর'
            : h < 12
                ? 'সকাল'
                : h < 15
                    ? 'দুপুর'
                    : h < 18
                        ? 'বিকাল'
                        : h < 20
                            ? 'সন্ধ্যা'
                            : 'রাত';
    return '$p ${_bn(h12)}টা';
  }

  String _key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  DateTime _daysAgo(int i) {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day - i);
  }

  /// আজ থেকে [from] দিন আগে থেকে [to] দিন আগে পর্যন্ত যে দিনগুলোর তথ্য আছে
  List<Map<String, dynamic>> _daysIn(int from, int to) {
    final keys = <String>{for (var i = from; i <= to; i++) _key(_daysAgo(i))};
    return days.where((d) => keys.contains(d['day'])).toList();
  }

  int _sum(List<Map<String, dynamic>> ds) => ds.fold<int>(0, (a, d) => a + _dayTotal(d));

  Iterable<Map<String, dynamic>> _appsOf(List<Map<String, dynamic>> ds) sync* {
    for (final d in ds) {
      for (final a in (d['apps'] as List)) {
        final m = Map<String, dynamic>.from(a as Map);
        if (m['pkg'] != '?') yield m;
      }
    }
  }

  String _compare(List<Map<String, dynamic>> cur, List<Map<String, dynamic>> prev) {
    final c = _sum(cur);
    final p = _sum(prev);
    if (p == 0) return 'গত সপ্তাহের তথ্য নেই, কয়েকদিন পরে তুলনা দেখা যাবে';
    final pct = ((c - p) * 100 / p).round();
    final partial = prev.length < 7 ? ' (গত সপ্তাহের ${_bn(prev.length)} দিনের তথ্য ধরে)' : '';
    if (pct == 0) return 'গত সপ্তাহের সমান$partial';
    return pct < 0
        ? 'গত সপ্তাহের চেয়ে ${_bn(-pct)}% কম$partial'
        : 'গত সপ্তাহের চেয়ে ${_bn(pct)}% বেশি$partial';
  }

  // ---------- ব্লক চেষ্টা ----------

  Widget _triesCard() {
    final cur = _daysIn(0, 6);
    final prev = _daysIn(7, 13);
    final byDay = {for (final d in cur) d['day'] as String: d};
    final tot = <String, int>{};
    for (final m in _appsOf(cur)) {
      final p = m['pkg'] as String;
      tot[p] = (tot[p] ?? 0) + (m['n'] as num).toInt();
    }
    final top = tot.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final week = [for (var i = 0; i < 7; i++) _key(_daysAgo(i))];
    final maxDay = week.fold<int>(1, (a, k) {
      final t = byDay[k] == null ? 0 : _dayTotal(byDay[k]!);
      return t > a ? t : a;
    });
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${_sum(cur)} বার',
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text('ব্লক হওয়া অ্যাপ নেটে ঢোকার চেষ্টা করেছে (একটা অ্যাপের চেষ্টা প্রতি মিনিটে একবার গোনা)',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 6),
        Text(_compare(cur, prev), style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        for (final k in week)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [
              SizedBox(width: 48, child: Text(k.substring(5))),
              Expanded(
                child: LinearProgressIndicator(
                    value: (byDay[k] == null ? 0 : _dayTotal(byDay[k]!)) / maxDay,
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4)),
              ),
              SizedBox(
                  width: 48,
                  child: Text('${byDay[k] == null ? 0 : _dayTotal(byDay[k]!)}',
                      textAlign: TextAlign.end)),
            ]),
          ),
        if (top.isNotEmpty) ...[
          const SizedBox(height: 12),
          const Text('কে বেশি চেষ্টা করল', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          for (final e in top.take(5)) _row(_name(e.key), '${e.value} বার'),
        ],
      ]),
    );
  }

  // ---------- ঘণ্টার ছক ----------

  Widget _hoursCard() {
    final hrs = List<int>.filled(24, 0);
    for (final m in _appsOf(_daysIn(0, 6))) {
      final h = m['h'];
      if (h is List) {
        for (var i = 0; i < 24 && i < h.length; i++) {
          hrs[i] += (h[i] as num).toInt();
        }
      }
    }
    final mx = hrs.fold<int>(0, (a, b) => b > a ? b : a);
    if (mx == 0) return const AppCard(child: Text('এখনো কোনো তথ্য নেই'));
    final cs = Theme.of(context).colorScheme;
    final peak = hrs.indexOf(mx);
    final small = Theme.of(context).textTheme.bodySmall;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${_hourName(peak)} নাগাদ সবচেয়ে বেশি চেষ্টা (${_bn(mx)} বার)',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            for (var i = 0; i < 24; i++)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 1),
                  child: Container(
                    height: 4 + 86 * hrs[i] / mx,
                    decoration: BoxDecoration(
                      color: i == peak ? cs.error : cs.primary.withAlpha(hrs[i] == 0 ? 40 : 200),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ),
              ),
          ]),
        ),
        const SizedBox(height: 4),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('১২ রাত', style: small),
          Text('৬ সকাল', style: small),
          Text('১২ দুপুর', style: small),
          Text('৬ সন্ধ্যা', style: small),
          Text('১১ রাত', style: small),
        ]),
      ]),
    );
  }

  // ---------- কারণ অনুযায়ী ভাগ ----------

  Widget _reasonsCard() {
    final tot = <String, int>{};
    var sum = 0;
    for (final m in _appsOf(_daysIn(0, 6))) {
      final r = m['r'];
      if (r is Map) {
        r.forEach((k, v) {
          final n = (v as num).toInt();
          tot[k as String] = (tot[k] ?? 0) + n;
          sum += n;
        });
      }
    }
    if (sum == 0) return const AppCard(child: Text('এখনো কোনো তথ্য নেই'));
    final list = tot.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final e in list)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _row(_reasonNames[e.key] ?? e.key,
                  '${e.value} বার • ${(e.value * 100 / sum).round()}%'),
              const SizedBox(height: 3),
              LinearProgressIndicator(
                  value: e.value / sum,
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(3)),
            ]),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সাপ্তাহিক রিপোর্ট'), actions: [
        IconButton(
            icon: const Icon(Icons.save_alt), tooltip: 'ফাইলে সেভ', onPressed: loading ? null : _export),
        IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
      ]),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                children: [
                  const SectionLabel('ডেটা খরচ (শেষ ৭ দিন)'),
                  _dataCard(),
                  const SectionLabel('ব্লক চেষ্টা (শেষ ৭ দিন)'),
                  _triesCard(),
                  const SectionLabel('কোন সময়ে বেশি চেষ্টা'),
                  _hoursCard(),
                  const SectionLabel('কেন ব্লক হলো'),
                  _reasonsCard(),
                ],
              ),
            ),
    );
  }
}
