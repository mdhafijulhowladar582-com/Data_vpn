import 'package:flutter/material.dart';
import '../models/rule.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';

/// অ্যাপ লক: লক করা অ্যাপ খুলতে পিন/ফিঙ্গারপ্রিন্ট লাগে (Accessibility Service দিয়ে)।
/// সফট হাইড: ফায়ারওয়ালের অ্যাপ তালিকা থেকে অ্যাপ আড়াল (ব্লকের নিয়ম আগের মতোই থাকে)।
class AppLockPage extends StatefulWidget {
  const AppLockPage({super.key});

  @override
  State<AppLockPage> createState() => _AppLockPageState();
}

class _AppLockPageState extends State<AppLockPage> with WidgetsBindingObserver {
  bool? enabled;
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final e = await VpnChannel.isGuardEnabled();
    final apps = await store.loadApps();
    if (!mounted) return;
    setState(() {
      enabled = e;
      names = {for (final a in apps) a.pkg: a.name};
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  Config get c => store.cfg;

  // ---------- অনুমতি ----------

  Widget _status() {
    final cs = Theme.of(context).colorScheme;
    final on = enabled == true;
    Widget step(int n, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 11, child: Text('$n', style: const TextStyle(fontSize: 11))),
            const SizedBox(width: 10),
            Expanded(child: Text(t)),
          ]),
        );
    return AppCard(
      color: on ? null : cs.errorContainer,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(on ? Icons.verified_user_outlined : Icons.warning_amber,
              color: on ? const Color(0xFF22C55E) : cs.onErrorContainer),
          const SizedBox(width: 10),
          Expanded(
              child: Text(on ? 'অ্যাপ গার্ড চালু' : 'অ্যাপ গার্ড বন্ধ, লক কাজ করবে না',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: on ? null : cs.onErrorContainer))),
        ]),
        if (!on) ...[
          const SizedBox(height: 10),
          step(1, '"Accessibility খুলুন" চাপুন, তালিকায় "Firewall অ্যাপ গার্ড" খুঁজে চালু করুন'),
          step(2, 'সুইচ ধূসর হলে: "অ্যাপ সেটিংস" → ⋮ → "Allow restricted settings" → পিন দিন, তারপর আবার চালু করুন'),
          step(3, 'এই সার্ভিস শুধু বোঝে কোন অ্যাপ সামনে এল। স্ক্রিনের লেখা পড়ে না'),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton.icon(
                onPressed: VpnChannel.openAccessibility,
                icon: const Icon(Icons.accessibility_new),
                label: const Text('Accessibility খুলুন')),
            OutlinedButton.icon(
                onPressed: VpnChannel.openAppSettings,
                icon: const Icon(Icons.settings),
                label: const Text('অ্যাপ সেটিংস')),
          ]),
        ],
      ]),
    );
  }

  Widget _noPin() {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: AppCard(
        color: cs.errorContainer,
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Icon(Icons.pin_outlined, color: cs.onErrorContainer),
          const SizedBox(width: 10),
          Expanded(
              child: Text('আগে সেটিংসে পিন দিন। পিন না থাকলে কোনো অ্যাপ লক হয় না (নিজেকে আটকে ফেলা ঠেকাতে)।',
                  style: TextStyle(fontSize: 12, color: cs.onErrorContainer))),
        ]),
      ),
    );
  }

  // ---------- তালিকা ----------

  Future<void> _pickLocked() async {
    if (!Lock.hasPin) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('আগে সেটিংসে পিন দিন')));
      return;
    }
    final r = await pickApps(context, title: 'যে অ্যাপগুলো লক থাকবে', selected: c.lockedApps);
    if (r == null) return;
    final next = r.toSet();
    // লক খোলা (কমানো) ঢিলা করা, তাই যাচাই
    if (c.lockedApps.difference(next).isNotEmpty &&
        !await Lock.ask(context, reason: 'লক সরাতে যাচাই করুন')) return;
    c.lockedApps = next;
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _pickHidden() async {
    final r = await pickApps(context, title: 'তালিকা থেকে আড়াল করবেন যাদের', selected: c.hiddenApps);
    if (r == null) return;
    final next = r.toSet();
    if (c.hiddenApps.difference(next).isNotEmpty &&
        !await Lock.ask(context, reason: 'আড়াল সরাতে যাচাই করুন')) return;
    c.hiddenApps = next;
    await store.save();
    if (mounted) setState(() {});
  }

  // ---------- Work Profile ----------

  bool _wpBusy = false;

  static const _wpReasons = {
    'android_old': 'এই ফোনের অ্যান্ড্রয়েড ভার্সন পুরোনো।',
    'no_feature': 'এই ফোনে Work Profile সুবিধাই নেই।',
    'not_allowed': 'ফোন এখন Work Profile বানাতে দিচ্ছে না।',
    'not_allowed_has_profile':
        'ফোনে আগেই একটা প্রোফাইল আছে (Work Profile বা Xiaomi Dual Apps হতে পারে), তাই নতুনটা বানানো যাচ্ছে না।',
    'no_screen': 'ফোনে Work Profile সেটআপের স্ক্রিনই নেই।',
  };

  Future<void> _info(String title, String body) => showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ঠিক আছে'))],
        ),
      );

  Future<void> _workProfile() async {
    if (_wpBusy) return;
    setState(() => _wpBusy = true);
    try {
      final st = await VpnChannel.wpState();
      if (!mounted) return;
      if (st['state'] != 'ready') {
        await _info('এই ডিভাইসে এটি সাপোর্ট করে না',
            _wpReasons[st['reason']] ?? 'কারণ জানা যায়নি।');
        return;
      }
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Work Profile বানাবেন?'),
          content: const Text(
              'ফোনের নিজের স্ক্রিন খুলবে, সেখানে অনুমতি দিতে হবে। এখন শুধু প্রোফাইল তৈরি হবে, কোনো অ্যাপ সরবে না বা লুকাবে না।'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('থাক')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('শুরু করুন')),
          ],
        ),
      );
      if (go != true || !mounted) return;
      final r = await VpnChannel.wpStart();
      if (!mounted) return;
      switch (r['result']) {
        case 'created':
          await _info('Work Profile তৈরি হয়েছে',
              'প্রোফাইল ঠিকমতো বানানো গেছে। অ্যাপ সরানোর ধাপ এই সংস্করণে এখনো নেই।');
          break;
        case 'unsupported':
          await _info('এই ডিভাইসে এটি সাপোর্ট করে না',
              _wpReasons[r['reason']] ?? 'কারণ জানা যায়নি।');
          break;
        case 'busy':
          await _info('অপেক্ষা করুন', 'আগের সেটআপ এখনো চলছে।');
          break;
        case 'error':
          await _info('শুরু করা যায়নি', 'ফোন সেটআপ স্ক্রিন খুলতে দেয়নি।');
          break;
        default: // cancelled, unconfirmed
          await _info('সেটআপ শেষ হয়নি বা বাতিল হয়েছে',
              'প্রোফাইল তৈরি হয়েছে বলে নিশ্চিত হওয়া যায়নি। আপনার অ্যাপ আগের মতোই চলবে।');
      }
    } catch (_) {
      if (mounted) await _info('শুরু করা যায়নি', 'ফোন থেকে সাড়া পাওয়া যায়নি।');
    } finally {
      if (mounted) setState(() => _wpBusy = false);
    }
  }

  Widget _row(String pkg, VoidCallback onRemove) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: AppCard(
          padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
          child: Row(children: [
            AppIcon(pkg, size: 36),
            const SizedBox(width: 12),
            Expanded(
                child: Text(_name(pkg),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600))),
            IconButton(icon: const Icon(Icons.close), onPressed: onRemove),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final locked = c.lockedApps.toList()
      ..sort((a, b) => _name(a).toLowerCase().compareTo(_name(b).toLowerCase()));
    final hidden = c.hiddenApps.toList()
      ..sort((a, b) => _name(a).toLowerCase().compareTo(_name(b).toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: const Text('অ্যাপ লক')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _status(),
            if (!Lock.hasPin) _noPin(),
            const SectionLabel('লক করা অ্যাপ'),
            for (final p in locked)
              _row(p, () async {
                if (!await Lock.ask(context, reason: 'লক সরাতে যাচাই করুন')) return;
                c.lockedApps.remove(p);
                await store.save();
                if (mounted) setState(() {});
              }),
            OutlinedButton.icon(
                onPressed: _pickLocked,
                icon: const Icon(Icons.add),
                label: const Text('লক করা অ্যাপ বাছুন')),
            const SizedBox(height: 4),
            Text('আনলকের পর অন্য অ্যাপে বা হোমে গেলে বা স্ক্রিন বন্ধ হলে আবার লক হয়।',
                style: Theme.of(context).textTheme.bodySmall),
            const SectionLabel('সফট হাইড (তালিকা থেকে আড়াল)'),
            for (final p in hidden)
              _row(p, () async {
                if (!await Lock.ask(context, reason: 'আড়াল সরাতে যাচাই করুন')) return;
                c.hiddenApps.remove(p);
                await store.save();
                if (mounted) setState(() {});
              }),
            OutlinedButton.icon(
                onPressed: _pickHidden,
                icon: const Icon(Icons.visibility_off_outlined),
                label: const Text('আড়াল করার অ্যাপ বাছুন')),
            const SizedBox(height: 4),
            Text('আড়াল অ্যাপ অ্যাপস ট্যাবে দেখায় না, কিন্তু ব্লকের নিয়ম আগের মতোই চলে।',
                style: Theme.of(context).textTheme.bodySmall),
            const SectionLabel('আসল হাইড (Work Profile)'),
            OutlinedButton.icon(
                onPressed: _wpBusy ? null : _workProfile,
                icon: const Icon(Icons.work_outline),
                label: Text(_wpBusy ? 'অপেক্ষা করুন...' : 'সাপোর্ট দেখে Work Profile বানান')),
            const SizedBox(height: 4),
            Text(
                'ফোনে সাপোর্ট না থাকলে সতর্কবার্তা আসবে। এখন শুধু প্রোফাইল বানানো যায়, অ্যাপ সরানো বা লুকানো এখনো নেই।',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
