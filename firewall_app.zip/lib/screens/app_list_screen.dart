import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../services/rules_storage.dart';
import '../widgets/app_tile.dart';

class AppListScreen extends StatefulWidget {
  const AppListScreen({super.key});

  @override
  State<AppListScreen> createState() => _AppListScreenState();
}

class _AppListScreenState extends State<AppListScreen> {
  List<AppInfo> apps = [];
  bool loading = true;
  String q = '';
  int filter = 0; // 0 সব, 1 ইউজার, 2 সিস্টেম

  @override
  void initState() {
    super.initState();
    store.loadApps().then((a) {
      if (mounted) {
        setState(() {
          apps = a;
          loading = false;
        });
      }
    });
  }

  List<AppInfo> get shown => apps.where((a) {
        final okF = filter == 0 || (filter == 1 && !a.system) || (filter == 2 && a.system);
        final okQ = q.isEmpty || a.name.toLowerCase().contains(q) || a.pkg.contains(q);
        return okF && okQ;
      }).toList();

  void _bulk(bool block) {
    for (final a in shown) {
      if (store.cfg.mode == 'whitelist') {
        store.setAllowed(a.pkg, !block);
      } else {
        store.setRule(a.pkg, wifi: block, mobile: block);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final wl = store.cfg.mode == 'whitelist';
    return Scaffold(
      appBar: AppBar(
        title: Text(wl ? 'অনুমতি পাবে যারা' : 'ব্লক করবে যাদের'),
        actions: [
          PopupMenuButton<int>(
            onSelected: (v) => _bulk(v == 1),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 1, child: Text('দেখানো সব ব্লক')),
              PopupMenuItem(value: 0, child: Text('দেখানো সব আনব্লক')),
            ],
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                  child: TextField(
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search), hintText: 'অ্যাপ খুঁজুন'),
                    onChanged: (v) => setState(() => q = v.toLowerCase()),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(children: [
                    for (final e in {0: 'সব', 1: 'ইউজার', 2: 'সিস্টেম'}.entries)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(e.value),
                          selected: filter == e.key,
                          onSelected: (_) => setState(() => filter = e.key),
                        ),
                      ),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text(
                      wl ? 'সুইচ চালু = ইন্টারনেট পাবে' : 'টিক = ব্লক',
                      style: const TextStyle(fontSize: 12)),
                ),
                Expanded(
                  child: ListenableBuilder(
                    listenable: store,
                    builder: (context, _) {
                      final list = shown;
                      return ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (c, i) {
                          final a = list[i];
                          return AppTile(
                            key: ValueKey(a.pkg),
                            app: a,
                            rule: store.ruleOf(a.pkg),
                            whitelist: wl,
                            allowed: store.cfg.allowed.contains(a.pkg),
                            onWifi: (v) => store.setRule(a.pkg, wifi: v),
                            onMobile: (v) => store.setRule(a.pkg, mobile: v),
                            onAllow: (v) => store.setAllowed(a.pkg, v),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
