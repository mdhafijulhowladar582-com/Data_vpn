import 'dart:async';
import 'package:flutter/material.dart';
import '../services/focus_service.dart';
import '../services/lock_service.dart';
import '../services/log_service.dart';
import '../services/rules_storage.dart';
import '../services/screen_time_service.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';
import '../widgets/fx.dart';
import '../widgets/shell_actions.dart';
import 'logs_tab.dart';

class HomeTab extends StatefulWidget {
  final bool running;
  final bool guard; // অ্যাপ গার্ড (Accessibility) চালু কিনা
  final ValueChanged<bool> onToggle;
  final ValueChanged<int> onGo;
  const HomeTab(
      {super.key,
      required this.running,
      required this.guard,
      required this.onToggle,
      required this.onGo});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int blockedToday = 0;
  int? dataToday;
  ScreenTimeData? st;
  FocusInfo? focus;
  Map<String, String> names = {};
  Timer? _tm;

  @override
  void initState() {
    super.initState();
    _loadStats();
    _tm = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tm?.cancel();
    super.dispose();
  }

  Future<void> _loadStats() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    int n = 0;
    int? d;
    try {
      final logs = await LogService.fetch();
      n = logs.where((e) => e.time >= start).length;
    } catch (_) {}
    try {
      if (await VpnChannel.hasUsageAccess()) {
        final u = await UsageService.fetch(0);
        d = u.fold<int>(0, (a, e) => a + e.total);
      }
    } catch (_) {}
    ScreenTimeData? s;
    FocusInfo? f;
    try {
      s = await ScreenTimeService.fetch(force: true);
      f = await FocusService.get();
      final apps = await store.loadApps();
      names = {for (final a in apps) a.pkg: a.name};
    } catch (_) {}
    if (mounted) {
      setState(() {
        blockedToday = n;
        dataToday = d;
        st = s;
        focus = f;
      });
    }
  }

  Widget _power(BuildContext context, bool wl) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final on = widget.running;
    final fg = on ? cs.onPrimaryContainer : cs.onSurface;
    return AppCard(
      color: on ? cs.primaryContainer : null,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: on ? cs.primary : cs.outlineVariant,
              child: Icon(on ? Icons.shield : Icons.shield_outlined,
                  size: 30, color: on ? cs.onPrimary : cs.onSurface),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(on ? 'ফায়ারওয়াল (VPN) চালু' : 'ফায়ারওয়াল (VPN) বন্ধ',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w700, color: fg)),
                const SizedBox(height: 2),
                Text(
                    c.blockAll
                        ? 'সব অ্যাপ ব্লক'
                        : wl
                            ? 'হোয়াইটলিস্ট: বেছে নেওয়া অ্যাপ ছাড়া সব বন্ধ'
                            : 'ব্লকলিস্ট: বেছে নেওয়া অ্যাপ বন্ধ',
                    style: TextStyle(fontSize: 12, color: fg)),
              ]),
            ),
            Switch(value: on, onChanged: widget.onToggle),
          ]),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: c.blockAll
                ? FilledButton.icon(
                    onPressed: () async {
                      if (!await Lock.ask(context, reason: 'ব্লক তুলতে যাচাই করুন')) return;
                      c.blockAll = false;
                      store.save();
                    },
                    icon: const Icon(Icons.lock_open),
                    label: const Text('সব ব্লক তুলে নিন'),
                  )
                : FilledButton.tonalIcon(
                    onPressed: () {
                      c.blockAll = true;
                      store.save();
                    },
                    icon: const Icon(Icons.block),
                    label: const Text('সব ব্লক (এক ট্যাপ)'),
                  ),
          ),
          if (c.blockAll && !on)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('ফায়ারওয়াল চালু করলে তবেই ব্লক কাজ করবে',
                  style: TextStyle(fontSize: 12, color: fg)),
            ),
        ],
      ),
    );
  }

  Widget _guardCard(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = widget.guard;
    final fg = on ? cs.onPrimaryContainer : cs.onSurface;
    return AppCard(
      color: on ? cs.primaryContainer : null,
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: on ? cs.primary : cs.outlineVariant,
            child: Icon(on ? Icons.lock_person : Icons.lock_person_outlined,
                size: 28, color: on ? cs.onPrimary : cs.onSurface),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(on ? 'অ্যাপ গার্ড চালু' : 'অ্যাপ গার্ড বন্ধ',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: fg)),
              const SizedBox(height: 2),
              Text(
                  on
                      ? 'অ্যাপ লক, সময় শেষের স্ক্রিন ও ফোকাস গার্ড কাজ করছে'
                      : 'অ্যাপ লক ও "সময় শেষ" স্ক্রিন কাজ করছে না',
                  style: TextStyle(fontSize: 12, color: fg)),
            ]),
          ),
          Switch(
            value: on,
            onChanged: (v) async {
              // Accessibility অ্যাপ থেকে সরাসরি চালু/বন্ধ করা যায় না, সেটিংসে নিয়ে যাই
              if (!v && !await Lock.ask(context, reason: 'অ্যাপ গার্ড বন্ধ করতে যাচাই করুন')) return;
              await VpnChannel.openAccessibility();
            },
          ),
        ]),
        const SizedBox(height: 10),
        Text(
            on
                ? 'বন্ধ করতে সুইচ ধরুন, Accessibility সেটিংসে "Firewall অ্যাপ গার্ড" বন্ধ করুন।'
                : 'চালু করতে সুইচ ধরুন, Accessibility সেটিংসে "Firewall অ্যাপ গার্ড" চালু করুন।',
            style: TextStyle(fontSize: 12, color: fg)),
      ]),
    );
  }

  Widget _engineChip(BuildContext context, String label, bool on) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: on ? cs.primaryContainer : cs.errorContainer.withAlpha(140),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(on ? Icons.check_circle : Icons.cancel_outlined,
            size: 13, color: on ? cs.onPrimaryContainer : cs.onErrorContainer),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                fontSize: 11, color: on ? cs.onPrimaryContainer : cs.onErrorContainer)),
      ]),
    );
  }

  /// একটা ফিচার কোন ইঞ্জিনে চলে ও এখন কাজ করছে কিনা
  Widget _svc(BuildContext context, IconData icon, String title, String detail,
      {required bool useVpn, required bool useGuard}) {
    final cs = Theme.of(context).colorScheme;
    final works = (useVpn && widget.running) || (useGuard && widget.guard);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Icon(icon, color: works ? cs.primary : cs.error),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text(works ? detail : '$detail • এখন কাজ করছে না',
                style: TextStyle(fontSize: 11, color: works ? null : cs.error)),
          ]),
        ),
        const SizedBox(width: 8),
        Wrap(spacing: 4, children: [
          if (useVpn) _engineChip(context, 'VPN', widget.running),
          if (useGuard) _engineChip(context, 'গার্ড', widget.guard),
        ]),
      ]),
    );
  }

  /// ফোকাস ও লিমিট কোন ইঞ্জিন চালু থাকলে কাজ করে
  Widget _services(BuildContext context) {
    final c = store.cfg;
    final fa = focus != null && focus!.active;
    final rows = <Widget>[
      if (fa)
        _svc(context, Icons.self_improvement, 'ফোকাস চলছে',
            'ইন্টারনেট (VPN) ও অ্যাপ খোলা (গার্ড) দুটোই আটকায়',
            useVpn: true, useGuard: true),
      if (c.limits.isNotEmpty)
        _svc(context, Icons.timer_outlined, 'অ্যাপের সময় লিমিট (${c.limits.length}টি)',
            'VPN ইন্টারনেট কাটে, গার্ড "সময় শেষ" স্ক্রিন দেখায়',
            useVpn: true, useGuard: true),
      if (c.dlPhoneMb > 0 || c.dlApps.isNotEmpty)
        _svc(context, Icons.data_usage, 'ডেটা লিমিট',
            'গোনা ও কাট শুধু VPN দিয়ে',
            useVpn: true, useGuard: false),
      if (c.lockedApps.isNotEmpty)
        _svc(context, Icons.lock_outline, 'অ্যাপ লক (${c.lockedApps.length}টি)',
            'শুধু গার্ড দিয়ে',
            useVpn: false, useGuard: true),
    ];
    if (rows.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.only(top: 4, bottom: 2),
            child: Text('কে কী সামলাচ্ছে', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          ...rows,
        ]),
      ),
    );
  }

  Widget _mode(BuildContext context, bool wl) {
    final c = store.cfg;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('মোড', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                  value: 'blocklist',
                  icon: Icon(Icons.block),
                  label: Text('ব্লকলিস্ট')),
              ButtonSegment(
                  value: 'whitelist',
                  icon: Icon(Icons.verified_user_outlined),
                  label: Text('হোয়াইটলিস্ট')),
            ],
            selected: {c.mode},
            onSelectionChanged: (s) async {
              if (s.first == 'blocklist' && !await Lock.ask(context, reason: 'মোড বদলাতে যাচাই করুন')) {
                return;
              }
              c.mode = s.first;
              store.save();
            },
          ),
        ),
        const SizedBox(height: 10),
        Text(
            wl
                ? 'শুধু সুইচ চালু করা অ্যাপ ইন্টারনেট পাবে, বাকি সব বন্ধ।'
                : 'সবাই ইন্টারনেট পাবে, শুধু সুইচ বন্ধ করা অ্যাপ ছাড়া।',
            style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }

  Widget _summary(BuildContext context) {
    final d = st;
    if (d == null) {
      return InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => widget.onGo(3),
        child: const GradientCard(
          colors: stGradient,
          child: Row(children: [
            Icon(Icons.hourglass_bottom_rounded, color: Colors.white, size: 32),
            SizedBox(width: 12),
            Expanded(
                child: Text('স্ক্রিন টাইম দেখতে ট্যাপ করে Usage access দিন',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
          ]),
        ),
      );
    }
    final top = d.topApps(1);
    final streak = d.streak(store.cfg.goalMin * 60000);
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () => widget.onGo(3),
      child: GradientCard(
        colors: stGradient,
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('আজকের স্ক্রিন টাইম', style: TextStyle(color: Colors.white70)),
              CountUp(
                  value: d.total.last,
                  fmt: fmtDur,
                  style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [
                GlassChip(Icons.lock_open, 'আনলক ${d.unlocks.last}'),
                if (streak > 0) GlassChip(Icons.local_fire_department, '$streak দিনের স্ট্রিক'),
              ]),
            ]),
          ),
          if (top.isNotEmpty)
            SizedBox(
              width: 96,
              child: Column(children: [
                const Icon(Icons.emoji_events_outlined, color: Colors.white),
                const SizedBox(height: 4),
                Text(names[top.first.key] ?? top.first.key,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                Text(fmtDur(top.first.value),
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _focusMini(BuildContext context) {
    final f = focus;
    final active = f != null && f.active;
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () => widget.onGo(4),
      child: GradientCard(
        colors: focusGradient,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(children: [
          const Icon(Icons.self_improvement, color: Colors.white, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                active ? 'ফোকাস চলছে • ${fmtMmSs(f!.leftMs)} বাকি' : 'ফোকাস শুরু করুন (২৫/৫০ মিনিট)',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          const Icon(Icons.chevron_right, color: Colors.white),
        ]),
      ),
    );
  }

  Widget _stat(BuildContext context, IconData icon, String value, String label,
      {VoidCallback? onTap}) {
    final cs = Theme.of(context).colorScheme;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: AppCard(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          child: Column(children: [
            Icon(icon, color: cs.primary),
            const SizedBox(height: 8),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      ),
    );
  }

  Widget _stats(BuildContext context, bool wl) {
    final c = store.cfg;
    return Row(children: [
      _stat(context, Icons.report_gmailerrorred, '$blockedToday', 'আজ ব্লক হয়েছে',
          onTap: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const LogsTab()))),
      const SizedBox(width: 10),
      _stat(context, wl ? Icons.verified_user_outlined : Icons.block,
          '${wl ? c.allowed.length : c.rules.length}',
          wl ? 'অনুমতিপ্রাপ্ত অ্যাপ' : 'ব্লক করা অ্যাপ',
          onTap: () => widget.onGo(1)),
      const SizedBox(width: 10),
      _stat(context, Icons.data_usage,
          dataToday == null ? '—' : UsageService.fmt(dataToday!), 'আজকের ডেটা',
          onTap: () => widget.onGo(2)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Firewall'), actions: shellActions(context)),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final wl = store.cfg.mode == 'whitelist';
          final power = _power(context, wl);
          final guardCard = _guardCard(context);
          final services = _services(context);
          final mode = _mode(context, wl);
          final stats = _stats(context, wl);
          final summary = _summary(context);
          final fm = _focusMini(context);
          final Widget body = isWide(context)
              ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                      child: Column(children: [
                    power,
                    const SizedBox(height: 12),
                    guardCard,
                    services,
                    const SizedBox(height: 12),
                    mode,
                  ])),
                  const SizedBox(width: 16),
                  Expanded(
                      child: Column(children: [
                    summary,
                    const SizedBox(height: 12),
                    stats,
                    const SizedBox(height: 12),
                    fm,
                  ])),
                ])
              : Column(children: [
                  power,
                  const SizedBox(height: 12),
                  guardCard,
                  services,
                  const SizedBox(height: 12),
                  summary,
                  const SizedBox(height: 12),
                  stats,
                  const SizedBox(height: 12),
                  fm,
                  const SizedBox(height: 12),
                  mode,
                ]);
          return RefreshIndicator(
            onRefresh: _loadStats,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [body],
            ),
          );
        },
      ),
    );
  }
}
