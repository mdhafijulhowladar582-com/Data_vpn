import 'dart:async';
import 'package:flutter/material.dart';
import '../services/focus_service.dart';
import '../services/lock_service.dart';
import '../services/log_service.dart';
import '../services/rules_storage.dart';
import '../services/screen_time_service.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/common.dart';
import '../widgets/fx.dart';
import '../widgets/shell_actions.dart';
import 'logs_tab.dart';
import 'report_page.dart';

class HomeTab extends StatefulWidget {
  final bool running;
  final bool guard; // অ্যাপ গার্ড (Accessibility) চালু কিনা
  final ValueChanged<bool> onToggle;
  final ValueChanged<int> onGo;
  const HomeTab(
      {super.key,
      required this.running,
      required this.guard,
      required this.onToggle,
      required this.onGo});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> with WidgetsBindingObserver {
  int blockedToday = 0;
  int? dataToday;
  ScreenTimeData? st;
  FocusInfo? focus;
  Map<String, String> names = {};
  Timer? _tm;
  List<MapEntry<String, int>> topTries = []; // আজ ব্লক চেষ্টায় শীর্ষ
  bool batteryOk = true; // ব্যাটারি অপ্টিমাইজেশন থেকে ছাড় আছে কিনা
  List<Map<String, dynamic>> speeds = []; // এই মুহূর্তে শীর্ষ ৩ অ্যাপ (pkg, bps)
  bool speedOk = false; // Usage access আছে কিনা
  bool _resumed = true;
  Timer? _spTm;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkBattery();
    _loadStats();
    _tm = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
    _pollSpeed();
    _spTm = Timer.periodic(const Duration(seconds: 5), (_) => _pollSpeed());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tm?.cancel();
    _spTm?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _resumed = state == AppLifecycleState.resumed;
    if (state == AppLifecycleState.resumed) _checkBattery(); // সেটিংস থেকে ফিরলে আবার দেখি
  }

  /// অ্যাপ সামনে থাকলে ৫ সেকেন্ড পরপর (Kotlin নিজে ১৫ সেকেন্ডের আগে নতুন মাপ নেয় না)
  Future<void> _pollSpeed() async {
    if (!mounted || !_resumed) return;
    try {
      final ok = await VpnChannel.hasUsageAccess();
      final l = ok ? await VpnChannel.getTopSpeeds() : <Map<String, dynamic>>[];
      if (mounted) {
        setState(() {
          speedOk = ok;
          speeds = l;
        });
      }
    } catch (_) {}
  }

  String _fmtSpeed(double bps) => bps >= 1024 * 1024
      ? '${(bps / 1024 / 1024).toStringAsFixed(1)} MB/s'
      : '${(bps / 1024).toStringAsFixed(0)} KB/s';

  /// এই মুহূর্তে কে সবচেয়ে বেশি নেট খাচ্ছে (শীর্ষ ৩)
  Widget _speedCard(BuildContext context) {
    if (!speedOk) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('এই মুহূর্তে কে নেট খাচ্ছে', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          if (speeds.isEmpty)
            Text('এখন কেউ বেশি নেট খাচ্ছে না (বা মাপা হচ্ছে)',
                style: Theme.of(context).textTheme.bodySmall),
          for (final e in speeds)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(children: [
                Expanded(
                    child: Text(names[e['pkg']] ?? '${e['pkg']}',
                        maxLines: 1, overflow: TextOverflow.ellipsis)),
                Text(_fmtSpeed((e['bps'] as num).toDouble()),
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
            ),
        ]),
      ),
    );
  }

  Future<void> _checkBattery() async {
    bool ok = true;
    try {
      ok = await VpnChannel.isBatteryExempt();
    } catch (_) {}
    if (mounted && ok != batteryOk) setState(() => batteryOk = ok);
  }

  Future<void> _setMode(String n) async {
    final c = store.cfg;
    if (c.activeMode == n) return;
    if (c.activeMode.isNotEmpty && !await Lock.ask(context, reason: 'মোড বদলাতে যাচাই করুন')) return;
    if (!mounted) return;
    if (n.isNotEmpty && (c.profiles[n]?.isEmpty ?? true)) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(n),
          content: const Text('এই মোডে কোনো অ্যাপ বাছা নেই, চালু করলে সব অ্যাপের ইন্টারনেট বন্ধ হবে। এগোবেন?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('হ্যাঁ')),
          ],
        ),
      );
      if (ok != true) return;
    }
    c.activeMode = n;
    await store.save();
  }

  Future<void> _editProfile(String n) async {
    final c = store.cfg;
    final act = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(title: Text(n), children: [
        SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, 'apps'),
            child: Text('ইন্টারনেট পাবে যারা (${c.profiles[n]?.length ?? 0}টি)')),
        SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, 'del'), child: const Text('এই মোড মুছুন')),
      ]),
    );
    if (act == null || !mounted) return;
    if (c.activeMode == n && !await Lock.ask(context, reason: 'মোড বদলাতে যাচাই করুন')) return;
    if (!mounted) return;
    if (act == 'apps') {
      final r = await pickApps(context,
          title: '$n: ইন্টারনেট পাবে যারা', selected: c.profiles[n] ?? <String>{});
      if (r == null) return;
      c.profiles[n] = r.toSet();
    } else {
      c.profiles.remove(n);
      if (c.activeMode == n) c.activeMode = '';
    }
    await store.save();
  }

  Future<void> _newProfile() async {
    final t = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('নতুন মোডের নাম'),
        content: TextField(controller: t, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, t.text.trim()), child: const Text('তৈরি')),
        ],
      ),
    );
    if (name == null || name.isEmpty || !mounted) return;
    final c = store.cfg;
    if (c.profiles.containsKey(name)) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('এই নামে মোড আগে থেকেই আছে')));
      return;
    }
    final r = await pickApps(context, title: '$name: ইন্টারনেট পাবে যারা', selected: <String>{});
    if (r == null) return;
    c.profiles[name] = r.toSet();
    await store.save();
  }

  /// দ্রুত মোড: এক ট্যাপে "শুধু এই অ্যাপগুলো ইন্টারনেট পাবে"
  Widget _modesCard(BuildContext context) {
    final c = store.cfg;
    final active = c.activeMode;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('দ্রুত মোড', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
            active.isEmpty
                ? 'সাধারণ: আপনার নিজের নিয়ম চলছে'
                : '"$active" চালু: বেছে নেওয়া অ্যাপ ছাড়া সব বন্ধ',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          ChoiceChip(
              label: const Text('সাধারণ'),
              selected: active.isEmpty,
              onSelected: (_) => _setMode('')),
          for (final n in c.profiles.keys)
            GestureDetector(
              onLongPress: () => _editProfile(n),
              child: ChoiceChip(
                  label: Text(n), selected: active == n, onSelected: (_) => _setMode(n)),
            ),
          ActionChip(
              avatar: const Icon(Icons.add, size: 18),
              label: const Text('নতুন'),
              onPressed: _newProfile),
        ]),
        const SizedBox(height: 8),
        Text(
            active.isNotEmpty && !widget.running
                ? 'ফায়ারওয়াল চালু করলে তবেই মোড কাজ করবে'
                : 'চেপে ধরে অ্যাপ বাছুন বা মুছুন',
            style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }

  /// ব্যাটারি ছাড় না থাকলে সতর্কতা কার্ড
  Widget _batteryCard(BuildContext context) {
    if (batteryOk) return const SizedBox.shrink();
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        color: cs.errorContainer,
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.battery_alert, color: cs.onErrorContainer),
            const SizedBox(width: 10),
            Expanded(
              child: Text('ব্যাটারি লিমিট বন্ধ করুন',
                  style: TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700, color: cs.onErrorContainer)),
            ),
          ]),
          const SizedBox(height: 8),
          Text(
              'না করলে ফোন ব্যাটারি বাঁচাতে ফায়ারওয়াল নিজে বন্ধ করে দিতে পারে, আর আপনি টেরও পাবেন না।',
              style: TextStyle(fontSize: 12, color: cs.onErrorContainer)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: FilledButton(
                onPressed: VpnChannel.requestBatteryExempt,
                child: const Text('ছাড় দিন'),
              ),
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: VpnChannel.openAppSettings,
              child: Text('অ্যাপ সেটিংস', style: TextStyle(color: cs.onErrorContainer)),
            ),
          ]),
          const SizedBox(height: 6),
          Text(
              'Xiaomi, Realme, Oppo, Vivo হলে অ্যাপ সেটিংসে গিয়ে "Autostart" আর "Background" চালু রাখুন।',
              style: TextStyle(fontSize: 11, color: cs.onErrorContainer)),
        ]),
      ),
    );
  }

  Future<void> _loadStats() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    int n = 0;
    int? d;
    try {
      final logs = await LogService.fetch();
      n = logs.where((e) => e.time >= start).length;
    } catch (_) {}
    try {
      if (await VpnChannel.hasUsageAccess()) {
        final u = await UsageService.fetch(0);
        d = u.fold<int>(0, (a, e) => a + e.total);
      }
    } catch (_) {}
    final tops = <String, int>{};
    try {
      final t = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      for (final d in await VpnChannel.getAttempts()) {
        if (d['day'] != t) continue;
        for (final a in (d['apps'] as List)) {
          final m = Map<String, dynamic>.from(a as Map);
          if (m['pkg'] != '?') tops[m['pkg'] as String] = (m['n'] as num).toInt();
        }
      }
    } catch (_) {}
    final topList = (tops.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(3).toList();
    ScreenTimeData? s;
    FocusInfo? f;
    try {
      s = await ScreenTimeService.fetch(force: true);
      f = await FocusService.get();
      final apps = await store.loadApps();
      names = {for (final a in apps) a.pkg: a.name};
    } catch (_) {}
    if (mounted) {
      setState(() {
        blockedToday = n;
        topTries = topList;
        dataToday = d;
        st = s;
        focus = f;
      });
    }
  }

  Widget _power(BuildContext context, bool wl) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final on = widget.running;
    final fg = on ? cs.onPrimaryContainer : cs.onSurface;
    return AppCard(
      color: on ? cs.primaryContainer : null,
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: on ? cs.primary : cs.outlineVariant,
              child: Icon(on ? Icons.shield : Icons.shield_outlined,
                  size: 30, color: on ? cs.onPrimary : cs.onSurface),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(on ? 'ফায়ারওয়াল (VPN) চালু' : 'ফায়ারওয়াল (VPN) বন্ধ',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w700, color: fg)),
                const SizedBox(height: 2),
                Text(
                    c.blockAll
                        ? 'সব অ্যাপ ব্লক'
                        : wl
                            ? 'হোয়াইটলিস্ট: বেছে নেওয়া অ্যাপ ছাড়া সব বন্ধ'
                            : 'ব্লকলিস্ট: বেছে নেওয়া অ্যাপ বন্ধ',
                    style: TextStyle(fontSize: 12, color: fg)),
              ]),
            ),
            Switch(value: on, onChanged: widget.onToggle),
          ]),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: c.blockAll
                ? FilledButton.icon(
                    onPressed: () async {
                      if (!await Lock.ask(context, reason: 'ব্লক তুলতে যাচাই করুন')) return;
                      c.blockAll = false;
                      store.save();
                    },
                    icon: const Icon(Icons.lock_open),
                    label: const Text('সব ব্লক তুলে নিন'),
                  )
                : FilledButton.tonalIcon(
                    onPressed: () {
                      c.blockAll = true;
                      store.save();
                    },
                    icon: const Icon(Icons.block),
                    label: const Text('সব ব্লক (এক ট্যাপ)'),
                  ),
          ),
          if (c.blockAll && !on)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('ফায়ারওয়াল চালু করলে তবেই ব্লক কাজ করবে',
                  style: TextStyle(fontSize: 12, color: fg)),
            ),
        ],
      ),
    );
  }

  Widget _guardCard(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = widget.guard;
    final fg = on ? cs.onPrimaryContainer : cs.onSurface;
    return AppCard(
      color: on ? cs.primaryContainer : null,
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: on ? cs.primary : cs.outlineVariant,
            child: Icon(on ? Icons.lock_person : Icons.lock_person_outlined,
                size: 28, color: on ? cs.onPrimary : cs.onSurface),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(on ? 'অ্যাপ গার্ড চালু' : 'অ্যাপ গার্ড বন্ধ',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: fg)),
              const SizedBox(height: 2),
              Text(
                  on
                      ? 'অ্যাপ লক, সময় শেষের স্ক্রিন ও ফোকাস গার্ড কাজ করছে'
                      : 'অ্যাপ লক ও "সময় শেষ" স্ক্রিন কাজ করছে না',
                  style: TextStyle(fontSize: 12, color: fg)),
            ]),
          ),
          Switch(
            value: on,
            onChanged: (v) async {
              // Accessibility অ্যাপ থেকে সরাসরি চালু/বন্ধ করা যায় না, সেটিংসে নিয়ে যাই
              if (!v && !await Lock.ask(context, reason: 'অ্যাপ গার্ড বন্ধ করতে যাচাই করুন')) return;
              await VpnChannel.openAccessibility();
            },
          ),
        ]),
        const SizedBox(height: 10),
        Text(
            on
                ? 'বন্ধ করতে সুইচ ধরুন, Accessibility সেটিংসে "Firewall অ্যাপ গার্ড" বন্ধ করুন।'
                : 'চালু করতে সুইচ ধরুন, Accessibility সেটিংসে "Firewall অ্যাপ গার্ড" চালু করুন।',
            style: TextStyle(fontSize: 12, color: fg)),
      ]),
    );
  }

  Widget _engineChip(BuildContext context, String label, bool on) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: on ? cs.primaryContainer : cs.errorContainer.withAlpha(140),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(on ? Icons.check_circle : Icons.cancel_outlined,
            size: 13, color: on ? cs.onPrimaryContainer : cs.onErrorContainer),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                fontSize: 11, color: on ? cs.onPrimaryContainer : cs.onErrorContainer)),
      ]),
    );
  }

  /// একটা ফিচার কোন ইঞ্জিনে চলে ও এখন কাজ করছে কিনা
  Widget _svc(BuildContext context, IconData icon, String title, String detail,
      {required bool useVpn, required bool useGuard}) {
    final cs = Theme.of(context).colorScheme;
    final works = (useVpn && widget.running) || (useGuard && widget.guard);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Icon(icon, color: works ? cs.primary : cs.error),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text(works ? detail : '$detail • এখন কাজ করছে না',
                style: TextStyle(fontSize: 11, color: works ? null : cs.error)),
          ]),
        ),
        const SizedBox(width: 8),
        Wrap(spacing: 4, children: [
          if (useVpn) _engineChip(context, 'VPN', widget.running),
          if (useGuard) _engineChip(context, 'গার্ড', widget.guard),
        ]),
      ]),
    );
  }

  /// ফোকাস ও লিমিট কোন ইঞ্জিন চালু থাকলে কাজ করে
  Widget _services(BuildContext context) {
    final c = store.cfg;
    final fa = focus != null && focus!.active;
    final rows = <Widget>[
      if (fa)
        _svc(context, Icons.self_improvement, 'ফোকাস চলছে',
            'ইন্টারনেট (VPN) ও অ্যাপ খোলা (গার্ড) দুটোই আটকায়',
            useVpn: true, useGuard: true),
      if (c.limits.isNotEmpty)
        _svc(context, Icons.timer_outlined, 'অ্যাপের সময় লিমিট (${c.limits.length}টি)',
            'VPN ইন্টারনেট কাটে, গার্ড "সময় শেষ" স্ক্রিন দেখায়',
            useVpn: true, useGuard: true),
      if (c.dlPhoneMb > 0 || c.dlApps.isNotEmpty || c.dlPackMb > 0)
        _svc(context, Icons.data_usage, 'ডেটা লিমিট',
            'গোনা ও কাট শুধু VPN দিয়ে',
            useVpn: true, useGuard: false),
      if (c.lockedApps.isNotEmpty)
        _svc(context, Icons.lock_outline, 'অ্যাপ লক (${c.lockedApps.length}টি)',
            'শুধু গার্ড দিয়ে',
            useVpn: false, useGuard: true),
    ];
    if (rows.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.only(top: 4, bottom: 2),
            child: Text('কে কী সামলাচ্ছে', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          ...rows,
        ]),
      ),
    );
  }

  Widget _mode(BuildContext context, bool wl) {
    final c = store.cfg;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('মোড', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                  value: 'blocklist',
                  icon: Icon(Icons.block),
                  label: Text('ব্লকলিস্ট')),
              ButtonSegment(
                  value: 'whitelist',
                  icon: Icon(Icons.verified_user_outlined),
                  label: Text('হোয়াইটলিস্ট')),
            ],
            selected: {c.mode},
            onSelectionChanged: (s) async {
              if (s.first == 'blocklist' && !await Lock.ask(context, reason: 'মোড বদলাতে যাচাই করুন')) {
                return;
              }
              c.mode = s.first;
              store.save();
            },
          ),
        ),
        const SizedBox(height: 10),
        Text(
            wl
                ? 'শুধু সুইচ চালু করা অ্যাপ ইন্টারনেট পাবে, বাকি সব বন্ধ।'
                : 'সবাই ইন্টারনেট পাবে, শুধু সুইচ বন্ধ করা অ্যাপ ছাড়া।',
            style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }

  Widget _summary(BuildContext context) {
    final d = st;
    if (d == null) {
      return InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => widget.onGo(3),
        child: const GradientCard(
          colors: stGradient,
          child: Row(children: [
            Icon(Icons.hourglass_bottom_rounded, color: Colors.white, size: 32),
            SizedBox(width: 12),
            Expanded(
                child: Text('স্ক্রিন টাইম দেখতে ট্যাপ করে Usage access দিন',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
          ]),
        ),
      );
    }
    final top = d.topApps(1);
    final streak = d.streak(store.cfg.goalMin * 60000);
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () => widget.onGo(3),
      child: GradientCard(
        colors: stGradient,
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('আজকের স্ক্রিন টাইম', style: TextStyle(color: Colors.white70)),
              CountUp(
                  value: d.total.last,
                  fmt: fmtDur,
                  style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [
                GlassChip(Icons.lock_open, 'আনলক ${d.unlocks.last}'),
                if (streak > 0) GlassChip(Icons.local_fire_department, '$streak দিনের স্ট্রিক'),
              ]),
            ]),
          ),
          if (top.isNotEmpty)
            SizedBox(
              width: 96,
              child: Column(children: [
                const Icon(Icons.emoji_events_outlined, color: Colors.white),
                const SizedBox(height: 4),
                Text(names[top.first.key] ?? top.first.key,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                Text(fmtDur(top.first.value),
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _focusMini(BuildContext context) {
    final f = focus;
    final active = f != null && f.active;
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () => widget.onGo(4),
      child: GradientCard(
        colors: focusGradient,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(children: [
          const Icon(Icons.self_improvement, color: Colors.white, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                active ? 'ফোকাস চলছে • ${fmtMmSs(f!.leftMs)} বাকি' : 'ফোকাস শুরু করুন (২৫/৫০ মিনিট)',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          const Icon(Icons.chevron_right, color: Colors.white),
        ]),
      ),
    );
  }

  /// আজ কোন ব্লক অ্যাপ বেশি নেটে ঢোকার চেষ্টা করল
  Widget _triesCard(BuildContext context) {
    if (topTries.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const ReportPage())),
        child: AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('আজ কে বেশি ব্লকে ঠেকল', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            for (final e in topTries)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(children: [
                  Expanded(
                      child: Text(names[e.key] ?? e.key,
                          maxLines: 1, overflow: TextOverflow.ellipsis)),
                  Text('${e.value} বার', style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
          ]),
        ),
      ),
    );
  }

  Widget _stat(BuildContext context, IconData icon, String value, String label,
      {VoidCallback? onTap}) {
    final cs = Theme.of(context).colorScheme;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: AppCard(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          child: Column(children: [
            Icon(icon, color: cs.primary),
            const SizedBox(height: 8),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      ),
    );
  }

  Widget _stats(BuildContext context, bool wl) {
    final c = store.cfg;
    return Row(children: [
      _stat(context, Icons.report_gmailerrorred, '$blockedToday', 'আজ ব্লক হয়েছে',
          onTap: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const LogsTab()))),
      const SizedBox(width: 10),
      _stat(context, wl ? Icons.verified_user_outlined : Icons.block,
          '${wl ? c.allowed.length : c.rules.length}',
          wl ? 'অনুমতিপ্রাপ্ত অ্যাপ' : 'ব্লক করা অ্যাপ',
          onTap: () => widget.onGo(1)),
      const SizedBox(width: 10),
      _stat(context, Icons.data_usage,
          dataToday == null ? '—' : UsageService.fmt(dataToday!), 'আজকের ডেটা',
          onTap: () => widget.onGo(2)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Firewall'), actions: shellActions(context)),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final wl = store.cfg.mode == 'whitelist';
          final power = _power(context, wl);
          final guardCard = _guardCard(context);
          final battery = _batteryCard(context);
          final modes = _modesCard(context);
          final services = _services(context);
          final mode = _mode(context, wl);
          final stats = _stats(context, wl);
          final tries = _triesCard(context);
          final spd = _speedCard(context);
          final summary = _summary(context);
          final fm = _focusMini(context);
          final Widget body = isWide(context)
              ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                      child: Column(children: [
                    power,
                    battery,
                    const SizedBox(height: 12),
                    modes,
                    const SizedBox(height: 12),
                    guardCard,
                    services,
                    const SizedBox(height: 12),
                    mode,
                  ])),
                  const SizedBox(width: 16),
                  Expanded(
                      child: Column(children: [
                    summary,
                    const SizedBox(height: 12),
                    stats,
                    spd,
                    tries,
                    const SizedBox(height: 12),
                    fm,
                  ])),
                ])
              : Column(children: [
                  power,
                  battery,
                  const SizedBox(height: 12),
                  modes,
                  const SizedBox(height: 12),
                  guardCard,
                  services,
                  const SizedBox(height: 12),
                  summary,
                  const SizedBox(height: 12),
                  stats,
                  spd,
                  tries,
                  const SizedBox(height: 12),
                  fm,
                  const SizedBox(height: 12),
                  mode,
                ]);
          return RefreshIndicator(
            onRefresh: _loadStats,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [body],
            ),
          );
        },
      ),
    );
  }
}
