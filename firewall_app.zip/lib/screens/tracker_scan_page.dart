import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';

class _Hit {
  final AppInfo app;
  final List<String> trackers;
  _Hit(this.app, this.trackers);
}

/// ইনস্টল করা অ্যাপের ভেতরের বিজ্ঞাপন/ট্র্যাকার SDK গুনে তালিকা, আর এক ট্যাপে ব্লক।
class TrackerScanPage extends StatefulWidget {
  const TrackerScanPage({super.key});

  @override
  State<TrackerScanPage> createState() => _TrackerScanPageState();
}

class _TrackerScanPageState extends State<TrackerScanPage> {
  List<_Hit> hits = [];
  bool loading = true;
  bool failed = false;
  bool showSystem = false;

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    setState(() {
      loading = true;
      failed = false;
    });
    try {
      final apps = await store.loadApps();
      final byPkg = {for (final a in apps) a.pkg: a};
      final raw = await VpnChannel.scanTrackers();
      final l = <_Hit>[];
      for (final m in raw) {
        final a = byPkg[m['pkg'] as String];
        if (a == null) continue;
        final t = (m['trackers'] as List).map((e) => e as String).toList();
        l.add(_Hit(a, t));
      }
      l.sort((a, b) {
        final c = b.trackers.length.compareTo(a.trackers.length);
        return c != 0 ? c : a.app.name.toLowerCase().compareTo(b.app.name.toLowerCase());
      });
      if (!mounted) return;
      setState(() {
        hits = l;
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        failed = true;
      });
    }
  }

  bool _blocked(String pkg) => store.cfg.mode == 'whitelist'
      ? !store.cfg.allowed.contains(pkg)
      : store.ruleOf(pkg).any;

  void _block(String pkg) {
    if (store.cfg.mode == 'whitelist') {
      store.setAllowed(pkg, false);
    } else {
      store.setRule(pkg, wifi: true, mobile: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ট্র্যাকার স্ক্যান'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'আবার স্ক্যান',
            onPressed: loading ? null : _scan,
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : failed
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('স্ক্যান করা যায়নি'),
                    const SizedBox(height: 8),
                    FilledButton(onPressed: _scan, child: const Text('আবার চেষ্টা')),
                  ]),
                )
              : AnimatedBuilder(animation: store, builder: (c, _) => _body(c)),
    );
  }

  Widget _body(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final list = hits.where((h) => showSystem || !h.app.system).toList();
    return Centered(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Text(
            'অ্যাপের ভেতরে বিজ্ঞাপন/ট্র্যাকারের কোড আছে কিনা মিলিয়ে দেখা হয়েছে। '
            'চালানোর সময় আসলে ডেটা পাঠাচ্ছে কিনা এটা বলে না।\n'
            'ব্লক করলে ওই অ্যাপের পুরো ইন্টারনেট বন্ধ হবে, শুধু ট্র্যাকার নয়।',
            style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.4),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: const Text('সিস্টেম অ্যাপও দেখান'),
            value: showSystem,
            onChanged: (v) => setState(() => showSystem = v),
          ),
          if (list.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 48),
              child: Center(child: Text('কোনো ট্র্যাকার পাওয়া যায়নি')),
            )
          else ...[
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('${list.length}টি অ্যাপে ট্র্যাকার পাওয়া গেছে',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final h in list)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _tile(context, h),
              ),
          ],
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, _Hit h) {
    final cs = Theme.of(context).colorScheme;
    final pkg = h.app.pkg;
    final emergency = store.cfg.emergency.contains(pkg);
    final blocked = _blocked(pkg);
    Widget trailing;
    if (emergency) {
      trailing = Text('জরুরি', style: TextStyle(color: cs.outline, fontSize: 12));
    } else if (blocked) {
      trailing = Chip(
        label: const Text('ব্লক করা'),
        visualDensity: VisualDensity.compact,
        avatar: Icon(Icons.block, size: 16, color: cs.error),
      );
    } else {
      trailing = FilledButton.tonal(
        onPressed: () => _block(pkg),
        style: FilledButton.styleFrom(visualDensity: VisualDensity.compact),
        child: const Text('ব্লক'),
      );
    }
    return AppCard(
      padding: EdgeInsets.zero,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14),
          childrenPadding: const EdgeInsets.fromLTRB(70, 0, 16, 12),
          expandedCrossAxisAlignment: CrossAxisAlignment.start,
          leading: AppIcon(pkg),
          title: Text(h.app.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${h.trackers.length}টি ট্র্যাকার',
              style: TextStyle(color: h.trackers.length >= 4 ? cs.error : cs.outline)),
          trailing: trailing,
          children: [
            for (final t in h.trackers)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text('• $t', style: const TextStyle(fontSize: 13)),
              ),
          ],
        ),
      ),
    );
  }
}
