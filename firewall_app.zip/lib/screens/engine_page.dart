import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/common.dart';

/// নিজস্ব ইঞ্জিন: বাছা অ্যাপের নেট VPN-এর ভেতর দিয়ে নিজে পৌঁছে দেয়, আর বিজ্ঞাপন/ট্র্যাকারের ডোমেইনের প্রশ্নে
/// "এই ঠিকানা নেই" বলে। সুইচ ডিফল্ট বন্ধ।
class EnginePage extends StatefulWidget {
  const EnginePage({super.key});

  @override
  State<EnginePage> createState() => _EnginePageState();
}

class _EnginePageState extends State<EnginePage> {
  Map<String, dynamic> st = {};
  Map<String, String> names = {};
  Timer? _t;
  bool busy = false;
  final domCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    store.addListener(_onStore);
    _loadNames();
    _poll();
    _t = Timer.periodic(const Duration(seconds: 2), (_) => _poll());
  }

  @override
  void dispose() {
    _t?.cancel();
    store.removeListener(_onStore);
    domCtl.dispose();
    super.dispose();
  }

  void _onStore() {
    if (mounted) setState(() {});
  }

  Future<void> _loadNames() async {
    try {
      final apps = await store.loadApps();
      if (!mounted) return;
      setState(() => names = {for (final a in apps) a.pkg: a.name});
    } catch (_) {}
  }

  Future<void> _poll() async {
    try {
      final r = await VpnChannel.getEngine();
      if (!mounted) return;
      // সুইচ Kotlin-এর মালিকানায়, নিজে বন্ধ হলে এখানেও বদলে যাবে
      store.cfg.engineOn = r['on'] == true;
      setState(() => st = r);
    } catch (_) {}
  }

  bool get _supported => st['supported'] != false;
  bool get _on => st['on'] == true;

  void _snack(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 3)));
  }

  Future<void> _toggle(bool v) async {
    if (busy) return;
    final c = store.cfg;
    if (!v) {
      setState(() => busy = true);
      await VpnChannel.engineSet(false);
      await _poll();
      if (mounted) setState(() => busy = false);
      return;
    }
    if (c.engineApps.isEmpty) {
      _snack('আগে নিচে থেকে অন্তত একটা অ্যাপ বাছুন');
      return;
    }
    setState(() => busy = true);
    try {
      await store.save();
      if (st['fwRunning'] != true) {
        final ok = await VpnChannel.start();
        if (!ok) {
          _snack('VPN চালু করা যায়নি');
          return;
        }
        await Future.delayed(const Duration(milliseconds: 900));
      }
      final ok = await VpnChannel.engineSet(true);
      if (!ok) {
        _snack('এই ফোনে ইঞ্জিন চলবে না (অ্যান্ড্রয়েড ১০ বা তার উপরে লাগবে)');
        return;
      }
      await _poll();
      if (!mounted) return;
      final good = await _confirm();
      if (good) {
        await VpnChannel.engineConfirm();
      } else {
        await VpnChannel.engineSet(false);
      }
      await _poll();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  /// ৩০ সেকেন্ডের "নেট চলছে তো?" নিশ্চিতকরণ। না চাপলে ইঞ্জিন নিজে বন্ধ (Kotlin-ও আলাদাভাবে বন্ধ করে)
  Future<bool> _confirm() async {
    final r = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _ConfirmDialog(),
    );
    return r == true;
  }

  Future<void> _pickApps() async {
    final c = store.cfg;
    final r = await pickApps(context, title: 'ইঞ্জিনের অ্যাপ', selected: c.engineApps);
    if (r == null) return;
    c.engineApps = r.toSet();
    await store.save();
    _loadNames();
  }

  Future<void> _addDomain() async {
    final raw = domCtl.text.trim();
    if (raw.isEmpty) return;
    var d = raw.toLowerCase();
    d = d.replaceFirst(RegExp(r'^https?://'), '');
    final slash = d.indexOf('/');
    if (slash >= 0) d = d.substring(0, slash);
    final colon = d.indexOf(':');
    if (colon >= 0) d = d.substring(0, colon);
    d = d.replaceFirst(RegExp(r'^(\*\.|\.)'), '');
    d = d.replaceFirst(RegExp(r'\.+$'), '');
    final ok = RegExp(r'^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$').hasMatch(d);
    if (!ok) {
      _snack('ডোমেইনটা ঠিক মনে হচ্ছে না, যেমন: ads.example.com');
      return;
    }
    final c = store.cfg;
    if (!c.engineDomains.contains(d)) c.engineDomains = [...c.engineDomains, d];
    domCtl.clear();
    await store.save();
  }

  Future<void> _removeDomain(String d) async {
    final c = store.cfg;
    c.engineDomains = c.engineDomains.where((e) => e != d).toList();
    await store.save();
  }

  Future<void> _copyLog() async {
    final lines = (st['lines'] as List?)?.cast<String>() ?? const <String>[];
    final head = 'ইঞ্জিন: ${_on ? "চালু" : "বন্ধ"}, চলছে: ${st['running']}, সুইচ: ${st['on']}, '
        'প্রশ্ন: ${st['queries']}, আটকানো: ${st['blocked']}, TCP: ${st['tcp']}, UDP: ${st['udp']}, '
        'ত্রুটি: ${st['errors']}, অ্যাপ: ${store.cfg.engineApps.join(", ")}';
    await Clipboard.setData(ClipboardData(text: '$head\n${lines.join("\n")}'));
    _snack('লগ কপি হয়েছে, আমাকে পাঠান');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final lines = (st['lines'] as List?)?.cast<String>() ?? const <String>[];
    final apps = c.engineApps.toList()
      ..sort((a, b) => (names[a] ?? a).toLowerCase().compareTo((names[b] ?? b).toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: const Text('নিজস্ব ইঞ্জিন')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ইঞ্জিন চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(!_supported
                      ? 'এই ফোনে চলবে না, অ্যান্ড্রয়েড ১০ বা তার উপরে লাগবে'
                      : (_on
                          ? (st['running'] == true ? 'চলছে' : 'চালু করা আছে, ফায়ারওয়াল চালু হলে চলবে')
                          : 'বন্ধ (ডিফল্ট)')),
                  value: _on,
                  onChanged: (!_supported || busy) ? null : _toggle,
                ),
                const SizedBox(height: 4),
                Text(
                  'চালু করলে ৩০ সেকেন্ডের মধ্যে "নেট চলছে" নিশ্চিত করতে হবে, নইলে ইঞ্জিন নিজে বন্ধ হয়ে '
                  'অ্যাপ আগের মতো সরাসরি নেট পাবে। ইঞ্জিনে বারবার ত্রুটি হলেও নিজে বন্ধ হয়।',
                  style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
            const SectionLabel('অ্যাপ'),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  apps.isEmpty
                      ? 'কোনো অ্যাপ বাছা নেই। প্রথমে একটা অ্যাপ (যেমন ব্রাউজার) দিয়ে পরীক্ষা করুন'
                      : 'এই অ্যাপগুলোর নেট ইঞ্জিন দিয়ে যাবে',
                  style: const TextStyle(fontSize: 13.5),
                ),
                if (apps.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    for (final p in apps) Chip(label: Text(names[p] ?? p)),
                  ]),
                ],
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: _pickApps,
                  icon: const Icon(Icons.apps),
                  label: const Text('অ্যাপ বাছুন'),
                ),
                const SizedBox(height: 6),
                Text(
                  'ফায়ারওয়ালে ব্লক করা অ্যাপ ব্লকই থাকবে, ইঞ্জিনের তালিকায় থাকলেও। জরুরি অ্যাপ ইঞ্জিনের বাইরে থাকে।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.4),
                ),
              ]),
            ),
            const SectionLabel('ফিল্টার'),
            AppCard(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('বিল্ট-ইন ট্র্যাকার তালিকা'),
                  subtitle: Text('${st['builtinCount'] ?? 0}টি বিজ্ঞাপন ও ট্র্যাকার ডোমেইন, সাবডোমেইনসহ'),
                  value: c.engineBuiltin,
                  onChanged: (v) {
                    c.engineBuiltin = v;
                    store.save();
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('DoH সার্ভার আটকান'),
                  subtitle: const Text(
                      'অ্যাপ লুকিয়ে DoH ব্যবহার করলে ফিল্টার এড়াতে পারে, তাই পরিচিত DoH নামগুলো আটকায়। ফোনের Private DNS-এ dns.google, cloudflare-dns.com ইত্যাদি দেওয়া থাকলে এটা চালু করবেন না, নেট বন্ধ হতে পারে',
                      style: TextStyle(fontSize: 11)),
                  value: c.engineBlockDoh,
                  onChanged: (v) {
                    c.engineBlockDoh = v;
                    store.save();
                  },
                ),
                const SizedBox(height: 4),
                const Text('নিজের ডোমেইন', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: domCtl,
                      autocorrect: false,
                      keyboardType: TextInputType.url,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        isDense: true,
                        hintText: 'ads.example.com',
                      ),
                      onSubmitted: (_) => _addDomain(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(onPressed: _addDomain, child: const Text('যোগ')),
                ]),
                const SizedBox(height: 6),
                if (c.engineDomains.isEmpty)
                  Text('কোনো নিজের ডোমেইন নেই', style: TextStyle(fontSize: 12.5, color: cs.outline))
                else
                  for (final d in c.engineDomains)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text(d),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        tooltip: 'মুছুন',
                        onPressed: () => _removeDomain(d),
                      ),
                    ),
              ]),
            ),
            const SectionLabel('অবস্থা'),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  'DNS প্রশ্ন ${st['queries'] ?? 0}, আটকানো ${st['blocked'] ?? 0}\n'
                  'TCP ${st['tcp'] ?? 0}, UDP ${st['udp'] ?? 0}, ত্রুটি ${st['errors'] ?? 0}',
                  style: const TextStyle(fontSize: 14, height: 1.5),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  OutlinedButton.icon(
                    onPressed: _copyLog,
                    icon: const Icon(Icons.copy),
                    label: const Text('লগ কপি'),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () async {
                      await VpnChannel.engineClear();
                      await _poll();
                    },
                    child: const Text('মুছুন'),
                  ),
                ]),
                const SizedBox(height: 8),
                if (lines.isEmpty)
                  Text('এখনো কোনো লগ নেই', style: TextStyle(fontSize: 12.5, color: cs.outline))
                else
                  for (final l in lines.take(60))
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 1),
                      child: Text(l, style: const TextStyle(fontSize: 12, fontFamily: 'monospace')),
                    ),
              ]),
            ),
            const SizedBox(height: 16),
            Text(
              'মনে রাখবেন: শুধু বাছা অ্যাপে কাজ করে। যে অ্যাপ নিজের আলাদা DNS (DoH) চালায় তার বিজ্ঞাপন ডোমেইন দিয়ে '
              'আটকাবে না। প্রাইভেট DNS "বন্ধ" বা "অটোমেটিক" থাকলে ইঞ্জিন প্রশ্ন দেখতে পায়, হোস্টনেম বসানো থাকলে '
              'প্রশ্ন সরাসরি সেই সার্ভারে যায় (তখন সেই সার্ভারই আটকায়)। ইঞ্জিন চালু অ্যাপের নেট একটু ধীর হতে বা '
              'ব্যাটারি বেশি খেতে পারে।',
              style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConfirmDialog extends StatefulWidget {
  const _ConfirmDialog();

  @override
  State<_ConfirmDialog> createState() => _ConfirmDialogState();
}

class _ConfirmDialogState extends State<_ConfirmDialog> {
  int left = 30;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (left <= 1) {
        t.cancel();
        Navigator.of(context).pop(false);
      } else {
        setState(() => left--);
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('নেট চলছে তো?'),
        content: Text(
          'বাছা অ্যাপ খুলে একটা সাইট বা কিছু লোড করে দেখুন। চললে "চলছে" চাপুন। '
          '$left সেকেন্ডে না চাপলে ইঞ্জিন নিজে বন্ধ হবে।',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('চলছে না, বন্ধ করুন')),
          FilledButton(
              onPressed: () => Navigator.of(context).pop(true), child: const Text('চলছে')),
        ],
      );
}
