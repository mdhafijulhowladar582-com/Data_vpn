import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import 'app_list_screen.dart';
import 'lock_screen.dart';
import 'logs_screen.dart';
import 'schedule_screen.dart';
import 'usage_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  bool running = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    await store.load();
    final r = await VpnChannel.isRunning();
    if (mounted) setState(() => running = r);
  }

  Future<void> _toggle(bool on) async {
    if (on) {
      final ok = await VpnChannel.start();
      if (mounted) setState(() => running = ok);
    } else {
      await VpnChannel.stop();
      if (mounted) setState(() => running = false);
    }
  }

  Future<void> _setPin() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('নতুন পিন (কমপক্ষে ৪ সংখ্যা)'),
        content: TextField(
            controller: c, obscureText: true, keyboardType: TextInputType.number),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('সেভ')),
        ],
      ),
    );
    if (ok == true && c.text.length >= 4) {
      store.cfg.pinHash = hashPin(c.text);
      await store.save();
    }
  }

  void _go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Firewall')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final c = store.cfg;
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Card(
                color: running ? Colors.green.shade900 : null,
                child: SwitchListTile(
                  title: Text(running ? 'ফায়ারওয়াল চালু' : 'ফায়ারওয়াল বন্ধ',
                      style: const TextStyle(fontSize: 18)),
                  subtitle: Text(c.blockAll
                      ? 'সব অ্যাপ ব্লক'
                      : c.mode == 'whitelist'
                          ? 'হোয়াইটলিস্ট: বেছে নেওয়া অ্যাপ ছাড়া সব বন্ধ'
                          : 'ব্লকলিস্ট: বেছে নেওয়া অ্যাপ বন্ধ'),
                  value: running,
                  onChanged: _toggle,
                ),
              ),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'blocklist', label: Text('ব্লকলিস্ট')),
                  ButtonSegment(value: 'whitelist', label: Text('হোয়াইটলিস্ট')),
                ],
                selected: {c.mode},
                onSelectionChanged: (s) {
                  c.mode = s.first;
                  store.save();
                },
              ),
              SwitchListTile(
                title: const Text('সব ব্লক (এক ট্যাপ)'),
                subtitle: const Text('সব অ্যাপের নেট বন্ধ, আপনার নিয়ম ছাড়াই'),
                value: c.blockAll,
                onChanged: (v) {
                  c.blockAll = v;
                  store.save();
                },
              ),
              ListTile(
                leading: const Icon(Icons.apps),
                title: Text(c.mode == 'whitelist' ? 'অনুমতি পাবে যে অ্যাপগুলো' : 'অ্যাপ বেছে ব্লক করুন'),
                subtitle: Text(c.mode == 'whitelist'
                    ? '${c.allowed.length}টি অনুমতিপ্রাপ্ত'
                    : '${c.rules.length}টি ব্লক করা'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _go(const AppListScreen()),
              ),
              ListTile(
                leading: const Icon(Icons.schedule),
                title: const Text('শিডিউল'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _go(const ScheduleScreen()),
              ),
              ListTile(
                leading: const Icon(Icons.data_usage),
                title: const Text('ডেটা ব্যবহার (কে কত খেল)'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _go(const UsageScreen()),
              ),
              ListTile(
                leading: const Icon(Icons.list_alt),
                title: const Text('ব্লক লগ'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _go(const LogsScreen()),
              ),
              const Divider(),
              SwitchListTile(
                title: const Text('স্ক্রিন বন্ধ হলে সব ব্লক'),
                subtitle: const Text('সাবধান: স্ক্রিন অফে মেসেজ/অ্যালার্ট নেটও বন্ধ'),
                value: c.screenOffBlock,
                onChanged: (v) {
                  c.screenOffBlock = v;
                  store.save();
                },
              ),
              SwitchListTile(
                title: const Text('নতুন অ্যাপ ইনস্টল হলে ডিফল্টে ব্লক'),
                subtitle: const Text('ব্লকলিস্ট মোডে কাজ করে (হোয়াইটলিস্টে এমনিতেই ব্লক)'),
                value: c.blockNew,
                onChanged: (v) {
                  c.blockNew = v;
                  store.save();
                },
              ),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: Text(c.pinHash.isEmpty ? 'অ্যাপ লক (পিন) সেট করুন' : 'পিন বদলান'),
                onTap: _setPin,
                trailing: c.pinHash.isEmpty
                    ? null
                    : TextButton(
                        onPressed: () {
                          c.pinHash = '';
                          store.save();
                        },
                        child: const Text('পিন বাদ')),
              ),
            ],
          );
        },
      ),
    );
  }
}
