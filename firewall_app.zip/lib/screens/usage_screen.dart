import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';

class UsageScreen extends StatefulWidget {
  const UsageScreen({super.key});

  @override
  State<UsageScreen> createState() => _UsageScreenState();
}

class _UsageScreenState extends State<UsageScreen> with WidgetsBindingObserver {
  bool? has;
  bool loading = false;
  int range = 0;
  List<UsageEntry> data = [];
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load(); // অনুমতি দিয়ে ফিরলে
  }

  Future<void> _load() async {
    final h = await VpnChannel.hasUsageAccess();
    if (!mounted) return;
    if (!h) {
      setState(() => has = false);
      return;
    }
    setState(() {
      has = true;
      loading = true;
    });
    final apps = await store.loadApps();
    final d = await UsageService.fetch(range);
    if (!mounted) return;
    setState(() {
      names = {for (final a in apps) a.pkg: a.name};
      data = d;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (has == false) {
      return Scaffold(
        appBar: AppBar(title: const Text('ডেটা ব্যবহার')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text(
                  'কে কত ডেটা খেল দেখতে "Usage access" অনুমতি লাগবে। খুলে Firewall বেছে চালু করুন।',
                  textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                  onPressed: VpnChannel.openUsageAccess,
                  child: const Text('অনুমতি দিন')),
            ]),
          ),
        ),
      );
    }

    final wifi = data.fold<int>(0, (a, e) => a + e.wifi);
    final mob = data.fold<int>(0, (a, e) => a + e.mobile);
    final maxT = data.isEmpty ? 1 : data.first.total;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ডেটা ব্যবহার'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            for (final e in {0: 'আজ', 1: '৭ দিন', 2: '৩০ দিন'}.entries)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(e.value),
                  selected: range == e.key,
                  onSelected: (_) {
                    setState(() => range = e.key);
                    _load();
                  },
                ),
              ),
          ]),
        ),
        Card(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Text('মোট ${UsageService.fmt(wifi + mob)}',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('Wi-Fi ${UsageService.fmt(wifi)}   •   মোবাইল ডেটা ${UsageService.fmt(mob)}'),
            ]),
          ),
        ),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (c, i) {
                    final e = data[i];
                    return ListTile(
                      leading: AppIcon(e.pkg, size: 36),
                      title: Text(names[e.pkg] ?? e.pkg,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4),
                          LinearProgressIndicator(value: e.total / maxT),
                          const SizedBox(height: 4),
                          Text(
                              'Wi-Fi ${UsageService.fmt(e.wifi)} • ডেটা ${UsageService.fmt(e.mobile)}',
                              style: const TextStyle(fontSize: 11)),
                        ],
                      ),
                      trailing: Text(UsageService.fmt(e.total)),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
