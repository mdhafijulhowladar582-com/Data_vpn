import 'package:flutter/material.dart';
import '../services/log_service.dart';
import '../services/rules_storage.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';

class LogsTab extends StatefulWidget {
  const LogsTab({super.key});

  @override
  State<LogsTab> createState() => _LogsTabState();
}

class _LogsTabState extends State<LogsTab> {
  List<LogEntry> logs = [];
  Map<String, String> names = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final apps = await store.loadApps();
    final l = await LogService.fetch();
    if (!mounted) return;
    setState(() {
      names = {for (final a in apps) a.pkg: a.name};
      logs = l;
      loading = false;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  @override
  Widget build(BuildContext context) {
    final counts = <String, int>{};
    for (final e in logs) {
      counts[e.pkg] = (counts[e.pkg] ?? 0) + 1;
    }
    final top = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final wide = isWide(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('ব্লক লগ (${logs.length})'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              await LogService.clear();
              _load();
            },
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : logs.isEmpty
              ? const Center(child: Text('এখনো কোনো ব্লক চেষ্টা নেই'))
              : Column(children: [
                  SizedBox(
                    height: 48,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      children: [
                        for (final e in top.take(8))
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: Chip(
                                avatar: AppIcon(e.key, size: 18),
                                label: Text('${_name(e.key)}: ${e.value}')),
                          ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: wide ? 2 : 1,
                        mainAxisExtent: 68,
                        mainAxisSpacing: 8,
                        crossAxisSpacing: 8,
                      ),
                      itemCount: logs.length,
                      itemBuilder: (c, i) {
                        final e = logs[i];
                        return AppCard(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: Row(children: [
                            AppIcon(e.pkg, size: 34),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(_name(e.pkg),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.w600)),
                                  Text('${e.proto} → ${e.dst}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context).textTheme.bodySmall),
                                ],
                              ),
                            ),
                            Text(LogService.hms(e.time),
                                style: Theme.of(context).textTheme.bodySmall),
                          ]),
                        );
                      },
                    ),
                  ),
                ]),
    );
  }
}
