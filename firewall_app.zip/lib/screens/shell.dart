import 'package:flutter/material.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/common.dart';
import '../services/lock_service.dart';
import 'apps_tab.dart';
import 'data_tab.dart';
import 'focus_tab.dart';
import 'home_tab.dart';
import '../menu/registry.dart';
import 'report_page.dart';
import 'screen_time_tab.dart';

class _Dest {
  final IconData icon;
  final IconData selected;
  final String label;
  const _Dest(this.icon, this.selected, this.label);
}

const _dests = [
  _Dest(Icons.shield_outlined, Icons.shield, 'হোম'),
  _Dest(Icons.apps_outlined, Icons.apps, 'অ্যাপস'),
  _Dest(Icons.data_usage_outlined, Icons.data_usage, 'ডেটা'),
  _Dest(Icons.pie_chart_outline, Icons.pie_chart, 'স্ক্রিন টাইম'),
  _Dest(Icons.self_improvement_outlined, Icons.self_improvement, 'ফোকাস'),
];

/// ফোনে নিচে ৫ ট্যাব, ৭২০px+ এ পাশে সাইড-রেইল
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  int idx = 0;
  bool running = false;
  bool guard = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    await store.load();
    final r = await VpnChannel.isRunning();
    var g = false;
    try {
      g = await VpnChannel.isGuardEnabled();
    } catch (_) {}
    if (mounted) {
      setState(() {
        running = r;
        guard = g;
      });
    }
    await _checkRoute();
  }

  /// নোটিফিকেশন (সাপ্তাহিক রিপোর্ট বা সন্দেহজনক চেষ্টা) থেকে এলে রিপোর্ট পেজ খোলে
  Future<void> _checkRoute() async {
    String? r;
    try {
      r = await VpnChannel.takeLaunchRoute();
    } catch (_) {}
    if (r == 'report' && mounted) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ReportPage()));
    } else if (r != null && mounted) {
      openFeature(context, r); // নতুন টুলসের নোটিফিকেশন (রুট = ফিচারের id)
    }
  }

  Future<void> _toggle(bool on) async {
    if (on) {
      final ok = await VpnChannel.start();
      if (mounted) setState(() => running = ok);
    } else {
      if (!await Lock.ask(context, reason: 'ফায়ারওয়াল বন্ধ করতে যাচাই করুন')) return;
      final stopped = await VpnChannel.stop();
      final r = await VpnChannel.isRunning();
      if (!mounted) return;
      if (!stopped) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('ফোকাস চলছে, এখন বন্ধ করা যাবে না')));
      }
      setState(() => running = r);
    }
  }

  Widget _page() {
    switch (idx) {
      case 0:
        return HomeTab(
            running: running,
            guard: guard,
            onToggle: _toggle,
            onGo: (i) => setState(() => idx = i));
      case 1:
        return const AppsTab();
      case 2:
        return const DataTab();
      case 3:
        return const ScreenTimeTab();
      default:
        return const FocusTab();
    }
  }

  Widget _anim() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: KeyedSubtree(key: ValueKey(idx), child: _page()),
      );

  @override
  Widget build(BuildContext context) {
    if (isWide(context)) {
      return Scaffold(
        body: Row(children: [
          NavigationRail(
            selectedIndex: idx,
            labelType: NavigationRailLabelType.all,
            onDestinationSelected: (i) => setState(() => idx = i),
            destinations: [
              for (final d in _dests)
                NavigationRailDestination(
                    icon: Icon(d.icon),
                    selectedIcon: Icon(d.selected),
                    label: Text(d.label)),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: _anim()),
        ]),
      );
    }
    return Scaffold(
      body: _anim(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (i) => setState(() => idx = i),
        destinations: [
          for (final d in _dests)
            NavigationDestination(
                icon: Icon(d.icon), selectedIcon: Icon(d.selected), label: d.label),
        ],
      ),
    );
  }
}
