import 'package:flutter/material.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_picker.dart';
import '../widgets/common.dart';
import 'forgotten_page.dart';
import 'intruder_page.dart';

/// প্যানিক বাটন ও নজরদারির সব সুইচ এক পেজে
class SafetyPage extends StatefulWidget {
  const SafetyPage({super.key});

  @override
  State<SafetyPage> createState() => _SafetyPageState();
}

class _SafetyPageState extends State<SafetyPage> {
  bool _guest = false;
  bool _guardOn = false;

  @override
  void initState() {
    super.initState();
    _loadGuest();
  }

  Future<void> _loadGuest() async {
    var g = false;
    var on = false;
    try {
      g = await VpnChannel.guestOn();
      on = await VpnChannel.isGuardEnabled();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _guest = g;
      _guardOn = on;
    });
  }

  void _snack(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _toggleGuest(bool v) async {
    if (v) {
      if (!Lock.hasPin) {
        _snack('গেস্ট মোডের জন্য আগে সেটিংসে পিন দিন');
        return;
      }
      if (!_guardOn) {
        _snack('আগে অ্যাপ গার্ড (Accessibility) চালু করুন, নইলে অন্য অ্যাপ লক হবে না');
        return;
      }
      final okGo = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('গেস্ট মোড চালু করবেন?'),
          content: Text(store.cfg.guestApps.isEmpty
              ? 'এখন কোনো অ্যাপ বাছা নেই, তাই ফোনের সব অ্যাপ লক হবে (হোম আর ডায়ালার বাদে)। ফায়ারওয়াল অ্যাপ নিজে বন্ধ হয়ে যাবে।'
              : 'বাছা ${store.cfg.guestApps.length}টি অ্যাপ ছাড়া সব লক হবে। ফায়ারওয়াল অ্যাপ নিজে বন্ধ হয়ে যাবে।'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('চালু করুন')),
          ],
        ),
      );
      if (okGo != true) return;
      try {
        await VpnChannel.guestSet(true);
      } catch (_) {}
      return; // অ্যাপ বন্ধ হয়ে যায়
    }
    if (!await Lock.ask(context, reason: 'গেস্ট মোড বন্ধ করতে পিন দিন', force: true)) return;
    try {
      await VpnChannel.guestSet(false);
    } catch (_) {}
    await _loadGuest();
  }

  Future<void> _toggleIntruder(bool v) async {
    final c = store.cfg;
    if (v) {
      if (!Lock.hasPin) {
        _snack('আগে সেটিংসে পিন দিন, নইলে ভুল পিন বলে কিছু থাকে না');
        return;
      }
      bool granted = false;
      try {
        granted = await VpnChannel.camAsk();
      } catch (_) {}
      if (!granted) {
        _snack('ক্যামেরার অনুমতি না পেলে ছবি তোলা যাবে না');
        return;
      }
      setState(() => c.intruderPhoto = true);
      store.save();
      return;
    }
    if (!await Lock.ask(context, reason: 'বন্ধ করতে যাচাই করুন')) return;
    setState(() => c.intruderPhoto = false);
    store.save();
  }

  @override
  Widget build(BuildContext context) {
    final c = store.cfg;
    final cs = Theme.of(context).colorScheme;

    Future<bool> ok() => Lock.ask(context, reason: 'বন্ধ করতে যাচাই করুন');

    Widget group(List<Widget> kids) => AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: kids),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('প্যানিক ও নজরদারি')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          const SectionLabel('প্যানিক'),
          AppCard(
            color: cs.errorContainer.withAlpha(120),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('কেউ জোর করে ফোন চাইলে বা বিপদে এক ট্যাপে:',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              const Text('• ভল্ট ও লুকানো এলাকা বন্ধ, ভল্টের চাবি মেমরি থেকে সরানো\n'
                  '• লক করা অ্যাপ আবার লক\n'
                  '• ফায়ারওয়াল অ্যাপ বন্ধ হয়ে রিসেন্ট থেকেও সরে যায়, খুলতে পিন লাগবে'),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: cs.error, foregroundColor: cs.onError),
                  onPressed: VpnChannel.panicNow,
                  icon: const Icon(Icons.warning_amber_rounded),
                  label: const Text('এখনই প্যানিক'),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                  'ফোনের কুইক সেটিংস প্যানেল খুলে পেন্সিল (এডিট) চেপে "প্যানিক" টাইল যোগ করুন, তাহলে অ্যাপ না খুলেই এক ট্যাপে চলবে।',
                  style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
          const SizedBox(height: 8),
          group([
            SwitchListTile(
              title: const Text('প্যানিকে সব অ্যাপের নেটও বন্ধ'),
              subtitle: const Text('"সব ব্লক" চালু হয়ে যাবে। পরে অ্যাপ খুলে বন্ধ করলে নেট ফেরে'),
              value: c.panicNet,
              onChanged: (v) async {
                if (!v && !await ok()) return;
                setState(() => c.panicNet = v);
                store.save();
              },
            ),
          ]),
          const SizedBox(height: 8),
          group([
            SwitchListTile(
              title: const Text('ফোন ঝাঁকিয়ে প্যানিক'),
              subtitle: const Text('স্ক্রিন চালু থাকলে জোরে ৪ বার ঝাঁকালে চলবে। ফায়ারওয়াল চালু থাকা লাগে, আর ব্যাটারি সামান্য বেশি খায়'),
              value: c.panicShake,
              onChanged: (v) async {
                if (!v && !await ok()) return;
                setState(() => c.panicShake = v);
                store.save();
              },
            ),
          ]),
          const SectionLabel('নজরদারি'),
          group([
            ListTile(
              leading: const Icon(Icons.history_toggle_off),
              title: const Text('ভুলে যাওয়া অ্যাপ'),
              subtitle: const Text('৩০ দিন খোলা হয়নি অথচ ডেটা খাচ্ছে, এক ট্যাপে ব্লক'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const ForgottenPage())),
            ),
            SwitchListTile(
              secondary: const Icon(Icons.nights_stay_outlined),
              title: const Text('স্ক্রিন বন্ধে ডেটা পাঠানো ধরা'),
              subtitle: const Text(
                  'স্ক্রিন বন্ধ থাকা অবস্থায় কোনো অ্যাপ অনেক ডেটা পাঠালে নোটিফিকেশন ও "ব্লক করুন" বোতাম। ফায়ারওয়াল ও Usage access চালু থাকতে হবে'),
              value: c.leakWatch,
              onChanged: (v) async {
                if (!v && !await ok()) return;
                setState(() => c.leakWatch = v);
                store.save();
              },
            ),
            if (c.leakWatch)
              ListTile(
                title: const Text('কত ডেটা পাঠালে সতর্ক করবে'),
                trailing: DropdownButton<int>(
                  value: const [5, 10, 20, 50, 100].contains(c.leakMb) ? c.leakMb : 10,
                  items: [
                    for (final m in const [5, 10, 20, 50, 100])
                      DropdownMenuItem(value: m, child: Text('$m MB')),
                  ],
                  onChanged: (v) {
                    if (v == null) return;
                    setState(() => c.leakMb = v);
                    store.save();
                  },
                ),
              ),
            SwitchListTile(
              secondary: const Icon(Icons.key_outlined),
              title: const Text('আপডেটে নতুন পারমিশন ধরা'),
              subtitle: const Text(
                  'আপডেটের পর কোনো অ্যাপ ক্যামেরা, মাইক, লোকেশন, কন্টাক্টস, এসএমএস বা কল লগের অনুমতি চাইলে নোটিফিকেশন'),
              value: c.permWatch,
              onChanged: (v) async {
                if (!v && !await ok()) return;
                setState(() => c.permWatch = v);
                store.save();
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.new_releases_outlined),
              title: const Text('নতুন অ্যাপে আগে প্রশ্ন'),
              subtitle: const Text(
                  'নতুন অ্যাপ ইনস্টল হলেই নোটিফিকেশন: "ইন্টারনেট দেব, না ব্লক?" না বলা পর্যন্ত ওই অ্যাপের নেট বন্ধ। ফায়ারওয়াল চালু থাকলে কাজ করে'),
              value: c.askNew,
              onChanged: (v) async {
                if (!v && !await ok()) return;
                setState(() => c.askNew = v);
                store.save();
              },
            ),
          ]),
          const SectionLabel('স্ক্রিন বন্ধে অ্যাপ ব্লক'),
          group([
            ListTile(
              leading: const Icon(Icons.screen_lock_portrait_outlined),
              title: const Text('স্ক্রিন বন্ধে যাদের নেট বন্ধ'),
              subtitle: Text(c.screenOffApps.isEmpty
                  ? 'কোনো অ্যাপ বাছা নেই। স্ক্রিন জ্বললে নেট ফিরে আসে, ব্যাটারি আর ডেটা দুটোই বাঁচে'
                  : '${c.screenOffApps.length}টি অ্যাপ। স্ক্রিন জ্বললে নেট ফিরে আসে'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                final r = await pickApps(context,
                    title: 'স্ক্রিন বন্ধে নেট বন্ধ থাকবে যাদের', selected: c.screenOffApps);
                if (r == null) return;
                final next = r.toSet();
                if (c.screenOffApps.difference(next).isNotEmpty && !await ok()) return;
                setState(() => c.screenOffApps = next);
                store.save();
              },
            ),
          ]),
          const SectionLabel('ভুল পিন ও চোর ধরা'),
          group([
            SwitchListTile(
              secondary: const Icon(Icons.photo_camera_front_outlined),
              title: const Text('৩ বার ভুল পিনে চোরের ছবি'),
              subtitle: const Text(
                  'পরপর ৩, ৬, ৯... বার ভুল পিন দিলে সামনের ক্যামেরায় ছবি উঠে এনক্রিপ্ট হয়ে ভল্টে যায়। ক্যামেরার অনুমতি লাগে'),
              value: c.intruderPhoto,
              onChanged: _toggleIntruder,
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text('ভুল পিনের ইতিহাস'),
              subtitle: const Text('কতবার, কখন, কোন স্ক্রিনে ভুল পিন দেওয়া হয়েছে আর ছবিগুলো'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const IntruderPage())),
            ),
          ]),
          const SectionLabel('নকল পিন'),
          group([
            ListTile(
              leading: const Icon(Icons.theater_comedy_outlined),
              title: Text(c.decoyHash.isEmpty ? 'নকল পিন সেট করুন' : 'নকল পিন বদলান'),
              subtitle: const Text(
                  'লুকানো অ্যাপ এলাকা বা ভল্টে নকল পিন দিলে ভুয়া এলাকা খোলে (ভল্ট খালি দেখায়)। আসল পিন দিলে আসলটা। নকল পিন বসালে এই দুই জায়গায় ফিঙ্গারপ্রিন্ট বন্ধ থাকে'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                if (!Lock.hasPin) {
                  _snack('আগে সেটিংসে আসল পিন দিন');
                  return;
                }
                if (await setDecoyFlow(context)) {
                  if (mounted) setState(() {});
                  _snack('নকল পিন সেভ হয়েছে');
                }
              },
            ),
            if (c.decoyHash.isNotEmpty) ...[
              ListTile(
                leading: const Icon(Icons.apps_outlined),
                title: const Text('নকল এলাকায় যে অ্যাপ দেখাবে'),
                subtitle: Text(c.decoyApps.isEmpty
                    ? 'এখন খালি। নকল পিন দিয়ে ঢুকেও যোগ করা যায়'
                    : '${c.decoyApps.length}টি অ্যাপ'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final r = await pickApps(context,
                      title: 'নকল এলাকায় যা দেখাবে', selected: c.decoyApps);
                  if (r == null) return;
                  setState(() => c.decoyApps = r.toSet());
                  store.save();
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('নকল পিন বন্ধ করুন'),
                onTap: () async {
                  if (!await Lock.ask(context, reason: 'নকল পিন বন্ধ করতে যাচাই করুন', force: true)) return;
                  setState(() => c.decoyHash = '');
                  store.save();
                },
              ),
            ],
          ]),
          const SectionLabel('গেস্ট মোড'),
          group([
            SwitchListTile(
              secondary: const Icon(Icons.person_outline),
              title: const Text('গেস্ট মোড'),
              subtitle: const Text(
                  'কেউ ফোন চাইলে চালু করুন। বেছে দেওয়া অ্যাপ ছাড়া সব অ্যাপ (ফোনের সেটিংসসহ) পিন দিয়ে লক। ফায়ারওয়াল অ্যাপ বন্ধ হয়ে যায়, খুলতে পিন লাগে, লুকানো এলাকা ও ভল্ট বন্ধ। চালু করতে পিন লাগে না, বন্ধ করতে লাগে'),
              value: _guest,
              onChanged: _toggleGuest,
            ),
            ListTile(
              leading: const Icon(Icons.apps_outlined),
              title: const Text('গেস্ট যে অ্যাপ খুলতে পারবে'),
              subtitle: Text(c.guestApps.isEmpty
                  ? 'কোনো অ্যাপ বাছা নেই, চালু করলে সব লক হবে'
                  : '${c.guestApps.length}টি অ্যাপ'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                final r = await pickApps(context,
                    title: 'গেস্ট যা খুলতে পারবে', selected: c.guestApps);
                if (r == null) return;
                setState(() => c.guestApps = r.toSet());
                store.save();
              },
            ),
            if (!_guardOn)
              const ListTile(
                leading: Icon(Icons.warning_amber_rounded),
                title: Text('অ্যাপ গার্ড বন্ধ আছে'),
                subtitle: Text('গেস্ট মোড অন্য অ্যাপ লক করতে অ্যাপ গার্ড (Accessibility) ব্যবহার করে। আগে সেটা চালু করুন'),
              ),
          ]),
          const SizedBox(height: 8),
          Text(
              'কুইক সেটিংস প্যানেলে "গেস্ট" টাইল যোগ করলে অ্যাপ না খুলেই এক ট্যাপে গেস্ট মোড চালু হয়। বন্ধ করতে নোটিফিকেশন বা টাইল থেকে পিন দিতে হয়।',
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          Text(
              'লুকানো অ্যাপ এলাকা আর ভল্ট খোলা থাকলে ফোনের স্ক্রিনশট ও Recent অ্যাপের প্রিভিউ ফাঁকা দেখায়।',
              style: Theme.of(context).textTheme.bodySmall),
        ]),
      ),
    );
  }
}
