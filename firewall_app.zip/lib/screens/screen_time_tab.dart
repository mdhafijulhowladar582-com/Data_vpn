import 'package:flutter/material.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/screen_time_service.dart';
import '../services/vpn_channel.dart';
import '../widgets/app_tile.dart';
import '../widgets/common.dart';
import '../widgets/fx.dart';
import '../widgets/limit_sheet.dart';
import '../widgets/shell_actions.dart';
import '../widgets/usage_access.dart';

class ScreenTimeTab extends StatefulWidget {
  const ScreenTimeTab({super.key});

  @override
  State<ScreenTimeTab> createState() => _ScreenTimeTabState();
}

class _ScreenTimeTabState extends State<ScreenTimeTab> with WidgetsBindingObserver {
  bool? has;
  bool loading = false;
  int range = 0; // 0 আজ, 1 ৭ দিন, 2 ৩০ দিন
  int sel = -1;
  ScreenTimeData? d;
  Map<String, String> names = {};

  int get _n => const [1, 7, 30][range];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final h = await VpnChannel.hasUsageAccess();
    if (!mounted) return;
    if (!h) {
      setState(() => has = false);
      return;
    }
    setState(() {
      has = true;
      loading = true;
    });
    final apps = await store.loadApps();
    final data = await ScreenTimeService.fetch(force: true);
    if (!mounted) return;
    setState(() {
      names = {for (final a in apps) a.pkg: a.name};
      d = data;
      loading = false;
      sel = -1;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  // ---------- হেডার ----------

  Widget _header(ScreenTimeData d) {
    final n = _n;
    final total = d.sum(n);
    final title = range == 0
        ? 'আজকের স্ক্রিন টাইম'
        : range == 1
            ? 'গত ৭ দিনে মোট'
            : 'গত ৩০ দিনে মোট';
    final chips = <Widget>[];
    if (range == 0) {
      final y = d.days >= 2 ? d.total[d.days - 2] : 0;
      if (y > 0) {
        final diff = total - y;
        chips.add(GlassChip(
          diff > 0 ? Icons.arrow_upward : Icons.arrow_downward,
          'গতকালের চেয়ে ${fmtDur(diff.abs())} ${diff > 0 ? 'বেশি' : 'কম'} (গতকাল ${fmtDur(y)})',
        ));
      }
    } else {
      chips.add(GlassChip(Icons.timelapse, 'দিনে গড় ${fmtDur(total ~/ n)}'));
      if (range == 1) {
        final p = d.sumPrev(7);
        if (p > 0) {
          final pct = ((total - p) * 100 / p).round();
          chips.add(GlassChip(pct >= 0 ? Icons.trending_up : Icons.trending_down,
              'আগের সপ্তাহের চেয়ে ${pct.abs()}% ${pct >= 0 ? 'বেশি' : 'কম'}'));
        }
      }
    }
    return GradientCard(
      colors: stGradient,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.white70, fontSize: 14)),
        const SizedBox(height: 4),
        CountUp(
            value: total,
            fmt: fmtDur,
            style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: chips),
      ]),
    );
  }

  // ---------- চার্ট ----------

  Widget _chart(ScreenTimeData d) {
    final n = range == 2 ? 30 : 7;
    final vals = d.total.sublist(d.days - n);
    final starts = d.starts.sublist(d.days - n);
    final labels = <String>[];
    for (var i = 0; i < n; i++) {
      final dt = DateTime.fromMillisecondsSinceEpoch(starts[i]);
      if (n <= 7) {
        labels.add(weekdayNames[dt.weekday - 1]);
      } else {
        labels.add(i % 5 == 0 || i == n - 1 ? '${dt.day}' : '');
      }
    }
    final s = (sel < 0 || sel >= n) ? n - 1 : sel;
    final dt = DateTime.fromMillisecondsSinceEpoch(starts[s]);
    final dayIdx = d.days - n + s;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(n == 7 ? 'শেষ ৭ দিন' : 'শেষ ৩০ দিন',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const Spacer(),
          Text('${dt.day}/${dt.month}: ${fmtDur(vals[s])} • আনলক ${d.unlocks[dayIdx]}',
              style: Theme.of(context).textTheme.bodySmall),
        ]),
        const SizedBox(height: 12),
        BarChart(
          values: vals,
          labels: labels,
          selected: s,
          goal: store.cfg.goalMin * 60000,
          color: stGradient[0],
          onTap: (i) => setState(() => sel = i),
        ),
        const SizedBox(height: 4),
        Text('লাল লাইন = দৈনিক লক্ষ্য', style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }

  // ---------- ছোট স্ট্যাট ----------

  Widget _stats(ScreenTimeData d) {
    final n = _n;
    final top = d.topApps(n);
    final streak = d.streak(store.cfg.goalMin * 60000);
    return Row(children: [
      Expanded(child: MiniStat(Icons.lock_open, '${d.unlockSum(n)}', 'আনলক', const Color(0xFF0EA5E9))),
      const SizedBox(width: 10),
      Expanded(
          child: MiniStat(Icons.local_fire_department, '$streak দিন', 'টার্গেট স্ট্রিক',
              const Color(0xFFF97316))),
      const SizedBox(width: 10),
      Expanded(
          child: MiniStat(Icons.emoji_events_outlined, top.isEmpty ? '—' : _name(top.first.key),
              'সবচেয়ে বেশি সময়', const Color(0xFF8B5CF6))),
    ]);
  }

  // ---------- লক্ষ্য ----------

  Future<void> _editGoal() async {
    final cur = store.cfg.goalMin;
    var v = cur.clamp(30, 720).toDouble();
    final res = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('দৈনিক স্ক্রিন টাইম লক্ষ্য',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(fmtDur(v.round() * 60000),
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
            Slider(
                value: v,
                min: 30,
                max: 720,
                divisions: 23,
                onChanged: (x) => set(() => v = x)),
            SizedBox(
                width: double.infinity,
                child: FilledButton(
                    onPressed: () => Navigator.pop(ctx, v.round()), child: const Text('সেভ'))),
          ]),
        ),
      ),
    );
    if (res == null || !mounted) return;
    if (res > cur && !await Lock.ask(context, reason: 'লক্ষ্য বাড়াতে যাচাই করুন')) return;
    store.cfg.goalMin = res;
    await store.save();
    if (mounted) setState(() {});
  }

  Widget _goal(ScreenTimeData d) {
    final goal = store.cfg.goalMin * 60000;
    final today = d.total.last;
    final p = goal == 0 ? 0.0 : (today / goal).clamp(0.0, 1.0).toDouble();
    final over = today > goal;
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.flag_outlined),
          const SizedBox(width: 8),
          Expanded(
              child: Text('আজকের লক্ষ্য: ${fmtDur(goal)}',
                  style: const TextStyle(fontWeight: FontWeight.w700))),
          IconButton(onPressed: _editGoal, icon: const Icon(Icons.edit_outlined, size: 20)),
        ]),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: p),
            duration: const Duration(milliseconds: 800),
            builder: (_, v, __) => LinearProgressIndicator(
                value: v, minHeight: 12, color: over ? cs.error : const Color(0xFF22C55E)),
          ),
        ),
        const SizedBox(height: 6),
        Text(
            over
                ? 'লক্ষ্য ছাড়িয়েছে (${fmtDur(today - goal)} বেশি)'
                : 'আর ${fmtDur(goal - today)} বাকি',
            style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }

  // ---------- সাপ্তাহিক সারাংশ ----------

  Widget _weekly(ScreenTimeData d) {
    final total = d.sum(7);
    final prev = d.sumPrev(7);
    final top = d.topApps(7);
    var best = d.days - 7;
    var worst = d.days - 7;
    var lateNights = 0;
    for (var i = d.days - 7; i < d.days; i++) {
      if (d.total[i] > 0 && d.total[i] < d.total[best]) best = i;
      if (d.total[i] > d.total[worst]) worst = i;
      if (d.night[i] >= 15 * 60000) lateNights++;
    }
    String day(int i) =>
        weekdayNames[DateTime.fromMillisecondsSinceEpoch(d.starts[i]).weekday - 1];
    Widget row(IconData ic, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            Icon(ic, size: 18, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(child: Text(t)),
          ]),
        );
    String cmp = '';
    if (prev > 0) {
      final pct = ((total - prev) * 100 / prev).round();
      cmp = ' (আগের সপ্তাহের চেয়ে ${pct.abs()}% ${pct >= 0 ? 'বেশি' : 'কম'})';
    }
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('সাপ্তাহিক সারাংশ', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 8),
        row(Icons.timelapse, 'দিনে গড় ${fmtDur(total ~/ 7)}$cmp'),
        if (top.isNotEmpty)
          row(Icons.emoji_events_outlined, 'সবচেয়ে বেশি: ${_name(top.first.key)} (${fmtDur(top.first.value)})'),
        row(Icons.sentiment_satisfied_alt, 'সবচেয়ে কম: ${day(best)} (${fmtDur(d.total[best])})'),
        row(Icons.sentiment_dissatisfied, 'সবচেয়ে বেশি: ${day(worst)} (${fmtDur(d.total[worst])})'),
        row(Icons.lock_open, 'মোট আনলক: ${d.unlockSum(7)}'),
        row(Icons.bedtime_outlined, 'ঘুমের সময় ফোন চালিয়েছেন: $lateNights রাত'),
      ]),
    );
  }

  // ---------- অ্যাপ তালিকা ----------

  Widget _appList(ScreenTimeData d) {
    final list = d.topApps(_n);
    if (list.isEmpty) {
      return const Padding(
          padding: EdgeInsets.all(32), child: Center(child: Text('এই সময়ে কোনো ব্যবহার নেই')));
    }
    final maxT = list.first.value;
    final total = d.sum(_n);
    final cs = Theme.of(context).colorScheme;
    return Column(children: [
      for (var i = 0; i < list.length && i < 40; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: AppCard(
            padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
            child: Row(children: [
              AppIcon(list[i].key, size: 38),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(
                        child: Text(_name(list[i].key),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text(fmtDur(list[i].value), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: list[i].value / maxT),
                      duration: Duration(milliseconds: 500 + i * 40),
                      curve: Curves.easeOutCubic,
                      builder: (_, v, __) => LinearProgressIndicator(
                          value: v, minHeight: 6, color: stGradient[i % 2]),
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                      '${total == 0 ? 0 : (list[i].value * 100 / total).round()}%'
                      '${store.cfg.limits.containsKey(list[i].key) ? ' • ⏱ লিমিট ${store.cfg.limits[list[i].key]} মি' : ''}',
                      style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
              IconButton(
                tooltip: 'সময়সীমা',
                icon: Icon(
                    store.cfg.limits.containsKey(list[i].key) ? Icons.timer : Icons.timer_outlined,
                    color: store.cfg.limits.containsKey(list[i].key) ? cs.primary : cs.outline),
                onPressed: () async {
                  await showLimitSheet(context, list[i].key, _name(list[i].key));
                  if (mounted) setState(() {});
                },
              ),
            ]),
          ),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final appBar = AppBar(
      title: const Text('স্ক্রিন টাইম'),
      actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ...shellActions(context),
      ],
    );
    if (has == null) {
      return Scaffold(appBar: appBar, body: const Center(child: CircularProgressIndicator()));
    }
    if (has == false) return Scaffold(appBar: appBar, body: const UsageAccessPrompt());
    final data = d;
    return Scaffold(
      appBar: appBar,
      body: data == null || loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: Centered(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    SegmentedButton<int>(
                      segments: const [
                        ButtonSegment(value: 0, label: Text('আজ')),
                        ButtonSegment(value: 1, label: Text('৭ দিন')),
                        ButtonSegment(value: 2, label: Text('৩০ দিন')),
                      ],
                      selected: {range},
                      onSelectionChanged: (s) => setState(() {
                        range = s.first;
                        sel = -1;
                      }),
                    ),
                    const SizedBox(height: 12),
                    _header(data),
                    const SizedBox(height: 12),
                    _chart(data),
                    const SizedBox(height: 12),
                    _stats(data),
                    const SizedBox(height: 12),
                    _goal(data),
                    const SizedBox(height: 12),
                    _weekly(data),
                    const SectionLabel('অ্যাপ অনুযায়ী সময়'),
                    _appList(data),
                    if (range == 2)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                            'দ্রষ্টব্য: ফোন পুরনো দিনের বিস্তারিত রাখে না, তাই ~১ সপ্তাহের আগের দিনগুলো আনুমানিক।',
                            style: Theme.of(context).textTheme.bodySmall),
                      ),
                  ],
                ),
              ),
            ),
    );
  }
}
