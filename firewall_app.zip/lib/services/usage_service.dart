import 'vpn_channel.dart';

class UsageEntry {
  final String pkg;
  final int wifi;
  final int mobile;
  UsageEntry(this.pkg, this.wifi, this.mobile);
  int get total => wifi + mobile;
}

class UsageService {
  /// range: 0 আজ, 1 ৭ দিন, 2 ৩০ দিন
  static Future<List<UsageEntry>> fetch(int range) async {
    final now = DateTime.now();
    final from = range == 0
        ? DateTime(now.year, now.month, now.day)
        : now.subtract(Duration(days: range == 1 ? 7 : 30));
    final l = await VpnChannel.getUsage(from.millisecondsSinceEpoch);
    final out = l
        .map((m) => UsageEntry(
            m['pkg'] as String, (m['wifi'] as num).toInt(), (m['mobile'] as num).toInt()))
        .where((e) => e.total > 0)
        .toList();
    out.sort((a, b) => b.total.compareTo(a.total));
    return out;
  }

  static String fmt(int b) {
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
  }
}
