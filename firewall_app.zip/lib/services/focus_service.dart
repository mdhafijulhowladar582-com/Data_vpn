import 'vpn_channel.dart';

class FocusRec {
  final int t;
  final int m;
  final bool early;
  FocusRec(this.t, this.m, this.early);
}

class FocusInfo {
  final int until;
  final List<FocusRec> hist;
  FocusInfo(this.until, this.hist);

  int get _now => DateTime.now().millisecondsSinceEpoch;
  bool get active => until > _now;
  int get leftMs => active ? until - _now : 0;
  int get startMs => hist.isEmpty ? 0 : hist.last.t;
  int get totalMs => (startMs > 0 && until > startMs) ? until - startMs : 1;

  int get weekSessions {
    final from = _now - 7 * 86400000;
    return hist.where((e) => e.t >= from && e.m > 0).length;
  }

  int get weekMinutes {
    final from = _now - 7 * 86400000;
    return hist.where((e) => e.t >= from).fold<int>(0, (a, e) => a + e.m);
  }
}

class FocusService {
  static Future<FocusInfo> get() async {
    final m = await VpnChannel.getFocus();
    final h = <FocusRec>[];
    for (final e in (m['hist'] as List? ?? [])) {
      final x = Map<String, dynamic>.from(e as Map);
      h.add(FocusRec((x['t'] as num).toInt(), (x['m'] as num).toInt(), x['early'] == true));
    }
    return FocusInfo((m['until'] as num?)?.toInt() ?? 0, h);
  }
}
