import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'rules_storage.dart';
import 'vpn_channel.dart';

const _iters = 20000;

/// PBKDF2-HMAC-SHA256 (একটা ব্লক = ৩২ বাইট)
String _pbkdf2(String pin, List<int> salt) {
  final hmac = Hmac(sha256, utf8.encode(pin));
  var u = hmac.convert([...salt, 0, 0, 0, 1]).bytes;
  final out = List<int>.from(u);
  for (var i = 1; i < _iters; i++) {
    u = hmac.convert(u).bytes;
    for (var j = 0; j < out.length; j++) {
      out[j] ^= u[j];
    }
  }
  return base64Url.encode(out);
}

bool _constEq(String a, String b) {
  if (a.length != b.length) return false;
  var r = 0;
  for (var i = 0; i < a.length; i++) {
    r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
  }
  return r == 0;
}

/// নতুন হ্যাশ: p2$salt$hash (র‍্যান্ডম salt)
String hashPin(String pin) {
  final r = Random.secure();
  final salt = List<int>.generate(16, (_) => r.nextInt(256));
  return 'p2\$${base64Url.encode(salt)}\$${_pbkdf2(pin, salt)}';
}

bool checkPin(String pin, String stored) {
  if (stored.startsWith('p2\$')) {
    final p = stored.split('\$');
    if (p.length != 3) return false;
    try {
      return _constEq(_pbkdf2(pin, base64Url.decode(p[1])), p[2]);
    } catch (_) {
      return false;
    }
  }
  // পুরনো দুর্বল হ্যাশ (সফল হলে নতুনে আপগ্রেড হবে)
  var h = 7;
  for (final c in pin.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return _constEq(h.toString(), stored);
}

enum PinResult { ok, wrong, locked, decoy }

/// লুকানো এলাকা ও ভল্টের দরজার ফল: আসল পিন, নকল পিন, বা ঢোকা হয়নি
enum Gate { denied, real, decoy }

class Lock {
  static int _untilMs = 0; // শুধু কাউন্টডাউন দেখানোর আয়না; আসল গোনা ও সময় ফোনে সেভ (Kotlin)
  static int _graceMs = 0;
  static final LocalAuthentication _auth = LocalAuthentication();

  static int get _now => DateTime.now().millisecondsSinceEpoch;
  static bool get hasPin => store.cfg.pinHash.isNotEmpty;
  static bool get inGrace => _now < _graceMs;

  static int get lockLeftSec {
    final d = _untilMs - _now;
    return d > 0 ? (d / 1000).ceil() : 0;
  }

  /// যাচাইয়ের পর ২ মিনিট আর জিজ্ঞেস করবে না
  static void grace() => _graceMs = _now + 120000;
  static void resetGrace() => _graceMs = 0;

  /// ফোনে সেভ করা লকের অবস্থা এনে আয়না মেলায়
  static Future<void> sync() async {
    try {
      final left = await VpnChannel.pinLeftSec();
      _untilMs = left > 0 ? _now + left * 1000 : 0;
    } catch (_) {}
  }

  /// where = ভুল পিনের ইতিহাসে কোন স্ক্রিনে ভুল হলো সেই লেখা।
  /// allowDecoy = true হলে নকল পিন চিনবে (শুধু লুকানো এলাকা ও ভল্টের দরজায়)। অন্য কোথাও নকল পিন ভুল গোনা হয়।
  static Future<PinResult> tryPin(String pin, {String where = '', bool allowDecoy = false}) async {
    await sync();
    if (lockLeftSec > 0) return PinResult.locked;
    if (checkPin(pin, store.cfg.pinHash)) {
      try {
        await VpnChannel.pinOk();
      } catch (_) {}
      _untilMs = 0;
      grace();
      if (!store.cfg.pinHash.startsWith('p2\$')) {
        store.cfg.pinHash = hashPin(pin);
        store.save();
      }
      return PinResult.ok;
    }
    if (allowDecoy && store.cfg.decoyHash.isNotEmpty && checkPin(pin, store.cfg.decoyHash)) {
      return PinResult.decoy; // ভুল হিসেবে গোনা হয় না
    }
    int left = 0;
    try {
      left = await VpnChannel.pinFail(where);
    } catch (_) {}
    if (left > 0) {
      _untilMs = _now + left * 1000;
      return PinResult.locked;
    }
    return PinResult.wrong;
  }

  /// লুকানো এলাকা ও ভল্টের দরজা। সবসময় পিন চায় (২ মিনিটের ছাড় ধরে না)।
  /// নকল পিন সেট থাকলে ফিঙ্গারপ্রিন্ট বন্ধ, নইলে জোর করে আঙুল দিয়ে আসল এলাকা খোলানো যেত।
  static Future<Gate> gate(BuildContext context, {required String reason}) async {
    var res = Gate.denied;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(24, 0, 24, 24 + MediaQuery.of(ctx).viewInsets.bottom),
        child: PinEntry(
          reason: reason,
          autoBio: true,
          bio: store.cfg.decoyHash.isEmpty,
          allowDecoy: true,
          onOk: () {
            res = Gate.real;
            Navigator.pop(ctx);
          },
          onDecoy: () {
            res = Gate.decoy;
            Navigator.pop(ctx);
          },
        ),
      ),
    );
    return res;
  }

  /// গেস্ট মোড চালু থাকলে লুকানো এলাকা ও ভল্ট খোলা যায় না। চালু থাকলে true (আর মেসেজ দেখায়)
  static Future<bool> guestBlocks(BuildContext context) async {
    var on = false;
    try {
      on = await VpnChannel.guestOn();
    } catch (_) {}
    if (on && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('গেস্ট মোড চালু আছে। আগে গেস্ট মোড বন্ধ করুন (সেটিংস > প্যানিক, নজরদারি ও সতর্কতা)')));
    }
    return on;
  }

  static Future<bool> bioAvailable() async {
    try {
      return await _auth.canCheckBiometrics && (await _auth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> bioRaw(String reason) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }

  static Future<bool> bio(String reason) async {
    if (!store.cfg.bio) return false;
    return bioRaw(reason);
  }

  /// সংবেদনশীল কাজের আগে যাচাই। পিন না থাকলে সরাসরি true
  /// force = true হলে ২ মিনিটের ছাড় ধরা হয় না, সবসময় পিন চায়
  static Future<bool> ask(BuildContext context,
      {String reason = 'নিশ্চিত করুন', bool force = false}) async {
    if (!hasPin || (inGrace && !force)) return true;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(24, 0, 24, 24 + MediaQuery.of(ctx).viewInsets.bottom),
        child: PinEntry(reason: reason, autoBio: true, onOk: () => Navigator.pop(ctx, true)),
      ),
    );
    return ok == true;
  }
}

class PinEntry extends StatefulWidget {
  final String reason;
  final bool autoBio;
  final VoidCallback onOk;
  final bool allowDecoy; // নকল পিন চিনবে কিনা
  final VoidCallback? onDecoy;
  final bool bio; // false হলে ফিঙ্গারপ্রিন্ট বাটন ও অটো-চালু বন্ধ
  const PinEntry({
    super.key,
    required this.reason,
    required this.onOk,
    this.autoBio = false,
    this.allowDecoy = false,
    this.onDecoy,
    this.bio = true,
  });

  @override
  State<PinEntry> createState() => _PinEntryState();
}

class _PinEntryState extends State<PinEntry> {
  final _c = TextEditingController();
  Timer? _t;
  bool _wrong = false;

  bool get _useBio => widget.bio && store.cfg.bio;

  @override
  void initState() {
    super.initState();
    Lock.sync().then((_) {
      if (!mounted) return;
      setState(() {});
      if (Lock.lockLeftSec > 0) _startTicker();
    });
    if (widget.autoBio && _useBio) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  void _startTicker() {
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {});
      if (Lock.lockLeftSec <= 0) _t?.cancel();
    });
  }

  Future<void> _bio() async {
    final ok = await Lock.bio(widget.reason);
    if (ok && mounted) {
      Lock.grace();
      widget.onOk();
    }
  }

  Future<void> _check() async {
    final r = await Lock.tryPin(_c.text, where: widget.reason, allowDecoy: widget.allowDecoy);
    _c.clear();
    if (!mounted) return;
    if (r == PinResult.ok) {
      widget.onOk();
      return;
    }
    if (r == PinResult.decoy) {
      widget.onDecoy?.call();
      return;
    }
    setState(() => _wrong = r == PinResult.wrong);
    if (Lock.lockLeftSec > 0) _startTicker();
  }

  @override
  Widget build(BuildContext context) {
    final left = Lock.lockLeftSec;
    final cs = Theme.of(context).colorScheme;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.lock_outline, size: 48, color: cs.primary),
        const SizedBox(height: 12),
        Text(widget.reason, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 16),
        TextField(
          controller: _c,
          obscureText: true,
          autofocus: !(widget.autoBio && _useBio),
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          enabled: left == 0,
          onSubmitted: (_) => _check(),
          decoration: InputDecoration(
            labelText: 'পিন দিন',
            errorText: left > 0
                ? 'অনেকবার ভুল, $left সেকেন্ড পরে চেষ্টা করুন'
                : (_wrong ? 'ভুল পিন' : null),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: FilledButton(onPressed: left == 0 ? _check : null, child: const Text('যাচাই')),
        ),
        if (_useBio)
          TextButton.icon(
            onPressed: _bio,
            icon: const Icon(Icons.fingerprint),
            label: const Text('ফিঙ্গারপ্রিন্ট দিয়ে খুলুন'),
          ),
      ],
    );
  }
}

/// নতুন পিন বসানোর ডায়ালগ (আগে থেকে পিন থাকলে পুরনোটা যাচাই)। সেভ হলে true।
Future<bool> setPinFlow(BuildContext context) async {
  if (!await Lock.ask(context, reason: 'পিন বদলাতে যাচাই করুন')) return false;
  if (!context.mounted) return false;
  final c = TextEditingController();
  final c2 = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('নতুন পিন (কমপক্ষে ৪ সংখ্যা)'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
            controller: c,
            obscureText: true,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'নতুন পিন')),
        TextField(
            controller: c2,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'আবার লিখুন')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('সেভ')),
      ],
    ),
  );
  if (ok != true || !context.mounted) return false;
  if (c.text.length < 4 || c.text != c2.text) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('পিন কমপক্ষে ৪ সংখ্যা ও দুইবার একই হতে হবে')));
    return false;
  }
  if (store.cfg.decoyHash.isNotEmpty && checkPin(c.text, store.cfg.decoyHash)) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('এটা নকল পিনের মতো। আসল পিন আলাদা হতে হবে')));
    return false;
  }
  store.cfg.pinHash = hashPin(c.text);
  await store.save();
  Lock.grace();
  return true;
}

/// নকল পিন বসানো/বদলানো (আসল পিন দিয়ে যাচাইয়ের পর)। সেভ হলে true।
Future<bool> setDecoyFlow(BuildContext context) async {
  if (!Lock.hasPin) return false;
  if (!await Lock.ask(context, reason: 'নকল পিন বদলাতে আসল পিন দিন', force: true)) return false;
  if (!context.mounted) return false;
  final c = TextEditingController();
  final c2 = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('নকল পিন (কমপক্ষে ৪ সংখ্যা)'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
            controller: c,
            obscureText: true,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'নকল পিন')),
        TextField(
            controller: c2,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'আবার লিখুন')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('সেভ')),
      ],
    ),
  );
  if (ok != true || !context.mounted) return false;
  if (c.text.length < 4 || c.text != c2.text) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('পিন কমপক্ষে ৪ সংখ্যা ও দুইবার একই হতে হবে')));
    return false;
  }
  if (checkPin(c.text, store.cfg.pinHash)) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('নকল পিন আসল পিনের থেকে আলাদা হতে হবে')));
    return false;
  }
  store.cfg.decoyHash = hashPin(c.text);
  await store.save();
  return true;
}
