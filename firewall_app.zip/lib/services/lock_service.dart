import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'rules_storage.dart';

const _iters = 20000;

/// PBKDF2-HMAC-SHA256 (একটা ব্লক = ৩২ বাইট)
String _pbkdf2(String pin, List<int> salt) {
  final hmac = Hmac(sha256, utf8.encode(pin));
  var u = hmac.convert([...salt, 0, 0, 0, 1]).bytes;
  final out = List<int>.from(u);
  for (var i = 1; i < _iters; i++) {
    u = hmac.convert(u).bytes;
    for (var j = 0; j < out.length; j++) {
      out[j] ^= u[j];
    }
  }
  return base64Url.encode(out);
}

bool _constEq(String a, String b) {
  if (a.length != b.length) return false;
  var r = 0;
  for (var i = 0; i < a.length; i++) {
    r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
  }
  return r == 0;
}

/// নতুন হ্যাশ: p2$salt$hash (র‍্যান্ডম salt)
String hashPin(String pin) {
  final r = Random.secure();
  final salt = List<int>.generate(16, (_) => r.nextInt(256));
  return 'p2\$${base64Url.encode(salt)}\$${_pbkdf2(pin, salt)}';
}

bool checkPin(String pin, String stored) {
  if (stored.startsWith('p2\$')) {
    final p = stored.split('\$');
    if (p.length != 3) return false;
    try {
      return _constEq(_pbkdf2(pin, base64Url.decode(p[1])), p[2]);
    } catch (_) {
      return false;
    }
  }
  // পুরনো দুর্বল হ্যাশ (সফল হলে নতুনে আপগ্রেড হবে)
  var h = 7;
  for (final c in pin.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return _constEq(h.toString(), stored);
}

enum PinResult { ok, wrong, locked }

class Lock {
  static int _fails = 0;
  static int _untilMs = 0;
  static int _graceMs = 0;
  static final LocalAuthentication _auth = LocalAuthentication();

  static int get _now => DateTime.now().millisecondsSinceEpoch;
  static bool get hasPin => store.cfg.pinHash.isNotEmpty;
  static bool get inGrace => _now < _graceMs;

  static int get lockLeftSec {
    final d = _untilMs - _now;
    return d > 0 ? (d / 1000).ceil() : 0;
  }

  /// যাচাইয়ের পর ২ মিনিট আর জিজ্ঞেস করবে না
  static void grace() => _graceMs = _now + 120000;
  static void resetGrace() => _graceMs = 0;

  static PinResult tryPin(String pin) {
    if (lockLeftSec > 0) return PinResult.locked;
    if (checkPin(pin, store.cfg.pinHash)) {
      _fails = 0;
      grace();
      if (!store.cfg.pinHash.startsWith('p2\$')) {
        store.cfg.pinHash = hashPin(pin);
        store.save();
      }
      return PinResult.ok;
    }
    _fails++;
    if (_fails % 5 == 0) {
      final step = min(5, _fails ~/ 5 - 1);
      final secs = min(900, 30 * (1 << step));
      _untilMs = _now + secs * 1000;
      return PinResult.locked;
    }
    return PinResult.wrong;
  }

  static Future<bool> bioAvailable() async {
    try {
      return await _auth.canCheckBiometrics && (await _auth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> bioRaw(String reason) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }

  static Future<bool> bio(String reason) async {
    if (!store.cfg.bio) return false;
    return bioRaw(reason);
  }

  /// সংবেদনশীল কাজের আগে যাচাই। পিন না থাকলে সরাসরি true
  static Future<bool> ask(BuildContext context, {String reason = 'নিশ্চিত করুন'}) async {
    if (!hasPin || inGrace) return true;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(24, 0, 24, 24 + MediaQuery.of(ctx).viewInsets.bottom),
        child: PinEntry(reason: reason, autoBio: true, onOk: () => Navigator.pop(ctx, true)),
      ),
    );
    return ok == true;
  }
}

class PinEntry extends StatefulWidget {
  final String reason;
  final bool autoBio;
  final VoidCallback onOk;
  const PinEntry({super.key, required this.reason, required this.onOk, this.autoBio = false});

  @override
  State<PinEntry> createState() => _PinEntryState();
}

class _PinEntryState extends State<PinEntry> {
  final _c = TextEditingController();
  Timer? _t;
  bool _wrong = false;

  @override
  void initState() {
    super.initState();
    if (Lock.lockLeftSec > 0) _startTicker();
    if (widget.autoBio && store.cfg.bio) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  void _startTicker() {
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {});
      if (Lock.lockLeftSec <= 0) _t?.cancel();
    });
  }

  Future<void> _bio() async {
    final ok = await Lock.bio(widget.reason);
    if (ok && mounted) {
      Lock.grace();
      widget.onOk();
    }
  }

  void _check() {
    final r = Lock.tryPin(_c.text);
    _c.clear();
    if (r == PinResult.ok) {
      widget.onOk();
      return;
    }
    setState(() => _wrong = r == PinResult.wrong);
    if (Lock.lockLeftSec > 0) _startTicker();
  }

  @override
  Widget build(BuildContext context) {
    final left = Lock.lockLeftSec;
    final cs = Theme.of(context).colorScheme;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.lock_outline, size: 48, color: cs.primary),
        const SizedBox(height: 12),
        Text(widget.reason, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 16),
        TextField(
          controller: _c,
          obscureText: true,
          autofocus: !(widget.autoBio && store.cfg.bio),
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          enabled: left == 0,
          onSubmitted: (_) => _check(),
          decoration: InputDecoration(
            labelText: 'পিন দিন',
            errorText: left > 0
                ? 'অনেকবার ভুল, $left সেকেন্ড পরে চেষ্টা করুন'
                : (_wrong ? 'ভুল পিন' : null),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: FilledButton(onPressed: left == 0 ? _check : null, child: const Text('যাচাই')),
        ),
        if (store.cfg.bio)
          TextButton.icon(
            onPressed: _bio,
            icon: const Icon(Icons.fingerprint),
            label: const Text('ফিঙ্গারপ্রিন্ট দিয়ে খুলুন'),
          ),
      ],
    );
  }
}
