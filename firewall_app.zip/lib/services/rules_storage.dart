import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/app_info.dart';
import '../models/rule.dart';
import 'vpn_channel.dart';

/// সব নিয়ম এখানে। সেভ হয় Kotlin-এর SharedPreferences-এ (boot/tile-ও যেন পড়তে পারে)।
class RulesStore extends ChangeNotifier {
  Config cfg = Config();
  List<AppInfo>? _apps;
  Timer? _t;

  Future<void> load() async {
    final s = await VpnChannel.loadConfig();
    if (s.isNotEmpty) {
      try {
        cfg = Config.fromJson(jsonDecode(s) as Map<String, dynamic>);
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<List<AppInfo>> loadApps() async {
    _apps ??= (await VpnChannel.getApps()).map(AppInfo.fromMap).toList();
    return _apps!;
  }

  Future<void> save() async {
    _t?.cancel();
    await VpnChannel.saveConfig(jsonEncode(cfg.toJson()));
    notifyListeners();
  }

  /// বারবার ট্যাপে VPN বারবার না রিস্টার্ট হয়, তাই একটু দেরি করে সেভ
  void saveSoon() {
    notifyListeners();
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 600), save);
  }

  Rule ruleOf(String pkg) => cfg.rules[pkg] ?? Rule();

  void setRule(String pkg, {bool? wifi, bool? mobile}) {
    final r = ruleOf(pkg);
    r.wifi = wifi ?? r.wifi;
    r.mobile = mobile ?? r.mobile;
    if (r.any) {
      cfg.rules[pkg] = r;
    } else {
      cfg.rules.remove(pkg);
    }
    saveSoon();
  }

  void setLimit(String pkg, int minutes) {
    cfg.limits[pkg] = minutes;
    saveSoon();
  }

  void removeLimit(String pkg) {
    cfg.limits.remove(pkg);
    saveSoon();
  }

  Future<void> setFocusAllowed(Set<String> s) {
    cfg.focusAllowed = s;
    return save();
  }

  void setAllowed(String pkg, bool v) {
    if (v) {
      cfg.allowed.add(pkg);
    } else {
      cfg.allowed.remove(pkg);
    }
    saveSoon();
  }
}

final store = RulesStore();
