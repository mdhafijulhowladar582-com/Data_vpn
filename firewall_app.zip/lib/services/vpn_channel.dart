import 'dart:typed_data';
import 'package:flutter/services.dart';

class VpnChannel {
  static const _ch = MethodChannel('firewall/vpn');
  static final Map<String, Future<Uint8List?>> _icons = {};

  static Future<List<Map<String, dynamic>>> getApps() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getApps');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<Uint8List?> icon(String pkg) => _icons.putIfAbsent(
      pkg, () => _ch.invokeMethod<Uint8List>('getIcon', {'pkg': pkg}));

  static Future<bool> start() async =>
      (await _ch.invokeMethod<bool>('start')) ?? false;

  static Future<void> stop() async {
    await _ch.invokeMethod('stop');
  }

  static Future<bool> isRunning() async =>
      (await _ch.invokeMethod<bool>('isRunning')) ?? false;

  static Future<String> loadConfig() async =>
      (await _ch.invokeMethod<String>('loadConfig')) ?? '';

  static Future<void> saveConfig(String json) async {
    await _ch.invokeMethod('saveConfig', {'json': json});
  }

  static Future<List<Map<String, dynamic>>> getLogs() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getLogs');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<void> clearLogs() async {
    await _ch.invokeMethod('clearLogs');
  }

  static Future<bool> hasUsageAccess() async =>
      (await _ch.invokeMethod<bool>('hasUsageAccess')) ?? false;

  static Future<void> openUsageAccess() async {
    await _ch.invokeMethod('openUsageAccess');
  }

  static Future<List<Map<String, dynamic>>> getUsage(int fromMs) async {
    final r = await _ch.invokeMethod<List<dynamic>>('getUsage', {'from': fromMs});
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}
