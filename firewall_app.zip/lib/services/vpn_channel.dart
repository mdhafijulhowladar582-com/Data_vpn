import 'dart:typed_data';
import 'package:flutter/services.dart';

class VpnChannel {
  static const _ch = MethodChannel('firewall/vpn');
  static final Map<String, Future<Uint8List?>> _icons = {};

  static Future<List<Map<String, dynamic>>> getApps() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getApps');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<Uint8List?> icon(String pkg) => _icons.putIfAbsent(
      pkg, () => _ch.invokeMethod<Uint8List>('getIcon', {'pkg': pkg}));

  static Future<bool> start() async =>
      (await _ch.invokeMethod<bool>('start')) ?? false;

  /// false = ফোকাস চলছে বলে বন্ধ হয়নি
  static Future<bool> stop() async =>
      (await _ch.invokeMethod<bool>('stop')) ?? true;

  static Future<bool> isRunning() async =>
      (await _ch.invokeMethod<bool>('isRunning')) ?? false;

  static Future<String> loadConfig() async =>
      (await _ch.invokeMethod<String>('loadConfig')) ?? '';

  static Future<void> saveConfig(String json) async {
    await _ch.invokeMethod('saveConfig', {'json': json});
  }

  static Future<List<Map<String, dynamic>>> getLogs() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getLogs');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<void> clearLogs() async {
    await _ch.invokeMethod('clearLogs');
  }

  static Future<bool> hasUsageAccess() async =>
      (await _ch.invokeMethod<bool>('hasUsageAccess')) ?? false;

  static Future<void> openUsageAccess() async {
    await _ch.invokeMethod('openUsageAccess');
  }

  static Future<void> openAppSettings() async {
    await _ch.invokeMethod('openAppSettings');
  }

  static Future<Map<String, dynamic>> getScreenTime(int days, int ns, int ne) async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>(
        'getScreenTime', {'days': days, 'ns': ns, 'ne': ne});
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  static Future<bool> startFocus(int minutes) async =>
      (await _ch.invokeMethod<bool>('startFocus', {'minutes': minutes})) ?? false;

  static Future<bool> endFocus() async =>
      (await _ch.invokeMethod<bool>('endFocus')) ?? false;

  static Future<Map<String, dynamic>> getFocus() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getFocus');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// অ্যাপ গার্ড (Accessibility Service) চালু আছে কিনা
  static Future<bool> isGuardEnabled() async =>
      (await _ch.invokeMethod<bool>('isGuardEnabled')) ?? false;

  static Future<void> openAccessibility() async {
    await _ch.invokeMethod('openAccessibility');
  }

  /// {used: বাইট, extra: বাড়তি MB, from: গণনার শুরু (ms), apps: [{pkg, used}]}
  static Future<Map<String, dynamic>> getDataStatus() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getDataStatus');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// এই পিরিয়ডের জন্য ফোনের ডেটা লিমিটে আরও [mb] MB
  static Future<void> addDataExtra(int mb) async {
    await _ch.invokeMethod('addDataExtra', {'mb': mb});
  }

  static Future<List<Map<String, dynamic>>> getUsage(int fromMs) async {
    final r = await _ch.invokeMethod<List<dynamic>>('getUsage', {'from': fromMs});
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  // ---------- ফাইল ভল্ট ----------

  /// "ready" | "restore" (চাবি হারানো, ব্যাকআপ কী লাগবে) | "unsupported"
  static Future<String> vaultStatus() async =>
      (await _ch.invokeMethod<String>('vaultStatus')) ?? 'unsupported';

  /// [{id, name, size, added, mime}] নতুন আগে
  static Future<List<Map<String, dynamic>>> vaultList() async {
    final r = await _ch.invokeMethod<List<dynamic>>('vaultList');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// ফাইল বাছাই ও ভল্টে ঢোকানো। বাতিল করলে null, নইলে {added, failed, deleted}
  static Future<Map<String, dynamic>?> vaultPick(bool deleteOriginal) async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>(
        'vaultPick', {'deleteOriginal': deleteOriginal});
    return r == null ? null : Map<String, dynamic>.from(r);
  }

  /// "ok" | "no_app" | "error"
  static Future<String> vaultOpen(String id) async =>
      (await _ch.invokeMethod<String>('vaultOpen', {'id': id})) ?? 'error';

  static Future<String> vaultShare(String id) async =>
      (await _ch.invokeMethod<String>('vaultShare', {'id': id})) ?? 'error';

  static Future<bool> vaultDelete(String id) async =>
      (await _ch.invokeMethod<bool>('vaultDelete', {'id': id})) ?? false;

  static Future<String> vaultBackupKey() async =>
      (await _ch.invokeMethod<String>('vaultBackupKey')) ?? '';

  static Future<bool> vaultRestoreKey(String key) async =>
      (await _ch.invokeMethod<bool>('vaultRestoreKey', {'key': key})) ?? false;

  /// ডিক্রিপ্ট করা অস্থায়ী কপি মোছে
  static Future<void> vaultClean() async {
    await _ch.invokeMethod('vaultClean');
  }

  /// স্ক্রিনশট/রিসেন্টস প্রিভিউ বন্ধ (FLAG_SECURE)
  static Future<void> setSecure(bool on) async {
    await _ch.invokeMethod('setSecure', {'on': on});
  }
}
