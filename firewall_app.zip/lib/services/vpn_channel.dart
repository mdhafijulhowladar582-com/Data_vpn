import 'dart:typed_data';
import 'package:flutter/services.dart';

class VpnChannel {
  static const _ch = MethodChannel('firewall/vpn');
  static final Map<String, Future<Uint8List?>> _icons = {};

  static Future<List<Map<String, dynamic>>> getApps() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getApps');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<Uint8List?> icon(String pkg) => _icons.putIfAbsent(
      pkg, () => _ch.invokeMethod<Uint8List>('getIcon', {'pkg': pkg}));

  /// [{pkg, trackers: [নাম]}] শুধু যে অ্যাপে অন্তত একটা বিজ্ঞাপন/ট্র্যাকার SDK আছে
  static Future<List<Map<String, dynamic>>> scanTrackers() async {
    final r = await _ch.invokeMethod<List<dynamic>>('scanTrackers');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// {supported, found, active, host}: ফোনের Private DNS এখন কেমন (VPN বাদে আসল নেটওয়ার্ক)
  static Future<Map<String, dynamic>> getPrivateDns() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getPrivateDns');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// ফোনের নেটওয়ার্ক সেটিংস খোলে (Private DNS পেজে সরাসরি যাওয়ার নির্ভরযোগ্য উপায় নেই)
  static Future<void> openNetworkSettings() async {
    await _ch.invokeMethod('openNetworkSettings');
  }

  /// ইঞ্জিনের অবস্থা: {supported, on, confirmBy, fwRunning, running, queries, blocked, tcp, udp, errors, builtinCount, lines}
  static Future<Map<String, dynamic>> getEngine() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getEngine');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// on = true হলে সুইচ চালু ও ৩০ সেকেন্ডের নিশ্চিতকরণ শুরু। false = ফোনে সাপোর্ট নেই
  static Future<bool> engineSet(bool on) async =>
      (await _ch.invokeMethod<bool>('engineSet', {'on': on})) ?? false;

  static Future<void> engineConfirm() async {
    await _ch.invokeMethod('engineConfirm');
  }

  static Future<void> engineClear() async {
    await _ch.invokeMethod('engineClear');
  }

  static Future<bool> start() async =>
      (await _ch.invokeMethod<bool>('start')) ?? false;

  /// false = ফোকাস চলছে বলে বন্ধ হয়নি
  static Future<bool> stop() async =>
      (await _ch.invokeMethod<bool>('stop')) ?? true;

  static Future<bool> isRunning() async =>
      (await _ch.invokeMethod<bool>('isRunning')) ?? false;

  /// অ্যাপ খোলে (হোমে আইকন না থাকলেও চলে)। খোলা না গেলে false
  static Future<bool> launchApp(String pkg) async =>
      (await _ch.invokeMethod<bool>('launchApp', {'pkg': pkg})) ?? false;

  /// Work Profile: {state: ready|unsupported, reason, profiles}
  static Future<Map<String, dynamic>> wpState() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('wpState');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// সেটআপ শুরু। {result: created|unconfirmed|cancelled|unsupported|busy|error, reason?}
  static Future<Map<String, dynamic>> wpStart() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('wpStart');
    return r == null ? {'result': 'error'} : Map<String, dynamic>.from(r);
  }

  static Future<String> loadConfig() async =>
      (await _ch.invokeMethod<String>('loadConfig')) ?? '';

  static Future<void> saveConfig(String json) async {
    await _ch.invokeMethod('saveConfig', {'json': json});
  }

  static Future<List<Map<String, dynamic>>> getLogs() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getLogs');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// [{day: 'yyyy-MM-dd', apps: [{pkg, n, h: [২৪টা ঘণ্টার সংখ্যা], r: {কারণ: সংখ্যা}}]}] শেষ ৩০ দিনের ব্লক চেষ্টা
  static Future<List<Map<String, dynamic>>> getAttempts() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getAttempts');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<void> clearLogs() async {
    await _ch.invokeMethod('clearLogs');
  }

  static Future<bool> hasUsageAccess() async =>
      (await _ch.invokeMethod<bool>('hasUsageAccess')) ?? false;

  static Future<void> openUsageAccess() async {
    await _ch.invokeMethod('openUsageAccess');
  }

  /// ব্যাটারি অপ্টিমাইজেশন থেকে ছাড় পাওয়া আছে কিনা (না থাকলে সিস্টেম সার্ভিস মেরে দেয়)
  static Future<bool> isBatteryExempt() async =>
      (await _ch.invokeMethod<bool>('isBatteryExempt')) ?? true;

  static Future<void> requestBatteryExempt() async {
    await _ch.invokeMethod('requestBatteryExempt');
  }

  /// সেটিংস ফাইলে সেভ (ব্যবহারকারী জায়গা বাছে)। true = সেভ হয়েছে
  static Future<bool> backupExport(String json, String name) async =>
      (await _ch.invokeMethod<bool>('backupExport', {'json': json, 'name': name})) ?? false;

  /// ব্যাকআপ ফাইল বেছে লেখা ফেরত। null = বাতিল বা ফাইল বড়
  static Future<String?> backupImport() => _ch.invokeMethod<String>('backupImport');

  static Future<void> openAppSettings() async {
    await _ch.invokeMethod('openAppSettings');
  }

  static Future<Map<String, dynamic>> getScreenTime(int days, int ns, int ne) async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>(
        'getScreenTime', {'days': days, 'ns': ns, 'ne': ne});
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// পিন লকআউটের বাকি সেকেন্ড (ফোনে সেভ করা, Kotlin-এর সাথে একই গোনা)
  static Future<int> pinLeftSec() async => (await _ch.invokeMethod<int>('pinLeftSec')) ?? 0;

  static Future<void> pinOk() async {
    await _ch.invokeMethod('pinOk');
  }

  /// ভুল পিন গুনে রাখে, ফেরত = লকের বাকি সেকেন্ড
  static Future<int> pinFail([String where = '']) async =>
      (await _ch.invokeMethod<int>('pinFail', {'where': where})) ?? 0;

  static Future<bool> startFocus(int minutes) async =>
      (await _ch.invokeMethod<bool>('startFocus', {'minutes': minutes})) ?? false;

  static Future<bool> endFocus() async =>
      (await _ch.invokeMethod<bool>('endFocus')) ?? false;

  static Future<Map<String, dynamic>> getFocus() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getFocus');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// অ্যাপ গার্ড (Accessibility Service) চালু আছে কিনা
  static Future<bool> isGuardEnabled() async =>
      (await _ch.invokeMethod<bool>('isGuardEnabled')) ?? false;

  static Future<void> openAccessibility() async {
    await _ch.invokeMethod('openAccessibility');
  }

  /// {used: বাইট, extra: বাড়তি MB, from: গণনার শুরু (ms), apps: [{pkg, used}],
  ///  pack: {active, used, remain, daysLeft, todayUsed, todayAllow, lastDays, strict, end} (প্যাক থাকলে)}
  static Future<Map<String, dynamic>> getDataStatus() async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('getDataStatus');
    return r == null ? {} : Map<String, dynamic>.from(r);
  }

  /// বাড়তি নেওয়া ডেটা [mb] MB কমানো (পিন লাগে না, কারণ লিমিট কড়া হয়)
  static Future<void> reduceDataExtra(int mb) async {
    await _ch.invokeMethod('reduceDataExtra', {'mb': mb});
  }

  /// এই পিরিয়ডের জন্য ফোনের ডেটা লিমিটে আরও [mb] MB
  static Future<void> addDataExtra(int mb) async {
    await _ch.invokeMethod('addDataExtra', {'mb': mb});
  }

  static Future<List<Map<String, dynamic>>> getUsage(int fromMs) async {
    final r = await _ch.invokeMethod<List<dynamic>>('getUsage', {'from': fromMs});
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// নোটিফিকেশন ট্যাপ করে অ্যাপ খুললে কোন পেজে যাবে ("report" বা null)। একবার নিলে মুছে যায়
  static Future<String?> takeLaunchRoute() => _ch.invokeMethod<String>('takeLaunchRoute');

  /// [{pkg, bps}] এই মুহূর্তে সবচেয়ে বেশি নেট খাওয়া সর্বোচ্চ ৩ অ্যাপ (বাইট/সেকেন্ড, আনুমানিক)
  static Future<List<Map<String, dynamic>>> getTopSpeeds() async {
    final r = await _ch.invokeMethod<List<dynamic>>('getTopSpeeds');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  // ---------- ফাইল ভল্ট ----------

  /// "ready" | "restore" (চাবি হারানো, ব্যাকআপ কী লাগবে) | "unsupported"
  static Future<String> vaultStatus() async =>
      (await _ch.invokeMethod<String>('vaultStatus')) ?? 'unsupported';

  /// [{id, name, size, added, mime}] নতুন আগে
  static Future<List<Map<String, dynamic>>> vaultList() async {
    final r = await _ch.invokeMethod<List<dynamic>>('vaultList');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// ফাইল বাছাই ও ভল্টে ঢোকানো। বাতিল করলে null, নইলে {added, failed, deleted}
  static Future<Map<String, dynamic>?> vaultPick(bool deleteOriginal) async {
    final r = await _ch.invokeMethod<Map<dynamic, dynamic>>(
        'vaultPick', {'deleteOriginal': deleteOriginal});
    return r == null ? null : Map<String, dynamic>.from(r);
  }

  /// "ok" | "no_app" | "error"
  static Future<String> vaultOpen(String id) async =>
      (await _ch.invokeMethod<String>('vaultOpen', {'id': id})) ?? 'error';

  static Future<String> vaultShare(String id) async =>
      (await _ch.invokeMethod<String>('vaultShare', {'id': id})) ?? 'error';

  static Future<bool> vaultDelete(String id) async =>
      (await _ch.invokeMethod<bool>('vaultDelete', {'id': id})) ?? false;

  static Future<String> vaultBackupKey() async =>
      (await _ch.invokeMethod<String>('vaultBackupKey')) ?? '';

  static Future<bool> vaultRestoreKey(String key) async =>
      (await _ch.invokeMethod<bool>('vaultRestoreKey', {'key': key})) ?? false;

  /// ডিক্রিপ্ট করা অস্থায়ী কপি মোছে
  static Future<void> vaultClean() async {
    await _ch.invokeMethod('vaultClean');
  }

  /// ৩০ দিন খোলা হয়নি অথচ ডেটা খরচ করেছে: [{pkg, name, bytes, days, never}]
  static Future<List<Map<String, dynamic>>> scanForgotten() async {
    final r = await _ch.invokeMethod<List<dynamic>>('scanForgotten');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// প্যানিক: সব লক, ভল্ট বন্ধ, অ্যাপ বন্ধ (চালু থাকলে নেটও বন্ধ)
  static Future<void> panicNow() async {
    await _ch.invokeMethod('panicNow');
  }

  /// ভুল পিনের ইতিহাস: [{id, t, where, n, vid, photo}] নতুন আগে
  static Future<List<Map<String, dynamic>>> intruderList() async {
    final r = await _ch.invokeMethod<List<dynamic>>('intruderList');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// ভল্টের চোরের ছবির ডিক্রিপ্ট করা অস্থায়ী ফাইলের পথ (না পেলে null)
  static Future<String?> intruderPhoto(String id) async =>
      _ch.invokeMethod<String>('intruderPhoto', {'id': id});

  /// ইতিহাস ও ভল্টের চোরের ছবি সব মোছা
  static Future<void> intruderClear() async {
    await _ch.invokeMethod('intruderClear');
  }

  static Future<bool> camStatus() async => (await _ch.invokeMethod<bool>('camStatus')) ?? false;

  /// ক্যামেরার অনুমতি চায়। পেলে true
  static Future<bool> camAsk() async => (await _ch.invokeMethod<bool>('camAsk')) ?? false;

  static Future<bool> guestOn() async => (await _ch.invokeMethod<bool>('guestOn')) ?? false;

  /// গেস্ট মোড চালু/বন্ধ। চালু হলে ফায়ারওয়াল অ্যাপ নিজে বন্ধ হয়ে যায়। ফেরত = কাজ হলো কিনা
  static Future<bool> guestSet(bool on) async =>
      (await _ch.invokeMethod<bool>('guestSet', {'on': on})) ?? false;

  /// স্ক্রিনশট/রিসেন্টস প্রিভিউ বন্ধ (FLAG_SECURE)
  static Future<void> setSecure(bool on) async {
    await _ch.invokeMethod('setSecure', {'on': on});
  }
}
