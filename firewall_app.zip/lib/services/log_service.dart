import 'vpn_channel.dart';

class LogEntry {
  final int time;
  final String pkg;
  final String dst;
  final String proto;
  LogEntry(this.time, this.pkg, this.dst, this.proto);
}

class LogService {
  /// নতুন আগে
  static Future<List<LogEntry>> fetch() async {
    final l = await VpnChannel.getLogs();
    return l.reversed
        .map((m) => LogEntry((m['time'] as num).toInt(), m['pkg'] as String,
            m['dst'] as String, m['proto'] as String))
        .toList();
  }

  static Future<void> clear() => VpnChannel.clearLogs();

  static String hms(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    String t(int x) => x.toString().padLeft(2, '0');
    return '${t(d.hour)}:${t(d.minute)}:${t(d.second)}';
  }
}
