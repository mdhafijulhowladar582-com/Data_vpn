import 'rules_storage.dart';
import 'vpn_channel.dart';

class ScreenTimeData {
  final List<int> starts; // প্রতিটা দিনের শুরু (ms), পুরনো আগে, শেষটা আজ
  final List<int> total; // দিনের মোট (ms)
  final List<int> unlocks;
  final List<int> night; // ঘুমের জানালায় ফোন চালানো (ms)
  final List<int> nightLast; // সবশেষ কখন চালিয়েছে (epoch ms, 0 = নেই)
  final Map<String, List<int>> apps; // pkg -> দিন ধরে ms

  ScreenTimeData(this.starts, this.total, this.unlocks, this.night, this.nightLast, this.apps);

  int get days => total.length;

  static List<int> _ints(dynamic l) =>
      (l as List).map((e) => (e as num).toInt()).toList();

  factory ScreenTimeData.fromMap(Map<String, dynamic> m) {
    final apps = <String, List<int>>{};
    for (final a in (m['apps'] as List? ?? [])) {
      final mm = Map<String, dynamic>.from(a as Map);
      apps[mm['pkg'] as String] = _ints(mm['d']);
    }
    return ScreenTimeData(_ints(m['starts']), _ints(m['total']), _ints(m['unlocks']),
        _ints(m['night']), _ints(m['nightLast']), apps);
  }

  static int _sum(List<int> l, int from, int to) {
    var s = 0;
    for (var i = from; i < to; i++) {
      if (i >= 0 && i < l.length) s += l[i];
    }
    return s;
  }

  /// শেষ n দিনের মোট
  int sum(int n) => _sum(total, days - n, days);

  /// তার আগের n দিনের মোট
  int sumPrev(int n) => _sum(total, days - 2 * n, days - n);

  int unlockSum(int n) => _sum(unlocks, days - n, days);

  /// শেষ n দিনে অ্যাপ ধরে সময়, বেশি আগে
  List<MapEntry<String, int>> topApps(int n) {
    final out = <MapEntry<String, int>>[];
    apps.forEach((pkg, d) {
      final t = _sum(d, days - n, days);
      if (t > 0) out.add(MapEntry(pkg, t));
    });
    out.sort((a, b) => b.value.compareTo(a.value));
    return out;
  }

  int todayOf(String pkg) => (apps[pkg]?.last) ?? 0;

  /// টানা কত দিন লক্ষ্যের মধ্যে ছিল (গতকাল থেকে পিছনে, আজ এখনো ঠিক থাকলে +১)
  int streak(int goalMs) {
    if (goalMs <= 0 || days < 2) return 0;
    var s = 0;
    for (var i = days - 2; i >= 0; i--) {
      if (total[i] > 0 && total[i] <= goalMs) {
        s++;
      } else {
        break;
      }
    }
    if (total[days - 1] <= goalMs) s++;
    return s;
  }
}

class ScreenTimeService {
  static ScreenTimeData? _cache;
  static int _at = 0;

  /// অনুমতি না থাকলে null
  static Future<ScreenTimeData?> fetch({bool force = false}) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && _cache != null && now - _at < 20000) return _cache;
    if (!await VpnChannel.hasUsageAccess()) return null;
    final m = await VpnChannel.getScreenTime(30, store.cfg.schStart, store.cfg.schEnd);
    if (m.isEmpty) return null;
    _cache = ScreenTimeData.fromMap(m);
    _at = now;
    return _cache;
  }
}
