import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/lock_screen.dart';
import 'services/rules_storage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  runApp(const FirewallApp());
}

class FirewallApp extends StatefulWidget {
  const FirewallApp({super.key});

  @override
  State<FirewallApp> createState() => _FirewallAppState();
}

class _FirewallAppState extends State<FirewallApp> {
  bool unlocked = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Firewall',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
      ),
      home: (store.cfg.pinHash.isEmpty || unlocked)
          ? const HomeScreen()
          : LockScreen(onUnlock: () => setState(() => unlocked = true)),
    );
  }
}
