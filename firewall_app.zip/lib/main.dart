import 'package:flutter/material.dart';
import 'screens/lock_screen.dart';
import 'screens/shell.dart';
import 'services/lock_service.dart';
import 'services/rules_storage.dart';
import 'services/vpn_channel.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  VpnChannel.vaultClean().catchError((_) {});
  runApp(const FirewallApp());
}

class FirewallApp extends StatefulWidget {
  const FirewallApp({super.key});

  @override
  State<FirewallApp> createState() => _FirewallAppState();
}

class _FirewallAppState extends State<FirewallApp> with WidgetsBindingObserver {
  bool unlocked = false;
  int _pausedAt = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// ১ মিনিটের বেশি ব্যাকগ্রাউন্ডে থাকলে আবার লক
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (s == AppLifecycleState.paused) {
      _pausedAt = now;
    } else if (s == AppLifecycleState.resumed) {
      if (_pausedAt > 0 && now - _pausedAt > 60000 && store.cfg.pinHash.isNotEmpty) {
        Lock.resetGrace();
        navKey.currentState?.popUntil((r) => r.isFirst);
        setState(() => unlocked = false);
      }
      _pausedAt = 0;
    }
  }

  ThemeData _theme(Brightness b) => ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: b,
        appBarTheme: const AppBarTheme(centerTitle: false),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.cfg.theme;
        return MaterialApp(
          navigatorKey: navKey,
          title: 'Firewall',
          debugShowCheckedModeBanner: false,
          theme: _theme(Brightness.light),
          darkTheme: _theme(Brightness.dark),
          themeMode: t == 'light'
              ? ThemeMode.light
              : t == 'system'
                  ? ThemeMode.system
                  : ThemeMode.dark,
          home: (store.cfg.pinHash.isEmpty || unlocked)
              ? const Shell()
              : LockScreen(onUnlock: () => setState(() => unlocked = true)),
        );
      },
    );
  }
}
