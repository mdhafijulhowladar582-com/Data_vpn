import 'package:flutter/material.dart';
import 'screens/hidden_page.dart';
import 'screens/lock_screen.dart';
import 'screens/shell.dart';
import 'services/lock_service.dart';
import 'services/rules_storage.dart';
import 'services/vpn_channel.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  VpnChannel.vaultClean().catchError((_) {});
  runApp(const FirewallApp());
}

class FirewallApp extends StatefulWidget {
  const FirewallApp({super.key});

  @override
  State<FirewallApp> createState() => _FirewallAppState();
}

class _FirewallAppState extends State<FirewallApp> with WidgetsBindingObserver {
  bool unlocked = false;
  int _pausedAt = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// ১ মিনিটের বেশি ব্যাকগ্রাউন্ডে থাকলে আবার লক
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (s == AppLifecycleState.paused) {
      _pausedAt = now;
    } else if (s == AppLifecycleState.resumed) {
      final p = _pausedAt;
      _pausedAt = 0;
      _onResume(p, now);
    }
  }

  /// ১ মিনিটের বেশি ব্যাকগ্রাউন্ডে ছিল, বা গেস্ট মোড চালু (তখন প্রতিবার পিন)
  Future<void> _onResume(int pausedAt, int now) async {
    if (pausedAt <= 0 || store.cfg.pinHash.isEmpty) return;
    var relock = now - pausedAt > 60000;
    if (!relock) {
      try {
        relock = await VpnChannel.guestOn();
      } catch (_) {}
    }
    if (!relock || !mounted) return;
    Lock.resetGrace();
    navKey.currentState?.popUntil((r) => r.isFirst);
    setState(() => unlocked = false);
  }

  ThemeData _theme(Brightness b) => ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: b,
        appBarTheme: const AppBarTheme(centerTitle: false),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.cfg.theme;
        return MaterialApp(
          navigatorKey: navKey,
          title: 'Firewall',
          debugShowCheckedModeBanner: false,
          theme: _theme(Brightness.light),
          darkTheme: _theme(Brightness.dark),
          themeMode: t == 'light'
              ? ThemeMode.light
              : t == 'system'
                  ? ThemeMode.system
                  : ThemeMode.dark,
          // দুই আঙুল দূর থেকে কাছে আনলে লুকানো অ্যাপ এলাকা (পিন লাগে)
          builder: (context, child) => PinchGate(
            onPinch: () {
              if (store.cfg.pinHash.isNotEmpty && !unlocked) return;
              final nc = navKey.currentContext;
              if (nc != null) openHiddenArea(nc);
            },
            child: child ?? const SizedBox.shrink(),
          ),
          home: (store.cfg.pinHash.isEmpty || unlocked)
              ? const Shell()
              : LockScreen(onUnlock: () => setState(() => unlocked = true)),
        );
      },
    );
  }
}
