import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../models/rule.dart';
import '../services/vpn_channel.dart';

class AppIcon extends StatelessWidget {
  final String pkg;
  final double size;
  const AppIcon(this.pkg, {super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: VpnChannel.icon(pkg),
      builder: (c, s) {
        if (s.data != null) {
          return Image.memory(s.data!,
              width: size, height: size, gaplessPlayback: true);
        }
        return SizedBox(width: size, height: size, child: const Icon(Icons.android));
      },
    );
  }
}

class AppTile extends StatelessWidget {
  final AppInfo app;
  final Rule rule;
  final bool whitelist;
  final bool allowed;
  final ValueChanged<bool> onWifi;
  final ValueChanged<bool> onMobile;
  final ValueChanged<bool> onAllow;

  const AppTile({
    super.key,
    required this.app,
    required this.rule,
    required this.whitelist,
    required this.allowed,
    required this.onWifi,
    required this.onMobile,
    required this.onAllow,
  });

  Widget _chk(String label, bool v, ValueChanged<bool> cb) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 10)),
          Checkbox(
            value: v,
            visualDensity: VisualDensity.compact,
            onChanged: (x) => cb(x ?? false),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: AppIcon(app.pkg),
      title: Text(app.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(app.system ? '${app.pkg} • সিস্টেম' : app.pkg,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 11)),
      trailing: whitelist
          ? Switch(value: allowed, onChanged: onAllow)
          : Row(mainAxisSize: MainAxisSize.min, children: [
              _chk('Wi-Fi', rule.wifi, onWifi),
              _chk('ডেটা', rule.mobile, onMobile),
            ]),
    );
  }
}
