import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../models/rule.dart';
import '../services/vpn_channel.dart';
import 'common.dart';

class AppIcon extends StatelessWidget {
  final String pkg;
  final double size;
  const AppIcon(this.pkg, {super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: VpnChannel.icon(pkg),
      builder: (c, s) {
        if (s.data != null) {
          return Image.memory(s.data!,
              width: size, height: size, gaplessPlayback: true);
        }
        return SizedBox(width: size, height: size, child: const Icon(Icons.android));
      },
    );
  }
}

/// সুইচ চালু = ইন্টারনেট পাবে, বন্ধ = ব্লক (দুই মোডেই একই নিয়ম)
class AppTile extends StatelessWidget {
  final AppInfo app;
  final Rule rule;
  final bool whitelist;
  final bool allowed;
  final String? extra;
  final ValueChanged<bool> onWifi; // true = পাবে
  final ValueChanged<bool> onMobile; // true = পাবে
  final ValueChanged<bool> onAllow;

  const AppTile({
    super.key,
    required this.app,
    required this.rule,
    required this.whitelist,
    required this.allowed,
    required this.onWifi,
    required this.onMobile,
    required this.onAllow,
    this.extra,
  });

  Widget _sw(BuildContext context, IconData icon, bool on, ValueChanged<bool> cb) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: on ? cs.primary : cs.outline),
        Transform.scale(
          scale: 0.8,
          child: Switch(
            value: on,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            onChanged: cb,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final small = Theme.of(context).textTheme.bodySmall;

    String? status;
    if (whitelist) {
      if (!allowed) status = 'ইন্টারনেট বন্ধ';
    } else if (rule.wifi && rule.mobile) {
      status = 'Wi-Fi ও ডেটা বন্ধ';
    } else if (rule.wifi) {
      status = 'Wi-Fi বন্ধ';
    } else if (rule.mobile) {
      status = 'মোবাইল ডেটা বন্ধ';
    }

    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      child: Row(
        children: [
          AppIcon(app.pkg),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(app.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(app.system ? '${app.pkg} • সিস্টেম' : app.pkg,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: small?.copyWith(color: cs.outline)),
                if (status != null || extra != null)
                  Text(
                    [if (status != null) status, if (extra != null) extra!].join(' • '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: small?.copyWith(
                        color: status != null ? cs.error : cs.primary,
                        fontWeight: FontWeight.w600),
                  ),
              ],
            ),
          ),
          if (whitelist)
            _sw(context, Icons.public, allowed, onAllow)
          else ...[
            _sw(context, Icons.wifi, !rule.wifi, onWifi),
            _sw(context, Icons.signal_cellular_alt, !rule.mobile, onMobile),
          ],
        ],
      ),
    );
  }
}
