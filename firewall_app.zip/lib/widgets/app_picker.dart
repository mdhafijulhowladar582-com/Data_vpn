import 'package:flutter/material.dart';
import '../models/app_info.dart';
import '../services/rules_storage.dart';
import 'app_tile.dart';

/// অ্যাপ বাছাইয়ের বটম শিট। multi = false হলে একটা ট্যাপেই ফেরত
Future<List<String>?> pickApps(BuildContext context,
    {required String title, Set<String> selected = const {}, bool multi = true}) {
  return showModalBottomSheet<List<String>>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => _Picker(title: title, selected: selected, multi: multi),
  );
}

class _Picker extends StatefulWidget {
  final String title;
  final Set<String> selected;
  final bool multi;
  const _Picker({required this.title, required this.selected, required this.multi});

  @override
  State<_Picker> createState() => _PickerState();
}

class _PickerState extends State<_Picker> {
  List<AppInfo> apps = [];
  bool loading = true;
  bool system = false;
  String q = '';
  late Set<String> sel;

  @override
  void initState() {
    super.initState();
    sel = Set.of(widget.selected);
    store.loadApps().then((a) {
      if (mounted) {
        setState(() {
          apps = List.of(a);
          loading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final list = apps.where((a) {
      if (!system && a.system && !sel.contains(a.pkg)) return false;
      return q.isEmpty || a.name.toLowerCase().contains(q) || a.pkg.contains(q);
    }).toList();
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.85,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 12, 0),
          child: Row(children: [
            Expanded(
                child: Text(widget.title,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
            if (widget.multi)
              FilledButton(
                  onPressed: () => Navigator.pop(context, sel.toList()),
                  child: Text('ঠিক আছে (${sel.length})')),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'অ্যাপ খুঁজুন',
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
            ),
            onChanged: (v) => setState(() => q = v.toLowerCase()),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: FilterChip(
              label: const Text('সিস্টেম অ্যাপও'),
              selected: system,
              onSelected: (v) => setState(() => system = v),
            ),
          ),
        ),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (c, i) {
                    final a = list[i];
                    return ListTile(
                      leading: AppIcon(a.pkg, size: 36),
                      title: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: widget.multi
                          ? Checkbox(
                              value: sel.contains(a.pkg),
                              onChanged: (v) => setState(() {
                                    if (v == true) {
                                      sel.add(a.pkg);
                                    } else {
                                      sel.remove(a.pkg);
                                    }
                                  }))
                          : null,
                      onTap: () {
                        if (widget.multi) {
                          setState(() {
                            if (!sel.remove(a.pkg)) sel.add(a.pkg);
                          });
                        } else {
                          Navigator.pop(context, [a.pkg]);
                        }
                      },
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
