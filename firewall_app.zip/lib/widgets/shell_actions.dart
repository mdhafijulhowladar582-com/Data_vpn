import 'package:flutter/material.dart';
import '../screens/logs_tab.dart';
import '../screens/settings_tab.dart';
import '../services/lock_service.dart';

/// প্রতি ট্যাবের উপরের কোণায়: লগ ও সেটিংস (সেটিংসে লক)
List<Widget> shellActions(BuildContext context) => [
      IconButton(
        icon: const Icon(Icons.receipt_long_outlined),
        tooltip: 'ব্লক লগ',
        onPressed: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const LogsTab())),
      ),
      IconButton(
        icon: const Icon(Icons.settings_outlined),
        tooltip: 'সেটিংস',
        onPressed: () async {
          final nav = Navigator.of(context);
          if (!await Lock.ask(context, reason: 'সেটিংস খুলতে যাচাই করুন')) return;
          nav.push(MaterialPageRoute(builder: (_) => const SettingsTab()));
        },
      ),
    ];
