import 'dart:async';
import 'package:flutter/material.dart';
import '../models/rule.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import '../services/usage_service.dart';
import '../services/vpn_channel.dart';
import 'app_picker.dart';
import 'app_tile.dart';
import 'common.dart';
import 'usage_access.dart';

const _steps = [0, 100, 200, 300, 500, 750, 1024, 1536, 2048, 3072, 5120, 10240];
const _pctOpts = [50, 70, 80, 90];
const _mbOpts = [100, 200, 500, 1024];
const _extraOpts = [50, 100, 200, 500];
const _appOpts = [50, 100, 200, 500, 1024, 2048];

String _mbLabel(int mb) {
  if (mb <= 0) return 'নেই';
  if (mb >= 1024 && mb % 1024 == 0) return '${mb ~/ 1024} GB';
  if (mb >= 1024) return '${(mb / 1024).toStringAsFixed(1)} GB';
  return '$mb MB';
}

/// ফোকাস ট্যাবের "ডেটা লিমিট" সেকশন। গণনা ও ব্লক করে Kotlin (VPN সার্ভিস চালু থাকলে)।
/// লিমিট বাড়ানো/সরানো বা নিয়ম ঢিলা করার আগে Lock.ask।
class DataLimitSection extends StatefulWidget {
  final bool running;
  final bool hasUsage;
  const DataLimitSection({super.key, required this.running, required this.hasUsage});

  @override
  State<DataLimitSection> createState() => _DataLimitSectionState();
}

class _DataLimitSectionState extends State<DataLimitSection> {
  Map<String, dynamic> st = {};
  Map<String, String> names = {};
  Timer? _t;
  double? _drag; // স্লাইডার টানার সময়ের মান
  final _ctl = TextEditingController();

  Config get c => store.cfg;

  @override
  void initState() {
    super.initState();
    _refresh();
    _t = Timer.periodic(const Duration(seconds: 10), (_) => _refresh());
  }

  @override
  void didUpdateWidget(covariant DataLimitSection old) {
    super.didUpdateWidget(old);
    if (widget.hasUsage && !old.hasUsage) _refresh();
  }

  @override
  void dispose() {
    _t?.cancel();
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (!widget.hasUsage) return;
    final r = await VpnChannel.getDataStatus();
    final apps = await store.loadApps();
    if (!mounted) return;
    setState(() {
      st = r;
      names = {for (final a in apps) a.pkg: a.name};
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  int get _used => (st['used'] as num?)?.toInt() ?? 0;
  int get _extra => (st['extra'] as num?)?.toInt() ?? 0;

  int _usedOf(String pkg) {
    final l = st['apps'];
    if (l is List) {
      for (final e in l) {
        if (e is Map && e['pkg'] == pkg) return (e['used'] as num).toInt();
      }
    }
    return 0;
  }

  String get _period => c.dlResetDay == 0 ? 'আজ' : 'এই মাসে';

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  /// ঢিলা করার কাজের আগে যাচাই
  Future<bool> _ok(String reason) => Lock.ask(context, reason: reason);

  // ---------- ফোনের লিমিট ----------

  Future<void> _setPhone(int mb) async {
    final cur = c.dlPhoneMb;
    if (mb == cur) return;
    if (cur > 0 && (mb == 0 || mb > cur)) {
      if (!await _ok(mb == 0 ? 'লিমিট সরাতে যাচাই করুন' : 'লিমিট বাড়াতে যাচাই করুন')) {
        if (mounted) setState(() => _drag = null);
        return;
      }
    }
    c.dlPhoneMb = mb;
    store.saveSoon();
    if (mounted) setState(() => _drag = null);
  }

  int _idxOf(int mb) {
    var best = 0;
    for (var i = 0; i < _steps.length; i++) {
      if ((_steps[i] - mb).abs() < (_steps[best] - mb).abs()) best = i;
    }
    return best;
  }

  Widget _phoneCard() {
    final cs = Theme.of(context).colorScheme;
    final lim = c.dlPhoneMb;
    final eff = (lim + _extra) * 1024 * 1024;
    final p = eff <= 0 ? 0.0 : (_used / eff).clamp(0.0, 1.0).toDouble();
    final over = eff > 0 && _used >= eff;
    final color = over
        ? cs.error
        : (p >= 0.8 ? const Color(0xFFF59E0B) : const Color(0xFF22C55E));
    final idx = _drag ?? _idxOf(lim).toDouble();
    final sliderMb = _steps[idx.round().clamp(0, _steps.length - 1)];

    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.data_usage),
          const SizedBox(width: 10),
          const Expanded(
              child: Text('মোবাইল ডেটা লিমিট',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          Text(_period, style: Theme.of(context).textTheme.bodySmall),
        ]),
        const SizedBox(height: 12),
        if (lim > 0) ...[
          Row(children: [
            Expanded(
                child: Text(
                    over ? 'লিমিট শেষ' : '${UsageService.fmt(eff - _used)} বাকি',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w800, color: color))),
            Text('${UsageService.fmt(_used)} / ${UsageService.fmt(eff)}',
                style: Theme.of(context).textTheme.bodySmall),
          ]),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: p),
              duration: const Duration(milliseconds: 700),
              builder: (_, v, __) =>
                  LinearProgressIndicator(value: v, minHeight: 10, color: color),
            ),
          ),
          if (_extra > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('বাড়তি নেওয়া: $_extra MB',
                  style: Theme.of(context).textTheme.bodySmall),
            ),
        ] else
          Text('লিমিট নেই। $_period খরচ: ${UsageService.fmt(_used)}',
              style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 8),
        Row(children: [
          Text(_mbLabel(_drag == null ? lim : sliderMb),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          Expanded(
            child: Slider(
              value: idx.clamp(0, _steps.length - 1).toDouble(),
              min: 0,
              max: (_steps.length - 1).toDouble(),
              divisions: _steps.length - 1,
              label: _mbLabel(sliderMb),
              onChanged: (v) => setState(() => _drag = v),
              onChangeEnd: (v) => _setPhone(_steps[v.round()]),
            ),
          ),
        ]),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _ctl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  isDense: true, border: OutlineInputBorder(), labelText: 'নিজে লিখুন', suffixText: 'MB'),
            ),
          ),
          const SizedBox(width: 10),
          FilledButton(
            onPressed: () async {
              final v = int.tryParse(_ctl.text.trim());
              if (v == null || v < 0 || v > 100000) {
                _snack('০ থেকে ১,০০,০০০ এর মধ্যে MB লিখুন');
                return;
              }
              FocusScope.of(context).unfocus();
              await _setPhone(v);
              _ctl.clear();
            },
            child: const Text('সেট'),
          ),
        ]),
        if (lim > 0) ...[
          const SizedBox(height: 12),
          Text('$_period আরও নিন (পিন/ফিঙ্গারপ্রিন্ট লাগবে):',
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final m in _extraOpts)
              ActionChip(
                label: Text('+$m MB'),
                onPressed: () async {
                  if (!await _ok('আরও ডেটা নিতে যাচাই করুন')) return;
                  await VpnChannel.addDataExtra(m);
                  await _refresh();
                },
              ),
          ]),
          // বাড়তি নেওয়া থাকলে কমানো যায়। কড়া করা তাই পিন লাগে না। লিমিট নেমে গেলে সাথে সাথে কাটতে পারে
          if (_extra > 0) ...[
            const SizedBox(height: 12),
            Text('বাড়তি কমান (পিন লাগবে না):', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final m in _extraOpts)
                if (m < _extra)
                  ActionChip(
                    label: Text('−$m MB'),
                    onPressed: () async {
                      await VpnChannel.reduceDataExtra(m);
                      await _refresh();
                    },
                  ),
              ActionChip(
                avatar: const Icon(Icons.undo, size: 18),
                label: Text('সব বাড়তি মুছুন ($_extra MB)'),
                onPressed: () async {
                  await VpnChannel.reduceDataExtra(_extra);
                  await _refresh();
                },
              ),
            ]),
          ],
        ],
      ]),
    );
  }

  // ---------- সেটিং ----------

  Widget _settings() {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('লিমিট পূর্ণ হলে ডেটা কেটে দাও'),
          subtitle: const Text('জরুরি অ্যাপ ছাড়া সবার ডেটা বন্ধ। বন্ধ থাকলে শুধু নোটিফিকেশন আসে।'),
          value: c.dlCut,
          onChanged: (v) async {
            if (!v && !await _ok('কাট বন্ধ করতে যাচাই করুন')) return;
            c.dlCut = v;
            store.saveSoon();
            if (mounted) setState(() {});
          },
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Wi-Fi-র ডেটাও গুনব'),
          subtitle: const Text('চালু থাকলে Wi-Fi খরচও এই লিমিটে ধরা হয়'),
          value: c.dlWifi,
          onChanged: (v) async {
            if (!v && !await _ok('Wi-Fi গণনা বন্ধ করতে যাচাই করুন')) return;
            c.dlWifi = v;
            store.saveSoon();
            if (mounted) setState(() {});
          },
        ),
        Row(children: [
          const Expanded(child: Text('গণনা নতুন করে শুরু')),
          DropdownButton<int>(
            value: c.dlResetDay,
            items: [
              const DropdownMenuItem(value: 0, child: Text('প্রতিদিন মাঝরাতে')),
              for (var d = 1; d <= 28; d++)
                DropdownMenuItem(value: d, child: Text('প্রতি মাসের $d তারিখ')),
            ],
            onChanged: (v) async {
              if (v == null || v == c.dlResetDay) return;
              if (!await _ok('রিসেটের দিন বদলাতে যাচাই করুন')) return;
              c.dlResetDay = v;
              store.saveSoon();
              await Future.delayed(const Duration(milliseconds: 800));
              await _refresh();
            },
          ),
        ]),
        const Divider(height: 24),
        Text('সতর্কতা (লিমিটের %)', style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 6),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final p in _pctOpts)
            FilterChip(
              label: Text('$p%'),
              selected: c.dlWarnPct.contains(p),
              onSelected: (on) {
                final l = List<int>.from(c.dlWarnPct);
                if (on) {
                  l.add(p);
                } else {
                  l.remove(p);
                }
                l.sort();
                c.dlWarnPct = l;
                store.saveSoon();
                setState(() {});
              },
            ),
        ]),
        const SizedBox(height: 10),
        Text('সতর্কতা (মোট খরচ)', style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 6),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final m in _mbOpts)
            FilterChip(
              label: Text(_mbLabel(m)),
              selected: c.dlWarnMb.contains(m),
              onSelected: (on) {
                final l = List<int>.from(c.dlWarnMb);
                if (on) {
                  l.add(m);
                } else {
                  l.remove(m);
                }
                l.sort();
                c.dlWarnMb = l;
                store.saveSoon();
                setState(() {});
              },
            ),
        ]),
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('প্রতিটা সতর্কতা প্রতি পিরিয়ডে একবারই আসে।',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: cs.outline)),
        ),
        const Divider(height: 24),
        InkWell(
          onTap: _pickExempt,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(children: [
              const Icon(Icons.health_and_safety_outlined),
              const SizedBox(width: 10),
              Expanded(child: Text('জরুরি ছাড়: ${c.dlExempt.length}টি অ্যাপ')),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      ]),
    );
  }

  Future<void> _pickExempt() async {
    final r = await pickApps(context,
        title: 'ডেটা কাটের সময়ও পাবে যারা', selected: c.dlExempt);
    if (r == null) return;
    final next = r.toSet();
    final added = next.difference(c.dlExempt);
    if (added.isNotEmpty && !await _ok('জরুরি ছাড় বাড়াতে যাচাই করুন')) return;
    c.dlExempt = next;
    store.saveSoon();
    if (mounted) setState(() {});
  }

  // ---------- অ্যাপ ধরে লিমিট ----------

  Widget _appRow(String pkg, int mb) {
    final cs = Theme.of(context).colorScheme;
    final lim = mb * 1024 * 1024;
    final used = _usedOf(pkg);
    final p = lim == 0 ? 1.0 : (used / lim).clamp(0.0, 1.0).toDouble();
    final over = used >= lim;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _appSheet(pkg),
      child: AppCard(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          AppIcon(pkg, size: 38),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                    child: Text(_name(pkg),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600))),
                Text(over ? 'শেষ' : '${UsageService.fmt(lim - used)} বাকি',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, color: over ? cs.error : cs.primary)),
              ]),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                    value: p,
                    minHeight: 8,
                    color: over ? cs.error : const Color(0xFF22C55E)),
              ),
              const SizedBox(height: 3),
              Text('${UsageService.fmt(used)} / ${_mbLabel(mb)}',
                  style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ]),
      ),
    );
  }

  Future<void> _appSheet(String pkg) {
    return showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        final cur = c.dlApps[pkg];
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  AppIcon(pkg, size: 36),
                  const SizedBox(width: 12),
                  Expanded(
                      child: Text(_name(pkg),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
                ]),
                const SizedBox(height: 6),
                Text('$_period এই অ্যাপের মোবাইল ডেটা এই সীমা ছাড়ালে ডেটা বন্ধ (কাট চালু থাকলে)।',
                    style: Theme.of(ctx).textTheme.bodySmall),
                const SizedBox(height: 16),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final m in _appOpts)
                    ChoiceChip(
                      label: Text(_mbLabel(m)),
                      selected: cur == m,
                      onSelected: (_) async {
                        if (cur != null && m > cur) {
                          if (!await Lock.ask(ctx, reason: 'লিমিট বাড়াতে যাচাই করুন')) return;
                        }
                        c.dlApps[pkg] = m;
                        store.saveSoon();
                        if (ctx.mounted) Navigator.pop(ctx);
                        if (mounted) setState(() {});
                      },
                    ),
                ]),
                if (cur != null) ...[
                  const SizedBox(height: 12),
                  TextButton.icon(
                    onPressed: () async {
                      if (!await Lock.ask(ctx, reason: 'লিমিট সরাতে যাচাই করুন')) return;
                      c.dlApps.remove(pkg);
                      store.saveSoon();
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (mounted) setState(() {});
                    },
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('লিমিট সরান'),
                  ),
                ],
              ]),
        );
      },
    );
  }

  Future<void> _addApp() async {
    final r = await pickApps(context, title: 'কোন অ্যাপের ডেটায় লিমিট?', multi: false);
    if (r == null || r.isEmpty || !mounted) return;
    await _appSheet(r.first);
  }

  // ---------- ডেটা প্যাক বাজেট ----------

  static const _packGb = [2, 5, 10, 20, 30, 50, 100];
  static const _packDays = [7, 15, 28, 30, 60, 90];

  Map<String, dynamic> get _pack {
    final p = st['pack'];
    return p is Map ? Map<String, dynamic>.from(p) : {};
  }

  String _bytes(num b) {
    final v = b < 0 ? 0 : b;
    if (v < 1024 * 1024 * 1024) return '${(v / (1024 * 1024)).round()} MB';
    return '${(v / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  Future<void> _setPack() async {
    if (c.dlPackMb > 0 && !await _ok('প্যাক বদলাতে যাচাই করুন')) return;
    // আকার MB-তে রাখা হয়; নিজে লেখা হলে GB বা MB দুটোই চলবে
    var mb = c.dlPackMb > 0 ? c.dlPackMb : 20 * 1024;
    var days = c.dlPackDays > 0 ? c.dlPackDays : 30;
    var customSize = !(mb % 1024 == 0 && _packGb.contains(mb ~/ 1024));
    var customDays = !_packDays.contains(days);
    var sizeUnitGb = !(customSize && mb % 1024 != 0);
    final sizeCtl = TextEditingController(
        text: customSize ? (sizeUnitGb ? '${mb ~/ 1024}' : '$mb') : '');
    final daysCtl = TextEditingController(text: customDays ? '$days' : '');
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) {
          int? sizeVal() {
            final v = int.tryParse(sizeCtl.text.trim());
            if (v == null || v <= 0) return null;
            final m = sizeUnitGb ? v * 1024 : v;
            return m > 10 * 1024 * 1024 ? null : m;
          }

          int? daysVal() {
            final v = int.tryParse(daysCtl.text.trim());
            if (v == null || v <= 0 || v > 3650) return null;
            return v;
          }

          final canSave = (customSize ? sizeVal() != null : true) && (customDays ? daysVal() != null : true);
          return AlertDialog(
            title: const Text('ডেটা প্যাক বসান'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('প্যাকের আকার'),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final g in _packGb)
                    ChoiceChip(
                        label: Text('$g GB'),
                        selected: !customSize && mb == g * 1024,
                        onSelected: (_) => set(() {
                              customSize = false;
                              mb = g * 1024;
                            })),
                  ChoiceChip(
                      avatar: const Icon(Icons.edit, size: 16),
                      label: const Text('নিজে লিখুন'),
                      selected: customSize,
                      onSelected: (_) => set(() => customSize = true)),
                ]),
                if (customSize) ...[
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                      child: TextField(
                        controller: sizeCtl,
                        keyboardType: TextInputType.number,
                        autofocus: true,
                        decoration: InputDecoration(
                          hintText: sizeUnitGb ? 'যেমন 7' : 'যেমন 1500',
                          border: const OutlineInputBorder(),
                          isDense: true,
                        ),
                        onChanged: (_) => set(() {}),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SegmentedButton<bool>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(value: true, label: Text('GB')),
                        ButtonSegment(value: false, label: Text('MB')),
                      ],
                      selected: {sizeUnitGb},
                      onSelectionChanged: (v) => set(() => sizeUnitGb = v.first),
                    ),
                  ]),
                ],
                const SizedBox(height: 14),
                const Text('মেয়াদ'),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final d in _packDays)
                    ChoiceChip(
                        label: Text('$d দিন'),
                        selected: !customDays && days == d,
                        onSelected: (_) => set(() {
                              customDays = false;
                              days = d;
                            })),
                  ChoiceChip(
                      avatar: const Icon(Icons.edit, size: 16),
                      label: const Text('নিজে লিখুন'),
                      selected: customDays,
                      onSelected: (_) => set(() => customDays = true)),
                ]),
                if (customDays) ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: daysCtl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      hintText: 'কত দিন? যেমন 45',
                      suffixText: 'দিন',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (_) => set(() {}),
                  ),
                ],
                const SizedBox(height: 10),
                const Text('গণনা আজ মাঝরাত থেকে শুরু ধরা হবে (শুধু মোবাইল ডেটা)।', style: TextStyle(fontSize: 12)),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
              FilledButton(
                onPressed: canSave
                    ? () {
                        if (customSize) mb = sizeVal()!;
                        if (customDays) days = daysVal()!;
                        Navigator.pop(ctx, true);
                      }
                    : null,
                child: const Text('বসান'),
              ),
            ],
          );
        },
      ),
    );
    sizeCtl.dispose();
    daysCtl.dispose();
    if (ok != true) return;
    final n = DateTime.now();
    c.dlPackMb = mb;
    c.dlPackDays = days;
    c.dlPackStart = DateTime(n.year, n.month, n.day).millisecondsSinceEpoch;
    store.saveSoon();
    await Future.delayed(const Duration(milliseconds: 800));
    await _refresh();
  }

  Future<void> _removePack() async {
    if (!await _ok('প্যাক সরাতে যাচাই করুন')) return;
    c.dlPackMb = 0;
    c.dlPackDays = 0;
    c.dlPackStart = 0;
    store.saveSoon();
    if (mounted) setState(() {});
  }

  Widget _packCard() {
    final cs = Theme.of(context).colorScheme;
    if (c.dlPackMb <= 0) {
      return AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('প্যাকের আকার আর মেয়াদ বসালে অ্যাপ বলবে আজ কতটা চালানো যাবে, আর এভাবে চললে প্যাক কত দিনে শেষ হবে।',
              style: TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: _setPack, icon: const Icon(Icons.data_usage), label: const Text('প্যাক বসান')),
        ]),
      );
    }
    final p = _pack;
    final total = c.dlPackMb * 1024 * 1024;
    final used = (p['used'] as num?)?.toInt() ?? 0;
    final remain = (p['remain'] as num?)?.toInt() ?? (total - used);
    final active = p['active'] != false;
    final strict = p['strict'] == true;
    final daysLeft = (p['daysLeft'] as num?)?.toInt() ?? 0;
    final todayUsed = (p['todayUsed'] as num?)?.toInt() ?? 0;
    final todayAllow = (p['todayAllow'] as num?)?.toInt() ?? 0;
    final last = (p['lastDays'] as num?)?.toDouble() ?? -1;
    final frac = total <= 0 ? 0.0 : (used / total).clamp(0.0, 1.0).toDouble();
    final todayLeft = todayAllow - todayUsed;
    final color = (!active || remain <= 0)
        ? cs.error
        : (strict ? const Color(0xFFF59E0B) : const Color(0xFF22C55E));

    String headline;
    if (st['pack'] == null) {
      headline = 'হিসাব হচ্ছে...';
    } else if (!active) {
      headline = 'প্যাকের মেয়াদ শেষ। নতুন প্যাক বসান।';
    } else if (remain <= 0) {
      headline = 'প্যাকের ডেটা শেষ।';
    } else if (todayLeft <= 0) {
      headline = 'আজকের ভাগ (${_bytes(todayAllow)}) শেষ।';
    } else {
      headline = 'আজ ${_bytes(todayLeft)} চালাতে পারবেন।';
    }
    String? pace;
    if (active && remain > 0) {
      if (last < 0) {
        pace = 'কয়েক ঘণ্টা ব্যবহারের পর হিসাব দেখাবে।';
      } else if (last >= daysLeft) {
        pace = 'এভাবে চললে মেয়াদ পর্যন্ত চলবে ($daysLeft দিন বাকি)।';
      } else {
        pace = 'এভাবে চললে ${last.floor()} দিনে শেষ, কিন্তু মেয়াদ বাকি $daysLeft দিন।';
      }
    }

    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(headline, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        if (pace != null) ...[
          const SizedBox(height: 4),
          Text(pace, style: const TextStyle(fontSize: 13)),
        ],
        const SizedBox(height: 10),
        LinearProgressIndicator(value: frac, minHeight: 8, color: color, backgroundColor: color.withOpacity(0.15)),
        const SizedBox(height: 6),
        Text('খরচ ${_bytes(used)} / ${_bytes(total)}, বাকি ${_bytes(remain)}', style: const TextStyle(fontSize: 12)),
        if (active) Text('আজ খরচ ${_bytes(todayUsed)}, আজকের ভাগ ${_bytes(todayAllow)}', style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('শেষের দিকে কড়া মোড'),
          subtitle: const Text('প্যাকের ২৫% বাকি থাকলে আজকের ভাগ পেরোলেই মোবাইল ডেটা বন্ধ (জরুরি অ্যাপ ছাড়া), পরদিন ফিরবে। প্যাক শেষ হলেও বন্ধ।'),
          value: c.dlPackStrict,
          onChanged: (v) async {
            if (!v && !await _ok('কড়া মোড বন্ধ করতে যাচাই করুন')) return;
            c.dlPackStrict = v;
            store.saveSoon();
            if (mounted) setState(() {});
          },
        ),
        Row(children: [
          TextButton(onPressed: _setPack, child: const Text('প্যাক বদলান')),
          TextButton(onPressed: _removePack, child: const Text('প্যাক সরান')),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final entries = c.dlApps.entries.toList()
      ..sort((a, b) => _name(a.key).toLowerCase().compareTo(_name(b.key).toLowerCase()));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionLabel('ডেটা লিমিট'),
      if (!widget.running)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: AppCard(
            color: cs.errorContainer,
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Icon(Icons.warning_amber, color: cs.onErrorContainer),
              const SizedBox(width: 10),
              Expanded(
                  child: Text('ফায়ারওয়াল বন্ধ, তাই ডেটা লিমিট গোনা ও কাট কাজ করবে না। হোমে গিয়ে চালু করুন।',
                      style: TextStyle(fontSize: 12, color: cs.onErrorContainer))),
            ]),
          ),
        ),
      if (!widget.hasUsage)
        const Padding(padding: EdgeInsets.only(bottom: 8), child: UsageAccessPrompt(compact: true)),
      const SectionLabel('ডেটা প্যাক বাজেট'),
      _packCard(),
      const SizedBox(height: 8),
      _phoneCard(),
      const SizedBox(height: 8),
      _settings(),
      const SectionLabel('অ্যাপ ধরে ডেটা লিমিট'),
      for (final e in entries)
        Padding(padding: const EdgeInsets.only(bottom: 8), child: _appRow(e.key, e.value)),
      OutlinedButton.icon(
        onPressed: _addApp,
        icon: const Icon(Icons.add),
        label: const Text('অ্যাপ লিমিট যোগ করুন'),
      ),
    ]);
  }
}
