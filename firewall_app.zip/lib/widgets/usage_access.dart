import 'package:flutter/material.dart';
import '../services/vpn_channel.dart';
import 'common.dart';

/// Usage access অনুমতি না থাকলে দেখানো হয়
class UsageAccessPrompt extends StatelessWidget {
  final bool compact;
  const UsageAccessPrompt({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (compact) {
      return AppCard(
        child: Row(children: [
          Icon(Icons.info_outline, color: cs.primary),
          const SizedBox(width: 12),
          const Expanded(child: Text('সময় দেখতে Usage access অনুমতি লাগবে')),
          TextButton(onPressed: VpnChannel.openUsageAccess, child: const Text('অনুমতি')),
        ]),
      );
    }
    Widget step(int n, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 12, child: Text('$n', style: const TextStyle(fontSize: 12))),
            const SizedBox(width: 12),
            Expanded(child: Text(t)),
          ]),
        );
    return Centered(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        const SizedBox(height: 12),
        Icon(Icons.hourglass_bottom_rounded, size: 64, color: cs.primary),
        const SizedBox(height: 12),
        const Text('স্ক্রিন টাইম দেখতে অনুমতি লাগবে',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('সুইচ ধূসর হয়ে থাকলে (Restricted Setting):',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            step(1, 'নিচের "অ্যাপ সেটিংস খুলুন" বাটনে চাপুন'),
            step(2, 'উপরে ডানে ⋮ (তিন ডট) চাপুন'),
            step(3, '"Allow restricted settings" চাপুন, তারপর PIN/ফিঙ্গারপ্রিন্ট দিন'),
            step(4, 'ফিরে এসে "Usage access" খুলে Firewall চালু করুন'),
          ]),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
            onPressed: VpnChannel.openAppSettings,
            icon: const Icon(Icons.settings),
            label: const Text('অ্যাপ সেটিংস খুলুন')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
            onPressed: VpnChannel.openUsageAccess,
            icon: const Icon(Icons.key),
            label: const Text('Usage access খুলুন')),
      ]),
    );
  }
}
