import 'package:flutter/material.dart';

const stGradient = [Color(0xFF0EA5E9), Color(0xFF6366F1)];
const focusGradient = [Color(0xFFF97316), Color(0xFFE11D48)];

const weekdayNames = ['সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি', 'রবি'];

String fmtDur(int ms) {
  final m = ms ~/ 60000;
  if (m <= 0) return ms > 0 ? '<1 মি' : '0 মি';
  final h = m ~/ 60;
  final r = m % 60;
  return h > 0 ? '$h ঘ $r মি' : '$m মি';
}

String fmtClock(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final p = d.hour >= 5 && d.hour < 12
      ? 'সকাল'
      : d.hour < 16 && d.hour >= 12
          ? 'দুপুর'
          : d.hour < 18 && d.hour >= 16
              ? 'বিকাল'
              : d.hour < 20 && d.hour >= 18
                  ? 'সন্ধ্যা'
                  : 'রাত';
  return '$p $h:${d.minute.toString().padLeft(2, '0')}';
}

String fmtMmSs(int ms) {
  final s = ms ~/ 1000;
  return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
}

/// সংখ্যা ০ থেকে গুনে উঠবে
class CountUp extends StatelessWidget {
  final int value;
  final String Function(int) fmt;
  final TextStyle? style;
  const CountUp({super.key, required this.value, required this.fmt, this.style});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: value.toDouble()),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => Text(fmt(v.round()), style: style),
    );
  }
}

class GradientCard extends StatelessWidget {
  final List<Color> colors;
  final Widget child;
  final EdgeInsetsGeometry padding;
  const GradientCard(
      {super.key, required this.colors, required this.child, this.padding = const EdgeInsets.all(20)});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
      ),
      child: child,
    );
  }
}

/// গ্রেডিয়েন্টের ওপর ছোট চিপ
class GlassChip extends StatelessWidget {
  final IconData icon;
  final String text;
  const GlassChip(this.icon, this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: Colors.white.withAlpha(45), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: Colors.white),
        const SizedBox(width: 6),
        Flexible(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 12))),
      ]),
    );
  }
}

/// অ্যানিমেটেড বার চার্ট (ট্যাপ করে দিন বাছা যায়)
class BarChart extends StatelessWidget {
  final List<int> values;
  final List<String> labels;
  final int selected;
  final int goal; // ০ হলে লাইন নেই
  final Color color;
  final ValueChanged<int>? onTap;
  const BarChart({
    super.key,
    required this.values,
    required this.labels,
    required this.selected,
    required this.color,
    this.goal = 0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    var maxV = 1;
    for (final v in values) {
      if (v > maxV) maxV = v;
    }
    if (goal > maxV) maxV = goal;
    const h = 120.0;
    final sum = values.fold<int>(0, (a, b) => a + b);
    return TweenAnimationBuilder<double>(
      key: ValueKey('${values.length}-$sum'),
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (c, t, _) => SizedBox(
        height: h + 20,
        child: Stack(children: [
          if (goal > 0)
            Positioned(
              left: 0,
              right: 0,
              bottom: 18 + h * goal / maxV,
              child: Container(height: 1, color: cs.error.withAlpha(140)),
            ),
          Positioned.fill(
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var i = 0; i < values.length; i++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: onTap == null ? null : () => onTap!(i),
                    child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Container(
                        height: values[i] > 0 ? (h * values[i] / maxV * t < 3 ? 3.0 : h * values[i] / maxV * t) : 0.0,
                        margin: EdgeInsets.symmetric(horizontal: values.length > 10 ? 1 : 6),
                        decoration: BoxDecoration(
                          color: i == selected ? color : color.withAlpha(110),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                        ),
                      ),
                      SizedBox(
                        height: 18,
                        child: Text(labels[i],
                            maxLines: 1,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: i == selected ? FontWeight.w700 : FontWeight.w400,
                              color: i == selected ? cs.onSurface : cs.outline,
                            )),
                      ),
                    ]),
                  ),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class MiniStat extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;
  const MiniStat(this.icon, this.value, this.label, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: color.withAlpha(28),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(children: [
        Icon(icon, color: color),
        const SizedBox(height: 6),
        Text(value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(label, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}
