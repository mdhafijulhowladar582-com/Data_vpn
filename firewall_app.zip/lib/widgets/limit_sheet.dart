import 'package:flutter/material.dart';
import '../services/lock_service.dart';
import '../services/rules_storage.dart';
import 'app_tile.dart';

/// একটা অ্যাপের দৈনিক সময়সীমা বাছাই/বদল/সরানো।
/// বাড়ানো বা সরানোর আগে পিন/ফিঙ্গারপ্রিন্ট যাচাই (লক থাকলে)।
Future<void> showLimitSheet(BuildContext context, String pkg, String name) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (ctx) {
      final cur = store.cfg.limits[pkg];
      const options = [15, 30, 45, 60, 90, 120, 180];
      String label(int m) => m < 60 ? '$m মি' : (m % 60 == 0 ? '${m ~/ 60} ঘ' : '${m ~/ 60} ঘ ${m % 60} মি');
      return Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            AppIcon(pkg, size: 36),
            const SizedBox(width: 12),
            Expanded(
                child: Text(name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
          ]),
          const SizedBox(height: 6),
          Text('দৈনিক সময়সীমা শেষ হলে এই অ্যাপের ইন্টারনেট বন্ধ হবে (ফায়ারওয়াল চালু থাকলে)।',
              style: Theme.of(ctx).textTheme.bodySmall),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final m in options)
              ChoiceChip(
                label: Text(label(m)),
                selected: cur == m,
                onSelected: (_) async {
                  if (cur != null && m > cur) {
                    if (!await Lock.ask(ctx, reason: 'লিমিট বাড়াতে যাচাই করুন')) return;
                  }
                  store.setLimit(pkg, m);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
              ),
          ]),
          if (cur != null) ...[
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: () async {
                if (!await Lock.ask(ctx, reason: 'লিমিট সরাতে যাচাই করুন')) return;
                store.removeLimit(pkg);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              icon: const Icon(Icons.delete_outline),
              label: const Text('লিমিট সরান'),
            ),
          ],
        ]),
      );
    },
  );
}
