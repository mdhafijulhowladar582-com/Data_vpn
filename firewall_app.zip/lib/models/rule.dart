/// true = ব্লক
class Rule {
  bool wifi;
  bool mobile;
  Rule({this.wifi = false, this.mobile = false});

  bool get any => wifi || mobile;

  Map<String, dynamic> toJson() => {'wifi': wifi, 'mobile': mobile};

  factory Rule.fromJson(Map<String, dynamic> j) =>
      Rule(wifi: j['wifi'] == true, mobile: j['mobile'] == true);
}

class Config {
  bool enabled = false; // Kotlin নিজে এটা ঠিক রাখে
  String mode = 'blocklist'; // blocklist | whitelist
  bool blockAll = false;
  Map<String, Rule> rules = {};
  Set<String> allowed = {};
  bool screenOffBlock = false;
  bool scheduleEnabled = false;
  int schStart = 0; // মিনিট (০ = রাত ১২টা)
  int schEnd = 360; // সকাল ৬টা
  bool blockNew = false;
  String pinHash = '';
  String theme = 'dark'; // dark | light | system
  Map<String, int> limits = {}; // pkg -> দৈনিক লিমিট (মিনিট)
  Set<String> focusAllowed = {}; // ফোকাসে ইন্টারনেট পাবে যারা
  int focusUntil = 0; // Kotlin-এর মালিকানা, শুধু পড়া
  bool bio = false; // ফিঙ্গারপ্রিন্ট
  int goalMin = 240; // দৈনিক স্ক্রিন টাইম লক্ষ্য (মিনিট)

  // ---- ডেটা লিমিট (গণনা ও ব্লক করে Kotlin) ----
  int dlPhoneMb = 0; // ফোনের মোবাইল ডেটা লিমিট (MB), ০ = নেই
  Map<String, int> dlApps = {}; // pkg -> অ্যাপ ডেটা লিমিট (MB)
  List<int> dlWarnPct = [80]; // সতর্কতা: লিমিটের % (একাধিক)
  List<int> dlWarnMb = []; // সতর্কতা: মোট খরচ MB (একাধিক)
  bool dlCut = false; // লিমিট পূর্ণ হলে ডেটা কাটবে কিনা
  bool dlWifi = false; // Wi-Fi-র ডেটাও গুনবে কিনা
  int dlResetDay = 0; // ০ = প্রতিদিন মাঝরাতে, ১-২৮ = প্রতি মাসের ওই তারিখে
  Set<String> dlExempt = {}; // জরুরি ছাড়ের অ্যাপ (কাটের সময়ও ডেটা পাবে)

  // ---- অ্যাপ গার্ড ----
  Set<String> lockedApps = {}; // খুলতে পিন/ফিঙ্গারপ্রিন্ট লাগবে
  Set<String> hiddenApps = {}; // সফট হাইড: ফায়ারওয়ালের অ্যাপ তালিকা থেকে আড়াল (নিয়ম থাকে)

  Config();

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'mode': mode,
        'blockAll': blockAll,
        'rules': rules.map((k, v) => MapEntry(k, v.toJson())),
        'allowed': allowed.toList(),
        'screenOffBlock': screenOffBlock,
        'scheduleEnabled': scheduleEnabled,
        'schStart': schStart,
        'schEnd': schEnd,
        'blockNew': blockNew,
        'pinHash': pinHash,
        'theme': theme,
        'limits': limits,
        'focusAllowed': focusAllowed.toList(),
        'focusUntil': focusUntil,
        'bio': bio,
        'goalMin': goalMin,
        'dlPhoneMb': dlPhoneMb,
        'dlApps': dlApps,
        'dlWarnPct': dlWarnPct,
        'dlWarnMb': dlWarnMb,
        'dlCut': dlCut,
        'dlWifi': dlWifi,
        'dlResetDay': dlResetDay,
        'dlExempt': dlExempt.toList(),
        'lockedApps': lockedApps.toList(),
        'hiddenApps': hiddenApps.toList(),
      };

  factory Config.fromJson(Map<String, dynamic> j) {
    final c = Config();
    c.enabled = j['enabled'] == true;
    c.mode = (j['mode'] as String?) ?? 'blocklist';
    c.blockAll = j['blockAll'] == true;
    final r = j['rules'];
    if (r is Map) {
      r.forEach((k, v) {
        c.rules[k as String] = Rule.fromJson(Map<String, dynamic>.from(v as Map));
      });
    }
    final a = j['allowed'];
    if (a is List) c.allowed = a.map((e) => e as String).toSet();
    c.screenOffBlock = j['screenOffBlock'] == true;
    c.scheduleEnabled = j['scheduleEnabled'] == true;
    c.schStart = (j['schStart'] as num?)?.toInt() ?? 0;
    c.schEnd = (j['schEnd'] as num?)?.toInt() ?? 360;
    c.blockNew = j['blockNew'] == true;
    c.pinHash = (j['pinHash'] as String?) ?? '';
    c.theme = (j['theme'] as String?) ?? 'dark';
    final l = j['limits'];
    if (l is Map) {
      l.forEach((k, v) => c.limits[k as String] = (v as num).toInt());
    }
    final fa = j['focusAllowed'];
    if (fa is List) c.focusAllowed = fa.map((e) => e as String).toSet();
    c.focusUntil = (j['focusUntil'] as num?)?.toInt() ?? 0;
    c.bio = j['bio'] == true;
    c.goalMin = (j['goalMin'] as num?)?.toInt() ?? 240;
    c.dlPhoneMb = (j['dlPhoneMb'] as num?)?.toInt() ?? 0;
    final da = j['dlApps'];
    if (da is Map) {
      da.forEach((k, v) => c.dlApps[k as String] = (v as num).toInt());
    }
    final wp = j['dlWarnPct'];
    if (wp is List) c.dlWarnPct = wp.map((e) => (e as num).toInt()).toList();
    final wm = j['dlWarnMb'];
    if (wm is List) c.dlWarnMb = wm.map((e) => (e as num).toInt()).toList();
    c.dlCut = j['dlCut'] == true;
    c.dlWifi = j['dlWifi'] == true;
    c.dlResetDay = (j['dlResetDay'] as num?)?.toInt() ?? 0;
    final de = j['dlExempt'];
    if (de is List) c.dlExempt = de.map((e) => e as String).toSet();
    final la = j['lockedApps'];
    if (la is List) c.lockedApps = la.map((e) => e as String).toSet();
    final ha = j['hiddenApps'];
    if (ha is List) c.hiddenApps = ha.map((e) => e as String).toSet();
    return c;
  }
}
