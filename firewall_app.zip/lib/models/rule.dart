/// true = ব্লক
class Rule {
  bool wifi;
  bool mobile;
  Rule({this.wifi = false, this.mobile = false});

  bool get any => wifi || mobile;

  Map<String, dynamic> toJson() => {'wifi': wifi, 'mobile': mobile};

  factory Rule.fromJson(Map<String, dynamic> j) =>
      Rule(wifi: j['wifi'] == true, mobile: j['mobile'] == true);
}

class Config {
  bool enabled = false; // Kotlin নিজে এটা ঠিক রাখে
  String mode = 'blocklist'; // blocklist | whitelist
  bool blockAll = false;
  Map<String, Rule> rules = {};
  Set<String> allowed = {};
  bool screenOffBlock = false;
  bool scheduleEnabled = false;
  int schStart = 0; // মিনিট (০ = রাত ১২টা)
  int schEnd = 360; // সকাল ৬টা
  bool blockNew = false;
  String pinHash = '';

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'mode': mode,
        'blockAll': blockAll,
        'rules': rules.map((k, v) => MapEntry(k, v.toJson())),
        'allowed': allowed.toList(),
        'screenOffBlock': screenOffBlock,
        'scheduleEnabled': scheduleEnabled,
        'schStart': schStart,
        'schEnd': schEnd,
        'blockNew': blockNew,
        'pinHash': pinHash,
      };

  factory Config.fromJson(Map<String, dynamic> j) {
    final c = Config();
    c.enabled = j['enabled'] == true;
    c.mode = (j['mode'] as String?) ?? 'blocklist';
    c.blockAll = j['blockAll'] == true;
    final r = j['rules'];
    if (r is Map) {
      r.forEach((k, v) {
        c.rules[k as String] = Rule.fromJson(Map<String, dynamic>.from(v as Map));
      });
    }
    final a = j['allowed'];
    if (a is List) c.allowed = a.map((e) => e as String).toSet();
    c.screenOffBlock = j['screenOffBlock'] == true;
    c.scheduleEnabled = j['scheduleEnabled'] == true;
    c.schStart = (j['schStart'] as num?)?.toInt() ?? 0;
    c.schEnd = (j['schEnd'] as num?)?.toInt() ?? 360;
    c.blockNew = j['blockNew'] == true;
    c.pinHash = (j['pinHash'] as String?) ?? '';
    return c;
  }
}
