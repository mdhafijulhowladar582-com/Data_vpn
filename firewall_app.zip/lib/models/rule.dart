/// true = ব্লক
class Rule {
  bool wifi;
  bool mobile;
  Rule({this.wifi = false, this.mobile = false});

  bool get any => wifi || mobile;

  Map<String, dynamic> toJson() => {'wifi': wifi, 'mobile': mobile};

  factory Rule.fromJson(Map<String, dynamic> j) =>
      Rule(wifi: j['wifi'] == true, mobile: j['mobile'] == true);
}

class Config {
  bool enabled = false; // Kotlin নিজে এটা ঠিক রাখে
  String mode = 'blocklist'; // blocklist | whitelist
  bool blockAll = false;
  Map<String, Rule> rules = {};
  Set<String> allowed = {};
  bool screenOffBlock = false;
  bool scheduleEnabled = false;
  int schStart = 0; // মিনিট (০ = রাত ১২টা)
  int schEnd = 360; // সকাল ৬টা
  bool blockNew = false;
  String pinHash = '';
  String theme = 'dark'; // dark | light | system
  Map<String, int> limits = {}; // pkg -> দৈনিক লিমিট (মিনিট)
  Set<String> focusAllowed = {}; // ফোকাসে ইন্টারনেট পাবে যারা
  int focusUntil = 0; // Kotlin-এর মালিকানা, শুধু পড়া
  bool bio = false; // ফিঙ্গারপ্রিন্ট
  int goalMin = 240; // দৈনিক স্ক্রিন টাইম লক্ষ্য (মিনিট)

  // ---- ডেটা লিমিট (গণনা ও ব্লক করে Kotlin) ----
  int dlPhoneMb = 0; // ফোনের মোবাইল ডেটা লিমিট (MB), ০ = নেই
  Map<String, int> dlApps = {}; // pkg -> অ্যাপ ডেটা লিমিট (MB)
  List<int> dlWarnPct = [80]; // সতর্কতা: লিমিটের % (একাধিক)
  List<int> dlWarnMb = []; // সতর্কতা: মোট খরচ MB (একাধিক)
  bool dlCut = false; // লিমিট পূর্ণ হলে ডেটা কাটবে কিনা
  bool dlWifi = false; // Wi-Fi-র ডেটাও গুনবে কিনা
  int dlResetDay = 0; // ০ = প্রতিদিন মাঝরাতে, ১-২৮ = প্রতি মাসের ওই তারিখে
  Set<String> dlExempt = {}; // জরুরি ছাড়ের অ্যাপ (কাটের সময়ও ডেটা পাবে)
  int dlPackMb = 0; // ডেটা প্যাকের আকার (MB), ০ = প্যাক নেই
  int dlPackDays = 0; // প্যাকের মেয়াদ (দিন)
  int dlPackStart = 0; // প্যাক শুরুর সময় (ms, ওই দিনের মাঝরাত)
  bool dlPackStrict = true; // শেষ ২৫%-এ আজকের ভাগ পেরোলে মোবাইল ডেটা বন্ধ

  // ---- অ্যাপ গার্ড ----
  Set<String> lockedApps = {}; // খুলতে পিন/ফিঙ্গারপ্রিন্ট লাগবে
  Set<String> hiddenApps = {}; // সফট হাইড: ফায়ারওয়ালের অ্যাপ তালিকা থেকে আড়াল (নিয়ম থাকে)

  // ---- স্বয়ংক্রিয় নিয়ম ----
  bool wifiOpen = false; // Wi-Fi-তে অ্যাপ-ভিত্তিক ব্লক বন্ধ (মোবাইল ডেটায় আগের নিয়ম)
  bool roamBlock = false; // রোমিংয়ে মোবাইল ডেটা বন্ধ
  Set<String> bgBlock = {}; // ব্যাকগ্রাউন্ডে ইন্টারনেট বন্ধ থাকবে যাদের

  bool liveStat = true; // নোটিফিকেশনে লাইভ স্পিড ও আজকের ডেটা

  // ---- দ্রুত মোড (ট্রেডিং, ঘুম ইত্যাদি): চালু থাকলে শুধু বাছা অ্যাপ ইন্টারনেট পায় ----
  Map<String, Set<String>> profiles = {'ট্রেডিং মোড': <String>{}, 'ঘুম মোড': <String>{}};
  String activeMode = ''; // খালি = সাধারণ নিয়ম

  // ---- ব্লক নোটিফিকেশন (দেখায় Kotlin) ----
  bool noticeOn = true; // অ্যাপ খুললে "ইন্টারনেট বন্ধ" নোটিফিকেশন
  bool weeklyOn = true; // প্রতি শুক্রবার রাতে সাপ্তাহিক রিপোর্টের নোটিফিকেশন
  bool anomalyOn = true; // ব্লক অ্যাপ হঠাৎ বেশি চেষ্টা করলে সতর্কতা
  Set<String> emergency = {}; // জরুরি অ্যাপ: কখনো ব্লক হয় না (ব্যাংক, OTP ইত্যাদি)

  // ---- নিজস্ব ইঞ্জিন (বিজ্ঞাপন ব্লক) ----
  bool engineOn = false; // সুইচ: মালিক Kotlin (নিজে বন্ধ হওয়ার ব্যবস্থার জন্য), Dart শুধু পড়ে
  Set<String> engineApps = {}; // যে অ্যাপগুলোর নেট ইঞ্জিন দিয়ে যাবে
  bool engineBuiltin = true; // বিল্ট-ইন ট্র্যাকার তালিকা
  bool engineBlockDoh = false; // পরিচিত DoH সার্ভারের নাম আটকানো
  List<String> engineDomains = []; // নিজের ডোমেইন তালিকা

  // ---- নিরাপত্তা সরঞ্জাম ----
  bool askNew = false; // নতুন অ্যাপ ইনস্টল হলে "ইন্টারনেট দেব, না ব্লক?" প্রশ্ন (না বলা পর্যন্ত ব্লক)
  bool permWatch = true; // আপডেটে নতুন সংবেদনশীল পারমিশন ধরা
  Set<String> screenOffApps = {}; // স্ক্রিন বন্ধ হলে এদের নেট বন্ধ
  bool leakWatch = true; // স্ক্রিন বন্ধে বেশি ডেটা পাঠালে সতর্কতা
  int leakMb = 10; // সতর্কতার সীমা (MB)
  bool panicNet = false; // প্যানিকে সব অ্যাপের নেটও বন্ধ
  bool intruderPhoto = false; // ৩ বার ভুল পিনে সামনের ক্যামেরায় ছবি (ভল্টে যায়)
  String decoyHash = ''; // নকল পিন (শুধু লুকানো এলাকা ও ভল্টের দরজায় চলে)
  Set<String> decoyApps = {}; // নকল লুকানো এলাকায় যা দেখাবে
  Set<String> guestApps = {}; // গেস্ট মোডে যে অ্যাপ খোলা থাকবে

  Config();

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'mode': mode,
        'blockAll': blockAll,
        'rules': rules.map((k, v) => MapEntry(k, v.toJson())),
        'allowed': allowed.toList(),
        'screenOffBlock': screenOffBlock,
        'scheduleEnabled': scheduleEnabled,
        'schStart': schStart,
        'schEnd': schEnd,
        'blockNew': blockNew,
        'pinHash': pinHash,
        'theme': theme,
        'limits': limits,
        'focusAllowed': focusAllowed.toList(),
        'focusUntil': focusUntil,
        'bio': bio,
        'goalMin': goalMin,
        'dlPhoneMb': dlPhoneMb,
        'dlApps': dlApps,
        'dlWarnPct': dlWarnPct,
        'dlWarnMb': dlWarnMb,
        'dlCut': dlCut,
        'dlWifi': dlWifi,
        'dlResetDay': dlResetDay,
        'dlExempt': dlExempt.toList(),
        'dlPackMb': dlPackMb,
        'dlPackDays': dlPackDays,
        'dlPackStart': dlPackStart,
        'dlPackStrict': dlPackStrict,
        'lockedApps': lockedApps.toList(),
        'hiddenApps': hiddenApps.toList(),
        'profiles': profiles.map((k, v) => MapEntry(k, {'allowed': v.toList()})),
        'activeMode': activeMode,
        'liveStat': liveStat,
        'wifiOpen': wifiOpen,
        'roamBlock': roamBlock,
        'bgBlock': bgBlock.toList(),
        'noticeOn': noticeOn,
        'weeklyOn': weeklyOn,
        'anomalyOn': anomalyOn,
        'emergency': emergency.toList(),
        'engineOn': engineOn,
        'engineApps': engineApps.toList(),
        'engineBuiltin': engineBuiltin,
        'engineBlockDoh': engineBlockDoh,
        'engineDomains': engineDomains,
        'askNew': askNew,
        'permWatch': permWatch,
        'screenOffApps': screenOffApps.toList(),
        'leakWatch': leakWatch,
        'leakMb': leakMb,
        'panicNet': panicNet,
        'intruderPhoto': intruderPhoto,
        'decoyHash': decoyHash,
        'decoyApps': decoyApps.toList(),
        'guestApps': guestApps.toList(),
      };

  factory Config.fromJson(Map<String, dynamic> j) {
    final c = Config();
    c.enabled = j['enabled'] == true;
    c.mode = (j['mode'] as String?) ?? 'blocklist';
    c.blockAll = j['blockAll'] == true;
    final r = j['rules'];
    if (r is Map) {
      r.forEach((k, v) {
        c.rules[k as String] = Rule.fromJson(Map<String, dynamic>.from(v as Map));
      });
    }
    final a = j['allowed'];
    if (a is List) c.allowed = a.map((e) => e as String).toSet();
    c.screenOffBlock = j['screenOffBlock'] == true;
    c.scheduleEnabled = j['scheduleEnabled'] == true;
    c.schStart = (j['schStart'] as num?)?.toInt() ?? 0;
    c.schEnd = (j['schEnd'] as num?)?.toInt() ?? 360;
    c.blockNew = j['blockNew'] == true;
    c.pinHash = (j['pinHash'] as String?) ?? '';
    c.theme = (j['theme'] as String?) ?? 'dark';
    final l = j['limits'];
    if (l is Map) {
      l.forEach((k, v) => c.limits[k as String] = (v as num).toInt());
    }
    final fa = j['focusAllowed'];
    if (fa is List) c.focusAllowed = fa.map((e) => e as String).toSet();
    c.focusUntil = (j['focusUntil'] as num?)?.toInt() ?? 0;
    c.bio = j['bio'] == true;
    c.goalMin = (j['goalMin'] as num?)?.toInt() ?? 240;
    c.dlPhoneMb = (j['dlPhoneMb'] as num?)?.toInt() ?? 0;
    final da = j['dlApps'];
    if (da is Map) {
      da.forEach((k, v) => c.dlApps[k as String] = (v as num).toInt());
    }
    final wp = j['dlWarnPct'];
    if (wp is List) c.dlWarnPct = wp.map((e) => (e as num).toInt()).toList();
    final wm = j['dlWarnMb'];
    if (wm is List) c.dlWarnMb = wm.map((e) => (e as num).toInt()).toList();
    c.dlCut = j['dlCut'] == true;
    c.dlWifi = j['dlWifi'] == true;
    c.dlResetDay = (j['dlResetDay'] as num?)?.toInt() ?? 0;
    c.dlPackMb = (j['dlPackMb'] as num?)?.toInt() ?? 0;
    c.dlPackDays = (j['dlPackDays'] as num?)?.toInt() ?? 0;
    c.dlPackStart = (j['dlPackStart'] as num?)?.toInt() ?? 0;
    c.dlPackStrict = j['dlPackStrict'] != false;
    final de = j['dlExempt'];
    if (de is List) c.dlExempt = de.map((e) => e as String).toSet();
    final la = j['lockedApps'];
    if (la is List) c.lockedApps = la.map((e) => e as String).toSet();
    final ha = j['hiddenApps'];
    if (ha is List) c.hiddenApps = ha.map((e) => e as String).toSet();
    final pf = j['profiles'];
    if (pf is Map) {
      c.profiles = {};
      pf.forEach((k, v) {
        final al = v is Map ? v['allowed'] : null;
        c.profiles[k as String] = al is List ? al.map((e) => e as String).toSet() : <String>{};
      });
    }
    c.activeMode = (j['activeMode'] as String?) ?? '';
    c.liveStat = j['liveStat'] != false;
    c.wifiOpen = j['wifiOpen'] == true;
    c.roamBlock = j['roamBlock'] == true;
    final bg = j['bgBlock'];
    if (bg is List) c.bgBlock = bg.map((e) => e as String).toSet();
    c.noticeOn = j['noticeOn'] != false;
    c.weeklyOn = j['weeklyOn'] != false;
    c.anomalyOn = j['anomalyOn'] != false;
    final em = j['emergency'];
    if (em is List) c.emergency = em.map((e) => e as String).toSet();
    c.engineOn = j['engineOn'] == true;
    final ea = j['engineApps'];
    if (ea is List) c.engineApps = ea.map((e) => e as String).toSet();
    c.engineBuiltin = j['engineBuiltin'] != false;
    c.engineBlockDoh = j['engineBlockDoh'] == true;
    final ed = j['engineDomains'];
    if (ed is List) c.engineDomains = ed.map((e) => e as String).toList();
    c.askNew = j['askNew'] == true;
    c.permWatch = j['permWatch'] != false;
    final so = j['screenOffApps'];
    if (so is List) c.screenOffApps = so.map((e) => e as String).toSet();
    c.leakWatch = j['leakWatch'] != false;
    c.leakMb = (j['leakMb'] as num?)?.toInt() ?? 10;
    c.panicNet = j['panicNet'] == true;
    c.intruderPhoto = j['intruderPhoto'] == true;
    c.decoyHash = (j['decoyHash'] as String?) ?? '';
    final dca = j['decoyApps'];
    if (dca is List) c.decoyApps = dca.map((e) => e as String).toSet();
    final ga = j['guestApps'];
    if (ga is List) c.guestApps = ga.map((e) => e as String).toSet();
    return c;
  }
}
