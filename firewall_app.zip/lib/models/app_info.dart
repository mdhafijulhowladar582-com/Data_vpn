class AppInfo {
  final String name;
  final String pkg;
  final bool system;
  AppInfo(this.name, this.pkg, this.system);

  factory AppInfo.fromMap(Map<String, dynamic> m) =>
      AppInfo(m['name'] as String, m['pkg'] as String, m['system'] == true);
}
