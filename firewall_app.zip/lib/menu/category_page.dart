import 'package:flutter/material.dart';
import '../widgets/common.dart';
import 'badge_center.dart';
import 'registry.dart';

/// এক ক্যাটাগরির পেজ: ভেতরে শুধু ওই ধরনের নতুন ফিচারের কার্ড। কার্ডে ট্যাপ করলে ফিচারের পূর্ণ পেজ খোলে।
class CategoryPage extends StatelessWidget {
  final MenuGroup group;
  const CategoryPage({super.key, required this.group});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(group.title)),
      body: ListenableBuilder(
        listenable: BadgeCenter.instance,
        builder: (context, _) {
          final items = featuresOf(group.id);
          if (items.isEmpty) return _empty(context);
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Centered(
                child: Column(children: [
                  for (final f in items) ...[
                    _card(context, f),
                    const SizedBox(height: 12),
                  ],
                ]),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _empty(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(group.icon, size: 56, color: cs.onSurfaceVariant),
          const SizedBox(height: 16),
          Text(group.title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(
            'এখানে এখনো কোনো ফিচার নেই। ফিচার তৈরি হলে এই পেজে কার্ড হিসেবে আসবে।',
            textAlign: TextAlign.center,
            style: TextStyle(color: cs.onSurfaceVariant),
          ),
        ]),
      ),
    );
  }

  Widget _card(BuildContext context, FeatureEntry f) {
    final cs = Theme.of(context).colorScheme;
    final badge = f.badgeKey == null ? 0 : BadgeCenter.instance.of(f.badgeKey!);
    return AppCard(
      padding: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (ctx) => f.page(ctx))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            CircleAvatar(
              backgroundColor: cs.primaryContainer,
              foregroundColor: cs.onPrimaryContainer,
              child: Icon(f.icon),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(f.title,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                const SizedBox(height: 2),
                Text(f.subtitle,
                    style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
              ]),
            ),
            if (badge > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                    color: cs.error, borderRadius: BorderRadius.circular(10)),
                child: Text('$badge',
                    style: TextStyle(
                        color: cs.onError, fontSize: 12, fontWeight: FontWeight.w700)),
              ),
            const SizedBox(width: 6),
            Icon(Icons.chevron_right, color: cs.onSurfaceVariant),
          ]),
        ),
      ),
    );
  }
}
