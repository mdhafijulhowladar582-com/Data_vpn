import 'dart:convert';
import 'package:flutter/services.dart';

/// নতুন ফিচারের Kotlin পাশের সাথে যোগাযোগ। আগের `firewall/vpn` চ্যানেলে হাত দেওয়া হয়নি।
class XChannel {
  static const _ch = MethodChannel('firewall/x');

  static Future<List<Map<String, dynamic>>> _list(String m, [Map<String, dynamic>? a]) async {
    try {
      final r = await _ch.invokeMethod<List<dynamic>>(m, a);
      return (r ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<bool> _ok(String m, [Map<String, dynamic>? a]) async {
    try {
      return (await _ch.invokeMethod<bool>(m, a)) == true;
    } catch (_) {
      return false;
    }
  }

  /// নতুন ডেটাবেসের অবস্থা: {ok, version, conn_log, samples, incidents, scam_hits, net_ping}
  static Future<Map<String, dynamic>> dbInfo() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('dbInfo');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  // ---- কানেকশন লগ ----
  /// অ্যাপ ধরে মোট: pkg, up, down, hosts, last
  static Future<List<Map<String, dynamic>>> connApps(int fromMs) =>
      _list('connApps', {'from': fromMs});

  /// একটা অ্যাপের গন্তব্য: host, named, up, down, last, fgRows
  static Future<List<Map<String, dynamic>>> connHosts(String pkg, int fromMs) =>
      _list('connHosts', {'pkg': pkg, 'from': fromMs});

  static Future<bool> connClear() => _ok('connClear');

  // ---- স্ক্যাম গার্ড ----
  static Future<List<Map<String, dynamic>>> scamHits() => _list('scamHits');
  static Future<bool> scamSeen() => _ok('scamSeen');
  static Future<bool> scamClear() => _ok('scamClear');

  /// নিজের যোগ করা: host, kind ("block" বা "allow")
  static Future<List<Map<String, dynamic>>> scamUsers() => _list('scamUsers');
  static Future<bool> scamSet(String host, String kind) =>
      _ok('scamSet', {'host': host, 'kind': kind});
  static Future<bool> scamRemove(String host) => _ok('scamRemove', {'host': host});

  // ---- নেটের মান ----
  /// সর্বশেষ ৬০০টা মাপ, নতুন আগে: t, net, ms, ok
  static Future<List<Map<String, dynamic>>> qualityList(int sinceMs) =>
      _list('qualityList', {'since': sinceMs});

  // ---- ব্ল্যাক বক্স ----
  /// স্যাম্পল, পুরনো আগে: t, batt, temp (দশমিক °C), charging, mem (MB), lowMem, thermal, screen, fg, data (বাইট)
  static Future<List<Map<String, dynamic>>> bbSamples(int sinceMs) =>
      _list('bbSamples', {'since': sinceMs});

  /// ইনসিডেন্ট, নতুন আগে: id, t, type, title, detail, seen
  static Future<List<Map<String, dynamic>>> bbIncidents() => _list('bbIncidents');
  static Future<bool> bbSeen() => _ok('bbSeen');
  static Future<bool> bbClear() => _ok('bbClear');

  /// "এখন কেন?": শেষ ১০ মিনিটের বাংলা বিশ্লেষণ
  static Future<String> bbWhy([String type = 'now']) async {
    try {
      return (await _ch.invokeMethod<String>('bbWhy', {'type': type})) ?? '';
    } catch (_) {
      return '';
    }
  }

  // ---- পারমিশন অডিটর ----
  /// pkg, name, score, level (high/mid/low), perms, unusedDays (-1 = জানা নেই), bytes, reasons, usageOk
  static Future<List<Map<String, dynamic>>> permScan() => _list('permScan');
  static Future<bool> openPkgSettings(String pkg) => _ok('openPkgSettings', {'pkg': pkg});

  // ---- পাবলিক Wi-Fi ----
  /// perm, onWifi, ssid (null = পড়া যায়নি), trusted, list
  static Future<Map<String, dynamic>> wifiState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('wifiState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> wifiTrust(String ssid, bool on) => _ok('wifiTrust', {'ssid': ssid, 'on': on});
  static Future<bool> wifiSeen() => _ok('wifiSeen');
  static Future<bool> wifiAskPerm() => _ok('wifiAskPerm');
  static Future<bool> openLocationSettings() => _ok('openLocationSettings');

  // ---- ধাপ ৪: কন্ট্রোল (অবস্থা Kotlin-এর আলাদা প্রেফারেন্সে, Config-এ নয়) ----
  /// name = auto | parental | trade। auto হলে List, বাকিগুলো Map
  static Future<dynamic> ctlGet(String name) async {
    try {
      final s = await _ch.invokeMethod<String>('ctlGet', {'name': name});
      return jsonDecode(s ?? (name == 'auto' ? '[]' : '{}'));
    } catch (_) {
      return name == 'auto' ? <dynamic>[] : <String, dynamic>{};
    }
  }

  /// false = সেভ হয়নি (যেমন ট্রেড লক চলাকালে বদলানো যায় না)
  static Future<bool> ctlSet(String name, Object data) =>
      _ok('ctlSet', {'name': name, 'json': jsonEncode(data)});

  static Future<List<String>> autoActive() async {
    try {
      final r = await _ch.invokeMethod<List<dynamic>>('autoActive');
      return (r ?? const []).cast<String>();
    } catch (_) {
      return [];
    }
  }

  /// {trades, losses, opens, lockLeftMs}
  static Future<Map<String, dynamic>> tradeInfo() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('tradeInfo');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  /// kind = trade | loss
  static Future<Map<String, dynamic>> tradeAdd(String kind) async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('tradeAdd', {'kind': kind});
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  // ---- ধাপ ৫: ল্যাব ----
  static Future<Map<String, dynamic>> chargerState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('chargerState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> chargerActive(String name) => _ok('chargerActive', {'name': name});
  static Future<bool> chargerDelete(String name) => _ok('chargerDelete', {'name': name});
  static Future<bool> chargerReset(String name) => _ok('chargerReset', {'name': name});

  /// জমা মাপ: name, rssi, speed, t, ssid (সিগন্যাল শক্তি অনুযায়ী)
  static Future<List<Map<String, dynamic>>> wifiSpots() => _list('wifiSpots');

  /// {ok, rssi, speed} বা {ok:false, reason}। ~৪ সেকেন্ড লাগে
  static Future<Map<String, dynamic>> wifiMeasure(String name) async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('wifiMeasure', {'name': name});
      return r == null ? {'ok': false} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {'ok': false};
    }
  }

  static Future<bool> wifiSpotDelete(String name) => _ok('wifiSpotDelete', {'name': name});
  static Future<bool> wifiSpotsClear() => _ok('wifiSpotsClear');

  // ---- পকেট গার্ড ----
  /// {state 0 বন্ধ|1 কাউন্টডাউন|2 চালু|3 পিনের সময়|4 সাইরেন, left, graceLeft, since, reason, prox,
  /// hasPin, cam, hasProxSensor, cfg{mode,sens,tMove,tProx,tCharger,photo,grace,countdown}, log[{t,reason}]}
  static Future<Map<String, dynamic>> pocketState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('pocketState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> pocketCfg(Map<String, dynamic> cfg) => _ok('pocketCfg', {'json': jsonEncode(cfg)});
  static Future<bool> pocketArm() => _ok('pocketArm');
  static Future<bool> pocketCancelArm() => _ok('pocketCancelArm');

  /// পিনের স্ক্রিন খোলে। ঠিক পিনে গার্ড/সাইরেন বন্ধ হয়
  static Future<bool> pocketDisarmAsk() => _ok('pocketDisarmAsk');
  static Future<bool> pocketTest() => _ok('pocketTest');
  static Future<bool> pocketLogClear() => _ok('pocketLogClear');

  // ---- রাতের ডেটা চোর / ঠান্ডা মোড ----
  /// {on, minMb, acc:[{pkg,name,bytes}], last:{t,total,items}|null, fwRunning}
  static Future<Map<String, dynamic>> nightInfo() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('nightInfo');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> nightBlock(String pkg) => _ok('nightBlock', {'pkg': pkg});

  /// {on, active, reason, temp (দশমিক ডিগ্রি), batt, charging, guard, fwRunning}
  static Future<Map<String, dynamic>> coolInfo() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('coolInfo');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  // ---- ফ্লোটিং বাবল ----
  /// {on, running, canDraw, pkgs}
  static Future<Map<String, dynamic>> bubbleState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('bubbleState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> bubbleSet(List<String> pkgs) => _ok('bubbleSet', {'json': jsonEncode(pkgs)});
  static Future<bool> bubbleMini(bool on, int size) => _ok('bubbleMini', {'on': on, 'size': size});
  static Future<bool> bubbleStart() => _ok('bubbleStart');
  static Future<bool> bubbleStop() => _ok('bubbleStop');
  static Future<bool> bubbleAskPerm() => _ok('bubbleAskPerm');

  // ---- রাডার, ফ্লোটিং ডট, ভয়েস অ্যালার্ট ----
  /// {rated, screen, apps: [{pkg, label, bps, today, fg, susp, system}]}
  static Future<Map<String, dynamic>> radarSample() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('radarSample');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  /// "ok", "self", "core" বা "bad"
  static Future<String> radarBlock(String pkg) async {
    try {
      return (await _ch.invokeMethod<String>('radarBlock', {'pkg': pkg})) ?? 'bad';
    } catch (_) {
      return 'bad';
    }
  }

  /// {dot, voice, quiet, canDraw, running}
  static Future<Map<String, dynamic>> wowState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('wowState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  /// key: "dot", "voice" বা "quiet"
  static Future<bool> wowSet(String key, bool on) => _ok('wowSet', {'key': key, 'on': on});
  static Future<bool> wowTest() => _ok('wowTest');

  // ---- নতুন তিন সার্ভিস: আলসে-লক, নেট-হার্টবিট, ডেটা-পোষা ----
  /// {canDraw, lazy, beat, pet, lazyMin, lazySteps, beatVib, petHealth, petUsedMb, petAllowMb, sitMin, steps, lazyRun, beatRun, petRun}
  static Future<Map<String, dynamic>> buddyState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('buddyState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  /// key: "lazy", "beat" বা "pet"। পারমিশন না থাকলে চালু করতে গেলে false
  static Future<bool> buddySet(String key, bool on) => _ok('buddySet', {'key': key, 'on': on});

  /// key: "lazyMin", "lazySteps" বা "beatVib" (১ = চালু, ০ = বন্ধ)
  static Future<bool> buddyOpt(String key, int value) => _ok('buddyOpt', {'key': key, 'value': value});
  static Future<bool> buddyAskPerm() => _ok('buddyAskPerm');

  /// রেফার কোড মিললে true (পোষা সুরক্ষিত: স্ট্রিক ভাঙে না, বাড়ার সীমা নেই)
  static Future<bool> buddyCode(String code) => _ok('buddyCode', {'code': code});

  /// হোম স্ক্রিনে "পোষা ও হার্টবিট" উইজেট বসানোর অনুরোধ (লঞ্চার সমর্থন না করলে false)
  static Future<bool> buddyPinWidget() => _ok('buddyPinWidget');

  // ---- লেখা তোলার ভাসমান বাটন ----
  /// {enabled, on, style, names}
  static Future<Map<String, dynamic>> grabState() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('grabState');
      return r == null ? {} : Map<String, dynamic>.from(r);
    } catch (_) {
      return {};
    }
  }

  static Future<bool> grabSet({bool? on, int? style}) =>
      _ok('grabSet', {if (on != null) 'on': on, if (style != null) 'style': style});

  /// অ্যাক্সেসিবিলিটি সেটিংস খোলে
  static Future<bool> grabAccess() => _ok('grabAccess');

  // ---- মেনুর ব্যাজ ----
  static Future<Map<String, int>> badges() async {
    try {
      final r = await _ch.invokeMethod<Map<dynamic, dynamic>>('badges');
      if (r == null) return {};
      return r.map((k, v) => MapEntry(k as String, (v as num).toInt()));
    } catch (_) {
      return {};
    }
  }
}
