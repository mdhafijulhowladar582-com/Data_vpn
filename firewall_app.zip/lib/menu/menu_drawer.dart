import 'package:flutter/material.dart';
import 'badge_center.dart';
import 'category_page.dart';
import 'registry.dart';
import 'x_channel.dart';

/// হোম পেজের অ্যাপ বারে ☰ বাটন। কোনো নতুন ফিচারে খেয়াল দরকার হলে আইকনে ডট দেখায়।
class MenuButton extends StatefulWidget {
  const MenuButton({super.key});

  @override
  State<MenuButton> createState() => _MenuButtonState();
}

class _MenuButtonState extends State<MenuButton> {
  @override
  void initState() {
    super.initState();
    BadgeCenter.instance.refresh();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: BadgeCenter.instance,
      builder: (ctx, _) => IconButton(
        tooltip: 'নতুন টুলস',
        icon: Badge(
          isLabelVisible: BadgeCenter.instance.total > 0,
          smallSize: 8,
          child: const Icon(Icons.menu),
        ),
        onPressed: () {
          BadgeCenter.instance.refresh();
          Scaffold.of(ctx).openEndDrawer();
        },
      ),
    );
  }
}

/// ডান থেকে খোলা মেনু: শুধু ক্যাটাগরির নাম। ট্যাপ করলে ওই ক্যাটাগরির পেজ খোলে।
class MenuDrawer extends StatelessWidget {
  const MenuDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Drawer(
      child: SafeArea(
        child: ListenableBuilder(
          listenable: BadgeCenter.instance,
          builder: (context, _) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                child: Text('নতুন টুলস',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700)),
              ),
              Expanded(
                child: ListView(children: [
                  for (final g in menuGroups) _tile(context, g),
                ]),
              ),
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.all(16),
                child: _status(cs),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, MenuGroup g) {
    final n = featuresOf(g.id).length;
    final badge = BadgeCenter.instance.ofGroup(g.id);
    return ListTile(
      leading: Icon(g.icon),
      title: Text(g.title),
      subtitle: Text(g.hint),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (badge > 0)
          const Padding(
            padding: EdgeInsets.only(right: 8),
            child: Badge(smallSize: 8),
          ),
        Text('$n'),
      ]),
      onTap: () {
        final nav = Navigator.of(context);
        nav.pop(); // মেনু বন্ধ
        nav.push(MaterialPageRoute(builder: (_) => CategoryPage(group: g)));
      },
    );
  }

  /// নতুন ডেটাবেস ঠিকমতো খুলছে কিনা, ছোট করে দেখায় (ধাপ ০ যাচাইয়ের জন্য)
  Widget _status(ColorScheme cs) {
    return FutureBuilder<Map<String, dynamic>>(
      future: XChannel.dbInfo(),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final ok = snap.data!['ok'] == true;
        return Text(
          ok ? 'ভিত্তি প্রস্তুত · ডেটাবেস ঠিক আছে' : 'ডেটাবেস খোলেনি',
          style: TextStyle(fontSize: 12, color: ok ? cs.onSurfaceVariant : cs.error),
        );
      },
    );
  }
}
