import 'package:flutter/foundation.dart';
import 'registry.dart';
import 'x_channel.dart';

/// মেনুর লাল ডটের হিসাব। ফিচারের পেজ নিজে জানায় ([set]), মেনু শুধু দেখায়।
class BadgeCenter extends ChangeNotifier {
  BadgeCenter._();
  static final BadgeCenter instance = BadgeCenter._();

  final Map<String, int> _counts = {};

  int of(String key) => _counts[key] ?? 0;

  /// সব ক্যাটাগরি মিলিয়ে মোট (☰ আইকনের ডটের জন্য)
  int get total => _counts.values.fold(0, (a, b) => a + b);

  /// একটা ক্যাটাগরির ফিচারগুলোর মোট
  int ofGroup(String groupId) {
    var n = 0;
    for (final f in menuFeatures) {
      if (f.group == groupId && f.badgeKey != null) n += of(f.badgeKey!);
    }
    return n;
  }

  /// [n] <= 0 হলে ব্যাজ মুছে যায়
  void set(String key, int n) {
    if (n <= 0) {
      if (_counts.remove(key) != null) notifyListeners();
    } else if (_counts[key] != n) {
      _counts[key] = n;
      notifyListeners();
    }
  }

  void clear(String key) => set(key, 0);

  /// Kotlin পাশ থেকে নতুন কাউন্ট এনে বসায় (অ্যাপ খোলা ও মেনু খোলার সময়)
  Future<void> refresh() async {
    final b = await XChannel.badges();
    for (final e in b.entries) {
      set(e.key, e.value);
    }
  }
}
