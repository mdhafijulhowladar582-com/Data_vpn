import 'package:flutter/material.dart';
import '../features/automation/automation_page.dart';
import '../features/bubble/bubble_page.dart';
import '../features/buddy/buddy_page.dart';
import '../features/cool/cool_page.dart';
import '../features/night/night_page.dart';
import '../features/tradetime/tradetime_page.dart';
import '../features/blackbox/blackbox_page.dart';
import '../features/charger/charger_page.dart';
import '../features/command/command_page.dart';
import '../features/heatmap/heatmap_page.dart';
import '../features/inspector/inspector_page.dart';
import '../features/money/money_page.dart';
import '../features/parental/parental_page.dart';
import '../features/perm/perm_audit_page.dart';
import '../features/pocket/pocket_page.dart';
import '../features/quality/quality_page.dart';
import '../features/scam/scam_page.dart';
import '../features/textgrab/textgrab_page.dart';
import '../features/trade/trade_page.dart';
import '../features/wifi/wifi_page.dart';
import '../features/wow/radar_page.dart';
import '../features/wow/wow_page.dart';

/// ☰ মেনুর একটা ক্যাটাগরি। প্রতিটা আলাদা পেজ, ভেতরে শুধু ওই ধরনের নতুন ফিচার।
class MenuGroup {
  final String id;
  final String title;
  final String hint;
  final IconData icon;
  const MenuGroup(this.id, this.title, this.hint, this.icon);
}

/// ক্যাটাগরির তালিকা ও ক্রম। নতুন ধরনের ফিচার এলে এখানে একটা লাইন যোগ হবে।
const menuGroups = <MenuGroup>[
  MenuGroup('monitor', 'নজরদারি', 'কে কী করছে, ফোনে কী ঘটছে', Icons.visibility_outlined),
  MenuGroup('data', 'ডেটা ও টাকা', 'ডেটার হিসাব, খরচ', Icons.payments_outlined),
  MenuGroup('security', 'সুরক্ষা', 'স্ক্যাম, পারমিশন, নিরাপদ নেটওয়ার্ক', Icons.verified_user_outlined),
  MenuGroup('control', 'কন্ট্রোল', 'অটোমেশন, প্যারেন্টাল, ট্রেডিং', Icons.tune),
  MenuGroup('lab', 'ল্যাব', 'পরীক্ষামূলক ও বাড়তি টুল', Icons.science_outlined),
];

/// একটা নতুন ফিচার = এক পেজ। [menuFeatures]-এ একটা এন্ট্রি যোগ করলেই সঠিক ক্যাটাগরিতে ঢুকে যাবে।
class FeatureEntry {
  /// অনন্য নাম (নোটিফিকেশন ট্যাপে পেজ খোলার রুটও এটাই হবে)
  final String id;

  /// [MenuGroup.id]
  final String group;
  final String title;
  final String subtitle;
  final IconData icon;

  /// ট্যাপের আগে পেজ তৈরি হয় না, তাই অনেক পেজ থাকলেও অ্যাপ চালু হতে দেরি হয় না
  final WidgetBuilder page;

  /// ব্যাজের কাউন্ট এই নামে [BadgeCenter]-এ জমা হবে (না থাকলে ব্যাজ নেই)
  final String? badgeKey;

  const FeatureEntry({
    required this.id,
    required this.group,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.page,
    this.badgeKey,
  });
}

/// বানানো শেষ হওয়া ফিচারের তালিকা। নতুন ফিচার বানালে এখানে একটা এন্ট্রি যোগ হবে। যেমন:
///
/// ```dart
/// FeatureEntry(
///   id: 'inspector',
///   group: 'monitor',
///   title: 'নেটওয়ার্ক ইনস্পেক্টর',
///   subtitle: 'কোন অ্যাপ কোন সার্ভারে কথা বলছে',
///   icon: Icons.travel_explore,
///   page: (_) => const InspectorPage(),
///   badgeKey: 'inspector',
/// ),
/// ```
final List<FeatureEntry> menuFeatures = <FeatureEntry>[
  // ---- ধাপ ১ ----
  FeatureEntry(
    id: 'inspector',
    group: 'monitor',
    title: 'নেটওয়ার্ক ইনস্পেক্টর',
    subtitle: 'কোন অ্যাপ কোন সার্ভারে কত ডেটা পাঠাল',
    icon: Icons.travel_explore,
    page: (_) => const InspectorPage(),
  ),
  FeatureEntry(
    id: 'quality',
    group: 'monitor',
    title: 'নেটের মান',
    subtitle: 'নেট ধীর বা বন্ধ হলে ধরে ফেলে, সতর্ক করে',
    icon: Icons.network_check,
    page: (_) => const QualityPage(),
  ),
  // ---- ধাপ ২ ----
  FeatureEntry(
    id: 'blackbox',
    group: 'monitor',
    title: 'ব্ল্যাক বক্স',
    subtitle: 'ব্যাটারি, তাপ, RAM-এর সমস্যা ধরে কারণ বলে',
    icon: Icons.fact_check_outlined,
    page: (_) => const BlackBoxPage(),
    badgeKey: 'blackbox',
  ),
  FeatureEntry(
    id: 'money',
    group: 'data',
    title: 'টাকার হিসাব',
    subtitle: 'কোন অ্যাপে মোবাইল ডেটার কত টাকা গেল',
    icon: Icons.payments_outlined,
    page: (_) => const MoneyPage(),
  ),
  FeatureEntry(
    id: 'scam',
    group: 'security',
    title: 'স্ক্যাম গার্ড',
    subtitle: 'নকল বিকাশ/নগদ বা ফিশিং সাইট আটকায়',
    icon: Icons.phishing,
    page: (_) => const ScamPage(),
    badgeKey: 'scam',
  ),
  // ---- ধাপ ৩ ----
  FeatureEntry(
    id: 'perm_audit',
    group: 'security',
    title: 'পারমিশন অডিটর',
    subtitle: 'ক্ষমতা আছে, ব্যবহার নেই, তবু নেটে কথা বলছে এমন অ্যাপ',
    icon: Icons.admin_panel_settings_outlined,
    page: (_) => const PermAuditPage(),
  ),
  FeatureEntry(
    id: 'wifi_safety',
    group: 'security',
    title: 'পাবলিক Wi-Fi',
    subtitle: 'অচেনা Wi-Fi-তে সতর্ক করে, কড়া মোডে নেট সীমিত',
    icon: Icons.wifi_find,
    page: (_) => const WifiPage(),
    badgeKey: 'wifi_safety',
  ),
  FeatureEntry(
    id: 'pocket_guard',
    group: 'security',
    title: 'পকেট গার্ড',
    subtitle: 'ফোন তুললে, নাড়ালে বা চার্জার খুললে সাইরেন আর চোরের ছবি',
    icon: Icons.sensors,
    page: (_) => const PocketPage(),
  ),
  // ---- ধাপ ৪ ----
  FeatureEntry(
    id: 'automation',
    group: 'control',
    title: 'অটোমেশন',
    subtitle: 'Wi-Fi, চার্জিং বা সময় মিললে মোড নিজে বদলায়',
    icon: Icons.auto_mode,
    page: (_) => const AutomationPage(),
  ),
  FeatureEntry(
    id: 'parental',
    group: 'control',
    title: 'প্যারেন্টাল',
    subtitle: 'বাচ্চার অ্যাপে দৈনিক সময় আর ঘুমের সময় বন্ধ',
    icon: Icons.family_restroom,
    page: (_) => const ParentalPage(),
  ),
  FeatureEntry(
    id: 'trade_blocker',
    group: 'control',
    title: 'ট্রেড ব্লকার',
    subtitle: 'সীমা ছুঁলে ট্রেডিং অ্যাপ ২৪ ঘণ্টা লক',
    icon: Icons.candlestick_chart_outlined,
    page: (_) => const TradePage(),
  ),
  FeatureEntry(
    id: 'text_grab',
    group: 'control',
    title: 'লেখা তোলার বাটন',
    subtitle: 'কপি করা যায় না এমন জায়গার লেখাও তালিকা করে কপি, অনুবাদ, সার্চ',
    icon: Icons.text_snippet_outlined,
    page: (_) => const TextGrabPage(),
  ),
  FeatureEntry(
    id: 'bubble',
    group: 'control',
    title: 'ফ্লোটিং বাবল',
    subtitle: 'বাছা অ্যাপ স্ক্রিনে ভাসে, লং-প্রেসে নেট বন্ধ, ডেটা, লক',
    icon: Icons.bubble_chart_outlined,
    page: (_) => const BubblePage(),
  ),
  FeatureEntry(
    id: 'trade_time',
    group: 'control',
    title: 'ট্রেড টাইম গার্ড',
    subtitle: 'ট্রেডের সময় শুধু ট্রেডিং অ্যাপ নেট পায়, বিরক্তিকর অ্যাপ বন্ধ',
    icon: Icons.schedule,
    page: (_) => const TradeTimePage(),
  ),
  FeatureEntry(
    id: 'cool_mode',
    group: 'control',
    title: 'ঠান্ডা মোড',
    subtitle: 'ফোন গরম বা ব্যাটারি কমলে ব্যাকগ্রাউন্ড অ্যাপের নেট বন্ধ',
    icon: Icons.ac_unit,
    page: (_) => const CoolPage(),
  ),
  FeatureEntry(
    id: 'night_watch',
    group: 'monitor',
    title: 'রাতের ডেটা চোর',
    subtitle: 'স্ক্রিন বন্ধে রাতে কে ডেটা খেল, সকালে রিপোর্ট আর ব্লক',
    icon: Icons.nightlight_outlined,
    page: (_) => const NightPage(),
  ),
  // ---- ওয়াও: রাডার, ডট, ভয়েস ----
  FeatureEntry(
    id: 'radar',
    group: 'monitor',
    title: 'চোর ধরা রাডার',
    subtitle: 'ঘুরন্ত রাডারে কে গোপনে নেট খাচ্ছে লাল হয়ে জ্বলে, ট্যাপে ব্লক',
    icon: Icons.radar,
    page: (_) => const RadarPage(),
  ),
  FeatureEntry(
    id: 'wow',
    group: 'control',
    title: 'ফ্লোটিং ডট ও ভয়েস অ্যালার্ট',
    subtitle: 'স্ক্রিনে ভাসা নেট-বল, টেনে ব্লক, সন্দেহজনক অ্যাপ ধরলে ফোন কথা বলে',
    icon: Icons.blur_circular,
    page: (_) => const WowPage(),
  ),
  // ---- নতুন সার্ভিস: আলসে-লক, হার্টবিট, পোষা ----
  FeatureEntry(
    id: 'buddy',
    group: 'control',
    title: 'নতুন সার্ভিস',
    subtitle: 'আলসে-লক, নেট-হার্টবিট আর ডেটা-পোষা, প্রতিটার আলাদা সুইচ',
    icon: Icons.pets_outlined,
    page: (_) => const BuddyPage(),
  ),
  // ---- ধাপ ৫ ----
  FeatureEntry(
    id: 'command',
    group: 'lab',
    title: 'বাংলা কমান্ড',
    subtitle: 'বাংলায় লিখুন: "ফেসবুক ব্লক করো", "আজ কত ডেটা গেছে"',
    icon: Icons.keyboard_command_key,
    page: (_) => const CommandPage(),
  ),
  FeatureEntry(
    id: 'charger',
    group: 'lab',
    title: 'চার্জার লিডারবোর্ড',
    subtitle: 'কোন চার্জার সবচেয়ে দ্রুত চার্জ দেয়',
    icon: Icons.bolt,
    page: (_) => const ChargerPage(),
  ),
  FeatureEntry(
    id: 'heatmap',
    group: 'lab',
    title: 'Wi-Fi হিটম্যাপ',
    subtitle: 'ঘরের কোথায় সিগন্যাল ভালো, কোথায় দুর্বল',
    icon: Icons.wifi_tethering,
    page: (_) => const HeatmapPage(),
  ),
];

List<FeatureEntry> featuresOf(String groupId) =>
    menuFeatures.where((f) => f.group == groupId).toList();

/// নোটিফিকেশন ট্যাপে অ্যাপ খুললে রুটের নাম = ফিচারের id। মিললে সেই পেজ খোলে, true দেয়।
bool openFeature(BuildContext context, String id) {
  for (final f in menuFeatures) {
    if (f.id == id) {
      Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => f.page(ctx)));
      return true;
    }
  }
  return false;
}
