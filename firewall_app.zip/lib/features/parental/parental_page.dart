import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/lock_service.dart';
import '../../widgets/app_picker.dart';
import '../../widgets/common.dart';
import '../control_common.dart';

/// প্যারেন্টাল: বাচ্চার ফোনের অ্যাপে দৈনিক সময়সীমা আর ঘুমের সময় বন্ধ।
/// সেটিং বদলাতে বা বন্ধ করতে পিন লাগে (পিন না থাকলে চালু হয় না, নইলে বন্ধ করার পথ থাকত না)।
/// ব্লক ধরে অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি), তাই সেটা চালু থাকতে হবে।
class ParentalPage extends StatefulWidget {
  const ParentalPage({super.key});

  @override
  State<ParentalPage> createState() => _ParentalPageState();
}

class _ParentalPageState extends State<ParentalPage> {
  Map<String, dynamic> p = {};
  Map<String, String> names = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await XChannel.ctlGet('parental');
    final n = await appNames();
    if (!mounted) return;
    setState(() {
      p = Map<String, dynamic>.from(r as Map);
      names = n;
      loading = false;
    });
  }

  List<String> get apps => ((p['apps'] as List?) ?? const []).cast<String>();
  int get minutes => (p['minutes'] as num?)?.toInt() ?? 0;
  bool get on => p['on'] == true;
  bool get bedOn => p['bedOn'] == true;
  int get bedFrom => (p['bedFrom'] as num?)?.toInt() ?? 22 * 60;
  int get bedTo => (p['bedTo'] as num?)?.toInt() ?? 6 * 60;

  /// পিন যাচাই করে সেভ
  Future<void> _save(Map<String, dynamic> next, {String reason = 'প্যারেন্টাল সেটিং বদলাতে পিন দিন'}) async {
    if (!Lock.hasPin) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('আগে অ্যাপে পিন সেট করুন (সেটিংস → নিরাপত্তা)')));
      return;
    }
    final ok = await Lock.ask(context, reason: reason, force: true);
    if (!ok || !mounted) return;
    await XChannel.ctlSet('parental', next);
    await _load();
  }

  Map<String, dynamic> _copy() => Map<String, dynamic>.from(p);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('প্যারেন্টাল')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
                AppCard(
                  child: SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('প্যারেন্টাল নিয়ন্ত্রণ', style: TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: const Text('চালু/বন্ধ করতে পিন লাগবে'),
                    value: on,
                    onChanged: (v) {
                      final n = _copy()..['on'] = v;
                      _save(n, reason: v ? 'প্যারেন্টাল চালু করতে পিন দিন' : 'প্যারেন্টাল বন্ধ করতে পিন দিন');
                    },
                  ),
                ),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Expanded(
                          child: Text('যে অ্যাপগুলোতে নিয়ম', style: TextStyle(fontWeight: FontWeight.w700))),
                      TextButton(
                        onPressed: () async {
                          final r = await pickApps(context, title: 'অ্যাপ বাছুন', selected: apps.toSet());
                          if (r == null) return;
                          _save(_copy()..['apps'] = r);
                        },
                        child: const Text('বাছুন'),
                      ),
                    ]),
                    if (apps.isEmpty)
                      Text('কোনো অ্যাপ বাছা হয়নি', style: TextStyle(color: cs.onSurfaceVariant))
                    else
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        for (final a in apps) Chip(label: Text(names[a] ?? a)),
                      ]),
                  ]),
                ),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(children: [
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('দৈনিক সময়সীমা'),
                      subtitle: const Text('প্রতিটা বাছা অ্যাপে আলাদা করে গোনা হয়'),
                      trailing: Text(minutes > 0 ? '$minutes মিনিট' : 'নেই',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      onTap: () async {
                        final v = await askNumber(context, 'দিনে কত মিনিট?', minutes);
                        if (v == null) return;
                        _save(_copy()..['minutes'] = v);
                      },
                    ),
                    const Divider(height: 1),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('ঘুমের সময় বন্ধ'),
                      subtitle: Text('${hm(bedFrom)} থেকে ${hm(bedTo)} পর্যন্ত'),
                      value: bedOn,
                      onChanged: (v) => _save(_copy()..['bedOn'] = v),
                    ),
                    if (bedOn)
                      Row(children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () async {
                              final m = await pickMinute(context, bedFrom);
                              if (m != null) _save(_copy()..['bedFrom'] = m);
                            },
                            child: Text('শুরু ${hm(bedFrom)}'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () async {
                              final m = await pickMinute(context, bedTo);
                              if (m != null) _save(_copy()..['bedTo'] = m);
                            },
                            child: Text('শেষ ${hm(bedTo)}'),
                          ),
                        ),
                      ]),
                  ]),
                ),
                const SizedBox(height: 12),
                Text(
                  'সীমা: অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি) বন্ধ করলে ব্লক কাজ করে না। বাচ্চা সেটা বন্ধ করতে না পারে, সেজন্য ফোনের সেটিংসে পিন/স্ক্রিন লক রাখুন। '
                  'ব্যবহারের সময় Usage access থেকে আসে, তাই সেটা চালু থাকা দরকার।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
    );
  }
}
