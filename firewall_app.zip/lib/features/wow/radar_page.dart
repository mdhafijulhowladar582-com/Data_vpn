import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

class _RApp {
  final String pkg, label;
  final double bps;
  final int today;
  final bool fg, susp, system;
  const _RApp(this.pkg, this.label, this.bps, this.today, this.fg, this.susp, this.system);

  factory _RApp.from(Map m) => _RApp(
        '${m['pkg']}',
        '${m['label']}',
        (m['bps'] as num?)?.toDouble() ?? 0,
        (m['today'] as num?)?.toInt() ?? 0,
        m['fg'] == true,
        m['susp'] == true,
        m['system'] == true,
      );

  /// ০ (শান্ত) থেকে ১ (খুব বেশি, প্রায় ১ MB/s)
  double get level => (math.log(1 + bps / 1024) / math.ln10 / 3).clamp(0.0, 1.0);
}

class _Dot {
  final _RApp app;
  final Offset pos;
  final double angle; // 0..2π, ঘড়ির কাঁটার দিকে, ডানদিক থেকে
  final double r;
  const _Dot(this.app, this.pos, this.angle, this.r);
}

/// অ্যাপগুলোকে রাডারে বসানো: বেশি নেট খেলে মাঝের কাছে আর বড়, শান্ত হলে বাইরে।
/// অবস্থান অ্যাপের নামের হ্যাশ থেকে আসে, তাই বারবার নড়ে না।
List<_Dot> _layout(List<_RApp> apps, Offset c, double R) {
  final list = apps.take(16).toList()..sort((a, b) => a.pkg.compareTo(b.pkg));
  final out = <_Dot>[];
  for (final a in list) {
    final lv = a.level;
    final rad = (a.bps <= 0 ? 0.9 : 0.86 - 0.66 * lv) * R;
    var ang = ((a.pkg.hashCode & 0x7fffffff) % 3600) / 3600 * 2 * math.pi;
    final dr = 9.0 + lv * 8 + (a.susp ? 2 : 0);
    Offset at(double an) => c + Offset(math.cos(an), math.sin(an)) * rad;
    for (var i = 0; i < 14; i++) {
      final p = at(ang);
      if (out.every((d) => (d.pos - p).distance > dr + d.r + 6)) break;
      ang += 0.37;
    }
    out.add(_Dot(a, at(ang), ang % (2 * math.pi), dr));
  }
  return out;
}

class _RadarPainter extends CustomPainter {
  final List<_Dot> dots;
  final double sweep; // 0..1
  final Color text;
  _RadarPainter(this.dots, this.sweep, this.text);

  static const _green = Color(0xFF2ECC71);
  static const _red = Color(0xFFE74C3C);

  void _label(Canvas canvas, String s, Offset at, double size, Color col) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(color: col, fontSize: size, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: 70);
    tp.paint(canvas, at - Offset(tp.width / 2, 0));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final R = math.min(size.width, size.height) / 2 - 6;
    canvas.drawCircle(c, R, Paint()..color = const Color(0xFF061A12));
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = _green.withAlpha(70);
    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(c, R * i / 3, line);
    }
    canvas.drawLine(c - Offset(R, 0), c + Offset(R, 0), line);
    canvas.drawLine(c - Offset(0, R), c + Offset(0, R), line);
    canvas.drawCircle(
        c,
        R,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = _green.withAlpha(150));

    final a = sweep * 2 * math.pi;
    final wedge = SweepGradient(
      colors: [Colors.transparent, _green.withAlpha(120)],
      stops: const [0.75, 1.0],
      transform: GradientRotation(a),
    ).createShader(Rect.fromCircle(center: c, radius: R));
    canvas.drawCircle(c, R, Paint()..shader = wedge);
    canvas.drawLine(
        c,
        c + Offset(math.cos(a), math.sin(a)) * R,
        Paint()
          ..color = _green
          ..strokeWidth = 2);

    for (final d in dots) {
      final col = d.app.susp ? _red : _green;
      var diff = (a - d.angle) % (2 * math.pi);
      if (diff < 0) diff += 2 * math.pi;
      final flash = diff < 0.9 ? 1 - diff / 0.9 : 0.0;
      if (d.app.susp) {
        final pr = d.r + 4 + 6 * (0.5 + 0.5 * math.sin(sweep * 2 * math.pi * 4));
        canvas.drawCircle(d.pos, pr, Paint()..color = _red.withAlpha(70));
      }
      if (flash > 0) {
        canvas.drawCircle(d.pos, d.r + 3 + 8 * flash, Paint()..color = col.withAlpha((120 * flash).toInt()));
      }
      canvas.drawCircle(d.pos, d.r, Paint()..color = col.withAlpha(d.app.susp ? 255 : 210));
      canvas.drawCircle(
          d.pos,
          d.r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5
            ..color = Colors.white70);
      final l = d.app.label;
      if (l.isNotEmpty) _label(canvas, l.characters.first, d.pos - Offset(0, 6), 12, Colors.white);
      _label(canvas, l, d.pos + Offset(0, d.r + 2), 10, d.app.susp ? const Color(0xFFFFB4AB) : Colors.white70);
    }

    canvas.drawCircle(c, 7, Paint()..color = const Color(0xFF3B9DFF));
    canvas.drawCircle(
        c,
        7,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = Colors.white);
    _label(canvas, 'আপনি', c + const Offset(0, 10), 10, Colors.white70);
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) => true;
}

/// "কে আমার নেট চুরি করছে" রাডার: ঘুরন্ত লাইন, অ্যাপ ডট। যে অ্যাপ স্ক্রিন বন্ধ বা অ্যাপ খোলা না থাকা অবস্থায় নেট খায় সে লাল।
class RadarPage extends StatefulWidget {
  const RadarPage({super.key});

  @override
  State<RadarPage> createState() => _RadarPageState();
}

class _RadarPageState extends State<RadarPage> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _sweep =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
  Timer? _timer;
  List<_RApp> apps = [];
  List<_Dot> _dots = [];
  bool rated = false;
  bool hasUsage = true;
  bool loaded = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _sweep.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _poll();
  }

  Future<void> _poll() async {
    if (_busy) return;
    _busy = true;
    try {
      final ok = await VpnChannel.hasUsageAccess();
      if (!ok) {
        if (mounted) setState(() {
          hasUsage = false;
          loaded = true;
        });
        return;
      }
      final r = await XChannel.radarSample();
      final l = ((r['apps'] as List?) ?? const [])
          .map((e) => _RApp.from(Map<dynamic, dynamic>.from(e as Map)))
          .toList();
      if (mounted) {
        setState(() {
          hasUsage = true;
          apps = l;
          rated = r['rated'] == true;
          loaded = true;
        });
      }
    } finally {
      _busy = false;
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _block(_RApp a) async {
    final r = await XChannel.radarBlock(a.pkg);
    switch (r) {
      case 'ok':
        _snack('${a.label}-এর নেট ব্লক তালিকায় গেছে (ফায়ারওয়াল চালু থাকলে কাজ করবে)');
        break;
      case 'self':
        _snack('এটা এই অ্যাপ নিজেই, ব্লক করা যায় না');
        break;
      case 'core':
        _snack('ফোনের মূল সিস্টেম, ব্লক করা যায় না');
        break;
      default:
        _snack('ব্লক করা গেল না');
    }
  }

  void _open(_RApp a) {
    final cs = Theme.of(context).colorScheme;
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              AppIcon(a.pkg, size: 44),
              const SizedBox(width: 12),
              Expanded(
                  child: Text(a.label,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis)),
            ]),
            const SizedBox(height: 12),
            Text('এখনকার স্পিড: ${a.bps < 1 ? 'প্রায় শূন্য' : _spd(a.bps)}'),
            Text('আজ মোট: ${fmtBytes(a.today)}'),
            const SizedBox(height: 8),
            Text(
              a.susp
                  ? 'সন্দেহজনক: অ্যাপটা সামনে খোলা নেই (বা স্ক্রিন বন্ধ), তবু নেট খাচ্ছে।'
                  : a.fg
                      ? 'এখন সামনে খোলা, তাই স্বাভাবিক।'
                      : 'ব্যাকগ্রাউন্ডে আছে, নেট ব্যবহার কম।',
              style: TextStyle(color: a.susp ? cs.error : null, fontWeight: FontWeight.w600),
            ),
            if (a.susp)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text('লাল মানে সন্দেহ, চোর নিশ্চিত নয়। মেসেজ আনা, ব্যাকআপ বা আপডেটের জন্যও অ্যাপ ব্যাকগ্রাউন্ডে নেট খায়।',
                    style: TextStyle(fontSize: 12.5)),
              ),
            if (a.system)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text('সিস্টেম অ্যাপ: ব্লক করলে ফোনের কিছু সুবিধা (নোটিফিকেশন, আপডেট) বন্ধ হতে পারে।',
                    style: TextStyle(fontSize: 12.5)),
              ),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                  child: FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _block(a);
                      },
                      icon: const Icon(Icons.block),
                      label: const Text('ব্লক করো'))),
              const SizedBox(width: 10),
              OutlinedButton(onPressed: () => Navigator.pop(ctx), child: const Text('থাক')),
            ]),
          ]),
        ),
      ),
    );
  }

  String _spd(double b) =>
      b >= 1048576 ? '${(b / 1048576).toStringAsFixed(1)} MB/s' : '${(b / 1024).toStringAsFixed(0)} KB/s';

  void _tap(Offset p) {
    _Dot? best;
    var bd = 36.0;
    for (final d in _dots) {
      final dist = (d.pos - p).distance;
      if (dist < bd) {
        bd = dist;
        best = d;
      }
    }
    if (best != null) _open(best.app);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final susp = apps.where((a) => a.susp).toList();
    final active = apps.where((a) => a.bps >= 1024).take(5).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('চোর ধরা রাডার')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (!hasUsage)
            AppCard(
              color: cs.errorContainer.withAlpha(120),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('অনুমতি দরকার', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('কোন অ্যাপ কত নেট খাচ্ছে দেখতে \"Usage access\" অনুমতি লাগবে।'),
                const SizedBox(height: 10),
                FilledButton(onPressed: VpnChannel.openUsageAccess, child: const Text('অনুমতি দিন')),
              ]),
            )
          else ...[
            LayoutBuilder(builder: (ctx, bc) {
              final side = math.min(bc.maxWidth, 420.0);
              return Center(
                child: SizedBox(
                  width: side,
                  height: side,
                  child: GestureDetector(
                    onTapUp: (t) => _tap(t.localPosition),
                    child: AnimatedBuilder(
                      animation: _sweep,
                      builder: (_, __) {
                        final c = Offset(side / 2, side / 2);
                        _dots = _layout(apps, c, side / 2 - 6);
                        return CustomPaint(painter: _RadarPainter(_dots, _sweep.value, cs.onSurface));
                      },
                    ),
                  ),
                ),
              );
            }),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.circle, size: 12, color: Color(0xFF2ECC71)),
              const SizedBox(width: 6),
              const Text('শান্ত'),
              const SizedBox(width: 18),
              const Icon(Icons.circle, size: 12, color: Color(0xFFE74C3C)),
              const SizedBox(width: 6),
              const Text('সন্দেহ'),
              const SizedBox(width: 18),
              const Text('মাঝের কাছে = বেশি নেট', style: TextStyle(fontSize: 12.5)),
            ]),
            const SizedBox(height: 12),
            AppCard(
              color: susp.isEmpty ? null : cs.errorContainer.withAlpha(110),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  !loaded
                      ? 'মাপছি…'
                      : !rated
                          ? 'স্পিড মাপা শুরু হয়েছে, ১০-১৫ সেকেন্ড অপেক্ষা করুন'
                          : susp.isEmpty
                              ? 'এই মুহূর্তে কেউ সন্দেহজনক নেট খাচ্ছে না'
                              : '${susp.length}টা অ্যাপ সন্দেহজনক',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                const Text('ডটে ট্যাপ করলে অ্যাপের তথ্য আর \"ব্লক করো\" বাটন আসবে। সিস্টেম অ্যাপও দেখানো হয়।',
                    style: TextStyle(fontSize: 12.5)),
                for (final a in susp)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: AppIcon(a.pkg, size: 32),
                    title: Text(a.label),
                    subtitle: Text(_spd(a.bps)),
                    trailing: TextButton(onPressed: () => _open(a), child: const Text('দেখুন')),
                  ),
              ]),
            ),
            if (active.isNotEmpty) ...[
              const SectionLabel('এখন সবচেয়ে বেশি খাচ্ছে'),
              AppCard(
                child: Column(children: [
                  for (final a in active)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      leading: AppIcon(a.pkg, size: 32),
                      title: Text(a.label),
                      trailing: Text(_spd(a.bps), style: const TextStyle(fontWeight: FontWeight.w700)),
                      onTap: () => _open(a),
                    ),
                ]),
              ),
            ],
          ],
        ]),
      ),
    );
  }
}
