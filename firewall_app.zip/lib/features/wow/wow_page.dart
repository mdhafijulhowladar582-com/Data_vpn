import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/common.dart';
import 'radar_page.dart';

/// ফ্লোটিং নেট-ডট আর ভয়েস অ্যালার্টের সেটিংস
class WowPage extends StatefulWidget {
  const WowPage({super.key});

  @override
  State<WowPage> createState() => _WowPageState();
}

class _WowPageState extends State<WowPage> with WidgetsBindingObserver {
  Map<String, dynamic> st = {};
  bool hasUsage = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// অনুমতির সেটিংস থেকে ফিরলে অবস্থা আবার পড়ে
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  bool get dot => st['dot'] == true;
  bool get voice => st['voice'] == true;
  bool get quiet => st['quiet'] != false;
  bool get canDraw => st['canDraw'] == true;
  bool get running => st['running'] == true;

  Future<void> _load() async {
    final s = await XChannel.wowState();
    final u = await VpnChannel.hasUsageAccess();
    if (!mounted) return;
    setState(() {
      if (s.isNotEmpty) st = s;
      hasUsage = u;
    });
    // ডট চালু রাখা ছিল কিন্তু অনুমতি পরে এসেছে: সার্ভিসকে আবার সাজাতে বলা
    if (s['dot'] == true && s['canDraw'] == true && s['running'] != true) {
      await XChannel.wowSet('dot', true);
    }
  }

  Future<void> _set(String key, bool on) async {
    setState(() => st = {...st, key: on});
    if (key == 'dot' && on && !canDraw) await XChannel.bubbleAskPerm();
    await XChannel.wowSet(key, on);
    await Future.delayed(const Duration(milliseconds: 300));
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('ডট ও ভয়েস অ্যালার্ট')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          const AppCard(
            child: Text(
              'ফ্লোটিং ডট: স্ক্রিনের কোণে ছোট একটা বল ভাসে। এই মুহূর্তে যে অ্যাপ সবচেয়ে বেশি নেট খাচ্ছে, বলটা তার নামে '
              'আর স্পিডে বড় ও লাল হয়, শান্ত থাকলে ছোট ও সবুজ। বল ট্যাপ করলে রাডার খোলে। বল টেনে নিচের লাল জোনে ছেড়ে দিলে '
              'ওই অ্যাপের নেট ব্লক।\n\n'
              'ভয়েস অ্যালার্ট: কোনো অ্যাপ সামনে না থেকে বা স্ক্রিন বন্ধ থেকে টানা নেট খেলে ফোন নিজে কথা বলে আর নোটিফিকেশন দেয়।',
              style: TextStyle(height: 1.5),
            ),
          ),
          const SizedBox(height: 12),
          if (!hasUsage)
            AppCard(
              color: cs.errorContainer.withAlpha(120),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('অনুমতি দরকার', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('অ্যাপ ধরে নেট স্পিড মাপতে \"Usage access\" অনুমতি লাগে।'),
                const SizedBox(height: 10),
                FilledButton(onPressed: VpnChannel.openUsageAccess, child: const Text('অনুমতি দিন')),
              ]),
            ),
          if (!hasUsage) const SizedBox(height: 12),
          AppCard(
            child: Column(children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ফ্লোটিং নেট-ডট', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(dot && !canDraw
                    ? 'অন্য অ্যাপের ওপর দেখানোর অনুমতি লাগবে'
                    : dot && running
                        ? 'চলছে'
                        : 'বন্ধ'),
                value: dot,
                onChanged: (v) => _set('dot', v),
              ),
              if (dot && !canDraw)
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton.tonal(onPressed: XChannel.bubbleAskPerm, child: const Text('অনুমতি দিন')),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ভয়েস অ্যালার্ট', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('সন্দেহজনক অ্যাপ ধরলে ফোন কথা বলবে (একই অ্যাপ নিয়ে ১০ মিনিটে একবার)'),
                value: voice,
                onChanged: (v) => _set('voice', v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('রাতে চুপ (রাত ১২টা থেকে ভোর ৬টা)'),
                subtitle: const Text('এ সময় শুধু নোটিফিকেশন আসবে, কথা বলবে না'),
                value: quiet,
                onChanged: voice ? (v) => _set('quiet', v) : null,
              ),
              const SizedBox(height: 4),
              OutlinedButton.icon(
                onPressed: () async {
                  await XChannel.wowTest();
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('বাংলা ভয়েস ফোনে না থাকলে ইংরেজিতে বলবে। কিছু না শুনলে ফোনের ভলিউম দেখুন')));
                },
                icon: const Icon(Icons.record_voice_over),
                label: const Text('ভয়েস পরীক্ষা'),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RadarPage())),
            icon: const Icon(Icons.radar),
            label: const Text('রাডার খুলুন'),
          ),
          const SizedBox(height: 12),
          const AppCard(
            child: Text(
              'জেনে রাখুন: স্পিড মাপা আনুমানিক, ফোন কয়েক সেকেন্ড পরপর পরিসংখ্যান হালনাগাদ করে, তাই ১০-১৫ সেকেন্ড পর থেকে সঠিক দেখাবে। '
              '"সন্দেহজনক" মানে আন্দাজ: মেসেজ আনা বা ব্যাকআপের জন্যও অ্যাপ ব্যাকগ্রাউন্ডে নেট খায়। '
              'ডট ও ভয়েস চালু থাকলে একটা ছোট নোটিফিকেশন স্থায়ীভাবে থাকবে (অ্যান্ড্রয়েডের নিয়ম)। '
              'ডট দিয়ে ব্লক করলে ফায়ারওয়াল (VPN) চালু থাকতে হবে।',
              style: TextStyle(fontSize: 12.5, height: 1.5),
            ),
          ),
        ]),
      ),
    );
  }
}
