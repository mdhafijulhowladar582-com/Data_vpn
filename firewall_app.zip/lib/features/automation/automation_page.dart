import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../widgets/common.dart';
import '../control_common.dart';

/// অটোমেশন: "যদি (ট্রিগার) তাহলে (অ্যাকশন)"। শর্ত মেলা বা ভাঙার মুহূর্তে অ্যাকশন চলে।
/// ট্রিগার: নির্দিষ্ট Wi-Fi-তে যুক্ত, চার্জে লাগানো, সময়সীমা। অ্যাকশন: একটা মোড চালু (শর্ত ভাঙলে আগের অবস্থা ফেরে)
/// অথবা "Wi-Fi-তে সব খোলা" চালু/বন্ধ। লোকেশন-ভিত্তিক ট্রিগার নেই (ব্যাকগ্রাউন্ড লোকেশন অনুমতি লাগত)।
/// ৩০ সেকেন্ডের চক্রে মেলানো হয়, তাই ফায়ারওয়াল (VPN) চালু থাকলে কাজ করে।
class AutomationPage extends StatefulWidget {
  const AutomationPage({super.key});

  @override
  State<AutomationPage> createState() => _AutomationPageState();
}

class _AutomationPageState extends State<AutomationPage> {
  List<Map<String, dynamic>> rules = [];
  List<String> active = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await XChannel.ctlGet('auto');
    final a = await XChannel.autoActive();
    if (!mounted) return;
    setState(() {
      rules = (r as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      active = a;
      loading = false;
    });
  }

  Future<void> _save() async {
    await XChannel.ctlSet('auto', rules);
    await _load();
  }

  String _trig(Map<String, dynamic> t) {
    switch (t['type']) {
      case 'wifi':
        return 'Wi-Fi "${t['ssid']}"-এ যুক্ত থাকলে';
      case 'charging':
        return 'চার্জে লাগানো থাকলে';
      case 'time':
        return '${hm((t['from'] as num?)?.toInt() ?? 0)} থেকে ${hm((t['to'] as num?)?.toInt() ?? 0)} পর্যন্ত';
    }
    return '?';
  }

  String _act(Map<String, dynamic> a) {
    if (a['type'] == 'mode') return 'মোড চালু: ${a['value']}';
    if (a['type'] == 'wifiOpen') return a['value'] == true ? '"Wi-Fi-তে সব খোলা" চালু' : '"Wi-Fi-তে সব খোলা" বন্ধ';
    return '?';
  }

  Future<void> _add() async {
    final r = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _RuleEditor(),
    );
    if (r == null) return;
    rules.add(r);
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('অটোমেশন')),
      floatingActionButton: FloatingActionButton.extended(
          onPressed: _add, icon: const Icon(Icons.add), label: const Text('নতুন নিয়ম')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 96), children: [
                if (rules.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 40),
                    child: Text(
                      'কোনো নিয়ম নেই। যেমন: "বাড়ির Wi-Fi-তে থাকলে ঘুম মোড চালু" বা "রাত ১১টা থেকে ৬টা ট্রেডিং মোড"।',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: cs.onSurfaceVariant, height: 1.5),
                    ),
                  ),
                for (var i = 0; i < rules.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AppCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(
                            child: Text(rules[i]['name'] as String? ?? 'নিয়ম',
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                          ),
                          if (active.contains(rules[i]['id']))
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(color: Colors.green.withAlpha(40), borderRadius: BorderRadius.circular(8)),
                              child: const Text('এখন চালু', style: TextStyle(fontSize: 12, color: Colors.green)),
                            ),
                          Switch(
                            value: rules[i]['on'] != false,
                            onChanged: (v) {
                              rules[i]['on'] = v;
                              _save();
                            },
                          ),
                        ]),
                        Text('যদি: ${_trig(Map<String, dynamic>.from(rules[i]['trigger'] as Map))}'),
                        Text('তাহলে: ${_act(Map<String, dynamic>.from(rules[i]['action'] as Map))}'),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () {
                              rules.removeAt(i);
                              _save();
                            },
                            icon: const Icon(Icons.delete_outline, size: 18),
                            label: const Text('মুছুন'),
                          ),
                        ),
                      ]),
                    ),
                  ),
                const SizedBox(height: 8),
                Text(
                  'সীমা: Wi-Fi-র নাম পড়তে লোকেশন অনুমতি লাগে (পাবলিক Wi-Fi পেজ থেকে দেওয়া যায়), আর ব্যাকগ্রাউন্ডে নাম না পড়া গেলে নিয়ম আগের অবস্থায় থাকে। '
                  'শর্ত ভাঙলে নিয়ম নিজের বসানো মান ফিরিয়ে দেয়। মাঝখানে তুই হাতে মোড বদলালে সেটা বদলাবে না।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
    );
  }
}

class _RuleEditor extends StatefulWidget {
  const _RuleEditor();

  @override
  State<_RuleEditor> createState() => _RuleEditorState();
}

class _RuleEditorState extends State<_RuleEditor> {
  final name = TextEditingController();
  final ssid = TextEditingController();
  String trig = 'wifi';
  int from = 23 * 60;
  int to = 6 * 60;
  String act = 'mode';
  String mode = '';
  bool wifiOpen = true;
  List<String> trusted = [];

  @override
  void initState() {
    super.initState();
    final ms = store.cfg.profiles.keys.toList();
    if (ms.isNotEmpty) mode = ms.first;
    XChannel.wifiState().then((s) {
      if (!mounted) return;
      setState(() {
        trusted = ((s['list'] as List?) ?? const []).cast<String>();
        final cur = s['ssid'] as String?;
        if (cur != null && ssid.text.isEmpty) ssid.text = cur;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final modes = store.cfg.profiles.keys.toList();
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + bottom),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('নতুন নিয়ম', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'নিয়মের নাম')),
        const SizedBox(height: 16),
        const Text('যদি', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'wifi', label: Text('Wi-Fi')),
            ButtonSegment(value: 'charging', label: Text('চার্জিং')),
            ButtonSegment(value: 'time', label: Text('সময়')),
          ],
          selected: {trig},
          onSelectionChanged: (s) => setState(() => trig = s.first),
        ),
        const SizedBox(height: 8),
        if (trig == 'wifi') ...[
          TextField(controller: ssid, decoration: const InputDecoration(labelText: 'Wi-Fi-র নাম (SSID)')),
          if (trusted.isNotEmpty)
            Wrap(spacing: 6, children: [
              for (final s in trusted) ActionChip(label: Text(s), onPressed: () => setState(() => ssid.text = s)),
            ]),
        ],
        if (trig == 'time')
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  final m = await pickMinute(context, from);
                  if (m != null) setState(() => from = m);
                },
                child: Text('শুরু ${hm(from)}'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  final m = await pickMinute(context, to);
                  if (m != null) setState(() => to = m);
                },
                child: Text('শেষ ${hm(to)}'),
              ),
            ),
          ]),
        const SizedBox(height: 16),
        const Text('তাহলে', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'mode', label: Text('মোড চালু')),
            ButtonSegment(value: 'wifiOpen', label: Text('Wi-Fi সব খোলা')),
          ],
          selected: {act},
          onSelectionChanged: (s) => setState(() => act = s.first),
        ),
        const SizedBox(height: 8),
        if (act == 'mode')
          modes.isEmpty
              ? const Text('কোনো মোড নেই। আগে অ্যাপস ট্যাবে ট্রেডিং/ঘুম মোড বানান।')
              : DropdownButton<String>(
                  isExpanded: true,
                  value: modes.contains(mode) ? mode : modes.first,
                  items: [for (final m in modes) DropdownMenuItem(value: m, child: Text(m))],
                  onChanged: (v) => setState(() => mode = v ?? mode),
                ),
        if (act == 'wifiOpen')
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('"Wi-Fi-তে সব খোলা" চালু থাকবে'),
            subtitle: const Text('বন্ধ করলে শর্ত থাকাকালীন বন্ধ থাকবে'),
            value: wifiOpen,
            onChanged: (v) => setState(() => wifiOpen = v),
          ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () {
              if (trig == 'wifi' && ssid.text.trim().isEmpty) return;
              if (act == 'mode' && modes.isEmpty) return;
              final id = DateTime.now().millisecondsSinceEpoch.toString();
              Navigator.pop<Map<String, dynamic>>(context, {
                'id': id,
                'name': name.text.trim().isEmpty ? 'নিয়ম' : name.text.trim(),
                'on': true,
                'trigger': trig == 'wifi'
                    ? {'type': 'wifi', 'ssid': ssid.text.trim()}
                    : trig == 'time'
                        ? {'type': 'time', 'from': from, 'to': to}
                        : {'type': 'charging'},
                'action': act == 'mode'
                    ? {'type': 'mode', 'value': modes.contains(mode) ? mode : modes.first}
                    : {'type': 'wifiOpen', 'value': wifiOpen},
              });
            },
            child: const Text('যোগ করুন'),
          ),
        ),
      ]),
    );
  }
}
