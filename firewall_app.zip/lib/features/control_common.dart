import 'package:flutter/material.dart';
import '../services/rules_storage.dart';

/// কন্ট্রোল পেজগুলোর সাধারণ সাহায্য
Future<Map<String, String>> appNames() async {
  final apps = await store.loadApps();
  return {for (final a in apps) a.pkg: a.name};
}

/// মিনিট-অফ-ডে -> "রাত ১০:০০" ধরনের লেখা নয়, সহজ "22:00"
String hm(int m) =>
    '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';

Future<int?> pickMinute(BuildContext context, int initial) async {
  final t = await showTimePicker(
    context: context,
    initialTime: TimeOfDay(hour: (initial ~/ 60) % 24, minute: initial % 60),
    builder: (ctx, child) => MediaQuery(
      data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
      child: child!,
    ),
  );
  return t == null ? null : t.hour * 60 + t.minute;
}

/// সংখ্যা ইনপুটের ছোট ডায়ালগ। খালি বা ০ = সীমা নেই
Future<int?> askNumber(BuildContext context, String title, int current, {String hint = ''}) async {
  final c = TextEditingController(text: current > 0 ? '$current' : '');
  final r = await showDialog<int>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        keyboardType: TextInputType.number,
        autofocus: true,
        decoration: InputDecoration(hintText: hint.isEmpty ? 'খালি = সীমা নেই' : hint),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাদ')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim()) ?? 0),
            child: const Text('ঠিক আছে')),
      ],
    ),
  );
  return r;
}
