import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../widgets/app_picker.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../control_common.dart';

const _mode = 'ট্রেড টাইম'; // ফায়ারওয়ালের মোডের নাম
const _ruleId = 'ttg_mode'; // অটোমেশন নিয়মের id

/// ট্রেড টাইম গার্ড:
///  - ট্রেডের সময়সীমায় শুধু বাছা ট্রেডিং অ্যাপ (Exness, চার্ট) ইন্টারনেট পায়, বাকিদের নেট বন্ধ (মোড + অটোমেশন দিয়ে)।
///  - বিরক্তিকর অ্যাপ (ফেসবুক, ইউটিউব, গেম) ট্রেডের বাইরে (বা ইচ্ছে হলে ভেতরে) খুললেই "ট্রেড টাইম গার্ড" স্ক্রিন আসে।
class TradeTimePage extends StatefulWidget {
  const TradeTimePage({super.key});

  @override
  State<TradeTimePage> createState() => _TradeTimePageState();
}

class _TradeTimePageState extends State<TradeTimePage> {
  Map<String, dynamic> cfg = {};
  Map<String, String> names = {};
  bool loading = true;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
    appNames().then((n) {
      if (mounted) setState(() => names = n);
    });
  }

  Future<void> _load() async {
    final c = await XChannel.ctlGet('ttg');
    if (!mounted) return;
    setState(() {
      cfg = Map<String, dynamic>.from(c as Map);
      loading = false;
    });
  }

  bool get on => cfg['on'] == true;
  int get from => (cfg['from'] as num?)?.toInt() ?? 20 * 60;
  int get to => (cfg['to'] as num?)?.toInt() ?? 23 * 60;
  bool get netOnly => cfg['netMode'] != false;
  String get blockWhen => (cfg['blockWhen'] as String?) ?? 'out';
  List<String> _l(String k) => ((cfg[k] as List?) ?? const []).map((e) => '$e').toList();

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  /// সেটিংস সেভ করে, তারপর ফায়ারওয়ালের মোড আর অটোমেশন নিয়ম মিলিয়ে দেয়
  Future<void> _save(Map<String, dynamic> patch) async {
    if (busy) return;
    setState(() {
      busy = true;
      cfg = {...cfg, ...patch};
    });
    try {
      await XChannel.ctlSet('ttg', cfg);
      await _syncMode();
    } catch (_) {
      _snack('সেভ হতে সমস্যা হয়েছে');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _syncMode() async {
    final trade = _l('tradeApps');
    final wantNet = on && netOnly && trade.isNotEmpty;
    // Kotlin বা বাবল ফায়ারওয়ালের কনফিগ বদলে থাকতে পারে, তাই আগে নতুন করে পড়ি
    await store.load();
    final rules = ((await XChannel.ctlGet('auto')) as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .where((r) => r['id'] != _ruleId)
        .toList();
    if (wantNet) {
      store.cfg.profiles[_mode] = trade.toSet();
      rules.add({
        'id': _ruleId,
        'name': 'ট্রেড টাইম গার্ড',
        'on': true,
        'trigger': {'type': 'time', 'from': from, 'to': to},
        'action': {'type': 'mode', 'value': _mode},
      });
    } else {
      store.cfg.profiles.remove(_mode);
      if (store.cfg.activeMode == _mode) store.cfg.activeMode = '';
    }
    await store.save();
    await XChannel.ctlSet('auto', rules);
  }

  Future<void> _pick(String key, String title) async {
    final r = await pickApps(context, title: title, selected: _l(key).toSet());
    if (r != null) await _save({key: r});
  }

  Future<void> _time(bool isFrom) async {
    final m = await pickMinute(context, isFrom ? from : to);
    if (m != null) await _save(isFrom ? {'from': m} : {'to': m});
  }

  Widget _apps(String key, String title, String hint) {
    final list = _l(key);
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          FilledButton.tonal(
              onPressed: () => _pick(key, title), child: Text(list.isEmpty ? 'বাছুন' : 'বদলান')),
        ]),
        Padding(padding: const EdgeInsets.only(top: 4), child: Text(hint)),
        for (final p in list)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: AppIcon(p, size: 32),
            title: Text(names[p] ?? p),
            trailing: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => _save({key: list.where((e) => e != p).toList()})),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return Scaffold(appBar: AppBar(title: const Text('ট্রেড টাইম গার্ড')), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('ট্রেড টাইম গার্ড')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ট্রেড টাইম গার্ড চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('সময় আর অ্যাপ বেছে তারপর চালু করুন'),
                value: on,
                onChanged: busy ? null : (v) => _save({'on': v}),
              ),
              const SizedBox(height: 8),
              const Text('ট্রেডের সময়', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () => _time(true), child: Text('শুরু ${hm(from)}'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: () => _time(false), child: Text('শেষ ${hm(to)}'))),
              ]),
              const SizedBox(height: 4),
              const Text('রাত পেরোনো সময়ও চলে (যেমন ২২:০০ থেকে ০২:০০)।'),
            ]),
          ),
          const SizedBox(height: 12),
          _apps('tradeApps', 'ট্রেডিং অ্যাপ', 'ট্রেডের সময় শুধু এরা ইন্টারনেট পাবে (Exness, চার্ট অ্যাপ)।'),
          const SizedBox(height: 12),
          AppCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('ট্রেডের সময় বাকি অ্যাপের নেট বন্ধ'),
              subtitle: const Text('বন্ধ করলে শুধু নিচের বিরক্তিকর অ্যাপের পাহারা থাকবে।'),
              value: netOnly,
              onChanged: busy ? null : (v) => _save({'netMode': v}),
            ),
          ),
          const SizedBox(height: 12),
          _apps('block', 'বিরক্তিকর অ্যাপ', 'ফেসবুক, ইউটিউব, গেম। খুললেই "ট্রেড টাইম গার্ড" স্ক্রিন এসে হোমে পাঠাবে।'),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('বিরক্তিকর অ্যাপ কখন বন্ধ?', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'out', label: Text('ট্রেডের বাইরে')),
                  ButtonSegment(value: 'in', label: Text('ট্রেডের ভেতরে')),
                ],
                selected: {blockWhen},
                onSelectionChanged: (s) => _save({'blockWhen': s.first}),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            color: Colors.orange.withAlpha(40),
            child: const Text(
              '⚠️ সতর্কতা\n'
              '• ট্রেডের সময় বাকি সব অ্যাপের নেট বন্ধ থাকবে। ব্যাংক, OTP বা মেসেজ অ্যাপ লাগলে ফায়ারওয়ালের "জরুরি অ্যাপ" তালিকায় রাখুন, নইলে ওরাও আটকে যাবে।\n'
              '• এটা কাজ করতে ফায়ারওয়াল চালু থাকতে হবে। অ্যাপ খোলা আটকাতে অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি) চালু থাকতে হবে।\n'
              '• নেট বন্ধ/চালু হতে সর্বোচ্চ প্রায় ৩০ সেকেন্ড দেরি হতে পারে।\n'
              '• ফোনের ঘড়ি ভুল থাকলে সময়ও ভুল ধরবে। সময় অটো রাখুন।\n'
              '• সোনার বাজার শনি-রবি বন্ধ থাকলেও এটা প্রতিদিনই চলে, আলাদা করে দিন বাছা যায় না।\n'
              '• এটা শুধু আপনার নিজের শৃঙ্খলার সাহায্য, ট্রেডের লাভ-লোকসানের গ্যারান্টি নয়। ট্রেডের সিদ্ধান্ত আপনারই।',
              style: TextStyle(height: 1.55),
            ),
          ),
        ]),
      ),
    );
  }
}
