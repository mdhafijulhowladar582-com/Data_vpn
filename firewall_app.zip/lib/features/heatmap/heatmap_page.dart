import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

/// Wi-Fi সিগন্যাল ম্যাপ: বাড়ির এক এক জায়গায় দাঁড়িয়ে "মাপো" চাপলে সিগন্যাল শক্তি (dBm) আর লিংক স্পিড জমে।
/// এটা ফ্লোর-প্ল্যান ছাড়া তালিকা-ম্যাপ: জায়গাগুলো সিগন্যাল অনুযায়ী সাজানো ও রঙ করা, কোথায় রাউটার সরাতে বা এক্সটেন্ডার
/// বসাতে হবে বোঝার জন্য যথেষ্ট। মাপতে Wi-Fi-তে যুক্ত থাকতে হবে।
class HeatmapPage extends StatefulWidget {
  const HeatmapPage({super.key});

  @override
  State<HeatmapPage> createState() => _HeatmapPageState();
}

class _HeatmapPageState extends State<HeatmapPage> {
  List<Map<String, dynamic>> spots = [];
  final name = TextEditingController();
  bool busy = false;
  String? msg;

  static const quick = ['বেডরুম', 'ড্রয়িংরুম', 'রান্নাঘর', 'বারান্দা', 'বাথরুম'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await XChannel.wifiSpots();
    if (mounted) setState(() => spots = s);
  }

  Future<void> _measure() async {
    final n = name.text.trim();
    if (n.isEmpty) {
      setState(() => msg = 'আগে জায়গার নাম দিন');
      return;
    }
    setState(() {
      busy = true;
      msg = 'মাপা হচ্ছে, ৪ সেকেন্ড দাঁড়িয়ে থাকুন…';
    });
    final r = await XChannel.wifiMeasure(n);
    if (!mounted) return;
    setState(() {
      busy = false;
      msg = r['ok'] == true ? '$n: ${r['rssi']} dBm' : (r['reason'] as String? ?? 'মাপা যায়নি');
    });
    await _load();
  }

  // dBm -> (লেখা, রঙ, ০-১ ভরা অংশ)
  (String, Color, double) _grade(int r) {
    if (r >= -55) return ('চমৎকার', Colors.green, 1.0);
    if (r >= -65) return ('ভালো', Colors.lightGreen, 0.75);
    if (r >= -75) return ('মোটামুটি', Colors.orange, 0.5);
    return ('দুর্বল', Colors.red, 0.25);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Wi-Fi হিটম্যাপ')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('এখানে মাপুন', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TextField(controller: name, decoration: const InputDecoration(hintText: 'জায়গার নাম')),
              Wrap(spacing: 6, children: [
                for (final q in quick) ActionChip(label: Text(q), onPressed: () => setState(() => name.text = q)),
              ]),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: busy ? null : _measure,
                  icon: busy
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.wifi_find),
                  label: const Text('মাপো'),
                ),
              ),
              if (msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(msg!)),
            ]),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: Text('মাপা জায়গা (${spots.length})', style: const TextStyle(fontWeight: FontWeight.w700))),
            if (spots.isNotEmpty)
              TextButton(onPressed: () => XChannel.wifiSpotsClear().then((_) => _load()), child: const Text('সব মুছুন')),
          ]),
          const SizedBox(height: 8),
          if (spots.isEmpty)
            Text('এখনো কিছু মাপা হয়নি। এক এক ঘরে গিয়ে নাম দিয়ে "মাপো" চাপুন।', style: TextStyle(color: cs.onSurfaceVariant))
          else
            for (final s in spots) _row(s, cs),
          const SizedBox(height: 12),
          Text(
            'সীমা: dBm যত শূন্যের কাছে তত ভালো (−৫০ চমৎকার, −৭০ মোটামুটি, −৮০ দুর্বল)। ফোনের অ্যান্টেনা আর ধরার ভঙ্গিতে ২-৫ dBm এদিক-ওদিক হয়, '
            'তাই ছোট ফারাকে ভরসা করবেন না। ২.৪ আর ৫ GHz আলাদা সংখ্যা দেয়।',
            style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
          ),
        ]),
      ),
    );
  }

  Widget _row(Map<String, dynamic> s, ColorScheme cs) {
    final r = (s['rssi'] as num).toInt();
    final g = _grade(r);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(s['name'] as String, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
            Text(g.$1, style: TextStyle(fontWeight: FontWeight.w700, color: g.$2)),
          ]),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: g.$3, color: g.$2, minHeight: 8, borderRadius: BorderRadius.circular(4)),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(
              child: Text('$r dBm · ${s['speed']} Mbps · ${fmtAgo((s['t'] as num).toInt())}',
                  style: TextStyle(fontSize: 12, color: cs.outline)),
            ),
            IconButton(
              icon: const Icon(Icons.close, size: 18),
              tooltip: 'মুছুন',
              onPressed: () => XChannel.wifiSpotDelete(s['name'] as String).then((_) => _load()),
            ),
          ]),
        ]),
      ),
    );
  }
}
