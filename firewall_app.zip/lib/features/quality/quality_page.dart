import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

/// কোয়ালিটি মনিটর: প্রতি ৩০ সেকেন্ডে আসল নেটওয়ার্কে একটা ছোট সংযোগের সময় মাপে (স্ক্রিন চালু থাকলে)।
/// টানা খারাপ হলে সতর্কতা আসে। ফায়ারওয়াল (VPN) চালু না থাকলে মাপা হয় না।
class QualityPage extends StatefulWidget {
  const QualityPage({super.key});

  @override
  State<QualityPage> createState() => _QualityPageState();
}

class _QualityPageState extends State<QualityPage> {
  int hours = 1;
  bool loading = true;
  bool fwRunning = true;
  List<Map<String, dynamic>> pts = []; // পুরনো আগে
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final since = DateTime.now().subtract(Duration(hours: hours)).millisecondsSinceEpoch;
    final l = await XChannel.qualityList(since); // নতুন আগে
    bool run = true;
    try {
      run = await VpnChannel.isRunning();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      pts = l.reversed.toList();
      fwRunning = run;
      loading = false;
    });
  }

  Future<void> _toggle(bool v) async {
    store.cfg.qualityWatch = v;
    await store.save();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final okMs = [for (final p in pts) if (p['ok'] == true) (p['ms'] as num).toInt()];
    final fails = pts.length - okMs.length;
    final avg = okMs.isEmpty ? 0 : okMs.reduce((a, b) => a + b) ~/ okMs.length;
    final Map<String, dynamic> last = pts.isEmpty ? <String, dynamic>{} : pts.last;
    final lastOk = pts.isNotEmpty && last['ok'] == true;

    return Scaffold(
      appBar: AppBar(title: const Text('নেটের মান')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('নেটের মান মাপা', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(c.qualityWatch
                      ? (fwRunning ? 'চালু, প্রতি ৩০ সেকেন্ডে মাপছে' : 'চালু, কিন্তু ফায়ারওয়াল বন্ধ তাই মাপছে না')
                      : 'বন্ধ'),
                  value: c.qualityWatch,
                  onChanged: _toggle,
                ),
                const SizedBox(height: 4),
                Text(
                  'স্ক্রিন বন্ধ থাকলে মাপে না, ব্যাটারি বাঁচাতে। ১.১.১.১-এ সংযোগ হতে কত মিলিসেকেন্ড লাগল সেটাই মাপ। '
                  'শেষ ২ মিনিটের ৪টা মাপের ৩টা ধীর (৮০০ ms-র বেশি) বা ব্যর্থ হলে সতর্কতা আসে।',
                  style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              for (final h in const [1, 3])
                ChoiceChip(
                  label: Text('$h ঘণ্টা'),
                  selected: hours == h,
                  onSelected: (_) {
                    hours = h;
                    _load();
                  },
                ),
            ]),
            const SizedBox(height: 12),
            if (loading)
              const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
            else if (pts.isEmpty)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  c.qualityWatch
                      ? 'এখনো কোনো মাপ নেই। স্ক্রিন চালু রেখে ১ মিনিট পরে দেখুন।'
                      : 'সুইচ চালু করলে মাপ জমতে শুরু করবে।',
                  style: TextStyle(color: cs.onSurfaceVariant),
                ),
              )
            else ...[
              Row(children: [
                Expanded(child: _stat('এখন', lastOk ? '${(last['ms'] as num).toInt()} ms' : 'বন্ধ',
                    lastOk ? _label((last['ms'] as num).toInt()) : 'পৌঁছায়নি',
                    lastOk ? _color((last['ms'] as num).toInt(), cs) : cs.error)),
                const SizedBox(width: 12),
                Expanded(child: _stat('গড়', okMs.isEmpty ? '-' : '$avg ms',
                    '${pts.length}টা মাপ', cs.onSurface)),
                const SizedBox(width: 12),
                Expanded(child: _stat('ব্যর্থ', '$fails', '${(fails * 100 / pts.length).round()}%',
                    fails > 0 ? cs.error : cs.onSurface)),
              ]),
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('সংযোগ হতে সময় (কম = ভালো)', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 120,
                    width: double.infinity,
                    child: CustomPaint(painter: _BarPainter(pts, cs)),
                  ),
                  const SizedBox(height: 6),
                  Text('লাল দাগ = পৌঁছায়নি, হলুদ = ধীর (৮০০ ms-র বেশি)',
                      style: TextStyle(fontSize: 11.5, color: cs.outline)),
                ]),
              ),
              const SizedBox(height: 8),
              Text('সর্বশেষ মাপ: ${fmtAgo((last['t'] as num).toInt())} · ${_net(last['net'] as String)}',
                  style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
            ],
          ],
        ),
      ),
    );
  }

  String _net(String n) => n == 'wifi' ? 'Wi-Fi' : (n == 'mobile' ? 'মোবাইল ডেটা' : 'নেট নেই');

  String _label(int ms) => ms < 150 ? 'দারুণ' : (ms < 400 ? 'ঠিক আছে' : (ms < 800 ? 'কিছুটা ধীর' : 'ধীর'));

  Color _color(int ms, ColorScheme cs) =>
      ms < 400 ? Colors.green : (ms < 800 ? Colors.orange : cs.error);

  Widget _stat(String label, String main, String sub, Color color) {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        const SizedBox(height: 4),
        Text(main, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
        Text(sub, style: TextStyle(fontSize: 11.5, color: cs.outline)),
      ]),
    );
  }
}

class _BarPainter extends CustomPainter {
  final List<Map<String, dynamic>> pts;
  final ColorScheme cs;
  _BarPainter(this.pts, this.cs);

  @override
  void paint(Canvas canvas, Size size) {
    if (pts.isEmpty) return;
    const cap = 1000.0; // এর বেশি হলে পুরো উচ্চতা
    final n = pts.length;
    final w = size.width / n;
    final bw = w < 2 ? w : w - 1;
    final paint = Paint();
    for (var i = 0; i < n; i++) {
      final ok = pts[i]['ok'] == true;
      final ms = (pts[i]['ms'] as num).toDouble();
      final x = i * w;
      if (!ok) {
        paint.color = cs.error;
        canvas.drawRect(Rect.fromLTWH(x, 0, bw, size.height), paint);
      } else {
        final h = (ms.clamp(8, cap) / cap) * size.height;
        paint.color = ms < 400 ? Colors.green : (ms < 800 ? Colors.orange : cs.error);
        canvas.drawRect(Rect.fromLTWH(x, size.height - h, bw, h), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) => old.pts != pts;
}
