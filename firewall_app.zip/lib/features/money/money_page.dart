import 'package:flutter/material.dart';
import '../../services/rules_storage.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

/// টাকার হিসাব: মোবাইল ডেটা প্যাকের দাম থেকে কোন অ্যাপে কত টাকা গেল।
/// হিসাব = অ্যাপের মোবাইল ডেটা ÷ প্যাকের আকার × প্যাকের দাম। প্যাকের আকার আসে ডেটা লিমিটের প্যাক থেকে।
class MoneyPage extends StatefulWidget {
  const MoneyPage({super.key});

  @override
  State<MoneyPage> createState() => _MoneyPageState();
}

class _MoneyPageState extends State<MoneyPage> {
  final price = TextEditingController();
  bool loading = true;
  List<Map<String, dynamic>> rows = []; // {pkg, mobile}
  int today = 0;
  Map<String, String> names = {};

  @override
  void initState() {
    super.initState();
    final p = store.cfg.dlPackPrice;
    if (p > 0) price.text = p == p.roundToDouble() ? p.toInt().toString() : p.toString();
    _load();
  }

  @override
  void dispose() {
    price.dispose();
    super.dispose();
  }

  int get _since {
    final c = store.cfg;
    if (c.dlPackStart > 0) return c.dlPackStart;
    final n = DateTime.now();
    return DateTime(n.year, n.month, 1).millisecondsSinceEpoch; // প্যাক না থাকলে এই মাসের শুরু
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final all = await store.loadApps();
      names = {for (final a in all) a.pkg: a.name};
    } catch (_) {}
    List<Map<String, dynamic>> l = [];
    int t = 0;
    try {
      l = await VpnChannel.getUsage(_since);
      final td = await VpnChannel.getUsage(startOfToday());
      for (final m in td) {
        t += (m['mobile'] as num).toInt();
      }
    } catch (_) {}
    final r = <Map<String, dynamic>>[];
    for (final m in l) {
      final mob = (m['mobile'] as num).toInt();
      if (mob > 0) r.add({'pkg': m['pkg'] as String, 'mobile': mob});
    }
    r.sort((a, b) => (b['mobile'] as int).compareTo(a['mobile'] as int));
    if (!mounted) return;
    setState(() {
      rows = r;
      today = t;
      loading = false;
    });
  }

  Future<void> _savePrice() async {
    final v = double.tryParse(price.text.trim().replaceAll(',', '.')) ?? 0;
    store.cfg.dlPackPrice = v < 0 ? 0 : v;
    await store.save();
    FocusManager.instance.primaryFocus?.unfocus();
    if (mounted) setState(() {});
  }

  String _tk(double v) => '৳${v < 10 ? v.toStringAsFixed(2) : v.toStringAsFixed(1)}';

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final packMb = c.dlPackMb;
    final p = c.dlPackPrice;
    final ready = packMb > 0 && p > 0;
    final perByte = ready ? p / (packMb * 1024 * 1024) : 0.0;
    final totalMobile = rows.fold<int>(0, (a, e) => a + (e['mobile'] as int));

    return Scaffold(
      appBar: AppBar(title: const Text('টাকার হিসাব')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: Centered(
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('ডেটা প্যাক', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(
                    packMb > 0
                        ? 'আকার ${(packMb / 1024).toStringAsFixed(packMb % 1024 == 0 ? 0 : 1)} GB'
                            '${c.dlPackDays > 0 ? ", মেয়াদ ${c.dlPackDays} দিন" : ""}'
                        : 'প্যাকের আকার বসানো নেই। ডেটা ট্যাব থেকে ডেটা লিমিটে "প্যাক বসান", তারপর এখানে দাম দিন।',
                    style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant, height: 1.4),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: TextField(
                        controller: price,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: 'প্যাকের দাম (টাকা)',
                          prefixText: '৳ ',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        onSubmitted: (_) => _savePrice(),
                      ),
                    ),
                    const SizedBox(width: 10),
                    FilledButton(onPressed: _savePrice, child: const Text('সেভ')),
                  ]),
                  if (ready) ...[
                    const SizedBox(height: 8),
                    Text('প্রতি GB ≈ ${_tk(p / (packMb / 1024))}',
                        style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
                  ],
                ]),
              ),
              if (ready) ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: _stat('আজ', _tk(today * perByte), fmtBytes(today))),
                  const SizedBox(width: 12),
                  Expanded(child: _stat(
                      c.dlPackStart > 0 ? 'প্যাক শুরু থেকে' : 'এই মাসে',
                      _tk(totalMobile * perByte),
                      fmtBytes(totalMobile))),
                ]),
                const SectionLabel('অ্যাপ ধরে খরচ (মোবাইল ডেটা)'),
                if (loading)
                  const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))
                else if (rows.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('এই সময়ে মোবাইল ডেটা খরচ নেই', style: TextStyle(color: cs.onSurfaceVariant)),
                  )
                else
                  for (final r in rows.take(30))
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: AppIcon(r['pkg'] as String),
                      title: Text(names[r['pkg']] ?? r['pkg'] as String),
                      subtitle: Text(fmtBytes(r['mobile'] as int)),
                      trailing: Text(_tk((r['mobile'] as int) * perByte),
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                const SizedBox(height: 8),
                Text(
                  'হিসাবটা আনুমানিক: প্যাকের পুরো ডেটা ব্যবহার হবে ধরে ভাগ করা। অপারেটরের মেয়াদ বা বোনাস ডেটা আলাদা ধরা হয় না।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.4),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _stat(String label, String main, String sub) {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
        const SizedBox(height: 4),
        Text(main, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Text(sub, style: TextStyle(fontSize: 12, color: cs.outline)),
      ]),
    );
  }
}
