import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../widgets/app_picker.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';

/// ফ্লোটিং বাবল: বাছা অ্যাপের ছোট গোল আইকন স্ক্রিনের ওপর ভাসে।
/// ট্যাপে অ্যাপ খোলে, লং-প্রেসে মেনু (নেট বন্ধ/চালু, আজকের ডেটা, লক)। অ্যাপ বাবলের ভেতরে চলে না, বাবল শুধু শর্টকাট।
class BubblePage extends StatefulWidget {
  const BubblePage({super.key});

  @override
  State<BubblePage> createState() => _BubblePageState();
}

class _BubblePageState extends State<BubblePage> with WidgetsBindingObserver {
  Map<String, dynamic> st = {};
  Map<String, String> names = {};
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    store.loadApps().then((a) {
      if (mounted) setState(() => names = {for (final x in a) x.pkg: x.name});
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// অনুমতির সেটিংস থেকে ফিরলে অবস্থা আবার পড়ে
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final s = await XChannel.bubbleState();
    if (mounted && s.isNotEmpty) setState(() => st = s);
  }

  bool get canDraw => st['canDraw'] == true;
  bool get on => st['on'] == true;
  bool get mini => st['mini'] == true;
  int get msize => (st['msize'] as num?)?.toInt() ?? 1;
  bool get freeform => st['freeform'] == true;
  List<String> get pkgs => ((st['pkgs'] as List?) ?? const []).map((e) => e.toString()).toList();

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _pick() async {
    final r = await pickApps(context, title: 'বাবলে কোন অ্যাপ থাকবে?', selected: pkgs.toSet());
    if (r == null) return;
    await XChannel.bubbleSet(r);
    await _load();
  }

  Future<void> _remove(String pkg) async {
    await XChannel.bubbleSet(pkgs.where((p) => p != pkg).toList());
    await _load();
  }

  Future<void> _setMini(bool on, int size) async {
    setState(() => st = {...st, 'mini': on, 'msize': size});
    await XChannel.bubbleMini(on, size);
  }

  Future<void> _toggle(bool v) async {
    if (_busy) return;
    setState(() => _busy = true);
    if (v) {
      if (pkgs.isEmpty) {
        _snack('আগে অ্যাপ বেছে নিন');
      } else if (!await XChannel.bubbleStart()) {
        _snack('বাবল চালু হলো না, অনুমতি দেখুন');
      }
    } else {
      await XChannel.bubbleStop();
    }
    await Future.delayed(const Duration(milliseconds: 300));
    await _load();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('ফ্লোটিং বাবল')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppCard(
              child: Text(
                'ইউটিউব, হোয়াটসঅ্যাপ বা যেকোনো অ্যাপ বেছে নিন। স্ক্রিনের কিনারায় ছোট গোল আইকন ভাসবে। '
                'টেনে সরানো যায়, ছাড়লে কিনারায় লেগে যায়। ট্যাপে অ্যাপ খোলে। লং-প্রেস করলে মেনু আসে: '
                'নেট বন্ধ করো, আজ কত ডেটা গেছে, অ্যাপ লক করো।\n\n'
                'বাবল শুধু শর্টকাট, অ্যাপ বাবলের ভেতরে চলে না।',
                style: const TextStyle(height: 1.5),
              ),
            ),
            const SizedBox(height: 12),
            if (!canDraw)
              AppCard(
                color: cs.errorContainer.withAlpha(120),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('অনুমতি দরকার',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  const Text('অন্য অ্যাপের ওপর ভাসতে "অন্য অ্যাপের ওপর দেখানো" অনুমতি লাগে।'),
                  const SizedBox(height: 10),
                  FilledButton(
                      onPressed: XChannel.bubbleAskPerm, child: const Text('অনুমতি দিন')),
                ]),
              )
            else
              AppCard(
                child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('বাবল চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(on && st['running'] == true ? 'চলছে' : 'বন্ধ'),
                  value: on,
                  onChanged: _busy ? null : _toggle,
                ),
              ),
            const SizedBox(height: 12),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Expanded(
                      child: Text('বাবলের অ্যাপ',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
                  FilledButton.tonal(
                      onPressed: _pick, child: Text(pkgs.isEmpty ? 'অ্যাপ বাছুন' : 'বদলান')),
                ]),
                if (pkgs.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text('এখনো কোনো অ্যাপ বাছা হয়নি'),
                  ),
                for (final p in pkgs)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: AppIcon(p, size: 36),
                    title: Text(names[p] ?? p),
                    trailing: IconButton(
                        icon: const Icon(Icons.close), onPressed: () => _remove(p)),
                  ),
              ]),
            ),
            const SizedBox(height: 12),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ট্যাপে ছোট উইন্ডোতে খোলো',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: const Text('বন্ধ থাকলে ট্যাপে ফুলস্ক্রিনে খুলবে। লং-প্রেস মেনুতে ছোট উইন্ডোর বাটন সবসময় আছে।'),
                  value: mini,
                  onChanged: (v) => _setMini(v, msize),
                ),
                const SizedBox(height: 6),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('ছোট')),
                    ButtonSegment(value: 1, label: Text('মাঝারি')),
                    ButtonSegment(value: 2, label: Text('বড়')),
                  ],
                  selected: {msize},
                  onSelectionChanged: (s) => _setMini(mini, s.first),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Icon(freeform ? Icons.check_circle : Icons.warning_amber_rounded,
                      color: freeform ? Colors.green : Colors.orange),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(
                          freeform
                              ? 'এই ফোনে ছোট উইন্ডো চালু আছে বলে মনে হচ্ছে'
                              : 'এই ফোনে ছোট উইন্ডো চালু নেই',
                          style: const TextStyle(fontWeight: FontWeight.w600))),
                ]),
                if (!freeform)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'চালু করতে চাইলে: সেটিংস > ফোন সম্পর্কে > বিল্ড নম্বরে ৭ বার চাপুন (ডেভেলপার অপশন খুলবে)। '
                      'তারপর ডেভেলপার অপশনে "Enable freeform windows" আর "Force activities to be resizable" চালু করে ফোন রিস্টার্ট দিন। '
                      'কিছু ফোনে এই অপশন নেই, তখন ফুলস্ক্রিনেই খুলবে।',
                      style: TextStyle(height: 1.5),
                    ),
                  ),
              ]),
            ),
            const SizedBox(height: 12),
            AppCard(
              color: Colors.orange.withAlpha(40),
              child: const Text(
                '⚠️ সতর্কতা (ছোট উইন্ডো)\n'
                '• সব ফোনে কাজ করে না। না করলে অ্যাপ ফুলস্ক্রিনে খুলবে, কিছু ভাঙবে না।\n'
                '• ডেভেলপার অপশনের এই সুবিধা পরীক্ষামূলক। কিছু ফোনে অ্যাপ হ্যাং করতে বা হঠাৎ বন্ধ হতে পারে।\n'
                '• ব্যাংক, গেম, ক্যামেরা বা ভিডিও অ্যাপ অনেক সময় ছোট হতে চায় না, ফুলস্ক্রিনেই খোলে।\n'
                '• ৪ জিবি র‍্যামের ফোনে একসাথে কয়েকটা ছোট উইন্ডো চালালে ফোন ধীর হতে পারে।\n'
                '• ট্রেডিং বা টাকার অ্যাপ ছোট উইন্ডোতে ভুলে ট্যাপ লাগার ঝুঁকি বাড়ায়, ওসবে সাবধান।\n'
                '• লক করা অ্যাপ ছোট উইন্ডোতেও পিন চাইবে।',
                style: TextStyle(height: 1.55),
              ),
            ),
            const SizedBox(height: 12),
            AppCard(
              child: const Text(
                'জানা দরকার:\n'
                '• "নেট বন্ধ" কাজ করতে ফায়ারওয়াল চালু থাকতে হবে।\n'
                '• "আজ কত ডেটা" দেখাতে ইউসেজ অ্যাক্সেস দেওয়া থাকতে হবে।\n'
                '• বাবল থেকে শুধু কড়া দিকে যাওয়া সহজ (নেট বন্ধ, লক)। পিন সেট থাকলে বা ফোকাস চলছে এমন সময় '
                'নেট চালু বা আনলক করতে অ্যাপ খুলে পিন দিতে হবে।\n'
                '• কিছু ফোনের ব্যাটারি সেভার বাবল বন্ধ করে দেয়, তখন ব্যাটারি অপ্টিমাইজেশন থেকে এই অ্যাপ বাদ দিন।',
                style: TextStyle(height: 1.55),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
