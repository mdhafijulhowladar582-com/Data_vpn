import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../screens/intruder_page.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/common.dart';

/// পকেট গার্ড: ভিড়ে বা বাসে ফোন পকেটে রেখে চালু করুন। কেউ পকেট থেকে বের করলে, জোরে নাড়ালে বা চার্জার খুললে
/// প্রথমে পিনের স্ক্রিন আসে। পিন না দিলে জোরে সাইরেন বাজে আর সামনের ক্যামেরায় ছবি তোলা হয়।
/// ছবি ভল্টে এনক্রিপ্ট থাকে, "ভুল পিনের ইতিহাস" পেজে দেখা যায়।
class PocketPage extends StatefulWidget {
  const PocketPage({super.key});

  @override
  State<PocketPage> createState() => _PocketPageState();
}

class _PocketPageState extends State<PocketPage> {
  Map<String, dynamic> st = {};
  Timer? _t;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 1), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final s = await XChannel.pocketState();
    if (mounted && s.isNotEmpty) setState(() => st = s);
  }

  int get state => (st['state'] as num?)?.toInt() ?? 0;
  Map<String, dynamic> get cfg => Map<String, dynamic>.from((st['cfg'] as Map?) ?? const {});
  List<Map<String, dynamic>> get log =>
      ((st['log'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  bool get hasPin => st['hasPin'] == true;
  bool get cam => st['cam'] == true;

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _set(Map<String, dynamic> patch) async {
    final c = cfg;
    c.addAll(patch);
    setState(() => st = {...st, 'cfg': c});
    await XChannel.pocketCfg(c);
  }

  Future<void> _arm() async {
    if (_busy) return;
    setState(() => _busy = true);
    final ok = await XChannel.pocketArm();
    if (!ok) _snack('চালু করা গেল না। আগে অ্যাপের পিন সেট করা আছে কি না দেখুন');
    await _load();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _photoToggle(bool v) async {
    if (v && !cam) {
      final ok = await VpnChannel.camAsk();
      if (!ok) {
        _snack('ক্যামেরার অনুমতি না দিলে ছবি তোলা যাবে না');
        await _load();
        return;
      }
    }
    await _set({'photo': v});
    await _load();
  }

  String _when(int t) {
    final d = DateTime.fromMillisecondsSinceEpoch(t);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)} ${two(d.hour)}:${two(d.minute)}';
  }

  Widget _statusCard(ColorScheme cs) {
    final left = (st['left'] as num?)?.toInt() ?? 0;
    final graceLeft = (st['graceLeft'] as num?)?.toInt() ?? 0;
    final since = (st['since'] as num?)?.toInt() ?? 0;
    final reason = (st['reason'] as String?) ?? '';
    String big;
    String small;
    Color? bg;
    IconData icon;
    switch (state) {
      case 1:
        big = '$left সেকেন্ডে চালু হবে';
        small = 'এখন ফোন পকেটে ঢোকান';
        icon = Icons.hourglass_top;
        break;
      case 2:
        final mins = since > 0 ? ((DateTime.now().millisecondsSinceEpoch - since) ~/ 60000) : 0;
        big = 'পাহারা চালু';
        small = '$mins মিনিট ধরে চালু। বন্ধ করতে পিন লাগবে';
        icon = Icons.shield;
        bg = cs.primaryContainer;
        break;
      case 3:
        big = 'সতর্কতা: $reason';
        small = 'পিন না দিলে $graceLeft সেকেন্ডে সাইরেন';
        icon = Icons.warning_amber_rounded;
        bg = cs.errorContainer;
        break;
      case 4:
        big = 'সাইরেন বাজছে';
        small = reason;
        icon = Icons.notifications_active;
        bg = cs.errorContainer;
        break;
      default:
        big = 'বন্ধ আছে';
        small = 'চালু করে ফোন পকেটে রাখুন';
        icon = Icons.shield_outlined;
    }
    return AppCard(
      color: bg,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, size: 30),
          const SizedBox(width: 12),
          Expanded(
              child: Text(big, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
        ]),
        const SizedBox(height: 6),
        Text(small, style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
        const SizedBox(height: 14),
        if (state == 0)
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: (_busy || !hasPin) ? null : _arm,
              icon: const Icon(Icons.lock_outline),
              label: Text('চালু করুন (${cfg['countdown'] ?? 10} সেকেন্ড পরে)'),
            ),
          )
        else if (state == 1)
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () async {
                await XChannel.pocketCancelArm();
                await _load();
              },
              child: const Text('বাতিল'),
            ),
          )
        else
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => XChannel.pocketDisarmAsk(),
              icon: const Icon(Icons.pin_outlined),
              label: const Text('বন্ধ করুন (পিন লাগবে)'),
            ),
          ),
        if (state == 0 && !hasPin)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              'আগে সেটিংসে অ্যাপের পিন সেট করুন। পিন ছাড়া সাইরেন বন্ধ করার উপায় থাকে না, তাই চালুই হবে না।',
              style: TextStyle(fontSize: 12.5, color: cs.error),
            ),
          ),
        if (state == 2 && st['prox'] != true && cfg['mode'] == 'pocket' && cfg['tProx'] == true)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              'সেন্সর ঢাকা ছিল না, তাই "পকেট থেকে বের করা" ধরছে না। ঝাঁকুনি আর চার্জার ধরছে।',
              style: TextStyle(fontSize: 12.5, color: cs.outline),
            ),
          ),
      ]),
    );
  }

  Widget _settings(ColorScheme cs) {
    final c = cfg;
    final locked = state != 0;
    final pocket = (c['mode'] ?? 'pocket') == 'pocket';
    final sens = (c['sens'] as num?)?.toInt() ?? 1;
    final grace = (c['grace'] as num?)?.toInt() ?? 5;
    final cd = (c['countdown'] as num?)?.toInt() ?? 10;
    final hasProx = st['hasProxSensor'] != false;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('সেটিংস', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        if (locked)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text('বদলাতে আগে গার্ড বন্ধ করুন', style: TextStyle(fontSize: 12, color: cs.outline)),
          ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'pocket', label: Text('পকেট'), icon: Icon(Icons.checkroom_outlined)),
              ButtonSegment(value: 'table', label: Text('টেবিল'), icon: Icon(Icons.table_restaurant_outlined)),
            ],
            selected: {pocket ? 'pocket' : 'table'},
            onSelectionChanged: locked ? null : (s) => _set({'mode': s.first}),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          pocket
              ? 'পকেট: বের করলে বা ছিনতাইয়ের মতো জোরে ঝাঁকালে বাজে। সাধারণ হাঁটায় বাজে না।'
              : 'টেবিল: ফোন টেবিলে/চার্জে রেখে যান, সামান্য নড়লেই বাজে।',
          style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant),
        ),
        const SizedBox(height: 14),
        Text('সংবেদনশীলতা', style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
        const SizedBox(height: 6),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('কম')),
              ButtonSegment(value: 1, label: Text('মাঝারি')),
              ButtonSegment(value: 2, label: Text('বেশি')),
            ],
            selected: {sens.clamp(0, 2)},
            onSelectionChanged: locked ? null : (s) => _set({'sens': s.first}),
          ),
        ),
        const SizedBox(height: 8),
        if (pocket)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('পকেট থেকে বের করলে'),
            subtitle: Text(hasProx
                ? 'প্রক্সিমিটি সেন্সর ঢাকা থেকে খুললে ধরে'
                : 'এই ফোনে প্রক্সিমিটি সেন্সর নেই, কাজ করবে না'),
            value: c['tProx'] != false,
            onChanged: (locked || !hasProx) ? null : (v) => _set({'tProx': v}),
          ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(pocket ? 'জোরে ঝাঁকুনি (ছিনতাই)' : 'নাড়ালে'),
          value: c['tMove'] != false,
          onChanged: locked ? null : (v) => _set({'tMove': v}),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('চার্জার খুললে'),
          subtitle: const Text('চার্জে থাকা অবস্থায় প্লাগ খুললে'),
          value: c['tCharger'] != false,
          onChanged: locked ? null : (v) => _set({'tCharger': v}),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('সামনের ক্যামেরায় ছবি তুলুন'),
          subtitle: Text(cam ? 'ছবি ভল্টে এনক্রিপ্ট হয়ে থাকে' : 'ক্যামেরার অনুমতি লাগবে'),
          value: c['photo'] != false && cam,
          onChanged: locked ? null : _photoToggle,
        ),
        const SizedBox(height: 8),
        Text('সাইরেনের আগে পিনের সময়', style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
        const SizedBox(height: 6),
        Wrap(spacing: 8, children: [
          for (final g in const [0, 5, 10, 15])
            ChoiceChip(
              label: Text(g == 0 ? 'সাথে সাথে' : '$g সে.'),
              selected: grace == g,
              onSelected: locked ? null : (_) => _set({'grace': g}),
            ),
        ]),
        const SizedBox(height: 12),
        Text('চালুর কাউন্টডাউন (ফোন পকেটে ঢোকানোর সময়)',
            style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant)),
        const SizedBox(height: 6),
        Wrap(spacing: 8, children: [
          for (final s in const [5, 10, 20])
            ChoiceChip(
              label: Text('$s সে.'),
              selected: cd == s,
              onSelected: locked ? null : (_) => _set({'countdown': s}),
            ),
        ]),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          onPressed: state == 0 ? () => XChannel.pocketTest() : null,
          icon: const Icon(Icons.volume_up_outlined),
          label: const Text('সাইরেন পরীক্ষা (৩ সেকেন্ড)'),
        ),
      ]),
    );
  }

  Widget _history(ColorScheme cs) {
    final l = log;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(
              child: Text('কখন কখন বেজেছে', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          if (l.isNotEmpty)
            TextButton(
              onPressed: () async {
                await XChannel.pocketLogClear();
                await _load();
              },
              child: const Text('মুছুন'),
            ),
        ]),
        const SizedBox(height: 4),
        if (l.isEmpty)
          Text('এখনও কিছু ঘটেনি', style: TextStyle(fontSize: 13, color: cs.outline))
        else
          for (final e in l.take(20))
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.warning_amber_rounded, size: 18, color: cs.error),
                const SizedBox(width: 8),
                Expanded(child: Text((e['reason'] as String?) ?? '')),
                const SizedBox(width: 8),
                Text(_when((e['t'] as num?)?.toInt() ?? 0),
                    style: TextStyle(fontSize: 12, color: cs.outline)),
              ]),
            ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () =>
              Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IntruderPage())),
          icon: const Icon(Icons.photo_library_outlined),
          label: const Text('চোরের ছবি দেখুন'),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('পকেট গার্ড')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
          _statusCard(cs),
          const SizedBox(height: 12),
          _settings(cs),
          const SizedBox(height: 12),
          _history(cs),
        ]),
      ),
    );
  }
}
