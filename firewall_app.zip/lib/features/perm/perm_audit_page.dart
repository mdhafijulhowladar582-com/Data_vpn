import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../../widgets/usage_access.dart';
import '../fmt.dart';

/// পারমিশন অডিটর: সংবেদনশীল পারমিশন দেওয়া অ্যাপগুলো, শেষ কবে খোলা হয়েছে আর ৩০ দিনে কত ডেটা খেয়েছে
/// মিলিয়ে সন্দেহের স্তর দেখায়। এটা ম্যালওয়্যার-স্ক্যান নয়, শুধু সন্দেহজনক ছাঁচ খোঁজা।
class PermAuditPage extends StatefulWidget {
  const PermAuditPage({super.key});

  @override
  State<PermAuditPage> createState() => _PermAuditPageState();
}

class _PermAuditPageState extends State<PermAuditPage> with WidgetsBindingObserver {
  bool? access;
  List<Map<String, dynamic>>? list;
  bool showAll = false;
  final Set<String> blocked = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // সেটিংস (Usage access বা পারমিশন) থেকে ফিরলে আবার স্ক্যান
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final a = await VpnChannel.hasUsageAccess();
    if (!mounted) return;
    if (!a) {
      setState(() => access = false);
      return;
    }
    setState(() {
      access = true;
      list = null;
    });
    final l = await XChannel.permScan();
    if (!mounted) return;
    setState(() => list = l);
  }

  void _block(String pkg) {
    store.setRule(pkg, wifi: true, mobile: true);
    store.cfg.allowed.remove(pkg);
    setState(() => blocked.add(pkg));
  }

  Color _color(String lv, ColorScheme cs) => lv == 'high' ? cs.error : (lv == 'mid' ? Colors.orange : cs.outline);
  String _label(String lv) => lv == 'high' ? 'বেশি সন্দেহ' : (lv == 'mid' ? 'কিছুটা সন্দেহ' : 'স্বাভাবিক');

  @override
  Widget build(BuildContext context) {
    if (access == false) {
      return Scaffold(appBar: AppBar(title: const Text('পারমিশন অডিটর')), body: const UsageAccessPrompt());
    }
    final cs = Theme.of(context).colorScheme;
    final l = list;
    final shown = l == null ? <Map<String, dynamic>>[] : [for (final m in l) if (showAll || m['level'] != 'low') m];
    final high = l == null ? 0 : l.where((m) => m['level'] == 'high').length;

    return Scaffold(
      appBar: AppBar(title: const Text('পারমিশন অডিটর'), actions: [
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh), tooltip: 'আবার স্ক্যান'),
      ]),
      body: l == null
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
                Text(
                  'ক্যামেরা, মাইক্রোফোন, লোকেশন, কন্টাক্টস, এসএমএস বা কল লগের পারমিশন দেওয়া অ্যাপ। '
                  'যে অ্যাপ অনেক দিন খোলা হয়নি অথচ নেটে ডেটা খরচ করছে, সেটা ওপরে আসে। '
                  'এটা অনুমান, প্রমাণ নয়: অনেক ভালো অ্যাপও চুপচাপ সিঙ্ক করে।',
                  style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.45),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                    child: Text(
                      high > 0 ? '$highটা অ্যাপে বেশি সন্দেহ' : 'বেশি সন্দেহের কোনো অ্যাপ নেই',
                      style: TextStyle(fontWeight: FontWeight.w700, color: high > 0 ? cs.error : Colors.green),
                    ),
                  ),
                  FilterChip(
                    label: Text('স্বাভাবিকগুলোও (${l.where((m) => m['level'] == 'low').length})'),
                    selected: showAll,
                    onSelected: (v) => setState(() => showAll = v),
                  ),
                ]),
                const SizedBox(height: 8),
                if (shown.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 40),
                    child: Center(child: Text('দেখানোর মতো কিছু নেই।', textAlign: TextAlign.center)),
                  )
                else
                  for (final m in shown) _card(m, cs),
              ]),
            ),
    );
  }

  Widget _card(Map<String, dynamic> m, ColorScheme cs) {
    final pkg = m['pkg'] as String;
    final lv = m['level'] as String;
    final perms = (m['perms'] as List).cast<String>();
    final reasons = (m['reasons'] as List).cast<String>();
    final unused = (m['unusedDays'] as num).toInt();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            AppIcon(pkg, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(m['name'] as String,
                    maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Text(
                  [
                    if (unused >= 0) (unused == 0 ? 'আজ খোলা' : '$unused দিন আগে খোলা'),
                    if ((m['bytes'] as num) > 0) '৩০ দিনে ${fmtBytes(m['bytes'] as num)}',
                  ].join(' · '),
                  style: TextStyle(fontSize: 12, color: cs.outline),
                ),
              ]),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: _color(lv, cs).withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: Text(_label(lv), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: _color(lv, cs))),
            ),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (final p in perms)
              Chip(
                label: Text(p, style: const TextStyle(fontSize: 11.5)),
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
          ]),
          const SizedBox(height: 6),
          for (final r in reasons) Text('• $r', style: const TextStyle(fontSize: 13, height: 1.45)),
          const SizedBox(height: 8),
          Row(children: [
            OutlinedButton(onPressed: () => XChannel.openPkgSettings(pkg), child: const Text('পারমিশন দেখুন')),
            const SizedBox(width: 8),
            blocked.contains(pkg)
                ? const Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 4), Text('নেট ব্লক')])
                : OutlinedButton(onPressed: () => _block(pkg), child: const Text('নেট ব্লক')),
          ]),
        ]),
      ),
    );
  }
}
