import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../models/app_info.dart';
import '../../services/lock_service.dart';
import '../../services/rules_storage.dart';
import '../fmt.dart';

/// একটা বোঝা-কমান্ডের ফল। [apply] থাকলে কনফার্ম কার্ড দেখাবে, না থাকলে [answer] সরাসরি দেখাবে
class CmdPlan {
  final String title;
  final List<String> lines;
  final Future<String> Function(BuildContext context)? apply;
  CmdPlan(this.title, this.lines, {this.apply});
}

/// বাংলা বাক্য -> ফায়ারওয়ালের পরিবর্তন বা প্রশ্নের উত্তর। এটা নিয়ম-ভিত্তিক (কিওয়ার্ড), AI নয়,
/// তাই শুধু নিচের ধরনের বাক্য বোঝে: ব্লক/খুলে দেওয়া (মোবাইল ডেটা বা Wi-Fi আলাদা করে), দৈনিক সময়সীমা, আজকের ডেটার প্রশ্ন।
/// কোনো পরিবর্তন সরাসরি হয় না, আগে কার্ডে দেখিয়ে কনফার্ম চায়। ঢিলা করার কমান্ডে (খোলা, লিমিট বাড়ানো/তোলা) পিন লাগে।
class CommandParser {
  static const _aliases = <String, List<String>>{
    'ফেসবুক': ['facebook'],
    'ইউটিউব': ['youtube'],
    'হোয়াটসঅ্যাপ': ['whatsapp'],
    'হোয়াটসএপ': ['whatsapp'],
    'মেসেঞ্জার': ['messenger'],
    'টিকটক': ['tiktok'],
    'ইনস্টাগ্রাম': ['instagram'],
    'ইন্সটাগ্রাম': ['instagram'],
    'টেলিগ্রাম': ['telegram'],
    'ক্রোম': ['chrome'],
    'গুগল': ['google'],
    'ইমো': ['imo'],
    'নেটফ্লিক্স': ['netflix'],
    'ফ্রি ফায়ার': ['free fire'],
    'পাবজি': ['pubg'],
    'টুইটার': ['twitter'],
  };

  static String norm(String s) {
    const bn = '০১২৩৪৫৬৭৮৯';
    final b = StringBuffer();
    for (final r in s.runes) {
      final ch = String.fromCharCode(r);
      final i = bn.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    return b.toString().toLowerCase().replaceAll('ঘন্টা', 'ঘণ্টা');
  }

  static bool _has(String t, List<String> ks) => ks.any(t.contains);

  /// বাক্যে উল্লেখ করা অ্যাপ (সবচেয়ে ছোট নামের মিল)। না পেলে null
  static AppInfo? findApp(String t, List<AppInfo> apps) {
    final tokens = <String>{};
    _aliases.forEach((bn, en) {
      if (t.contains(bn)) tokens.addAll(en);
    });
    AppInfo? best;
    for (final a in apps) {
      final n = a.name.toLowerCase();
      final hit = tokens.any(n.contains) || (n.length >= 3 && t.contains(n));
      if (hit && (best == null || a.name.length < best.name.length)) best = a;
    }
    return best;
  }

  /// মিনিট বের করা: "৩০ মিনিট", "২ ঘণ্টা", "আধা ঘণ্টা", "দেড় ঘণ্টা", "১ ঘণ্টা ৩০ মিনিট"
  static int? minutes(String t) {
    if (t.contains('আধা ঘণ্টা')) return 30;
    if (t.contains('দেড় ঘণ্টা')) return 90;
    final h = RegExp(r'(\d+)\s*ঘণ্টা').firstMatch(t);
    final m = RegExp(r'(\d+)\s*মিনিট').firstMatch(t);
    if (h == null && m == null) return null;
    return (h == null ? 0 : int.parse(h.group(1)!) * 60) + (m == null ? 0 : int.parse(m.group(1)!));
  }

  static Future<CmdPlan?> parse(String raw) async {
    final t = norm(raw.trim());
    if (t.isEmpty) return null;
    final apps = await store.loadApps();
    final names = {for (final a in apps) a.pkg: a.name};
    final app = findApp(t, apps);
    final mins = minutes(t);

    // ---- প্রশ্ন: আজকের ডেটা ----
    if (t.contains('ডেটা') && _has(t, ['কত', 'কোন', 'বেশি', 'খেয়ে', 'খরচ'])) {
      final rows = await XChannel.connApps(startOfToday());
      if (rows.isEmpty) {
        return CmdPlan('আজকের ডেটা', ['এখনো কোনো হিসাব জমেনি। ইঞ্জিনে অ্যাপ যোগ করে ফায়ারওয়াল চালু রাখুন।']);
      }
      int tot(Map<String, dynamic> r) => ((r['up'] as num?) ?? 0).toInt() + ((r['down'] as num?) ?? 0).toInt();
      if (app != null) {
        final r = rows.where((e) => e['pkg'] == app.pkg).toList();
        final v = r.isEmpty ? 0 : tot(r.first);
        return CmdPlan('${app.name}, আজ', ['${fmtBytes(v)} ডেটা গেছে।', 'শুধু ইঞ্জিনে যোগ করা অ্যাপের হিসাব মেলে।']);
      }
      if (_has(t, ['কোন', 'বেশি'])) {
        final top = rows.take(3).toList();
        return CmdPlan('আজ সবচেয়ে বেশি ডেটা', [
          for (var i = 0; i < top.length; i++) '${i + 1}. ${names[top[i]['pkg']] ?? top[i]['pkg']}: ${fmtBytes(tot(top[i]))}',
          'শুধু ইঞ্জিনে যোগ করা অ্যাপের হিসাব।',
        ]);
      }
      final sum = rows.fold<int>(0, (a, r) => a + tot(r));
      return CmdPlan('আজকের মোট ডেটা', ['${fmtBytes(sum)} (ইঞ্জিনে যোগ করা অ্যাপের মোট)']);
    }

    // ---- সময়সীমা তোলা ----
    if (t.contains('লিমিট') && _has(t, ['তুলে', 'মুছে', 'বাদ'])) {
      if (app == null) return CmdPlan('বুঝিনি', ['কোন অ্যাপের লিমিট তুলতে চান? অ্যাপের নাম লিখুন।']);
      return CmdPlan('লিমিট তোলা', ['${app.name}-এর দৈনিক লিমিট মুছে যাবে।'], apply: (ctx) async {
        if (!await Lock.ask(ctx, reason: 'লিমিট তুলতে পিন দিন', force: true)) return 'বাতিল (পিন মেলেনি)';
        store.cfg.limits.remove(app.pkg);
        await store.save();
        return '${app.name}-এর লিমিট তোলা হয়েছে';
      });
    }

    // ---- দৈনিক সময়সীমা বসানো ----
    if (mins != null && mins > 0 && _has(t, ['দিনে', 'লিমিট', 'সীমা', 'সময়', 'এর বেশি'])) {
      if (app == null) return CmdPlan('বুঝিনি', ['কোন অ্যাপে $mins মিনিট? অ্যাপের নাম লিখুন।']);
      final old = store.cfg.limits[app.pkg] ?? 0;
      return CmdPlan('দৈনিক সময়সীমা', [
        '${app.name}: দিনে সর্বোচ্চ $mins মিনিট',
        if (old > 0) 'আগে ছিল $old মিনিট',
        'অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি) চালু থাকলে সীমা পেরোলে অ্যাপ বন্ধ হবে।',
      ], apply: (ctx) async {
        if (old > 0 && mins > old) {
          if (!await Lock.ask(ctx, reason: 'লিমিট বাড়াতে পিন দিন', force: true)) return 'বাতিল (পিন মেলেনি)';
        }
        store.cfg.limits[app.pkg] = mins;
        await store.save();
        return '${app.name}: দিনে $mins মিনিট';
      });
    }

    // ---- খুলে দেওয়া ----
    if (_has(t, ['খুলে', 'আনব্লক', 'ছেড়ে দাও', 'ছেড়ে দিন', 'চালু করো', 'চালু করুন', 'চালু কর'])) {
      if (app == null) return CmdPlan('বুঝিনি', ['কোন অ্যাপ খুলে দেব? অ্যাপের নাম লিখুন।']);
      return CmdPlan('ইন্টারনেট খুলে দেওয়া', ['${app.name}-এর ইন্টারনেট ব্লক সরবে (Wi-Fi ও মোবাইল ডেটা দুটোই)।'], apply: (ctx) async {
        if (!await Lock.ask(ctx, reason: 'ব্লক সরাতে পিন দিন', force: true)) return 'বাতিল (পিন মেলেনি)';
        if (store.cfg.mode == 'whitelist') {
          store.cfg.allowed.add(app.pkg);
        } else {
          store.cfg.rules.remove(app.pkg);
        }
        await store.save();
        return '${app.name}-এর ইন্টারনেট খোলা হয়েছে';
      });
    }

    // ---- ব্লক ----
    if (_has(t, ['ব্লক', 'বন্ধ'])) {
      if (app == null) return CmdPlan('বুঝিনি', ['কোন অ্যাপ ব্লক করব? অ্যাপের নাম লিখুন, যেমন "ফেসবুক ব্লক করো"।']);
      final mobile = _has(t, ['মোবাইল']);
      final wifi = _has(t, ['ওয়াইফাই', 'ওয়াই-ফাই', 'wifi', 'wi-fi', 'ওয়াই ফাই']);
      final w = wifi || !mobile; // কিছু না বললে দুটোই
      final m = mobile || !wifi;
      final scope = w && m ? 'Wi-Fi ও মোবাইল ডেটা' : (m ? 'মোবাইল ডেটা' : 'Wi-Fi');
      return CmdPlan('ইন্টারনেট ব্লক', [
        '${app.name}: $scope বন্ধ',
        if (store.cfg.mode == 'whitelist') 'আপনি হোয়াইটলিস্ট মোডে আছেন, তাই অ্যাপটা অনুমতির তালিকা থেকে সরবে।',
      ], apply: (ctx) async {
        if (store.cfg.mode == 'whitelist') {
          store.cfg.allowed.remove(app.pkg);
        } else {
          final r = store.ruleOf(app.pkg);
          if (w) r.wifi = true;
          if (m) r.mobile = true;
          store.cfg.rules[app.pkg] = r;
        }
        await store.save();
        return '${app.name}: $scope ব্লক করা হয়েছে';
      });
    }

    return null;
  }
}
