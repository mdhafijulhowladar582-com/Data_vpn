import 'package:flutter/material.dart';
import '../../widgets/common.dart';
import 'command_parser.dart';

/// বাংলা কমান্ড: সাধারণ বাংলা বাক্য লিখলে ফায়ারওয়ালের নিয়ম বদলায় বা আজকের ডেটার উত্তর দেয়।
/// নিয়ম-ভিত্তিক, তাই অচেনা বাক্যে "বুঝিনি" বলে। বদলের আগে কনফার্ম কার্ড আসে।
class CommandPage extends StatefulWidget {
  const CommandPage({super.key});

  @override
  State<CommandPage> createState() => _CommandPageState();
}

class _CommandPageState extends State<CommandPage> {
  final input = TextEditingController();
  CmdPlan? plan;
  bool notUnderstood = false;
  bool busy = false;
  String? done;

  static const examples = [
    'ফেসবুক ব্লক করো',
    'ইউটিউব মোবাইল ডেটায় বন্ধ করো',
    'ফেসবুকে দিনে ৩০ মিনিট',
    'টিকটকে দিনে ১ ঘণ্টা সময়সীমা',
    'ফেসবুক খুলে দাও',
    'আজ কোন অ্যাপ সবচেয়ে বেশি ডেটা খেয়েছে',
    'আজ কত ডেটা গেছে',
  ];

  Future<void> _run() async {
    setState(() {
      busy = true;
      done = null;
      plan = null;
      notUnderstood = false;
    });
    final p = await CommandParser.parse(input.text);
    if (!mounted) return;
    setState(() {
      busy = false;
      plan = p;
      notUnderstood = p == null;
    });
  }

  Future<void> _confirm() async {
    final p = plan;
    if (p?.apply == null) return;
    final r = await p!.apply!(context);
    if (!mounted) return;
    setState(() {
      done = r;
      plan = null;
      input.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final p = plan;
    return Scaffold(
      appBar: AppBar(title: const Text('বাংলা কমান্ড')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: input,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _run(),
                decoration: const InputDecoration(hintText: 'যেমন: ফেসবুক ব্লক করো'),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: busy ? null : _run, icon: const Icon(Icons.send)),
          ]),
          const SizedBox(height: 12),
          if (done != null)
            AppCard(
              color: Colors.green.withAlpha(40),
              child: Row(children: [
                const Icon(Icons.check_circle, color: Colors.green),
                const SizedBox(width: 10),
                Expanded(child: Text(done!, style: const TextStyle(fontWeight: FontWeight.w700))),
              ]),
            ),
          if (notUnderstood)
            AppCard(
              color: cs.errorContainer.withAlpha(120),
              child: const Text('বুঝতে পারিনি। নিচের উদাহরণের মতো লিখুন: অ্যাপের নাম আর কী করতে চান।'),
            ),
          if (p != null)
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                for (final l in p.lines) Padding(padding: const EdgeInsets.only(bottom: 3), child: Text(l)),
                if (p.apply != null) ...[
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: FilledButton(onPressed: _confirm, child: const Text('নিশ্চিত করুন'))),
                    const SizedBox(width: 8),
                    OutlinedButton(onPressed: () => setState(() => plan = null), child: const Text('বাদ')),
                  ]),
                ],
              ]),
            ),
          const SizedBox(height: 16),
          const Text('উদাহরণ', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final e in examples)
              ActionChip(
                label: Text(e),
                onPressed: () {
                  input.text = e;
                  _run();
                },
              ),
          ]),
          const SizedBox(height: 16),
          Text(
            'সীমা: এটা কিওয়ার্ড মিলিয়ে বোঝে, AI নয়। অ্যাপের নাম ফোনে ইনস্টল করা অ্যাপের সাথে মেলে (ফেসবুক, ইউটিউব ইত্যাদি চেনা নাম বাংলায় লেখা যায়, বাকিগুলো ইংরেজি নামে লিখুন)। '
            'ডেটার উত্তর শুধু ইঞ্জিনে যোগ করা অ্যাপের হিসাব থেকে আসে। ঢিলা করার কমান্ডে (খুলে দেওয়া, লিমিট বাড়ানো বা তোলা) পিন লাগে।',
            style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
          ),
        ]),
      ),
    );
  }
}
