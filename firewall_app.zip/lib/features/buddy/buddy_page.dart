import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/common.dart';

/// নতুন তিন সার্ভিস: আলসে-লক, নেট-হার্টবিট, ডেটা-পোষা। প্রতিটার আলাদা অন/অফ সুইচ।
class BuddyPage extends StatefulWidget {
  const BuddyPage({super.key});

  @override
  State<BuddyPage> createState() => _BuddyPageState();
}

class _BuddyPageState extends State<BuddyPage> with WidgetsBindingObserver {
  static const _minOpts = [15, 30, 45, 60, 90];
  static const _stepOpts = [10, 20, 30, 50];
  static const _flipOpts = [10, 25, 45, 60];
  static const _boolOpts = {'beatVib', 'senseFlip', 'senseShake', 'senseDark', 'senseSummary'};

  Map<String, dynamic> st = {};
  bool hasUsage = true;
  Timer? _timer;
  final _codeCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load(heal: true);
    // আলসে-লকের লাইভ হিসাব (কতক্ষণ বসা, কত পা) হালনাগাদ রাখা
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _codeCtl.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// অনুমতির সেটিংস থেকে ফিরলে অবস্থা আবার পড়ে
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load(heal: true);
  }

  bool _b(String k) => st[k] == true;
  int _i(String k, int d) => (st[k] as num?)?.toInt() ?? d;
  bool get canDraw => _b('canDraw');

  Future<void> _load({bool heal = false}) async {
    final s = await XChannel.buddyState();
    bool u = true;
    try {
      u = await VpnChannel.hasUsageAccess();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      if (s.isNotEmpty) st = s;
      hasUsage = u;
    });
    // সুইচ চালু রাখা ছিল, অনুমতি পরে এসেছে কিন্তু সার্ভিস চলছে না: আবার চালু করা
    if (heal && s['canDraw'] == true) {
      const run = {'lazy': 'lazyRun', 'beat': 'beatRun', 'pet': 'petRun', 'sense': 'senseRun'};
      for (final e in run.entries) {
        if (s[e.key] == true && s[e.value] != true) await XChannel.buddySet(e.key, true);
      }
    }
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _set(String key, bool on) async {
    if (on && !canDraw) {
      // অনুমতি ছাড়া চালু হয় না: অনুমতির পাতা খুলে দেওয়া, সুইচ বন্ধই থাকে
      await XChannel.buddyAskPerm();
      _snack('"অন্য অ্যাপের ওপর দেখানো" অনুমতি দিয়ে ফিরে এসে আবার সুইচ চালু করুন');
      return;
    }
    setState(() => st = {...st, key: on});
    final ok = await XChannel.buddySet(key, on);
    if (on && !ok) _snack('চালু করা গেল না। অনুমতি আর ফোনের সেটিংস দেখুন');
    await Future.delayed(const Duration(milliseconds: 300));
    await _load();
  }

  /// চারটা সার্ভিস একসাথে চালু/বন্ধ
  Future<void> _setAll(bool on) async {
    if (on && !canDraw) {
      await XChannel.buddyAskPerm();
      _snack('"অন্য অ্যাপের ওপর দেখানো" অনুমতি দিয়ে ফিরে এসে আবার সুইচ চালু করুন');
      return;
    }
    setState(() => st = {...st, 'lazy': on, 'beat': on, 'pet': on, 'sense': on});
    for (final k in const ['lazy', 'beat', 'pet', 'sense']) {
      await XChannel.buddySet(k, on);
    }
    await Future.delayed(const Duration(milliseconds: 300));
    await _load();
  }

  Future<void> _opt(String key, int value) async {
    setState(() => st = {...st, key: _boolOpts.contains(key) ? value != 0 : value});
    await XChannel.buddyOpt(key, value);
  }

  String _bn(int n) => n.toString().split('').map((c) {
        final i = '0123456789'.indexOf(c);
        return i < 0 ? c : '০১২৩৪৫৬৭৮৯'[i];
      }).join();

  Future<void> _applyCode() async {
    final t = _codeCtl.text.trim();
    if (t.isEmpty) return;
    final ok = await XChannel.buddyCode(t);
    if (!mounted) return;
    _codeCtl.clear();
    FocusScope.of(context).unfocus();
    _snack(ok ? 'কোড ঠিক আছে 🔓 পোষা এখন সুরক্ষিত' : 'ভুল কোড');
    await _load();
  }

  Future<void> _pinWidget() async {
    final ok = await XChannel.buddyPinWidget();
    if (!ok) {
      _snack('এই লঞ্চার সরাসরি যোগ করতে দেয় না। হোম স্ক্রিনের ফাঁকা জায়গায় লং-প্রেস করে উইজেট থেকে "পোষা ও হার্টবিট" বেছে নিন');
    }
  }

  String _dur(int m) {
    final h = m ~/ 60;
    final r = m % 60;
    if (h == 0) return '${_bn(r)} মিনিট';
    if (r == 0) return '${_bn(h)} ঘণ্টা';
    return '${_bn(h)} ঘণ্টা ${_bn(r)} মিনিট';
  }

  /// "yyyyMMdd" থেকে "শনি ১০/১০"
  String _dayLabel(String k) {
    if (k.length != 8) return k;
    try {
      final y = int.parse(k.substring(0, 4));
      final mo = int.parse(k.substring(4, 6));
      final d = int.parse(k.substring(6, 8));
      const wd = ['সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি', 'রবি'];
      return '${wd[DateTime(y, mo, d).weekday - 1]} ${_bn(d)}/${_bn(mo)}';
    } catch (_) {
      return k;
    }
  }

  /// শেষ ৭ রাতের ঘুমের হিসাব (আন্দাজ)
  Widget _sleepBlock(ColorScheme cs) {
    final raw = (st['sleepList'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];
    final avg = _i('sleepAvg', 0);
    final small = TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant);
    if (raw.isEmpty) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          '🌙 এখনো কোনো রাতের হিসাব নেই। ফোন রাতে ২ ঘণ্টা বা তার বেশি টানা অন্ধকারে থাকলে সেটা ঘুম ধরে এখানে জমা হবে।',
          style: small,
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('🌙 ঘুমের হিসাব (আন্দাজ): গড় ${_dur(avg)}', style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        for (final e in raw)
          Builder(builder: (_) {
            final parts = e.split(':');
            final m = parts.length == 2 ? (int.tryParse(parts[1]) ?? 0) : 0;
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(children: [
                SizedBox(width: 78, child: Text(_dayLabel(parts[0]), style: const TextStyle(fontSize: 12.5))),
                Expanded(
                  child: LinearProgressIndicator(
                    value: (m / 600).clamp(0.0, 1.0).toDouble(),
                    minHeight: 8,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(width: 92, child: Text(_dur(m), style: const TextStyle(fontSize: 12.5))),
              ]),
            );
          }),
        const SizedBox(height: 4),
        Text(
          'এটা ঘুম মাপে না, শুধু ফোন কতক্ষণ অন্ধকারে ছিল তা ধরে। রাত ৬টা থেকে ভোর ৫টার মধ্যে শুরু হওয়া ২ ঘণ্টার বেশি অন্ধকার গোনা হয়। '
          'ফোন বালিশের নিচে বা ব্যাগে থাকলে ভুল আসতে পারে। ফোন ঘুমের সময় পাশে খোলা জায়গায় রাখলে ভালো মেলে।',
          style: small,
        ),
      ]),
    );
  }

  String _minLabel(int m) => m >= 60 && m % 60 == 0 ? '${m ~/ 60} ঘণ্টা' : '$m মিনিট';

  Widget _chips(List<int> opts, int cur, String key, String Function(int) label) {
    // বর্তমান মান তালিকায় না থাকলেও (আগে অন্য মান সেভ থাকলে) দেখানো
    final all = {...opts, cur}.toList()..sort();
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        for (final v in all)
          ChoiceChip(
            label: Text(label(v)),
            selected: v == cur,
            onSelected: (_) => _opt(key, v),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final lazy = _b('lazy');
    final beat = _b('beat');
    final pet = _b('pet');
    final sense = _b('sense');
    final lazyMin = _i('lazyMin', 45);
    final lazySteps = _i('lazySteps', 20);
    final used = _i('petUsedMb', 0);
    final allow = _i('petAllowMb', 0);
    final health = _i('petHealth', 50);
    final streak = _i('petStreak', 0);
    final next = _i('petNext', 7);
    final form = (st['petForm'] ?? 'ছানা').toString();
    final code = _b('petCode');

    return Scaffold(
      appBar: AppBar(title: const Text('নতুন সার্ভিস')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          const AppCard(
            child: Text(
              'চারটা আলাদা সার্ভিস, প্রতিটা নিজের সুইচে চালু-বন্ধ। সবগুলোই পোষা বা ভাসমান ভিউয়ের জন্য স্ক্রিনের ওপর আঁকে, তাই '
              '"অন্য অ্যাপের ওপর দেখানো" অনুমতি লাগে। চালু থাকলে প্রতিটার জন্য একটা ছোট নোটিফিকেশন স্থায়ীভাবে থাকবে (অ্যান্ড্রয়েডের নিয়ম)।',
              style: TextStyle(height: 1.5),
            ),
          ),
          const SizedBox(height: 12),
          if (!canDraw)
            AppCard(
              color: cs.errorContainer.withAlpha(120),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('অনুমতি দরকার', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('সুইচ চালু করতে "অন্য অ্যাপের ওপর দেখানো" অনুমতি দিতে হবে।'),
                const SizedBox(height: 10),
                FilledButton(onPressed: XChannel.buddyAskPerm, child: const Text('অনুমতি দিন')),
              ]),
            ),
          if (!canDraw) const SizedBox(height: 12),
          if (!hasUsage && (beat || pet))
            AppCard(
              color: cs.errorContainer.withAlpha(120),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Usage access দরকার', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('নেট-হার্টবিট আর ডেটা-পোষা ডেটার হিসাব পেতে "Usage access" অনুমতি ছাড়া ঠিকমতো চলবে না।'),
                const SizedBox(height: 10),
                FilledButton(onPressed: VpnChannel.openUsageAccess, child: const Text('অনুমতি দিন')),
              ]),
            ),
          if (!hasUsage && (beat || pet)) const SizedBox(height: 12),

          // ---------- সব একসাথে ----------
          AppCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('সব একসাথে চালু/বন্ধ', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${[lazy, beat, pet, sense].where((x) => x).length}/৪ চালু আছে'),
              value: lazy && beat && pet && sense,
              onChanged: _setAll,
            ),
          ),
          const SizedBox(height: 12),

          // ---------- আলসে-লক ----------
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('🚶 আলসে-লক', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(lazy && _b('lazyRun')
                    ? 'চলছে। এখন বসে আছো ${_i('sitMin', 0)} মিনিট, মোট পা ${_i('steps', 0)}'
                    : 'অনেকক্ষণ বসে থাকলে স্ক্রিন ঝাপসা হয়, পা হাঁটলে কাটে'),
                value: lazy,
                onChanged: (v) => _set('lazy', v),
              ),
              if (lazy) ...[
                const SizedBox(height: 8),
                const Text('কতক্ষণ বসে থাকলে সতর্ক করবে', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                _chips(_minOpts, lazyMin, 'lazyMin', _minLabel),
                const SizedBox(height: 12),
                const Text('কত পা হাঁটতে হবে', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                _chips(_stepOpts, lazySteps, 'lazySteps', (v) => '$v পা'),
                const SizedBox(height: 10),
                Text(
                  'সময় গোনা হয় শুধু স্ক্রিন জ্বলা অবস্থায়। জরুরি দরকারে লক স্ক্রিনের "ছুটি" বাটন চেপে ধরলে ১০ মিনিট লক আসে না।',
                  style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
                ),
              ],
            ]),
          ),
          const SizedBox(height: 12),

          // ---------- নেট-হার্টবিট ----------
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('💓 নেট-হার্টবিট', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(beat && _b('beatRun')
                    ? 'চলছে'
                    : 'ভাসমান হৃদস্পন্দনের রেখা। নেট ধীর হলে ধীরে চলে, চুপিচুপি ডেটা গেলে লাফায়'),
                value: beat,
                onChanged: (v) => _set('beat', v),
              ),
              if (beat)
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('সন্দেহজনক ডেটায় ফোন কাঁপুক'),
                  subtitle: const Text('একই অ্যাপের জন্য ২ মিনিটে একবার'),
                  value: _b('beatVib'),
                  onChanged: (v) => _opt('beatVib', v ? 1 : 0),
                ),
              if (beat)
                Text(
                  'রেখা টেনে যেখানে খুশি সরানো যায়। "সন্দেহজনক" মানে আন্দাজ: কোনো অ্যাপ সামনে না থেকেও নেট খাচ্ছে।',
                  style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
                ),
            ]),
          ),
          const SizedBox(height: 12),

          // ---------- ডেটা-পোষা ----------
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('🐾 ডেটা-পোষা', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(pet && _b('petRun')
                    ? 'আজ $used MB / $allow MB, স্বাস্থ্য $health/১০০'
                    : 'ডেটা বাঁচালে মোটা ও খুশি, বেশি পোড়ালে রোগা ও মনমরা'),
                value: pet,
                onChanged: (v) => _set('pet', v),
              ),
              if (pet)
                Text(
                  'আজকের ভাগ আসে ডেটা প্যাক বাজেট থেকে; না থাকলে ডেটা লিমিটের ৩০ ভাগের এক ভাগ; তাও না থাকলে দিনে ৩০০ MB ধরা হয়। '
                  'পোষাকে ট্যাপ করলে আজকের হিসাব দেখায়, টেনে সরানো যায়।',
                  style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
                ),
              const SizedBox(height: 10),
              Text(
                'স্ট্রিক ${_bn(streak)} দিন · রূপ: $form\nপরের নতুন সাজ ${_bn(next)} দিন পরে',
                style: const TextStyle(fontWeight: FontWeight.w600, height: 1.5),
              ),
              const SizedBox(height: 4),
              Text(
                'টানা যত দিন ডেটা নিজের ভাগের মধ্যে থাকবে, পোষা তত বড় হবে। প্রতি ৭ দিনে নতুন সাজ, প্রতি ৯০ দিনে নতুন রূপ ও রঙ। '
                'প্রায় ৫ বছর ধরে আকার বাড়ে, তারপরও সাজ আর রঙ ঘুরে ঘুরে বদলায়। ভাগ পেরোলে স্ট্রিক শূন্য থেকে শুরু।',
                style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
              ),
              const SizedBox(height: 12),
              if (code)
                Row(children: [
                  const Icon(Icons.lock_open, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'রেফার কোড চালু: স্ট্রিক কখনো ভাঙবে না, স্বাস্থ্য কমবে না, বাড়ার কোনো সীমা নেই',
                      style: TextStyle(fontSize: 12.5, height: 1.4, color: cs.primary),
                    ),
                  ),
                ])
              else
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _codeCtl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'রেফার কোড',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                      onSubmitted: (_) => _applyCode(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.tonal(onPressed: _applyCode, child: const Text('দিন')),
                ]),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _pinWidget,
                icon: const Icon(Icons.widgets_outlined),
                label: const Text('হোম স্ক্রিনে উইজেট যোগ করুন'),
              ),
              const SizedBox(height: 4),
              Text(
                'উইজেটে পোষা আর হার্টবিট দুটোই দেখা যায়। পোষা সুইচ বন্ধ থাকলেও উইজেট চালু থাকলে স্ট্রিক এগোয়।',
                style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
              ),
            ]),
          ),
          const SizedBox(height: 12),

          // ---------- সেন্সর-পোষা ----------
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('📱 সেন্সর-পোষা', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(sense && _b('senseRun')
                    ? 'চলছে'
                    : 'ফোনের সেন্সর শুনে পোষাকে নাড়ায়: উল্টো রাখলে ফোকাস, ঝাঁকালে লাফ, অন্ধকারে ঘুম'),
                value: sense,
                onChanged: (v) => _set('sense', v),
              ),
              if (sense) ...[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('উল্টো রাখলে ফোকাস'),
                  subtitle: const Text('ফোন স্ক্রিন নিচে করে টেবিলে রাখলে ফোকাস চালু, তুললে বন্ধ'),
                  value: _b('senseFlip'),
                  onChanged: (v) => _opt('senseFlip', v ? 1 : 0),
                ),
                if (_b('senseFlip')) ...[
                  const Text('কত মিনিটের ফোকাস', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  _chips(_flipOpts, _i('senseFlipMin', 25), 'senseFlipMin', _minLabel),
                  const SizedBox(height: 6),
                  Text(
                    'ফোন ২-৩ সেকেন্ড উল্টো থাকলে চালু হয়। আগে থেকে ফোকাস চললে কিছু বদলায় না। '
                    'তুললে শুধু এভাবে চালানো ফোকাসটাই বন্ধ হয়, এর জন্য পিন লাগে না।',
                    style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.onSurfaceVariant),
                  ),
                  const SizedBox(height: 6),
                ],
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ঝাঁকালে পোষা লাফায়'),
                  subtitle: const Text('জোরে ঝাঁকালে ৩ সেকেন্ড খুশিতে নাচে'),
                  value: _b('senseShake'),
                  onChanged: (v) => _opt('senseShake', v ? 1 : 0),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('অন্ধকারে পোষা ঘুমায়'),
                  subtitle: const Text('কিছুক্ষণ অন্ধকার থাকলে চোখ বন্ধ, আলো এলে জাগে। রাতের লম্বা অন্ধকারকে ঘুম ধরে হিসাবও রাখে'),
                  value: _b('senseDark'),
                  onChanged: (v) => _opt('senseDark', v ? 1 : 0),
                ),
                if (_b('senseDark')) _sleepBlock(cs),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('তুললে ডেটা সারাংশ'),
                  subtitle: const Text(
                      'ফোন ৫ মিনিটের বেশি উল্টো থাকলে বা ঘুম শেষ হলে, ওই সময়ে কত মোবাইল ডেটা গেল আর কোন অ্যাপ বেশি খেল তা দেখায়'),
                  value: _b('senseSummary'),
                  onChanged: (v) => _opt('senseSummary', v ? 1 : 0),
                ),
                if (_b('senseSummary') && !hasUsage)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(children: [
                      Expanded(
                        child: Text('ডেটার হিসাব দেখাতে \"Usage access\" অনুমতি লাগে',
                            style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.error)),
                      ),
                      TextButton(onPressed: VpnChannel.openUsageAccess, child: const Text('অনুমতি দিন')),
                    ]),
                  ),
                if (!pet)
                  Text(
                    'পোষা প্রাণীকে নড়তে দেখতে ওপরের "ডেটা-পোষা" সুইচটাও চালু করুন। উল্টো রাখলে ফোকাস পোষা ছাড়াও চলে।',
                    style: TextStyle(fontSize: 12.5, height: 1.5, color: cs.error),
                  ),
              ],
            ]),
          ),
        ]),
      ),
    );
  }
}
