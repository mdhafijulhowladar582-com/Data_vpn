import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';

/// রাতের ডেটা চোর: রাতে (২১:০০–০৫:৫৯) স্ক্রিন বন্ধ থাকা সময়ে কোন অ্যাপ কত ডেটা খেল তা জমে।
/// সকালে প্রথমবার স্ক্রিন চালু হলে নোটিফিকেশনে ছোট রিপোর্ট আসে, সেখান থেকে বা এই পেজ থেকে ব্লক করা যায়।
class NightPage extends StatefulWidget {
  const NightPage({super.key});

  @override
  State<NightPage> createState() => _NightPageState();
}

class _NightPageState extends State<NightPage> {
  Map<String, dynamic> st = {};
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final s = await XChannel.nightInfo();
    if (mounted && s.isNotEmpty) setState(() => st = s);
  }

  List<Map<String, dynamic>> _items(dynamic v) =>
      ((v as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  String _fmt(num b) {
    if (b < 1024 * 1024) return '${(b / 1024).round()} KB';
    if (b < 1024 * 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
    return '${(b / 1073741824).toStringAsFixed(2)} GB';
  }

  Future<void> _cfg({bool? on, int? mb}) async {
    final cur = Map<String, dynamic>.from(await XChannel.ctlGet('night') as Map);
    if (on != null) cur['on'] = on;
    if (mb != null) cur['minMb'] = mb;
    await XChannel.ctlSet('night', cur);
    await _load();
  }

  Future<void> _block(Map<String, dynamic> a) async {
    await XChannel.nightBlock(a['pkg'] as String);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('${a['name']} ব্লক হলো (ফায়ারওয়াল চালু থাকলে)')));
  }

  Widget _row(Map<String, dynamic> a) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: AppIcon(a['pkg'] as String, size: 36),
        title: Text('${a['name']}'),
        subtitle: Text(_fmt((a['bytes'] as num?) ?? 0)),
        trailing: TextButton(onPressed: () => _block(a), child: const Text('ব্লক')),
      );

  @override
  Widget build(BuildContext context) {
    final on = st['on'] != false;
    final minMb = (st['minMb'] as num?)?.toInt() ?? 5;
    final acc = _items(st['acc']);
    final last = st['last'] == null ? null : Map<String, dynamic>.from(st['last'] as Map);
    return Scaffold(
      appBar: AppBar(title: const Text('রাতের ডেটা চোর')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('রাতের নজরদারি', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'রাতে স্ক্রিন বন্ধ থাকলে কোন অ্যাপ ডেটা খায় তা জমায়, সকালে রিপোর্ট দেয়।'),
              value: on,
              onChanged: (v) => _cfg(on: v),
            ),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('এর বেশি ডেটা গেলে তবেই রিপোর্ট',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final m in const [2, 5, 10, 20, 50])
                  ChoiceChip(
                      label: Text('$m MB'), selected: minMb == m, onSelected: (_) => _cfg(mb: m)),
              ]),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('এই রাতের হিসাব (এখন পর্যন্ত)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              if (acc.isEmpty)
                const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('এখনো কিছু জমেনি। রাতে ফোন রেখে ঘুমালে সকালে এখানে দেখা যাবে।')),
              for (final a in acc) _row(a),
            ]),
          ),
          if (last != null) ...[
            const SizedBox(height: 12),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('শেষ রিপোর্ট: মোট ${_fmt((last['total'] as num?) ?? 0)}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                for (final a in _items(last['items'])) _row(a),
              ]),
            ),
          ],
          const SizedBox(height: 12),
          AppCard(
            color: Colors.orange.withAlpha(40),
            child: Text(
              '⚠️ জানা দরকার\n'
              '• ফায়ারওয়াল চালু থাকলেই স্ক্রিন বন্ধের হিসাব জমে${st['fwRunning'] == false ? ' (এখন বন্ধ আছে!)' : ''}।\n'
              '• হিসাব নিতে ইউসেজ অ্যাক্সেস দেওয়া থাকতে হবে।\n'
              '• সংখ্যা আনুমানিক (অ্যান্ড্রয়েড ঘণ্টা ধরে ডেটা গোনে)।\n'
              '• মেসেজ, ব্যাকআপ বা আপডেটও রাতে ডেটা খেতে পারে, সবই চুরি নয়। অচেনা বা অকারণে বেশি হলে তবেই ব্লক করুন।\n'
              '• ব্লক করা অ্যাপের নেট বন্ধ থাকবে, ফিরাতে ফায়ারওয়ালের অ্যাপ তালিকায় চালু করতে হবে।',
              style: const TextStyle(height: 1.55),
            ),
          ),
        ]),
      ),
    );
  }
}
