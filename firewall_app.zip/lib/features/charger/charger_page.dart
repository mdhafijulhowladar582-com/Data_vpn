import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../widgets/common.dart';

/// চার্জার লিডারবোর্ড: কোন চার্জার সবচেয়ে দ্রুত চার্জ দেয়। চার্জারের নাম দিয়ে "এখন লাগানো" বেছে ফোন চার্জে রাখুন।
/// স্ক্রিন বন্ধ আর ব্যাটারি ৮০%-এর নিচে থাকলে প্রতি ৩০ সেকেন্ডে কারেন্ট (mA) মেপে গড় জমে, যাতে তুলনা ন্যায্য হয়।
/// ফায়ারওয়াল (VPN) চালু থাকতে হবে, নইলে মাপা হয় না।
class ChargerPage extends StatefulWidget {
  const ChargerPage({super.key});

  @override
  State<ChargerPage> createState() => _ChargerPageState();
}

class _ChargerPageState extends State<ChargerPage> {
  Map<String, dynamic> st = {};
  final name = TextEditingController();
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 3), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final s = await XChannel.chargerState();
    if (mounted) setState(() => st = s);
  }

  List<Map<String, dynamic>> get list =>
      ((st['chargers'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  String get active => (st['active'] as String?) ?? '';
  Map<String, dynamic> get live => Map<String, dynamic>.from((st['live'] as Map?) ?? const {});

  Future<void> _use(String n) async {
    await XChannel.chargerActive(n);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final l = list;
    final best = l.isEmpty ? 1 : l.map((e) => (e['avg'] as num).toInt()).fold<int>(1, (a, b) => b > a ? b : a);
    final charging = live['charging'] == true;
    final ma = (live['ma'] as num?)?.toInt() ?? 0;
    return Scaffold(
      appBar: AppBar(title: const Text('চার্জার লিডারবোর্ড')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('এখন', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
              const SizedBox(height: 4),
              Text(charging ? (ma > 0 ? '$ma mA' : 'কারেন্ট পড়া যাচ্ছে না') : 'চার্জে নেই',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(
                'ব্যাটারি ${live['level']}%' +
                    (live['screenOn'] == true ? ' · স্ক্রিন চালু, তাই মাপা জমছে না' : ''),
                style: TextStyle(fontSize: 12.5, color: cs.outline),
              ),
              if (active.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('মাপা হচ্ছে: $active', style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('নতুন চার্জার', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: TextField(controller: name, decoration: const InputDecoration(hintText: 'যেমন: সাদা ২০W'))),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () async {
                    final n = name.text.trim();
                    if (n.isEmpty) return;
                    name.clear();
                    await _use(n);
                  },
                  child: const Text('লাগালাম'),
                ),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          const Text('লিডারবোর্ড', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (l.isEmpty)
            Text('কোনো চার্জার নেই। নাম দিয়ে "লাগালাম" চাপুন, তারপর স্ক্রিন বন্ধ করে চার্জে রাখুন।',
                style: TextStyle(color: cs.onSurfaceVariant, height: 1.45))
          else
            for (var i = 0; i < l.length; i++) _row(i, l[i], best, cs),
          const SizedBox(height: 12),
          Text(
            'সীমা: কারেন্ট পড়া ফোনের ওপর নির্ভর করে, কিছু ফোনে ভুল বা শূন্য আসে। একই ফোন আর একই ক্যাবলে তুলনা করুন, নইলে ক্যাবলের দোষ চার্জারের ঘাড়ে পড়বে। '
            'চার্জিং স্পিড তাপ আর ব্যাটারির স্তরে বদলায়, তাই কমপক্ষে ২০-৩০টা মাপ (১৫ মিনিট) জমলে গড়ে ভরসা করুন।',
            style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
          ),
        ]),
      ),
    );
  }

  Widget _row(int i, Map<String, dynamic> e, int best, ColorScheme cs) {
    final n = e['name'] as String;
    final avg = (e['avg'] as num).toInt();
    final cnt = (e['n'] as num).toInt();
    final isActive = n == active;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(i == 0 && cnt > 0 ? '🥇 ' : '${i + 1}. ', style: const TextStyle(fontSize: 16)),
            Expanded(child: Text(n, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
            Text(cnt == 0 ? '—' : '$avg mA', style: const TextStyle(fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: cnt == 0 ? 0 : avg / best, minHeight: 8, borderRadius: BorderRadius.circular(4)),
          const SizedBox(height: 6),
          Text('সর্বোচ্চ ${e['max']} mA · $cnt মাপ', style: TextStyle(fontSize: 12, color: cs.outline)),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            TextButton(onPressed: () => XChannel.chargerReset(n).then((_) => _load()), child: const Text('মাপ মুছুন')),
            TextButton(onPressed: () => XChannel.chargerDelete(n).then((_) => _load()), child: const Text('বাদ দিন')),
            isActive
                ? TextButton(onPressed: () => _use(''), child: const Text('মাপা থামান'))
                : FilledButton.tonal(onPressed: () => _use(n), child: const Text('এখন লাগানো')),
          ]),
        ]),
      ),
    );
  }
}
