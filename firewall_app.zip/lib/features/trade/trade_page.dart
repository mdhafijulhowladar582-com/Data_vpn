import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../services/lock_service.dart';
import '../../widgets/app_picker.dart';
import '../../widgets/common.dart';
import '../control_common.dart';

/// ট্রেড ব্লকার: ট্রেডিং অ্যাপে দিনের সীমা ছুঁলে অ্যাপটা ২৪ ঘণ্টা (বদলানো যায়) খুলতে দেয় না।
/// স্ক্রিন পড়ে ট্রেড গোনা হয় না (ভুল ধরত, আর সার্ভিসের ক্ষমতা বাড়াতে হতো)। তাই:
///  - "খোলা": অ্যাপ সামনে আসার সংখ্যা, নিজে গোনা হয়।
///  - "ট্রেড" ও "লস": এই পেজের বোতাম টিপে নিজে লেখেন। সৎভাবে টিপলেই সুরক্ষা কাজ করে।
/// লক চলাকালে সেটিং বদলানো বা বন্ধ করা যায় না। ব্রোকারের সার্ভারের খোলা ট্রেড এটা বন্ধ করে না।
class TradePage extends StatefulWidget {
  const TradePage({super.key});

  @override
  State<TradePage> createState() => _TradePageState();
}

class _TradePageState extends State<TradePage> {
  Map<String, dynamic> t = {};
  Map<String, dynamic> info = {};
  Map<String, String> names = {};
  bool loading = true;
  Timer? _tm;

  @override
  void initState() {
    super.initState();
    _load();
    _tm = Timer.periodic(const Duration(seconds: 20), (_) => _refreshInfo());
  }

  @override
  void dispose() {
    _tm?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final r = await XChannel.ctlGet('trade');
    final i = await XChannel.tradeInfo();
    final n = await appNames();
    if (!mounted) return;
    setState(() {
      t = Map<String, dynamic>.from(r as Map);
      info = i;
      names = n;
      loading = false;
    });
  }

  Future<void> _refreshInfo() async {
    final i = await XChannel.tradeInfo();
    if (mounted) setState(() => info = i);
  }

  List<String> get apps => ((t['apps'] as List?) ?? const []).cast<String>();
  bool get on => t['on'] == true;
  int _n(String k) => (t[k] as num?)?.toInt() ?? 0;
  int _i(String k) => (info[k] as num?)?.toInt() ?? 0;
  int get lockLeft => (info['lockLeftMs'] as num?)?.toInt() ?? 0;
  bool get locked => lockLeft > 0;

  Map<String, dynamic> _copy() => Map<String, dynamic>.from(t);

  Future<void> _save(Map<String, dynamic> next) async {
    if (locked) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('লক চলছে, এখন সেটিং বদলানো যাবে না')));
      return;
    }
    // শুধু সীমা আলগা বা বন্ধ করার সময় পিন (পিন সেট থাকলে)। কড়া করাতে লাগে না।
    final loosening = (on && next['on'] != true) ||
        _looser('maxTrades', next) ||
        _looser('maxLosses', next) ||
        _looser('maxOpens', next) ||
        ((next['lockHours'] as num?)?.toInt() ?? 24) < (_n('lockHours') == 0 ? 24 : _n('lockHours')) ||
        (apps.any((a) => !((next['apps'] as List?) ?? const []).contains(a)));
    if (loosening && Lock.hasPin) {
      final ok = await Lock.ask(context, reason: 'ট্রেড ব্লকারের সীমা আলগা করতে পিন দিন', force: true);
      if (!ok || !mounted) return;
    }
    final saved = await XChannel.ctlSet('trade', next);
    if (!saved && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়নি')));
    }
    await _load();
  }

  bool _looser(String k, Map<String, dynamic> next) {
    final old = _n(k);
    final nw = (next[k] as num?)?.toInt() ?? 0;
    if (old == 0) return false; // আগে সীমা ছিল না, নতুন সীমা বসানো কড়া করা
    return nw == 0 || nw > old;
  }

  Future<void> _add(String kind) async {
    if (!on || apps.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('আগে ট্রেড ব্লকার চালু করে অ্যাপ বাছুন')));
      return;
    }
    final i = await XChannel.tradeAdd(kind);
    if (mounted) setState(() => info = i);
  }

  String _left() {
    final h = lockLeft ~/ 3600000;
    final m = (lockLeft % 3600000) ~/ 60000;
    return '$h ঘণ্টা $m মিনিট';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    String lim(String k) => _n(k) > 0 ? '${_n(k)}' : 'নেই';
    return Scaffold(
      appBar: AppBar(title: const Text('ট্রেড ব্লকার')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
                if (locked)
                  AppCard(
                    color: cs.errorContainer.withAlpha(140),
                    child: Row(children: [
                      const Icon(Icons.lock_clock),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text('ট্রেডিং অ্যাপ লক। আর ${_left()} পর খুলবে।',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                    ]),
                  ),
                if (locked) const SizedBox(height: 12),
                AppCard(
                  child: SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('ট্রেড ব্লকার', style: TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: const Text('বন্ধ করতে বা সীমা আলগা করতে পিন লাগবে'),
                    value: on,
                    onChanged: (v) => _save(_copy()..['on'] = v),
                  ),
                ),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Expanded(child: Text('ট্রেডিং অ্যাপ', style: TextStyle(fontWeight: FontWeight.w700))),
                      TextButton(
                        onPressed: () async {
                          final r = await pickApps(context, title: 'ট্রেডিং অ্যাপ বাছুন', selected: apps.toSet());
                          if (r != null) _save(_copy()..['apps'] = r);
                        },
                        child: const Text('বাছুন'),
                      ),
                    ]),
                    if (apps.isEmpty)
                      Text('কোনো অ্যাপ বাছা হয়নি', style: TextStyle(color: cs.onSurfaceVariant))
                    else
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        for (final a in apps) Chip(label: Text(names[a] ?? a)),
                      ]),
                    const SizedBox(height: 4),
                    Text('ব্রাউজারে ওয়েব ট্রেডিং করলে ব্রাউজারও বাছা যায়, তবে তখন পুরো ব্রাউজার লক হবে।',
                        style: TextStyle(fontSize: 12, color: cs.outline)),
                  ]),
                ),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(children: [
                    _limitTile('আজ সর্বোচ্চ ট্রেড', 'maxTrades', lim('maxTrades')),
                    _limitTile('আজ সর্বোচ্চ লস', 'maxLosses', lim('maxLosses')),
                    _limitTile('আজ সর্বোচ্চ অ্যাপ খোলা', 'maxOpens', lim('maxOpens')),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('লক কতক্ষণ'),
                      trailing: Text('${_n('lockHours') == 0 ? 24 : _n('lockHours')} ঘণ্টা',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      onTap: () async {
                        final v = await askNumber(context, 'লক কত ঘণ্টা? (১-৭২)', _n('lockHours') == 0 ? 24 : _n('lockHours'),
                            hint: '২৪');
                        if (v == null || v < 1) return;
                        _save(_copy()..['lockHours'] = v.clamp(1, 72));
                      },
                    ),
                  ]),
                ),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('আজকের হিসাব', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Row(children: [
                      _stat('ট্রেড', _i('trades')),
                      _stat('লস', _i('losses')),
                      _stat('খোলা', _i('opens')),
                    ]),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(
                          child: FilledButton.tonal(onPressed: () => _add('trade'), child: const Text('+ ট্রেড নিলাম'))),
                      const SizedBox(width: 8),
                      Expanded(child: FilledButton.tonal(onPressed: () => _add('loss'), child: const Text('+ লস হলো'))),
                    ]),
                    const SizedBox(height: 6),
                    Text('ট্রেড নিলে "ট্রেড", হারলে "লস" টিপুন। লসও ট্রেড হিসেবে গোনা হয়, আলাদা করে ট্রেড টিপতে হবে না।',
                        style: TextStyle(fontSize: 12, color: cs.outline, height: 1.4)),
                  ]),
                ),
                const SizedBox(height: 12),
                Text(
                  'সীমা: এটা শুধু এই ফোনে অ্যাপটা আটকায়। ব্রোকারে খোলা ট্রেড বন্ধ হয় না, আর অন্য ফোন বা কম্পিউটার থেকে ট্রেড আটকায় না। '
                  'অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি) বন্ধ করলে লক কাজ করে না, তাই ওটা চালু রাখুন। দিন বদলালে গোনা শূন্য হয়, কিন্তু লকের সময় চলতেই থাকে।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
    );
  }

  Widget _limitTile(String title, String key, String value) => ListTile(
        contentPadding: EdgeInsets.zero,
        title: Text(title),
        trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        onTap: () async {
          final v = await askNumber(context, title, _n(key));
          if (v == null) return;
          _save(_copy()..[key] = v);
        },
      );

  Widget _stat(String label, int v) => Expanded(
        child: Column(children: [
          Text('$v', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          Text(label, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
      );
}
