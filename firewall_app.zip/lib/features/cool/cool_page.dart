import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../widgets/app_picker.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../control_common.dart';

/// ঠান্ডা মোড: ফোন গরম হলে বা ব্যাটারি কমে গেলে, সামনে নেই এমন (ইনস্টল করা) অ্যাপের নেট নিজে বন্ধ।
/// সামনের অ্যাপ, জরুরি অ্যাপ আর ছাড়ের তালিকার অ্যাপ বন্ধ হয় না। ঠিক হলে নিজে ফিরে আসে।
class CoolPage extends StatefulWidget {
  const CoolPage({super.key});

  @override
  State<CoolPage> createState() => _CoolPageState();
}

class _CoolPageState extends State<CoolPage> {
  Map<String, dynamic> cfg = {};
  Map<String, dynamic> info = {};
  Map<String, String> names = {};
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load();
    appNames().then((n) {
      if (mounted) setState(() => names = n);
    });
    _t = Timer.periodic(const Duration(seconds: 3), (_) => _live());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final c = await XChannel.ctlGet('cool');
    if (mounted) setState(() => cfg = Map<String, dynamic>.from(c as Map));
    await _live();
  }

  Future<void> _live() async {
    final i = await XChannel.coolInfo();
    if (mounted && i.isNotEmpty) setState(() => info = i);
  }

  bool get on => cfg['on'] == true;
  int get tempC => (cfg['tempC'] as num?)?.toInt() ?? 40;
  int get lowPct => (cfg['lowPct'] as num?)?.toInt() ?? 15;
  bool get onHot => cfg['onHot'] != false;
  bool get onLow => cfg['onLow'] != false;
  List<String> get exempt => ((cfg['exempt'] as List?) ?? const []).map((e) => '$e').toList();

  Future<void> _set(Map<String, dynamic> patch) async {
    final c = {...cfg, ...patch};
    setState(() => cfg = c);
    await XChannel.ctlSet('cool', c);
    await _live();
  }

  Future<void> _pickExempt() async {
    final r = await pickApps(context, title: 'ঠান্ডা মোডেও নেট পাবে যারা', selected: exempt.toSet());
    if (r != null) await _set({'exempt': r});
  }

  @override
  Widget build(BuildContext context) {
    final active = info['active'] == true;
    final temp = (info['temp'] as num?)?.toInt() ?? -1;
    final batt = (info['batt'] as num?)?.toInt() ?? -1;
    final guard = info['guard'] == true;
    final fw = info['fwRunning'] == true;
    return Scaffold(
      appBar: AppBar(title: const Text('ঠান্ডা মোড')),
      body: Centered(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ঠান্ডা মোড চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(active
                    ? 'এখন চলছে (${info['reason'] ?? ''}), ব্যাকগ্রাউন্ড অ্যাপের নেট বন্ধ'
                    : 'এখন চলছে না'),
                value: on,
                onChanged: (v) => _set({'on': v}),
              ),
              if (temp >= 0 || batt >= 0)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                      'এখন: ব্যাটারি তাপ ${(temp / 10).toStringAsFixed(1)}°C, চার্জ $batt%${info['charging'] == true ? ' (চার্জে)' : ''}'),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('গরম হলে'),
                value: onHot,
                onChanged: (v) => _set({'onHot': v}),
              ),
              if (onHot) ...[
                Text('ব্যাটারির তাপ $tempC°C ছুঁলে চালু'),
                Slider(
                  min: 36,
                  max: 48,
                  divisions: 12,
                  label: '$tempC°C',
                  value: tempC.clamp(36, 48).toDouble(),
                  onChanged: (v) => setState(() => cfg = {...cfg, 'tempC': v.round()}),
                  onChangeEnd: (v) => _set({'tempC': v.round()}),
                ),
              ],
              const Divider(),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ব্যাটারি কমলে'),
                value: onLow,
                onChanged: (v) => _set({'onLow': v}),
              ),
              if (onLow) ...[
                Text('চার্জে না থাকলে আর ব্যাটারি $lowPct% বা কমে গেলে চালু'),
                Slider(
                  min: 5,
                  max: 40,
                  divisions: 7,
                  label: '$lowPct%',
                  value: lowPct.clamp(5, 40).toDouble(),
                  onChanged: (v) => setState(() => cfg = {...cfg, 'lowPct': v.round()}),
                  onChangeEnd: (v) => _set({'lowPct': v.round()}),
                ),
              ],
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Expanded(
                    child: Text('ছাড়ের অ্যাপ (সবসময় নেট পাবে)',
                        style: TextStyle(fontWeight: FontWeight.w700))),
                FilledButton.tonal(onPressed: _pickExempt, child: const Text('বাছুন')),
              ]),
              const Text('যেমন ট্রেডিং, ব্যাংক, মেসেজ অ্যাপ। জরুরি তালিকার অ্যাপও বন্ধ হয় না।'),
              for (final p in exempt)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: AppIcon(p, size: 32),
                  title: Text(names[p] ?? p),
                  trailing: IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => _set({'exempt': exempt.where((e) => e != p).toList()})),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            color: Colors.orange.withAlpha(40),
            child: Text(
              '⚠️ সতর্কতা\n'
              '${on && !fw ? '• ফায়ারওয়াল এখন বন্ধ, তাই কিছুই বন্ধ হবে না। আগে চালু করুন।\n' : ''}'
              '${on && !guard ? '• অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি) বন্ধ, সামনের অ্যাপ চেনা যায় না, তাই এই মোড কিছু করবে না। চালু করুন।\n' : ''}'
              '• চালু থাকা সময়ে ব্যাকগ্রাউন্ড অ্যাপের মেসেজ ও নোটিফিকেশন দেরিতে আসবে। দরকারি অ্যাপ ছাড়ে রাখুন।\n'
              '• শুধু আপনার ইনস্টল করা অ্যাপ বন্ধ হয়, সিস্টেম অ্যাপ ও ফোন/মেসেজ ঠিক থাকে।\n'
              '• চালু বা বন্ধ হওয়ার সময় ফায়ারওয়াল নিয়ম নতুন করে বসে, নেট এক মুহূর্ত ঝিমিয়ে যেতে পারে।\n'
              '• ফোন গরম হওয়ার আসল কারণ (রোদ, চার্জিং, ভারী গেম) এটা ঠিক করে না। এটা শুধু নেটের কাজ কমায়।',
              style: const TextStyle(height: 1.55),
            ),
          ),
        ]),
      ),
    );
  }
}
