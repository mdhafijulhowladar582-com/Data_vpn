import 'package:flutter/material.dart';
import '../../menu/badge_center.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../widgets/common.dart';

/// পাবলিক Wi-Fi সতর্কতা: অচেনা (বিশ্বস্ত তালিকায় নেই) Wi-Fi-তে যুক্ত হলে সতর্ক করে। কড়া মোড চালু থাকলে অচেনা
/// Wi-Fi-তে "Wi-Fi-তে সব খোলা" সেটিং বন্ধ থাকে। নেটের নাম পড়তে লোকেশন অনুমতি লাগে, আর অনেক ফোনে অ্যাপ
/// ব্যাকগ্রাউন্ডে থাকলে নাম পড়া যায় না, তখন সতর্কতা না এলে সেটা ত্রুটি নয়।
class WifiPage extends StatefulWidget {
  const WifiPage({super.key});

  @override
  State<WifiPage> createState() => _WifiPageState();
}

class _WifiPageState extends State<WifiPage> with WidgetsBindingObserver {
  Map<String, dynamic> st = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load(markSeen: true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // অনুমতি/লোকেশন সেটিংস থেকে ফিরলে আবার পড়ি
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load({bool markSeen = false}) async {
    final s = await XChannel.wifiState();
    if (markSeen) {
      await XChannel.wifiSeen();
      BadgeCenter.instance.clear('wifi_safety');
    }
    if (!mounted) return;
    setState(() {
      st = s;
      loading = false;
    });
  }

  Future<void> _toggle(bool v) async {
    store.cfg.wifiGuard = v;
    await store.save();
    // চালু করার সময় এখনকার Wi-Fi চেনা থাকলে সেটাকেই বিশ্বস্ত ধরি (নইলে বাড়ির নেটেই সতর্কতা আসত)
    final ssid = st['ssid'] as String?;
    if (v && ssid != null && st['trusted'] != true) await XChannel.wifiTrust(ssid, true);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final perm = st['perm'] == true;
    final onWifi = st['onWifi'] == true;
    final ssid = st['ssid'] as String?;
    final trusted = st['trusted'] == true;
    final list = ((st['list'] as List?) ?? const []).cast<String>();

    return Scaffold(
      appBar: AppBar(title: const Text('পাবলিক Wi-Fi')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('অচেনা Wi-Fi-তে সতর্কতা', style: TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('বিশ্বস্ত তালিকার বাইরের Wi-Fi-তে যুক্ত হলে নোটিফিকেশন'),
                      value: c.wifiGuard,
                      onChanged: _toggle,
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('কড়া মোড'),
                      subtitle: const Text('অচেনা Wi-Fi-তে "Wi-Fi-তে সব খোলা" সেটিং বন্ধ থাকে, অ্যাপের নিয়ম আগের মতোই চলে'),
                      value: c.wifiStrict,
                      onChanged: c.wifiGuard
                          ? (v) async {
                              c.wifiStrict = v;
                              await store.save();
                              if (mounted) setState(() {});
                            }
                          : null,
                    ),
                  ]),
                ),
                const SizedBox(height: 12),
                if (c.wifiGuard && !perm)
                  AppCard(
                    color: cs.errorContainer.withAlpha(120),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('লোকেশন অনুমতি লাগবে', style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      const Text('Android Wi-Fi-র নাম দেয় শুধু লোকেশন অনুমতি থাকলে। লোকেশন কখনো সংরক্ষণ বা পাঠানো হয় না, শুধু নামটা পড়া হয়।'),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, children: [
                        FilledButton(
                          onPressed: () async {
                            await XChannel.wifiAskPerm();
                          },
                          child: const Text('অনুমতি দিন'),
                        ),
                        OutlinedButton(onPressed: XChannel.openLocationSettings, child: const Text('লোকেশন সেটিংস')),
                      ]),
                    ]),
                  )
                else ...[
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('এখনকার নেটওয়ার্ক', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                      const SizedBox(height: 4),
                      if (!onWifi)
                        const Text('Wi-Fi-তে যুক্ত নেই', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))
                      else if (ssid == null)
                        const Text('Wi-Fi-র নাম পড়া যাচ্ছে না', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))
                      else ...[
                        Text(ssid, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 2),
                        Text(trusted ? 'বিশ্বস্ত' : 'অচেনা',
                            style: TextStyle(fontWeight: FontWeight.w700, color: trusted ? Colors.green : Colors.orange)),
                        const SizedBox(height: 8),
                        trusted
                            ? OutlinedButton(onPressed: () => _trust(ssid, false), child: const Text('বিশ্বস্ত তালিকা থেকে সরান'))
                            : FilledButton(onPressed: () => _trust(ssid, true), child: const Text('বিশ্বস্ত করুন (বাড়ি/অফিস)')),
                      ],
                      if (onWifi && ssid == null) ...[
                        const SizedBox(height: 4),
                        Text('লোকেশন সেবা (GPS) বন্ধ থাকলে বা ফোন নাম লুকালে এমন হয়।', style: TextStyle(fontSize: 12.5, color: cs.outline)),
                        TextButton(onPressed: XChannel.openLocationSettings, child: const Text('লোকেশন সেটিংস')),
                      ],
                    ]),
                  ),
                ],
                const SizedBox(height: 16),
                Text('বিশ্বস্ত Wi-Fi (${list.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                if (list.isEmpty)
                  Text('এখনো কিছু নেই। বাড়ি বা অফিসের Wi-Fi-তে থেকে "বিশ্বস্ত করুন" চাপুন।', style: TextStyle(color: cs.onSurfaceVariant))
                else
                  for (final s in list)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: AppCard(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: Row(children: [
                          const Icon(Icons.wifi, size: 20),
                          const SizedBox(width: 10),
                          Expanded(child: Text(s)),
                          IconButton(icon: const Icon(Icons.close), tooltip: 'সরান', onPressed: () => _trust(s, false)),
                        ]),
                      ),
                    ),
                const SizedBox(height: 12),
                Text(
                  'সীমা: অ্যাপ ব্যাকগ্রাউন্ডে থাকলে অনেক ফোনে Wi-Fi-র নাম পড়া যায় না, তাই সতর্কতা দেরিতে (অ্যাপ খুললে) আসতে পারে। '
                  'ফায়ারওয়াল চালু না থাকলে কড়া মোড কাজ করে না।',
                  style: TextStyle(fontSize: 12, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
    );
  }

  Future<void> _trust(String ssid, bool on) async {
    await XChannel.wifiTrust(ssid, on);
    await _load();
  }
}
