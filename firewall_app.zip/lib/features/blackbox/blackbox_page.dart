import 'dart:async';
import 'package:flutter/material.dart';
import '../../menu/badge_center.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../services/vpn_channel.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

/// ব্ল্যাক বক্স: ফোনের ব্যাটারি, তাপ, RAM, ডেটার ছবি ২৪ ঘণ্টা ধরে জমে। ব্যাটারি দ্রুত কমা, অতিরিক্ত গরম,
/// কম মেমরি বা স্ক্রিন বন্ধ অবস্থায় ডেটা-ঢেউ ধরা পড়লে বাংলায় সম্ভাব্য কারণসহ ইনসিডেন্ট জমা হয়।
/// ফায়ারওয়াল (VPN) বন্ধ থাকলে ১৫ মিনিট পরপর মোটা স্যাম্পল আসে, মিহি নয়।
class BlackBoxPage extends StatefulWidget {
  const BlackBoxPage({super.key});

  @override
  State<BlackBoxPage> createState() => _BlackBoxPageState();
}

class _BlackBoxPageState extends State<BlackBoxPage> {
  int hours = 3;
  bool loading = true;
  bool fwRunning = true;
  bool asking = false;
  String why = '';
  List<Map<String, dynamic>> pts = []; // পুরনো আগে
  List<Map<String, dynamic>> incidents = [];
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load(markSeen: true);
    _t = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load({bool markSeen = false}) async {
    final since = DateTime.now().subtract(Duration(hours: hours)).millisecondsSinceEpoch;
    final s = await XChannel.bbSamples(since);
    final inc = await XChannel.bbIncidents();
    bool run = true;
    try {
      run = await VpnChannel.isRunning();
    } catch (_) {}
    if (markSeen) {
      await XChannel.bbSeen();
      BadgeCenter.instance.clear('blackbox');
    }
    if (!mounted) return;
    setState(() {
      pts = s;
      incidents = inc;
      fwRunning = run;
      loading = false;
    });
  }

  Future<void> _toggle(bool v) async {
    store.cfg.blackBox = v;
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _ask() async {
    setState(() => asking = true);
    final r = await XChannel.bbWhy('now');
    if (!mounted) return;
    setState(() {
      why = r.isEmpty ? 'বিশ্লেষণ করা গেল না।' : r;
      asking = false;
    });
  }

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সব মুছবেন?'),
        content: const Text('জমানো স্যাম্পল আর সব ইনসিডেন্ট মুছে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
        ],
      ),
    );
    if (ok == true) {
      await XChannel.bbClear();
      why = '';
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final Map<String, dynamic> last = pts.isEmpty ? <String, dynamic>{} : pts.last;
    final temp = last.isEmpty ? 0.0 : (last['temp'] as num) / 10.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ব্ল্যাক বক্স'),
        actions: [
          IconButton(tooltip: 'সব মুছুন', icon: const Icon(Icons.delete_outline), onPressed: _clear),
        ],
      ),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('ব্ল্যাক বক্স চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(c.blackBox
                      ? (fwRunning ? 'চালু, প্রতি ৩০ সেকেন্ডে স্যাম্পল নিচ্ছে' : 'চালু, কিন্তু ফায়ারওয়াল বন্ধ তাই ১৫ মিনিট পরপর মোটা স্যাম্পল')
                      : 'বন্ধ'),
                  value: c.blackBox,
                  onChanged: _toggle,
                ),
                const SizedBox(height: 4),
                Text(
                  'জমানো হয়: ব্যাটারি, তাপ, খালি RAM, সামনের অ্যাপের নাম, মোট ডেটা। সবই শুধু এই ফোনে থাকে, ২৪ ঘণ্টা পর মুছে যায়। '
                  'এগুলো অনুমান-ভিত্তিক "সম্ভাব্য" কারণ, নিশ্চিত প্রমাণ নয়।',
                  style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            if (loading)
              const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
            else ...[
              if (pts.isNotEmpty) ...[
                Row(children: [
                  Expanded(child: _stat('ব্যাটারি', '${last['batt']}%',
                      last['charging'] == true ? 'চার্জ হচ্ছে' : 'চার্জে নেই', cs.onSurface)),
                  const SizedBox(width: 12),
                  Expanded(child: _stat('তাপ', '${temp.toStringAsFixed(1)}°C',
                      temp >= 45 ? 'বেশি গরম' : (temp >= 40 ? 'কিছুটা গরম' : 'স্বাভাবিক'),
                      temp >= 45 ? cs.error : (temp >= 40 ? Colors.orange : Colors.green))),
                  const SizedBox(width: 12),
                  Expanded(child: _stat('খালি RAM', '${last['mem']} MB',
                      last['lowMem'] == true ? 'কম' : 'ঠিক আছে', last['lowMem'] == true ? cs.error : cs.onSurface)),
                ]),
                const SizedBox(height: 12),
                Wrap(spacing: 8, children: [
                  for (final h in const [1, 3, 6, 24])
                    ChoiceChip(
                      label: Text('$h ঘণ্টা'),
                      selected: hours == h,
                      onSelected: (_) {
                        hours = h;
                        _load();
                      },
                    ),
                ]),
                const SizedBox(height: 12),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('ব্যাটারি (সবুজ) আর তাপ (কমলা)', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 130,
                      width: double.infinity,
                      child: CustomPaint(painter: _LinePainter(pts, cs)),
                    ),
                    const SizedBox(height: 6),
                    Text('ব্যাটারি ০-১০০%, তাপ ২৫-৫০°C। লাল দাগ = ইনসিডেন্ট। ${pts.length}টা স্যাম্পল',
                        style: TextStyle(fontSize: 11.5, color: cs.outline)),
                  ]),
                ),
              ] else
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    c.blackBox
                        ? 'এখনো কোনো স্যাম্পল নেই। ফায়ারওয়াল চালু করে ১ মিনিট পরে দেখুন।'
                        : 'সুইচ চালু করলে স্যাম্পল জমতে শুরু করবে।',
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                ),
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('কেন?', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text('ফোন গরম বা ব্যাটারি কমছে মনে হলে শেষ ১০ মিনিট দেখে সম্ভাব্য কারণ বলে।',
                      style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.4)),
                  const SizedBox(height: 8),
                  FilledButton.tonalIcon(
                    onPressed: asking ? null : _ask,
                    icon: asking
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.search),
                    label: const Text('এখন কেন?'),
                  ),
                  if (why.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    SelectableText(why, style: const TextStyle(height: 1.5)),
                  ],
                ]),
              ),
              const SizedBox(height: 16),
              Text('ধরা পড়া ঘটনা (${incidents.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              if (incidents.isEmpty)
                Text('এখনো কিছু ধরা পড়েনি, সেটা ভালো খবর।', style: TextStyle(color: cs.onSurfaceVariant))
              else
                for (final i in incidents) _incident(i, cs),
            ],
          ],
        ),
      ),
    );
  }

  IconData _icon(String t) => switch (t) {
        'battery' => Icons.battery_alert,
        'heat' => Icons.thermostat,
        'mem' => Icons.memory,
        'data' => Icons.data_usage,
        _ => Icons.report_gmailerrorred_outlined,
      };

  Widget _incident(Map<String, dynamic> i, ColorScheme cs) {
    final lines = (i['detail'] as String).split('\n');
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        padding: EdgeInsets.zero,
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            leading: Icon(_icon(i['type'] as String), color: cs.error),
            title: Text(i['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(fmtAgo((i['t'] as num).toInt())),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final l in lines)
                Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(l, style: const TextStyle(height: 1.45))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _stat(String label, String main, String sub, Color color) {
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        const SizedBox(height: 4),
        Text(main, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: color)),
        Text(sub, style: TextStyle(fontSize: 11.5, color: cs.outline)),
      ]),
    );
  }
}

class _LinePainter extends CustomPainter {
  final List<Map<String, dynamic>> pts;
  final ColorScheme cs;
  _LinePainter(this.pts, this.cs);

  @override
  void paint(Canvas canvas, Size size) {
    if (pts.length < 2) return;
    final t0 = (pts.first['t'] as num).toDouble();
    final span = ((pts.last['t'] as num).toDouble() - t0).clamp(1.0, double.infinity);

    Offset at(Map<String, dynamic> p, double v, double lo, double hi) {
      final x = ((p['t'] as num).toDouble() - t0) / span * size.width;
      final y = size.height - ((v - lo) / (hi - lo)).clamp(0.0, 1.0) * size.height;
      return Offset(x, y);
    }

    final grid = Paint()
      ..color = cs.outlineVariant
      ..strokeWidth = 1;
    for (final f in const [0.0, 0.5, 1.0]) {
      canvas.drawLine(Offset(0, size.height * f), Offset(size.width, size.height * f), grid);
    }

    void line(double Function(Map<String, dynamic>) val, double lo, double hi, Color color, bool Function(Map<String, dynamic>) valid) {
      final path = Path();
      var started = false;
      for (final p in pts) {
        if (!valid(p)) {
          started = false;
          continue;
        }
        final o = at(p, val(p), lo, hi);
        if (!started) {
          path.moveTo(o.dx, o.dy);
          started = true;
        } else {
          path.lineTo(o.dx, o.dy);
        }
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }

    line((p) => (p['batt'] as num).toDouble(), 0, 100, Colors.green, (p) => (p['batt'] as num) >= 0);
    line((p) => (p['temp'] as num) / 10.0, 25, 50, Colors.orange, (p) => (p['temp'] as num) > 0);

    // গরম/কম মেমরির স্যাম্পলে হালকা লাল দাগ
    final red = Paint()..color = cs.error.withOpacity(0.35);
    for (final p in pts) {
      if ((p['temp'] as num) >= 450 || p['lowMem'] == true || (p['thermal'] as num) >= 3) {
        final x = ((p['t'] as num).toDouble() - t0) / span * size.width;
        canvas.drawRect(Rect.fromLTWH(x - 1, 0, 2, size.height), red);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _LinePainter old) => old.pts != pts;
}
