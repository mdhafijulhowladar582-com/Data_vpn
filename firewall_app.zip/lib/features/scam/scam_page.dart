import 'package:flutter/material.dart';
import '../../menu/badge_center.dart';
import '../../menu/x_channel.dart';
import '../../services/rules_storage.dart';
import '../../widgets/common.dart';
import '../fmt.dart';

/// স্ক্যাম গার্ড: নকল বিকাশ/নগদ/পেপ্যাল বা ফিশিং মনে হওয়া সাইট আটকায় (ইঞ্জিনের অ্যাপে)।
class ScamPage extends StatefulWidget {
  const ScamPage({super.key});

  @override
  State<ScamPage> createState() => _ScamPageState();
}

class _ScamPageState extends State<ScamPage> {
  final input = TextEditingController();
  List<Map<String, dynamic>> hits = [];
  List<Map<String, dynamic>> users = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load(markSeen: true);
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _load({bool markSeen = false}) async {
    final h = await XChannel.scamHits();
    final u = await XChannel.scamUsers();
    if (markSeen) {
      await XChannel.scamSeen();
      BadgeCenter.instance.clear('scam');
    }
    if (!mounted) return;
    setState(() {
      hits = h;
      users = u;
      loading = false;
    });
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _toggle(bool v) async {
    store.cfg.scamGuard = v;
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final t = input.text.trim();
    if (t.isEmpty) return;
    final ok = await XChannel.scamSet(t, 'block');
    if (!ok) {
      _snack('ডোমেইন বোঝা যায়নি (যেমন: example.com)');
      return;
    }
    input.clear();
    FocusManager.instance.primaryFocus?.unfocus();
    _load();
  }

  Future<void> _allow(String host) async {
    await XChannel.scamSet(host, 'allow');
    _snack('$host আর আটকাবে না');
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final blocks = users.where((e) => e['kind'] == 'block').toList();
    final allows = users.where((e) => e['kind'] == 'allow').toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('স্ক্যাম গার্ড'),
        actions: [
          if (hits.isNotEmpty)
            IconButton(
              tooltip: 'ইতিহাস মুছুন',
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                await XChannel.scamClear();
                _load();
              },
            ),
        ],
      ),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('স্ক্যাম গার্ড চালু', style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(c.engineOn
                      ? 'ইঞ্জিনের অ্যাপে কাজ করছে'
                      : 'ইঞ্জিন বন্ধ, তাই এখন কিছু ধরবে না'),
                  value: c.scamGuard,
                  onChanged: _toggle,
                ),
                const SizedBox(height: 4),
                Text(
                  'কাজ করে শুধু ইঞ্জিনের তালিকার অ্যাপে, তাই লিংক ধরতে ব্রাউজার ও মেসেঞ্জার ইঞ্জিনের অ্যাপে রাখুন। '
                  'ধরা হয় অনুমানে: বিকাশ/নগদ/পেপ্যালের নাম আছে অথচ আসল ডোমেইন নয়, অথবা ঝুঁকিপূর্ণ এক্সটেনশনের সাইটে '
                  '"login", "bonus"-জাতীয় শব্দ। সব নকল ধরা পড়বে না, আর কখনো আসল সাইটও আটকে যেতে পারে, তখন "ছাড়ুন" দিন।',
                  style: TextStyle(fontSize: 12.5, color: cs.outline, height: 1.45),
                ),
              ]),
            ),
            const SectionLabel('আটকানো সাইট'),
            if (loading)
              const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()))
            else if (hits.isEmpty)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text('এখনো কিছু আটকানো হয়নি', style: TextStyle(color: cs.onSurfaceVariant)),
              )
            else
              for (final h in hits)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.gpp_maybe_outlined, color: cs.error),
                  title: Text(h['host'] as String, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${h['why']} · ${fmtAgo((h['t'] as num).toInt())}'),
                  trailing: TextButton(onPressed: () => _allow(h['host'] as String), child: const Text('ছাড়ুন')),
                ),
            const SectionLabel('নিজের ব্লক তালিকা'),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    hintText: 'যেমন: fake-bonus.xyz',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  onSubmitted: (_) => _add(),
                ),
              ),
              const SizedBox(width: 10),
              FilledButton(onPressed: _add, child: const Text('যোগ')),
            ]),
            for (final u in blocks)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.block),
                title: Text(u['host'] as String),
                trailing: IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () async {
                    await XChannel.scamRemove(u['host'] as String);
                    _load();
                  },
                ),
              ),
            if (allows.isNotEmpty) ...[
              const SectionLabel('ছাড় দেওয়া'),
              for (final u in allows)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.check_circle_outline),
                  title: Text(u['host'] as String),
                  trailing: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () async {
                      await XChannel.scamRemove(u['host'] as String);
                      _load();
                    },
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
