import '../services/usage_service.dart';

/// নতুন ফিচারের পেজগুলোর ছোট সহায়ক
String fmtBytes(num b) => UsageService.fmt(b.toInt());

/// "এইমাত্র", "৫ মিনিট আগে", "৩ ঘণ্টা আগে", না হলে তারিখ
String fmtAgo(int ms) {
  final d = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
  if (d.inSeconds < 60) return 'এইমাত্র';
  if (d.inMinutes < 60) return '${d.inMinutes} মিনিট আগে';
  if (d.inHours < 24) return '${d.inHours} ঘণ্টা আগে';
  return '${d.inDays} দিন আগে';
}

int startOfToday() {
  final n = DateTime.now();
  return DateTime(n.year, n.month, n.day).millisecondsSinceEpoch;
}
