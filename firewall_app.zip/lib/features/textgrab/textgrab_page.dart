import 'package:flutter/material.dart';
import '../../menu/x_channel.dart';
import '../../widgets/common.dart';

/// লেখা তোলার বাটন: কপি করা যায় না এমন জায়গা থেকেও স্ক্রিনের লেখা তালিকা করে দেয়।
/// বাটন চাপলে তখনকার স্ক্রিনের সব লেখা তালিকা হয়, সেখান থেকে কপি, অনুবাদ বা গুগল সার্চ।
class TextGrabPage extends StatefulWidget {
  const TextGrabPage({super.key});

  @override
  State<TextGrabPage> createState() => _TextGrabPageState();
}

class _TextGrabPageState extends State<TextGrabPage> with WidgetsBindingObserver {
  Map<String, dynamic> st = {};

  static const _emoji = ['🔮', '🫧', '👁️', '✨', '⚡'];
  static const _hint = [
    'বেগুনি-নীল নরম আলো, নিঃশ্বাসের মতো ফোলে আর ছোট হয়',
    'স্বচ্ছ বুদবুদ, গায়ে রামধনুর আভা, হালকা দোলে',
    'ছোট চোখ, চারদিকে তাকায়, মাঝে মাঝে পলক ফেলে',
    'ছোট তারা, চারপাশে জোনাকির মতো আলোর কণা',
    'হলুদ, লাল গাল, কান নড়ে, বিদ্যুৎ-লেজ। চাপলে ঝিলিক ছোটে',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// অ্যাক্সেসিবিলিটি সেটিংস থেকে ফিরলে অবস্থা আবার পড়ে
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final s = await XChannel.grabState();
    if (mounted && s.isNotEmpty) setState(() => st = s);
  }

  bool get enabled => st['enabled'] == true;
  bool get on => st['on'] == true;
  int get style => (st['style'] as num?)?.toInt() ?? 0;

  Future<void> _toggle(bool v) async {
    setState(() => st = {...st, 'on': v});
    await XChannel.grabSet(on: v);
    await _load();
  }

  Future<void> _pickStyle(int i) async {
    setState(() => st = {...st, 'style': i});
    await XChannel.grabSet(style: i);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('লেখা তোলার বাটন')),
      body: Centered(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            AppCard(
              child: Text(
                'অনেক জায়গায় লেখা চেপে ধরলে কপি হয় না। চালু করলে স্ক্রিনের কোণে একটা ভাসমান বাটন থাকবে। '
                'বাটন চাপলে ওই মুহূর্তের স্ক্রিনের সব লেখা তালিকা হয়ে আসবে। সেখান থেকে যেটা চান কপি করুন, অনুবাদ করুন বা গুগলে খুঁজুন।',
                style: TextStyle(fontSize: 13.5, height: 1.5, color: cs.onSurfaceVariant),
              ),
            ),
            const SizedBox(height: 12),
            if (!enabled)
              AppCard(
                color: cs.tertiaryContainer.withAlpha(140),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('আগে অ্যাক্সেসিবিলিটি চালু করুন', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(
                    'অ্যাক্সেসিবিলিটি সেটিংসে গিয়ে "Firewall লেখা তোলা" বেছে চালু করুন। '
                    'এটা বাটন না চাপা পর্যন্ত কিছু পড়ে না, আর কিছু সেভ বা ইন্টারনেটে পাঠায় না।',
                    style: TextStyle(fontSize: 13, height: 1.45, color: cs.onSurfaceVariant),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () async {
                      final ok = await XChannel.grabAccess();
                      if (!ok && mounted) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(content: Text('সেটিংস খোলা গেল না। ফোনের সেটিংস থেকে অ্যাক্সেসিবিলিটিতে যান।')));
                      }
                    },
                    icon: const Icon(Icons.accessibility_new),
                    label: const Text('অ্যাক্সেসিবিলিটি সেটিংস খুলুন'),
                  ),
                ]),
              ),
            if (!enabled) const SizedBox(height: 12),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                title: const Text('ভাসমান বাটন চালু'),
                subtitle: Text(enabled ? 'বাটন টেনে যেখানে খুশি সরানো যায়' : 'অ্যাক্সেসিবিলিটি চালু না করলে বাটন আসবে না'),
                value: on,
                onChanged: _toggle,
              ),
            ),
            const SectionLabel('বাটনের স্টাইল'),
            AppCard(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(children: [
                for (var i = 0; i < 5; i++)
                  ListTile(
                    leading: Text(_emoji[i], style: const TextStyle(fontSize: 26)),
                    title: Text(const ['আলোর গোলক', 'সাবানের বুদবুদ', 'জাদুর চোখ', 'জোনাকি তারা', 'বিজলি-ছানা'][i]),
                    subtitle: Text(_hint[i], style: const TextStyle(fontSize: 12.5)),
                    trailing: style == i ? Icon(Icons.check_circle, color: cs.primary) : const Icon(Icons.circle_outlined),
                    selected: style == i,
                    onTap: () => _pickStyle(i),
                  ),
              ]),
            ),
            const SectionLabel('জেনে রাখুন'),
            AppCard(
              child: Text(
                '• ছবির ভেতরের লেখা (স্ক্রিনশটের মতো) পড়া যায় না।\n'
                '• ব্যাংক বা সুরক্ষিত অ্যাপ নিজেই লেখা পড়া আটকে দিতে পারে।\n'
                '• পাসওয়ার্ডের ঘরের লেখা তোলা হয় না।\n'
                '• "অনুবাদ" আর "গুগলে খুঁজুন" চাপলে ব্রাউজারে ওই লেখা যায়। কপি করলে ফোনেই থাকে।',
                style: TextStyle(fontSize: 13, height: 1.6, color: cs.onSurfaceVariant),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
