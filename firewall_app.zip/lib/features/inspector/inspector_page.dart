import 'package:flutter/material.dart';
import '../../screens/engine_page.dart';
import '../../services/rules_storage.dart';
import '../../services/usage_service.dart';
import '../../widgets/app_tile.dart';
import '../../widgets/common.dart';
import '../../menu/x_channel.dart';
import '../fmt.dart';

/// নেটওয়ার্ক ইনস্পেক্টর: কোন অ্যাপ কোন সার্ভারে কত ডেটা পাঠাল/পেল।
/// ইঞ্জিনের অ্যাপে ডোমেইনসহ, বাকি অ্যাপে শুধু মোট ডেটা (ফোনের নিজের হিসাব থেকে)।
class InspectorPage extends StatefulWidget {
  const InspectorPage({super.key});

  @override
  State<InspectorPage> createState() => _InspectorPageState();
}

class _InspectorPageState extends State<InspectorPage> {
  int range = 0; // 0 আজ, 1 ৭ দিন
  bool loading = true;
  List<Map<String, dynamic>> apps = [];
  List<UsageEntry> others = [];
  Map<String, String> names = {};

  int get _from => range == 0
      ? startOfToday()
      : DateTime.now().subtract(const Duration(days: 7)).millisecondsSinceEpoch;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final all = await store.loadApps();
      names = {for (final a in all) a.pkg: a.name};
    } catch (_) {}
    final a = await XChannel.connApps(_from);
    List<UsageEntry> u = [];
    try {
      u = await UsageService.fetch(range == 0 ? 0 : 1);
    } catch (_) {}
    final seen = a.map((e) => e['pkg'] as String).toSet();
    if (!mounted) return;
    setState(() {
      apps = a;
      others = u.where((e) => !seen.contains(e.pkg)).take(15).toList();
      loading = false;
    });
  }

  String _name(String pkg) => names[pkg] ?? pkg;

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('লগ মুছবেন?'),
        content: const Text('জমা থাকা সব সংযোগের তালিকা মুছে যাবে। এরপর থেকে আবার জমতে শুরু করবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('মুছুন')),
        ],
      ),
    );
    if (ok != true) return;
    await XChannel.connClear();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = store.cfg;
    final engineReady = c.engineOn && c.engineApps.isNotEmpty;
    return Scaffold(
      appBar: AppBar(
        title: const Text('নেটওয়ার্ক ইনস্পেক্টর'),
        actions: [
          IconButton(tooltip: 'লগ মুছুন', icon: const Icon(Icons.delete_outline), onPressed: _clear),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: Centered(
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              Wrap(spacing: 8, children: [
                ChoiceChip(
                    label: const Text('আজ'),
                    selected: range == 0,
                    onSelected: (_) {
                      range = 0;
                      _load();
                    }),
                ChoiceChip(
                    label: const Text('৭ দিন'),
                    selected: range == 1,
                    onSelected: (_) {
                      range = 1;
                      _load();
                    }),
              ]),
              const SizedBox(height: 12),
              if (!engineReady)
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('ডোমেইন দেখতে ইঞ্জিন চালু থাকতে হবে',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(
                      'ইঞ্জিনের তালিকার অ্যাপগুলোর ট্রাফিকই এখানে ডোমেইনসহ ধরা পড়ে। '
                      '${c.engineApps.isEmpty ? "এখনো কোনো অ্যাপ বাছা নেই।" : "ইঞ্জিন এখন বন্ধ।"}',
                      style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant, height: 1.4),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () async {
                        await Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) => const EnginePage()));
                        if (mounted) {
                          setState(() {});
                          _load();
                        }
                      },
                      icon: const Icon(Icons.settings_ethernet),
                      label: const Text('ইঞ্জিন পেজ'),
                    ),
                  ]),
                ),
              if (loading)
                const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()))
              else ...[
                const SectionLabel('ইঞ্জিনের অ্যাপ (ডোমেইনসহ)'),
                if (apps.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('এই সময়ে কোনো সংযোগ ধরা পড়েনি। অ্যাপ ব্যবহার করে কিছুক্ষণ পরে দেখুন (লেখা হয় ৩০ সেকেন্ড পরপর)।',
                        style: TextStyle(color: cs.onSurfaceVariant)),
                  ),
                for (final a in apps) _appTile(a),
                if (others.isNotEmpty) ...[
                  const SectionLabel('ইঞ্জিনের বাইরের অ্যাপ (শুধু মোট ডেটা)'),
                  for (final e in others)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: AppIcon(e.pkg),
                      title: Text(_name(e.pkg)),
                      subtitle: Text('Wi-Fi ${fmtBytes(e.wifi)} · মোবাইল ${fmtBytes(e.mobile)}'),
                      trailing: Text(fmtBytes(e.total)),
                    ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _appTile(Map<String, dynamic> a) {
    final pkg = a['pkg'] as String;
    final up = (a['up'] as num).toInt();
    final down = (a['down'] as num).toInt();
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: AppIcon(pkg),
      title: Text(_name(pkg)),
      subtitle: Text('↑ ${fmtBytes(up)}  ↓ ${fmtBytes(down)} · ${a['hosts']}টি গন্তব্য · ${fmtAgo((a['last'] as num).toInt())}'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => _HostsPage(pkg: pkg, title: _name(pkg), from: _from))),
    );
  }
}

class _HostsPage extends StatefulWidget {
  final String pkg;
  final String title;
  final int from;
  const _HostsPage({required this.pkg, required this.title, required this.from});

  @override
  State<_HostsPage> createState() => _HostsPageState();
}

class _HostsPageState extends State<_HostsPage> {
  List<Map<String, dynamic>>? hosts;

  @override
  void initState() {
    super.initState();
    XChannel.connHosts(widget.pkg, widget.from).then((h) {
      if (mounted) setState(() => hosts = h);
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final h = hosts;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: h == null
          ? const Center(child: CircularProgressIndicator())
          : Centered(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  if (h.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('কিছু নেই')),
                  for (final e in h)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        (e['named'] == true) ? Icons.language : Icons.dns_outlined,
                        color: cs.onSurfaceVariant,
                      ),
                      title: Text(e['host'] as String, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                          '↑ ${fmtBytes(e['up'] as num)}  ↓ ${fmtBytes(e['down'] as num)} · ${fmtAgo((e['last'] as num).toInt())}'
                          '${e['named'] == true ? "" : " · নাম জানা যায়নি (IP)"}'),
                    ),
                ],
              ),
            ),
    );
  }
}
