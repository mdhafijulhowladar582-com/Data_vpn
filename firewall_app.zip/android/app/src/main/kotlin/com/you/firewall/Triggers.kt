package com.you.firewall

import android.content.ContentValues
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * ব্ল্যাক বক্সের ট্রিগার: প্রতিটা নতুন স্যাম্পলের পর শেষ ১০ মিনিট দেখে চারটা সমস্যা খোঁজে।
 * ধরা পড়লে [Analyzer]-এর কারণসহ ইনসিডেন্ট ডিস্কে রাখে (শেষ ৫ মিনিটের স্ন্যাপশটসহ) আর একটা নোটিফিকেশন দেয়।
 * একই ধরনের ঘটনা ৩০ মিনিটে একবারের বেশি নয়।
 */
object Triggers {
    private const val GAP_MS = 30L * 60 * 1000
    private val lastAt = HashMap<String, Long>()
    private val ids = mapOf("battery" to 7110, "heat" to 7111, "mem" to 7112, "data" to 7113)

    fun check(c: Context, now: Long) {
        val win = Sampler.range(c, now - 10 * 60 * 1000L, now)
        if (win.size < 4) return
        val last = win.last()

        // ১. দ্রুত ব্যাটারি ক্ষয়: চার্জ ছাড়া অন্তত ৮ মিনিটে ৫% বা বেশি
        if (win.none { it.charging } && last.t - win.first().t >= 8 * 60 * 1000L &&
            win.first().batt >= 0 && last.batt >= 0 && win.first().batt - last.batt >= 5
        ) fire(c, now, "battery", "ব্যাটারি দ্রুত কমছে", win)

        // ২. অতিরিক্ত গরম: সিস্টেমের থার্মাল 'গুরুতর', বা ৪৫°C-র ওপরে, বা এই ফোনের নিজের স্বাভাবিকের চেয়ে অনেক বেশি
        if (heatBad(c, now, win)) fire(c, now, "heat", "ফোন অতিরিক্ত গরম", win)

        // ৩. কম মেমরি: টানা দুই স্যাম্পলে সিস্টেম 'কম মেমরি' বলেছে
        val tail = win.takeLast(2)
        if (tail.size == 2 && tail.all { it.lowMem }) fire(c, now, "mem", "ফোনের মেমরি কমে গেছে", win)

        // ৪. স্ক্রিন বন্ধ অবস্থায় ডেটা-ঢেউ: ১০ মিনিটে ২০ MB-র বেশি
        val off = win.filter { !it.screen }
        if (off.size >= 4 && off.sumOf { it.rx + it.tx } > 20L * 1024 * 1024) {
            fire(c, now, "data", "স্ক্রিন বন্ধ, তবু ডেটা যাচ্ছে", win)
        }
    }

    // ফোনের নিজের "স্বাভাবিক" তাপ (২৪ ঘণ্টার মধ্যমা), চার্জে/চার্জ ছাড়া আলাদা। ৫ মিনিটে একবার নতুন করে হিসাব
    private val baseTemp = HashMap<Boolean, Int>()
    private var baseAt = 0L

    private fun baseline(c: Context, now: Long, charging: Boolean): Int? {
        if (now - baseAt > 5 * 60 * 1000L) {
            baseAt = now
            baseTemp.clear()
            val old = Sampler.range(c, now - 24L * 3600 * 1000, now - 10 * 60 * 1000L).filter { it.temp > 0 }
            for (ch in listOf(true, false)) {
                val l = old.filter { it.charging == ch }.map { it.temp }.sorted()
                if (l.size >= 60) baseTemp[ch] = l[l.size / 2] // কমপক্ষে ৩০ মিনিটের স্যাম্পল না থাকলে তুলনা নেই
            }
        }
        return baseTemp[charging]
    }

    /**
     * তিন রকম প্রমাণ, যেকোনো একটা হলেই:
     *  ০. ব্যাটারির স্বাস্থ্য OVERHEAT, বা থার্মাল হেডরুম ০.৯৫+ (ফোনের নিজের সীমা, ফোনভেদে আলাদা)
     *  ১. Android-এর নিজের থার্মাল স্ট্যাটাস 'গুরুতর' (সবচেয়ে নির্ভরযোগ্য, ফোনভেদে ঠিক করা)
     *  ২. ব্যাটারির তাপ ৪৫°C বা বেশি (যেকোনো ফোনে বিপজ্জনক)
     *  ৩. টানা তিন স্যাম্পলে ৪০°C-র ওপরে আর এই ফোনের স্বাভাবিকের চেয়ে ৮°C বেশি
     */
    private fun heatBad(c: Context, now: Long, win: List<Sampler.S>): Boolean {
        val last = win.last()
        if (Sampler.overheatNow) return true // ব্যাটারি নিজেই "অতিরিক্ত গরম" জানিয়েছে
        if (last.thermal >= 3) return true
        if (!Sampler.headroom.isNaN() && Sampler.headroom >= 0.95f && last.temp >= 400) return true // গতি কমানোর সীমার কাছে
        if (last.temp >= 450) return true
        val tail = win.takeLast(3)
        if (tail.size < 3 || tail.any { it.temp < 400 }) return false
        val base = baseline(c, now, last.charging) ?: return false
        return tail.all { it.temp >= base + 80 }
    }

    private fun fire(c: Context, now: Long, type: String, title: String, win: List<Sampler.S>) {
        if (now - (lastAt[type] ?: 0L) < GAP_MS) return
        lastAt[type] = now
        val text = Analyzer.explain(c, type, win)
        val snap = JSONArray()
        for (s in win.filter { it.t >= now - 5 * 60 * 1000L }) {
            snap.put(
                JSONObject().put("t", s.t).put("b", s.batt).put("tp", s.temp).put("m", s.memFree)
                    .put("fg", s.fg).put("d", s.rx + s.tx).put("sc", s.screen)
            )
        }
        val v = ContentValues()
        v.put("t", now)
        v.put("type", type)
        v.put("title", title)
        v.put("detail", text)
        v.put("snapshot", snap.toString())
        XDb.get(c).writableDatabase.insert("incidents", null, v)
        val firstReason = text.lines().getOrNull(1)?.replaceFirst(Regex("^\\d+\\. "), "") ?: text
        Alert.report(c, ids[type] ?: 7119, title, firstReason, "blackbox")
    }

    /** পেজের জন্য */
    fun list(c: Context): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(c).readableDatabase.rawQuery(
            "SELECT id, t, type, title, detail, seen FROM incidents ORDER BY t DESC LIMIT 100", null
        ).use {
            while (it.moveToNext()) {
                out.add(
                    mapOf(
                        "id" to it.getLong(0), "t" to it.getLong(1), "type" to (it.getString(2) ?: ""),
                        "title" to (it.getString(3) ?: ""), "detail" to (it.getString(4) ?: ""),
                        "seen" to (it.getInt(5) != 0)
                    )
                )
            }
        }
        return out
    }

    fun unseen(c: Context): Int =
        XDb.get(c).readableDatabase.rawQuery("SELECT COUNT(*) FROM incidents WHERE seen = 0", null)
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun markSeen(c: Context) {
        XDb.get(c).writableDatabase.execSQL("UPDATE incidents SET seen = 1 WHERE seen = 0")
    }

    fun clear(c: Context) {
        val db = XDb.get(c).writableDatabase
        db.delete("incidents", null, null)
        db.delete("samples", null, null)
    }
}
