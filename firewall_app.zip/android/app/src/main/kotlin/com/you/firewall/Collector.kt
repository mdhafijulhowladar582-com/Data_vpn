package com.you.firewall

import android.content.Context

/**
 * নতুন ফিচারের ডেটা জমানোর প্রবেশপথ। আলাদা সার্ভিস নেই: VPN সার্ভিসের ৩০ সেকেন্ডের tick থেকে ডাকা হয়,
 * তাই ফোরগ্রাউন্ড সার্ভিস, নোটিফিকেশন বা ব্যাটারি খরচ বাড়ে না।
 * ধাপ ১: কানেকশন লগ ডিস্কে লেখা আর নেটের মান মাপা। ধাপ ২: ব্ল্যাক বক্সের স্যাম্পলিং ও ট্রিগার।
 */
object Collector {
    private const val PRUNE_EVERY_MS = 6L * 3600 * 1000
    @Volatile private var lastPrune = 0L

    /** ব্ল্যাক বক্স: স্যাম্পল নিয়ে ট্রিগার দেখা। আলাদা try, যাতে এর ভুলে বাকি কাজ না থামে */
    private fun blackBox(ctx: Context, coarse: Boolean) {
        try {
            if (!Sampler.enabled(ctx)) return
            val s = Sampler.take(ctx, coarse) ?: return
            if (!coarse) Triggers.check(ctx, s.t)
        } catch (e: Exception) {
        }
    }

    /** ফায়ারওয়াল বন্ধ থাকলে Guardian-এর ১৫ মিনিটের জব থেকে একটা মোটা স্যাম্পল (ট্রিগার দেখা হয় না) */
    fun onCoarse(c: Context) {
        try {
            if (com.you.firewall.FirewallVpnService.running) return // tick-ই মিহি নিচ্ছে
            blackBox(c.applicationContext, true)
        } catch (e: Exception) {
        }
    }

    fun onTick(c: Context) {
        try {
            val ctx = c.applicationContext
            RuleEngine.emit(ctx, RuleEngine.TICK)
            try { ConnLog.onTick(ctx) } catch (e: Exception) {}
            try { WifiGuard.onTick(ctx) } catch (e: Exception) {} // ধাপ ৩: পাবলিক Wi-Fi
            try { Ctl.onTick(ctx) } catch (e: Exception) {}       // ধাপ ৪: অটোমেশন
            try { Lab.onTick(ctx) } catch (e: Exception) {}       // ধাপ ৫: চার্জার লিডারবোর্ড
            try { CoolMode.onTick(ctx) } catch (e: Exception) {}  // ঠান্ডা মোড
            try { Shake.sync(ctx) } catch (e: Exception) {}       // ধাপ ৩: শেক-প্যানিক
            try { NetQuality.onTick(c) } catch (e: Exception) {} // VpnService লাগে (protect), তাই আসল c
            val now = System.currentTimeMillis()
            blackBox(ctx, false)
            if (now - lastPrune > PRUNE_EVERY_MS) {
                lastPrune = now
                Thread { XDb.get(ctx).prune(now) }.also { it.isDaemon = true }.start()
            }
        } catch (e: Exception) {
            // নতুন কোডের ভুলে যেন আসল ফায়ারওয়ালের tick না থামে
        }
    }
}
