package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * পকেট গার্ড (চুরি-বিরোধী অ্যালার্ম)। ভিড়ে বা বাসে ফোন পকেটে রেখে চালু করলে:
 * পকেট থেকে বের করলে (প্রক্সিমিটি সেন্সর), জোরে ঝাঁকুনি/নাড়ালে, বা চার্জার খুললে প্রথমে পিনের স্ক্রিন আসে,
 * [grace] সেকেন্ডে পিন না দিলে জোরে সাইরেন বাজে আর সামনের ক্যামেরায় ছবি তোলা হয় (ছবি ইনট্রুডার ভল্টে যায়)।
 *
 * অবস্থা: OFF -> ARMING (কাউন্টডাউন) -> ARMED -> GRACE (পিনের সময়) -> ALARM (সাইরেন)। বন্ধ করতে পিন লাগে।
 */
object PocketGuard {
    const val S_OFF = 0
    const val S_ARMING = 1
    const val S_ARMED = 2
    const val S_GRACE = 3
    const val S_ALARM = 4

    const val ACTION_ARM = "com.you.firewall.POCKET_ARM"

    @Volatile var state = S_OFF
    @Volatile var armEndsAt = 0L
    @Volatile var armedSince = 0L
    @Volatile var graceEndsAt = 0L
    @Volatile var lastReason = ""

    /** এই সেশনে পকেট-থেকে-বের-করা ধরার সেন্সর কাজ করছে কি না */
    @Volatile var proxActive = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_pocket", Context.MODE_PRIVATE)

    private fun rawCfg(c: Context): JSONObject = try {
        JSONObject(sp(c).getString("cfg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    /** ডিফল্টসহ পুরো সেটিং */
    fun cfgFull(c: Context): JSONObject {
        val j = rawCfg(c)
        val mode = if (j.optString("mode", "pocket") == "table") "table" else "pocket"
        return JSONObject()
            .put("mode", mode)
            .put("sens", j.optInt("sens", 1).coerceIn(0, 2))
            .put("tMove", j.optBoolean("tMove", true))
            .put("tProx", j.optBoolean("tProx", true))
            .put("tCharger", j.optBoolean("tCharger", true))
            .put("photo", j.optBoolean("photo", true))
            .put("grace", j.optInt("grace", 5).coerceIn(0, 30))
            .put("countdown", j.optInt("countdown", 10).coerceIn(3, 60))
    }

    fun setCfg(c: Context, json: String) {
        val inp = try {
            JSONObject(json)
        } catch (e: Exception) {
            return
        }
        val cur = cfgFull(c)
        for (k in listOf("mode", "sens", "tMove", "tProx", "tCharger", "photo", "grace", "countdown")) {
            if (inp.has(k)) cur.put(k, inp.get(k))
        }
        sp(c).edit().putString("cfg", cur.toString()).apply()
    }

    @Synchronized
    fun addLog(c: Context, reason: String) {
        val a = try {
            JSONArray(sp(c).getString("log", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("reason", reason))
        val out = if (a.length() > 50) {
            val b = JSONArray()
            for (i in a.length() - 50 until a.length()) b.put(a.get(i))
            b
        } else a
        sp(c).edit().putString("log", out.toString()).apply()
    }

    /** নতুন থেকে পুরনো ক্রমে */
    @Synchronized
    fun log(c: Context): List<Map<String, Any>> {
        val a = try {
            JSONArray(sp(c).getString("log", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Map<String, Any>>()
        for (i in a.length() - 1 downTo 0) {
            val o = a.optJSONObject(i) ?: continue
            out.add(mapOf("t" to o.optLong("t"), "reason" to o.optString("reason")))
        }
        return out
    }

    @Synchronized
    fun clearLog(c: Context) {
        sp(c).edit().putString("log", "[]").apply()
    }

    /** পিন সেট না থাকলে বন্ধ করার উপায় নেই, তাই চালুই করতে দেওয়া হয় না */
    fun hasPin(c: Context): Boolean = Store.load(c).optString("pinHash").isNotEmpty()

    fun info(c: Context): Map<String, Any?> {
        val ctx = c.applicationContext
        val now = System.currentTimeMillis()
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val cfg = cfgFull(ctx)
        val cm = HashMap<String, Any?>()
        for (k in cfg.keys()) cm[k] = cfg.get(k)
        return mapOf(
            "state" to state,
            "left" to (if (state == S_ARMING) max(0L, (armEndsAt - now + 999) / 1000).toInt() else 0),
            "graceLeft" to (if (state == S_GRACE) max(0L, (graceEndsAt - now + 999) / 1000).toInt() else 0),
            "since" to (if (state >= S_ARMED) armedSince else 0L),
            "reason" to lastReason,
            "prox" to proxActive,
            "hasPin" to hasPin(ctx),
            "cam" to (ctx.checkSelfPermission("android.permission.CAMERA") == PackageManager.PERMISSION_GRANTED),
            "hasProxSensor" to (sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null),
            "cfg" to cm,
            "log" to log(ctx)
        )
    }

    /** কাউন্টডাউন শুরু। পিন না থাকলে বা আগে থেকেই চালু থাকলে false */
    fun arm(c: Context): Boolean {
        val ctx = c.applicationContext
        if (state != S_OFF) return false
        if (!hasPin(ctx)) return false
        val cd = cfgFull(ctx).optInt("countdown", 10)
        state = S_ARMING
        armEndsAt = System.currentTimeMillis() + cd * 1000L
        lastReason = ""
        proxActive = false
        val i = Intent(ctx, PocketGuardService::class.java).setAction(ACTION_ARM)
        return try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            true
        } catch (e: Exception) {
            state = S_OFF
            false
        }
    }

    /** সাইরেন, সেন্সর, নোটিফিকেশন সব বন্ধ। কলারের দায়িত্ব আগে পিন যাচাই করা (শুধু কাউন্টডাউনের সময় বাতিলে পিন লাগে না) */
    fun disarm(c: Context) {
        val ctx = c.applicationContext
        Siren.stop(ctx)
        state = S_OFF
        PocketGuardService.instance?.requestStop()
    }
}

/** জোরালো সাইরেন (ওঠানামা করা সুর)। অ্যালার্ম স্ট্রিমে বাজে, ভলিউম সর্বোচ্চে তোলে, কেউ কমালে আবার বাড়িয়ে দেয়। */
object Siren {
    @Volatile private var run = false
    private var prevVol = -1

    fun running() = run

    @Synchronized
    fun start(c: Context) {
        if (run) return
        val ctx = c.applicationContext
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (prevVol < 0) prevVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
        }
        run = true
        Thread {
            var track: AudioTrack? = null
            try {
                val sr = 22050
                val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val tr = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(min, 8192))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track = tr
                tr.setVolume(1.0f)
                tr.play()
                val buf = ShortArray(1024)
                var phase = 0.0
                var pos = 0L
                val period = sr * 3L / 2 // ১.৫ সেকেন্ডে একবার ওঠা-নামা
                while (run) {
                    for (i in buf.indices) {
                        val x = (pos % period).toDouble() / period.toDouble()
                        val tri = if (x < 0.5) x * 2 else (1 - x) * 2
                        val f = 700.0 + 800.0 * tri
                        phase += 2 * PI * f / sr
                        if (phase > 2 * PI) phase -= 2 * PI
                        val s = sin(phase) + 0.35 * sin(3 * phase)
                        buf[i] = (s / 1.35 * 32000).toInt().toShort()
                        pos++
                    }
                    tr.write(buf, 0, buf.size)
                }
            } catch (e: Exception) {
            } finally {
                try { track?.stop() } catch (e: Exception) {}
                try { track?.release() } catch (e: Exception) {}
            }
        }.start()
    }

    @Synchronized
    fun stop(c: Context) {
        run = false
        if (prevVol >= 0) {
            try {
                (c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                    .setStreamVolume(AudioManager.STREAM_ALARM, prevVol, 0)
            } catch (e: Exception) {
            }
            prevVol = -1
        }
    }

    /** কেউ ভলিউম কমালে আবার সর্বোচ্চ */
    fun enforce(c: Context) {
        if (!run) return
        try {
            val am = c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
        }
    }

    /** ৩ সেকেন্ডের পরীক্ষা, ভলিউম ঠিক আছে কি না দেখতে */
    fun test(c: Context) {
        if (run) return
        start(c)
        Handler(Looper.getMainLooper()).postDelayed({
            if (PocketGuard.state != PocketGuard.S_ALARM) stop(c)
        }, 3000)
    }
}

class PocketGuardService : Service(), SensorEventListener {
    companion object {
        const val CH_RUN = "fwpg_run"
        const val CH_ALERT = "fwpg_alert"
        const val ID_RUN = 7711
        const val ID_ALERT = 7712
        const val MAX_ALARM_MS = 10 * 60 * 1000L

        @Volatile var instance: PocketGuardService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private var sm: SensorManager? = null
    private var proxSensor: Sensor? = null
    private var chargerR: BroadcastReceiver? = null
    private var cfg = JSONObject()

    private val gravity = FloatArray(3)
    private var gInit = false
    private var settleUntil = 0L
    private val hits = ArrayList<Long>()

    private var near: Boolean? = null
    private var wasNear = false
    private var proxEnabled = false
    private var alarmStartedAt = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        if (intent?.action == PocketGuard.ACTION_ARM) {
            begin()
        } else {
            // startForegroundService-এর নিয়ম মানতে একবার ফোরগ্রাউন্ডে যেতেই হয়
            ensureChannels()
            goForeground(buildRun("পকেট গার্ড বন্ধ হচ্ছে"))
            shutdown()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        super.onDestroy()
    }

    // ---------------- শুরু ও কাউন্টডাউন ----------------

    private fun begin() {
        ensureChannels()
        goForeground(buildRun("পকেট গার্ড চালু হচ্ছে…"))
        if (PocketGuard.state != PocketGuard.S_ARMING) {
            shutdown()
            return
        }
        cfg = PocketGuard.cfgFull(this)
        try {
            val p = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = p.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "firewall:pocket")
            w.setReferenceCounted(false)
            w.acquire(12 * 3600 * 1000L) // স্ক্রিন বন্ধেও সেন্সর চালু রাখতে। ১২ ঘণ্টার বেশি আটকে থাকবে না
            wl = w
        } catch (e: Exception) {
        }
        val m = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm = m
        // কাউন্টডাউনের সময়ই প্রক্সিমিটি পড়া শুরু, যাতে ফোন পকেটে ঢুকেছে কি না জানা যায়
        proxSensor = m.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        proxSensor?.let { m.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        armTick.run()
    }

    private val armTick = object : Runnable {
        override fun run() {
            if (PocketGuard.state != PocketGuard.S_ARMING) return
            val left = ((PocketGuard.armEndsAt - System.currentTimeMillis() + 999) / 1000).toInt()
            if (left <= 0) {
                armNow()
                return
            }
            notifyRun("$left সেকেন্ডে চালু হবে। ফোন পকেটে রাখুন")
            h.postDelayed(this, 1000)
        }
    }

    private fun armNow() {
        val pocket = cfg.optString("mode") == "pocket"
        proxEnabled = pocket && cfg.optBoolean("tProx", true) && near == true
        wasNear = near == true
        PocketGuard.proxActive = proxEnabled
        if (!proxEnabled) {
            try { proxSensor?.let { sm?.unregisterListener(this, it) } } catch (e: Exception) {}
        }
        gInit = false
        hits.clear()
        settleUntil = System.currentTimeMillis() + 1500
        if (cfg.optBoolean("tMove", true)) {
            sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }
        if (cfg.optBoolean("tCharger", true)) registerCharger()
        PocketGuard.armedSince = System.currentTimeMillis()
        PocketGuard.state = PocketGuard.S_ARMED
        buzz(250)
        notifyRun(armedText())
    }

    private fun armedText(): String {
        val pocket = cfg.optString("mode") == "pocket"
        return if (pocket && cfg.optBoolean("tProx", true) && !proxEnabled)
            "চালু আছে, কিন্তু সেন্সর ঢাকা ছিল না, তাই পকেট থেকে বের করা ধরবে না (শুধু ঝাঁকুনি/চার্জার)। বন্ধ করতে ট্যাপ করে পিন দিন"
        else "চালু আছে। বন্ধ করতে ট্যাপ করে পিন দিন"
    }

    // ---------------- সেন্সর ----------------

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_PROXIMITY -> onProx(e)
            Sensor.TYPE_ACCELEROMETER -> onAccel(e)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun onProx(e: SensorEvent) {
        val n = e.values[0] < minOf(e.sensor.maximumRange, 5f)
        near = n
        if (PocketGuard.state != PocketGuard.S_ARMED || !proxEnabled) return
        h.removeCallbacks(proxConfirm)
        if (n) wasNear = true
        else if (wasNear) h.postDelayed(proxConfirm, 400) // ঝিলিক নয়, সত্যিই দূরে গেছে কি না দেখতে
    }

    private val proxConfirm = Runnable {
        if (near == false && PocketGuard.state == PocketGuard.S_ARMED) trigger("ফোন পকেট থেকে বের করা হয়েছে")
    }

    private fun onAccel(e: SensorEvent) {
        if (PocketGuard.state != PocketGuard.S_ARMED) return
        val v = e.values
        if (!gInit) {
            gravity[0] = v[0]; gravity[1] = v[1]; gravity[2] = v[2]
            gInit = true
            return
        }
        val a = 0.9f
        for (k in 0..2) gravity[k] = a * gravity[k] + (1 - a) * v[k]
        val lx = v[0] - gravity[0]
        val ly = v[1] - gravity[1]
        val lz = v[2] - gravity[2]
        val mag = sqrt(lx * lx + ly * ly + lz * lz)
        val now = System.currentTimeMillis()
        if (now < settleUntil) return
        val pocket = cfg.optString("mode") == "pocket"
        val sens = cfg.optInt("sens", 1).coerceIn(0, 2)
        // পকেট মোডে শুধু ছিনতাইয়ের মতো জোরালো ঝাঁকুনি (হাঁটায় যেন না বাজে), টেবিল মোডে হালকা নড়াও ধরে
        val th = if (pocket) floatArrayOf(45f, 32f, 22f)[sens] else floatArrayOf(3.0f, 1.5f, 0.7f)[sens]
        val need = if (pocket) 2 else 3
        val win = if (pocket) 1500L else 1200L
        val gap = if (pocket) 200L else 100L
        if (mag < th) return
        if (hits.isNotEmpty() && now - hits[hits.size - 1] < gap) return // একই ঝাঁকুনি দুইবার গোনা নয়
        hits.add(now)
        hits.removeAll { now - it > win }
        if (hits.size >= need) {
            hits.clear()
            trigger(if (pocket) "জোরালো ঝাঁকুনি (ছিনতাইয়ের মতো)" else "ফোন নাড়ানো হয়েছে")
        }
    }

    private fun registerCharger() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (PocketGuard.state == PocketGuard.S_ARMED) trigger("চার্জার খোলা হয়েছে")
            }
        }
        chargerR = r
        registerReceiver(r, IntentFilter(Intent.ACTION_POWER_DISCONNECTED))
    }

    private fun stopSensors() {
        h.removeCallbacks(proxConfirm)
        try { sm?.unregisterListener(this) } catch (e: Exception) {}
        try { chargerR?.let { unregisterReceiver(it) } } catch (e: Exception) {}
        chargerR = null
    }

    // ---------------- ট্রিগার, পিনের সময়, সাইরেন ----------------

    private fun trigger(reason: String) {
        if (PocketGuard.state != PocketGuard.S_ARMED) return
        val grace = cfg.optInt("grace", 5)
        PocketGuard.lastReason = reason
        PocketGuard.graceEndsAt = System.currentTimeMillis() + grace * 1000L
        PocketGuard.state = PocketGuard.S_GRACE
        stopSensors()
        PocketGuard.addLog(this, reason)
        if (cfg.optBoolean("photo", true)) {
            try { Intruder.snap(this, "পকেট গার্ড: $reason") } catch (e: Exception) {}
            h.postDelayed({
                if (PocketGuard.state >= PocketGuard.S_GRACE) {
                    try { Intruder.snap(this, "পকেট গার্ড: $reason (২য় ছবি)") } catch (e: Exception) {}
                }
            }, (grace + 7) * 1000L)
        }
        showAlert(reason)
        notifyRun("🚨 $reason। পিন না দিলে সাইরেন বাজবে")
        if (grace <= 0) startAlarm() else h.postDelayed({ startAlarm() }, grace * 1000L)
    }

    private fun startAlarm() {
        if (PocketGuard.state != PocketGuard.S_GRACE) return
        PocketGuard.state = PocketGuard.S_ALARM
        alarmStartedAt = System.currentTimeMillis()
        Siren.start(this)
        vibrateLoop()
        notifyRun("🚨 সাইরেন বাজছে: ${PocketGuard.lastReason}")
        alarmTick.run()
    }

    private val alarmTick = object : Runnable {
        override fun run() {
            if (PocketGuard.state != PocketGuard.S_ALARM) return
            Siren.enforce(this@PocketGuardService)
            if (System.currentTimeMillis() - alarmStartedAt > MAX_ALARM_MS) {
                Siren.stop(this@PocketGuardService)
                cancelVibrate()
                notifyRun("সাইরেন ১০ মিনিট বেজে থেমেছে। ট্যাপ করে পিন দিয়ে বন্ধ করুন")
                return
            }
            h.postDelayed(this, 1000)
        }
    }

    // ---------------- বন্ধ ----------------

    fun requestStop() {
        h.post { shutdown() }
    }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        stopSensors()
        Siren.stop(this)
        cancelVibrate()
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
        wl = null
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID_ALERT) } catch (e: Exception) {}
        PocketGuard.state = PocketGuard.S_OFF
        PocketGuard.proxActive = false
    }

    @Suppress("DEPRECATION")
    private fun shutdown() {
        cleanup()
        try { stopForeground(true) } catch (e: Exception) {}
        stopSelf()
    }

    // ---------------- নোটিফিকেশন, ভাইব্রেশন ----------------

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "পকেট গার্ড চালু", NotificationManager.IMPORTANCE_LOW))
        val alert = NotificationChannel(CH_ALERT, "পকেট গার্ড সতর্কতা", NotificationManager.IMPORTANCE_HIGH)
        alert.setSound(null, null)
        alert.enableVibration(false)
        alert.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(alert)
    }

    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun alarmPi(): PendingIntent {
        val i = Intent(this, PocketAlarmActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(this, 11, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildRun(text: String): Notification =
        builder(CH_RUN)
            .setContentTitle("🛡 পকেট গার্ড")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(alarmPi())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun notifyRun(text: String) {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_RUN, buildRun(text))
        } catch (e: Exception) {
        }
    }

    private fun showAlert(reason: String) {
        try {
            val pi = alarmPi()
            val n = builder(CH_ALERT)
                .setContentTitle("🚨 পকেট গার্ড: $reason")
                .setContentText("পিন দিয়ে বন্ধ করুন, নইলে সাইরেন বাজবে")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_ALERT, n)
        } catch (e: Exception) {
        }
    }

    private fun goForeground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                // 0x40000000 = specialUse, 0x40 = camera (ক্যামেরার অনুমতি থাকলেই, নইলে Android ক্র্যাশ করায়)
                var type = 0x40000000
                if (checkSelfPermission("android.permission.CAMERA") == PackageManager.PERMISSION_GRANTED) type = type or 0x40
                startForeground(ID_RUN, n, type)
            } else {
                startForeground(ID_RUN, n)
            }
        } catch (e: Exception) {
            try {
                if (Build.VERSION.SDK_INT >= 34) startForeground(ID_RUN, n, 0x40000000) else startForeground(ID_RUN, n)
            } catch (e2: Exception) {
                PocketGuard.state = PocketGuard.S_OFF
                stopSelf()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateLoop() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val pat = longArrayOf(0, 700, 250)
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pat, 0)) else v.vibrate(pat, 0)
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            else v.vibrate(ms)
        } catch (e: Exception) {
        }
    }

    private fun cancelVibrate() {
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (e: Exception) {}
    }
}
