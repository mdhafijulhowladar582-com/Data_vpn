package com.you.firewall

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** সাপ্তাহিক রিপোর্টের নোটিফিকেশন আর "ব্লক অ্যাপ হঠাৎ বেশি চেষ্টা করছে" সতর্কতা */
object Insights {
    fun bn(n: Int): String {
        val d = "০১২৩৪৫৬৭৮৯"
        return n.toString().map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
    }

    private fun hourName(h: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        val p = when {
            h < 4 -> "রাত"
            h < 6 -> "ভোর"
            h < 12 -> "সকাল"
            h < 15 -> "দুপুর"
            h < 18 -> "বিকাল"
            h < 20 -> "সন্ধ্যা"
            else -> "রাত"
        }
        return "$p ${bn(h12)}টা"
    }

    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    /**
     * প্রতি শুক্রবার রাত ৮টার পর একবার। ফোন বন্ধ ছিল বা সার্ভিস মরা ছিল বলে মিস হলে
     * শেষ রিপোর্টের ৮ দিন পরে সকাল ৯টা থেকে রাত ১০টার মধ্যে ধরে নেয়। (জব প্রতি ১৫ মিনিটে চলে)
     */
    fun weeklyCheck(c: Context) {
        val cfg = Store.load(c)
        if (!cfg.optBoolean("weeklyOn", true)) return
        val p = Store.prefs(c)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val today = todayKey()
        val lastDay = p.getString("weeklyDay", "") ?: ""
        val lastAt = p.getLong("weeklyAt", 0L)
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val friEve = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY && hour >= 20 && lastDay != today
        val catchUp = lastAt > 0 && now - lastAt >= 8L * 24 * 3600 * 1000 && hour in 9..22
        if (!friEve && !catchUp) return

        p.edit().putString("weeklyDay", today).putLong("weeklyAt", now).apply()
        val s = Stats.weekSummary(c)
        if (s.cur == 0 && s.prev == 0) return // জানানোর মতো কিছু নেই

        val lines = ArrayList<String>()
        var head = "এই সপ্তাহে ব্লক হওয়া অ্যাপ ${bn(s.cur)} বার নেটে ঢুকতে চেয়েছে"
        if (s.prev > 0) {
            val pct = Math.round((s.cur - s.prev) * 100.0 / s.prev).toInt()
            head += when {
                pct == 0 -> " (গত সপ্তাহের সমান)"
                pct < 0 -> " (গত সপ্তাহের চেয়ে ${bn(-pct)}% কম)"
                else -> " (গত সপ্তাহের চেয়ে ${bn(pct)}% বেশি)"
            }
        }
        lines.add(head)
        if (s.topPkg != null) {
            lines.add("সবচেয়ে বেশি: ${NetNotice.label(c, s.topPkg)} (${bn(s.topN)} বার)")
        }
        if (s.peak >= 0) lines.add("${hourName(s.peak)} নাগাদ সবচেয়ে বেশি চেষ্টা")
        lines.add("ট্যাপ করে পুরো রিপোর্ট দেখুন")
        Alert.report(c, 7710, "সাপ্তাহিক রিপোর্ট", lines.joinToString("\n"), "report")
    }

    /** ব্লক থাকা অ্যাপ হঠাৎ আগের গড়ের অনেক গুণ চেষ্টা করলে দিনে একবার জানায় */
    fun anomaly(c: Context, pkg: String, nToday: Int, avg: Int) {
        if (!Store.load(c).optBoolean("anomalyOn", true)) return
        val p = Store.prefs(c)
        val today = todayKey()
        val saved = p.getString("anomalySent", "") ?: ""
        val parts = saved.split("|")
        val sent = if (parts.size == 2 && parts[0] == today) parts[1].split(",").filter { it.isNotEmpty() }.toMutableSet()
        else mutableSetOf()
        if (pkg in sent) return
        sent.add(pkg)
        p.edit().putString("anomalySent", today + "|" + sent.joinToString(",")).apply()
        val usual = if (avg < 1) "আগের দিনগুলোতে প্রায় চেষ্টাই করেনি" else "সাধারণত দিনে প্রায় ${bn(avg)} বার"
        Alert.report(
            c, 8000 + (pkg.hashCode() and 0xfff),
            "${NetNotice.label(c, pkg)} বারবার নেটে ঢুকতে চাইছে",
            "ব্লক থাকা সত্ত্বেও আজ ${bn(nToday)} বার চেষ্টা করেছে, $usual। অ্যাপটা সন্দেহজনক হলে দেখে নিন।",
            "report"
        )
    }
}
