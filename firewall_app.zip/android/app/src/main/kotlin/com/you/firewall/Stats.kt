package com.you.firewall

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * ব্লক চেষ্টার গণনা। একটা অ্যাপের চেষ্টা ১ মিনিটে একটাই "ঘটনা"।
 * প্রতিটা ঘটনার সাথে ঘণ্টা (০-২৩) আর কারণ সেভ হয়। ৩০ দিন রাখে।
 *
 * সেভ করা ফরম্যাট: { "yyyy-MM-dd": { pkg: { "n": মোট, "h": {"ঘণ্টা": সংখ্যা}, "r": {"কারণ": সংখ্যা} } } }
 * আগের সংস্করণের শুধু-সংখ্যার এন্ট্রি (ফোলানো গণনা) বাদ দেওয়া হয়, যাতে তুলনা ভুল না হয়।
 */
object Stats {
    private const val KEEP_DAYS = 30
    private const val GAP_MS = 60_000L

    class E {
        var n = 0
        val h = IntArray(24)
        val r = HashMap<String, Int>()
    }

    private val lock = Any()
    private var loaded = false
    private val all = HashMap<String, HashMap<String, E>>()
    private val lastEvent = HashMap<String, Long>()
    private var dirty = false

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun ensure(c: Context) {
        if (loaded) return
        loaded = true
        try {
            val o = JSONObject(Store.prefs(c).getString("attempts", "{}") ?: "{}")
            for (d in o.keys()) {
                val m = HashMap<String, E>()
                val a = o.getJSONObject(d)
                for (p in a.keys()) {
                    val v = a.optJSONObject(p) ?: continue // পুরোনো ফরম্যাট বাদ
                    val e = E()
                    e.n = v.optInt("n")
                    val h = v.optJSONObject("h")
                    if (h != null) for (k in h.keys()) {
                        val i = k.toIntOrNull() ?: continue
                        if (i in 0..23) e.h[i] = h.optInt(k)
                    }
                    val r = v.optJSONObject("r")
                    if (r != null) for (k in r.keys()) e.r[k] = r.optInt(k)
                    if (e.n > 0) m[p] = e
                }
                if (m.isNotEmpty()) all[d] = m
            }
        } catch (e: Exception) {
        }
    }

    class WeekSummary(
        val cur: Int, val prev: Int, val prevDays: Int,
        val topPkg: String?, val topN: Int, val peak: Int
    )

    private fun keyAgo(i: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -i)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    /** আজ মোট কতটা ঘটনা (উইজেটের জন্য) */
    fun todayTotal(c: Context): Int {
        synchronized(lock) {
            ensure(c)
            var t = 0
            for ((_, e) in all[today()] ?: HashMap()) t += e.n
            return t
        }
    }

    /** শেষ ৭ দিন বনাম আগের ৭ দিন, শীর্ষ অ্যাপ আর সবচেয়ে ব্যস্ত ঘণ্টা */
    fun weekSummary(c: Context): WeekSummary {
        synchronized(lock) {
            ensure(c)
            val curKeys = (0..6).map { keyAgo(it) }
            val prevKeys = (7..13).map { keyAgo(it) }
            var cur = 0
            var prev = 0
            var prevDays = 0
            val per = HashMap<String, Int>()
            val hrs = IntArray(24)
            for (k in curKeys) {
                for ((p, e) in all[k] ?: HashMap()) {
                    cur += e.n
                    per[p] = (per[p] ?: 0) + e.n
                    for (i in 0..23) hrs[i] += e.h[i]
                }
            }
            for (k in prevKeys) {
                val m = all[k] ?: continue
                prevDays++
                for ((_, e) in m) prev += e.n
            }
            val top = per.entries.maxByOrNull { it.value }
            var peak = -1
            var mx = 0
            for (i in 0..23) if (hrs[i] > mx) { mx = hrs[i]; peak = i }
            return WeekSummary(cur, prev, prevDays, top?.key, top?.value ?: 0, peak)
        }
    }

    /**
     * আজকের গণনা আগের ৭ দিনের দৈনিক গড়ের ৫ গুণ (আর অন্তত ২০) হলে (গড়, আজকের সংখ্যা) ফেরত।
     * অন্তত ৩ দিনের তথ্য না জমলে চুপ থাকে।
     */
    private fun anomalyOf(pkg: String, nToday: Int): Int? {
        var histDays = 0
        var sum = 0
        for (i in 1..7) {
            val m = all[keyAgo(i)] ?: continue
            histDays++
            sum += m[pkg]?.n ?: 0
        }
        if (histDays < 3) return null
        val avg = sum / 7.0
        val thr = maxOf(20.0, avg * 5)
        return if (nToday >= thr) Math.round(avg).toInt() else null
    }

    /** reason শুধু তখনই হিসাব হয় যখন ঘটনাটা সত্যিই গোনা হবে (১ মিনিটের মধ্যে একই অ্যাপ হলে বাদ) */
    fun hit(c: Context, pkg: String, reason: () -> String) {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val l = lastEvent[pkg]
            if (l != null && now - l < GAP_MS) return
            lastEvent[pkg] = now
        }
        val code = try { reason() } catch (e: Exception) { "other" }
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        var nToday = 0
        var avg: Int? = null
        synchronized(lock) {
            ensure(c)
            val m = all.getOrPut(today()) { HashMap() }
            val e = m.getOrPut(pkg) { E() }
            e.n++
            e.h[hour]++
            e.r[code] = (e.r[code] ?: 0) + 1
            dirty = true
            nToday = e.n
            avg = anomalyOf(pkg, e.n)
        }
        val a = avg
        if (a != null) {
            try {
                Insights.anomaly(c, pkg, nToday, a)
            } catch (e: Exception) {
            }
        }
    }

    fun flush(c: Context) {
        synchronized(lock) {
            if (!dirty) return
            dirty = false
            val keep = all.keys.sortedDescending().take(KEEP_DAYS)
            all.keys.retainAll(keep.toSet())
            val o = JSONObject()
            for (d in keep) {
                val a = JSONObject()
                for ((p, e) in all[d] ?: HashMap()) {
                    val v = JSONObject()
                    v.put("n", e.n)
                    val h = JSONObject()
                    for (i in 0..23) if (e.h[i] > 0) h.put(i.toString(), e.h[i])
                    v.put("h", h)
                    val r = JSONObject()
                    for ((k, n) in e.r) r.put(k, n)
                    v.put("r", r)
                    a.put(p, v)
                }
                o.put(d, a)
            }
            Store.prefs(c).edit().putString("attempts", o.toString()).apply()
        }
    }

    /** [{day, apps:[{pkg, n, h:[২৪টা সংখ্যা], r:{কারণ: সংখ্যা}}]}] নতুন দিন আগে, সর্বোচ্চ ৩০ দিন */
    fun snapshot(c: Context): List<Map<String, Any>> {
        synchronized(lock) {
            ensure(c)
            return all.keys.sortedDescending().take(KEEP_DAYS).map { d ->
                mapOf(
                    "day" to d,
                    "apps" to (all[d] ?: HashMap()).map {
                        mapOf(
                            "pkg" to it.key,
                            "n" to it.value.n,
                            "h" to it.value.h.toList(),
                            "r" to HashMap(it.value.r)
                        )
                    }
                )
            }
        }
    }
}
