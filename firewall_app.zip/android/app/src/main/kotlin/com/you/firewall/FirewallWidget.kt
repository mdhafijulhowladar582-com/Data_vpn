package com.you.firewall

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.view.View
import android.widget.RemoteViews

/**
 * হোম স্ক্রিন উইজেট: চালু/বন্ধ অবস্থা, আজকের ব্লক চেষ্টা আর এক ট্যাপের বোতাম।
 * বন্ধ করার নিয়ম কুইক টাইলের মতোই: পিন সেট থাকলে আগে পিন/ফিঙ্গারপ্রিন্ট, ফোকাস চললে বন্ধ হয় না।
 */
class FirewallWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        try {
            m.updateAppWidget(ids, build(c))
        } catch (e: Exception) {
        }
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION_TOGGLE) {
            toggle(c)
            refresh(c)
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.you.firewall.WIDGET_TOGGLE"

        private fun id(c: Context, name: String): Int =
            c.resources.getIdentifier(name, "id", c.packageName)

        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, FirewallWidget::class.java))
                if (ids.isEmpty()) return
                m.updateAppWidget(ids, build(c))
            } catch (e: Exception) {
            }
        }

        /** শুধু পিনহীন পথে আসে। পিন থাকলে বোতাম LockActivity খোলে, তাই এখানে বন্ধ হয় না */
        private fun toggle(c: Context) {
            if (FirewallVpnService.running) {
                if (Store.focusActive(c)) return
                if (Store.load(c).optString("pinHash").isNotEmpty()) return
                FirewallVpnService.stop(c)
            } else if (VpnService.prepare(c) == null) {
                FirewallVpnService.start(c)
            }
        }

        private const val PI_FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
            c, 13, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PI_FLAGS
        )

        private fun toggleBroadcast(c: Context): PendingIntent = PendingIntent.getBroadcast(
            c, 11, Intent(c, FirewallWidget::class.java).setAction(ACTION_TOGGLE), PI_FLAGS
        )

        private fun lockStop(c: Context): PendingIntent = PendingIntent.getActivity(
            c, 12,
            Intent(c, LockActivity::class.java).putExtra("stopFw", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PI_FLAGS
        )

        private fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, c.resources.getIdentifier("widget_firewall", "layout", c.packageName))
            val running = FirewallVpnService.running
            val focus = Store.focusActive(c)
            val pin = Store.load(c).optString("pinHash").isNotEmpty()
            val status = id(c, "w_status")
            val count = id(c, "w_count")
            val on = id(c, "w_btn_on")
            val off = id(c, "w_btn_off")

            v.setTextViewText(status, if (running) "চালু" else "বন্ধ")
            v.setTextColor(status, if (running) Color.parseColor("#66BB6A") else Color.parseColor("#EF5350"))
            v.setTextViewText(count, "আজ ব্লক চেষ্টা: ${Insights.bn(Stats.todayTotal(c))}")

            if (running) {
                v.setViewVisibility(on, View.GONE)
                v.setViewVisibility(off, View.VISIBLE)
                when {
                    focus -> {
                        v.setTextViewText(off, "ফোকাস চলছে")
                        v.setOnClickPendingIntent(off, openApp(c))
                    }
                    pin -> {
                        v.setTextViewText(off, "বন্ধ (পিন)")
                        v.setOnClickPendingIntent(off, lockStop(c))
                    }
                    else -> {
                        v.setTextViewText(off, "বন্ধ করুন")
                        v.setOnClickPendingIntent(off, toggleBroadcast(c))
                    }
                }
            } else {
                v.setViewVisibility(off, View.GONE)
                v.setViewVisibility(on, View.VISIBLE)
                // VPN অনুমতি না থাকলে আগে অ্যাপ খুলতে হবে
                v.setOnClickPendingIntent(
                    on, if (VpnService.prepare(c) == null) toggleBroadcast(c) else openApp(c)
                )
            }
            v.setOnClickPendingIntent(id(c, "w_root"), openApp(c))
            return v
        }
    }
}
