package com.you.firewall

import android.app.Activity
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle

/**
 * Work Profile তৈরির অংশ। এখানে শুধু প্রোফাইল বানানো আর যাচাই; অ্যাপ সরানো আলাদা ধাপ।
 * প্রোফাইল তৈরি শেষে সিস্টেম এই রিসিভার প্রোফাইলের ভেতরে চালায়।
 */
class FwAdminReceiver : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val cn = ComponentName(context, FwAdminReceiver::class.java)
            dpm.setProfileName(cn, "Firewall লুকানো")
            dpm.setProfileEnabled(cn)
        } catch (_: Exception) {
        }
    }
}

/** Android 10+: সিস্টেম জিজ্ঞেস করে কোন মোডে সেটআপ হবে। আমরা বলি Work Profile (২)। */
class WpModeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_OK, Intent().putExtra("android.app.extra.PROVISIONING_MODE", 2))
        finish()
    }
}

/** Android 11+: সেটআপের শেষ ধাপে সিস্টেম এটা খোলে। আমাদের আলাদা কোনো শর্ত নেই, তাই সরাসরি OK। */
class WpComplianceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_OK)
        finish()
    }
}

object WorkProfile {
    fun admin(c: Context) = ComponentName(c, FwAdminReceiver::class.java)

    /** এই ফোনে ইউজারের কয়টা প্রোফাইল দেখা যায় (মূলটা সহ) */
    fun profileCount(c: Context): Int = try {
        (c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps).profiles.size
    } catch (e: Exception) {
        1
    }

    fun provisionIntent(c: Context): Intent =
        Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
            .putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin(c))

    /** state = "ready" | "unsupported"; reason কারণের কোড; profiles = এখনকার প্রোফাইল সংখ্যা */
    fun state(c: Context): Map<String, Any> {
        val n = profileCount(c)
        fun no(r: String): Map<String, Any> = mapOf("state" to "unsupported", "reason" to r, "profiles" to n)
        if (Build.VERSION.SDK_INT < 24) return no("android_old")
        if (!c.packageManager.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)) return no("no_feature")
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val allowed = try {
            dpm.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
        } catch (e: Exception) {
            false
        }
        if (!allowed) return no(if (n > 1) "not_allowed_has_profile" else "not_allowed")
        if (provisionIntent(c).resolveActivity(c.packageManager) == null) return no("no_screen")
        return mapOf("state" to "ready", "reason" to "", "profiles" to n)
    }
}
