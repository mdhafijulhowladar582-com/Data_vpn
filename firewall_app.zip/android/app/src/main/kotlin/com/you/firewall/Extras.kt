package com.you.firewall

import android.app.PendingIntent
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** তিনটা ফিচারের কনফিগ সবই Ctl-এর "fw_ctl"-এ (Dart-এর কনফিগ সেভে মুছে যায় না) */
private fun cfgOf(c: Context, name: String): JSONObject = try {
    JSONObject(Ctl.get(c, name))
} catch (e: Exception) {
    JSONObject()
}

private fun strs(j: JSONObject, k: String): List<String> {
    val a = j.optJSONArray(k) ?: return emptyList()
    return (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
}

private fun hm(m: Int) = String.format("%02d:%02d", (m / 60) % 24, m % 60)

// ======================= ট্রেড টাইম গার্ড =======================

/**
 * ট্রেডের সময়সীমা (from..to) আর "বিরক্তিকর" অ্যাপের তালিকা। বাছা অ্যাপ ট্রেডের বাইরে (বা ইচ্ছে হলে ভেতরে)
 * খুললেই GuardService "ট্রেড টাইম গার্ড" স্ক্রিন দেখিয়ে হোমে পাঠায়।
 * ট্রেডের ভেতরে "শুধু ট্রেডিং অ্যাপ নেট পাবে" অংশটা অটোমেশন (মোড) দিয়ে চলে, Dart পেজ সেটা বসিয়ে দেয়।
 */
object TradeTime {
    const val CFG = "ttg"

    private fun nowMin(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    private fun inWin(from: Int, to: Int, now: Int): Boolean =
        if (from == to) false else if (from < to) now in from until to else (now >= from || now < to)

    fun windowText(c: Context): String {
        val j = cfgOf(c, CFG)
        return hm(j.optInt("from", 20 * 60)) + " – " + hm(j.optInt("to", 23 * 60))
    }

    fun reason(c: Context, pkg: String): String? {
        val j = cfgOf(c, CFG)
        if (!j.optBoolean("on")) return null
        if (pkg !in strs(j, "block")) return null
        val inside = inWin(j.optInt("from", 20 * 60), j.optInt("to", 23 * 60), nowMin())
        val whenIn = j.optString("blockWhen", "out") == "in"
        return if (whenIn == inside) "ttg" else null
    }
}

// ======================= রাতের ডেটা চোর =======================

/**
 * রাতে (২১:০০–০৫:৫৯ এ স্ক্রিন বন্ধ হলে) স্ক্রিন বন্ধ থাকা সময়ে কোন অ্যাপ কত ডেটা খেল তা জমায়।
 * সকালে (০৫:০০–১১:৫৯) প্রথমবার স্ক্রিন চালু হলে ছোট রিপোর্ট নোটিফিকেশন, ওখান থেকেই ব্লক।
 * স্ক্রিন চালু/বন্ধের খবর ফায়ারওয়াল (VPN) সার্ভিস দেয়, তাই ফায়ারওয়াল বন্ধ থাকলে কিছু জমে না।
 * মাপে NetworkStatsManager (ইউসেজ অ্যাক্সেস লাগে)। ঘণ্টাভিত্তিক হিসাব, তাই সংখ্যা আনুমানিক।
 */
object NightWatch {
    const val CFG = "night"
    const val ID_REPORT = 7421
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_night", Context.MODE_PRIVATE)

    fun enabled(c: Context) = cfgOf(c, CFG).optBoolean("on", true)
    private fun minBytes(c: Context) = cfgOf(c, CFG).optInt("minMb", 5).coerceIn(1, 500) * 1048576L

    private fun hourOf(t: Long): Int {
        val cal = Calendar.getInstance()
        cal.timeInMillis = t
        return cal.get(Calendar.HOUR_OF_DAY)
    }

    private fun dayKey(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}"
    }

    /** uid -> মোট (নামানো + পাঠানো) বাইট, [from] থেকে এখন পর্যন্ত। ইউসেজ অ্যাক্সেস না থাকলে null */
    private fun totals(c: Context, from: Long): HashMap<Int, Long>? = try {
        val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val to = System.currentTimeMillis()
        val m = HashMap<Int, Long>()
        var ok = false
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            val st = try {
                nsm.querySummary(type, null, from, to)
            } catch (e: Exception) {
                continue
            }
            ok = true
            val b = NetworkStats.Bucket()
            while (st.hasNextBucket()) {
                st.getNextBucket(b)
                if (b.uid < 10000) continue
                m[b.uid] = (m[b.uid] ?: 0L) + b.rxBytes + b.txBytes
            }
            st.close()
        }
        if (ok) m else null
    } catch (e: Exception) {
        null
    }

    fun screenOff(c: Context) {
        if (!enabled(c)) return
        val ctx = c.applicationContext
        Thread {
            try {
                val now = System.currentTimeMillis()
                val t0 = now - 48L * 3600000L
                val m = totals(ctx, t0) ?: return@Thread
                val snap = JSONObject()
                for ((u, v) in m) snap.put(u.toString(), v)
                synchronized(this) {
                    sp(ctx).edit().putString("snap", JSONObject().put("off", now).put("t0", t0).put("m", snap).toString()).apply()
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    fun screenOn(c: Context) {
        if (!enabled(c)) return
        val ctx = c.applicationContext
        Thread {
            try {
                process(ctx)
            } catch (e: Exception) {
            }
        }.start()
    }

    @Synchronized
    private fun process(ctx: Context) {
        val sp = sp(ctx)
        val now = System.currentTimeMillis()
        val raw = sp.getString("snap", null)
        if (raw != null) {
            sp.edit().remove("snap").apply()
            val s = JSONObject(raw)
            val off = s.optLong("off")
            val h = hourOf(off)
            if ((h >= 21 || h < 6) && now - off < 16L * 3600000L) {
                val before = s.optJSONObject("m") ?: JSONObject()
                val cur = totals(ctx, s.optLong("t0"))
                if (cur != null) {
                    val acc = try {
                        JSONObject(sp.getString("acc", "{}") ?: "{}")
                    } catch (e: Exception) {
                        JSONObject()
                    }
                    for ((uid, v) in cur) {
                        val d = v - before.optLong(uid.toString(), 0L)
                        if (d <= 0L) continue
                        val pk = ctx.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: continue
                        if (pk == ctx.packageName) continue
                        acc.put(pk, acc.optLong(pk, 0L) + d)
                    }
                    sp.edit().putString("acc", acc.toString()).apply()
                    if (!sp.contains("accSince")) sp.edit().putLong("accSince", off).apply()
                }
            }
        }
        // স্ক্রিন চালু হয়েছে সকালে? তাহলে রিপোর্ট
        val hour = hourOf(now)
        if (hour in 5..11 && sp.getString("reportDay", "") != dayKey()) {
            report(ctx)
        }
        // জমানো হিসাব ৩৬ ঘণ্টার বেশি পুরনো হলে ফেলে দিই
        if (now - sp.getLong("accSince", now) > 36L * 3600000L) {
            sp.edit().remove("acc").remove("accSince").apply()
        }
    }

    private fun accList(c: Context): List<Pair<String, Long>> {
        val acc = try {
            JSONObject(sp(c).getString("acc", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        return acc.keys().asSequence().map { it to acc.optLong(it, 0L) }.sortedByDescending { it.second }.toList()
    }

    private fun report(ctx: Context) {
        val list = accList(ctx)
        val total = list.sumOf { it.second }
        val sp = sp(ctx)
        sp.edit().putString("reportDay", dayKey()).apply()
        if (total >= minBytes(ctx) && list.isNotEmpty()) {
            val top = list.take(3)
            val items = JSONArray()
            for ((p, b) in top) items.put(JSONObject().put("pkg", p).put("bytes", b))
            sp.edit().putString("last", JSONObject().put("t", System.currentTimeMillis()).put("total", total).put("items", items).toString()).apply()
            val text = StringBuilder("গত রাতে স্ক্রিন বন্ধ থাকতে মোট ${Safety.fmtBytes(total)} গেছে।\n")
            for ((p, b) in top) text.append("• ${NetNotice.label(ctx, p)}: ${Safety.fmtBytes(b)}\n")
            text.append("আপনি না চালালে সন্দেহজনক অ্যাপ ব্লক করে দিন।")
            val open = PendingIntent.getActivity(
                ctx, ID_REPORT,
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("route", "night_watch"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val actions = ArrayList<Pair<String, PendingIntent>>()
            top.take(2).forEachIndexed { i, (p, _) ->
                actions.add(Pair("ব্লক: " + NetNotice.label(ctx, p), Safety.action(ctx, ID_REPORT, i, "NIGHT_BLOCK", p)))
            }
            Safety.post(ctx, ID_REPORT, "fws_night", "রাতের ডেটা রিপোর্ট", "রাতের ডেটা রিপোর্ট", text.toString().trim(), open, actions)
        }
        sp.edit().remove("acc").remove("accSince").apply()
    }

    /** পেজের জন্য: এখন পর্যন্ত জমা (রিপোর্টের অপেক্ষায়) আর শেষ রিপোর্ট */
    fun info(c: Context): Map<String, Any?> {
        val acc = accList(c).take(10).map {
            mapOf("pkg" to it.first, "name" to NetNotice.label(c, it.first), "bytes" to it.second)
        }
        val last = try {
            val o = JSONObject(sp(c).getString("last", "") ?: "")
            mapOf(
                "t" to o.optLong("t"), "total" to o.optLong("total"),
                "items" to (0 until (o.optJSONArray("items")?.length() ?: 0)).map {
                    val x = o.getJSONArray("items").getJSONObject(it)
                    mapOf("pkg" to x.optString("pkg"), "name" to NetNotice.label(c, x.optString("pkg")), "bytes" to x.optLong("bytes"))
                }
            )
        } catch (e: Exception) {
            null
        }
        val cfg = cfgOf(c, CFG)
        return mapOf(
            "on" to cfg.optBoolean("on", true), "minMb" to cfg.optInt("minMb", 5),
            "acc" to acc, "last" to last, "fwRunning" to FirewallVpnService.running
        )
    }
}

// ======================= ফোন ঠান্ডা মোড =======================

/**
 * ফোন গরম হলে (বা ব্যাটারি কমে গেলে) ব্যাকগ্রাউন্ড অ্যাপের নেট নিজে বন্ধ। যে অ্যাপ এখন সামনে, জরুরি তালিকায়
 * বা ছাড়ের তালিকায় আছে, তার নেট বন্ধ হয় না। সামনের অ্যাপ চেনে অ্যাপ গার্ড (অ্যাক্সেসিবিলিটি), তাই সেটা চালু থাকা চাই।
 * ঠান্ডা হলে আর চার্জে লাগলে নিজে বন্ধ হয়ে যায়। কনফিগের মালিক Kotlin, কোনো স্থায়ী ব্লক নিয়মে হাত দেয় না।
 */
object CoolMode {
    const val CFG = "cool"
    @Volatile var active = false
    @Volatile var reason = ""

    private fun batt(c: Context): IntArray {
        // [তাপমাত্রা (দশমিক ডিগ্রি), ব্যাটারি %, চার্জে আছে? 1/0]
        val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return intArrayOf(-1, -1, 0)
        val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
        val plug = if (bi.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0) 1 else 0
        return intArrayOf(temp, pct, plug)
    }

    private fun thermal(c: Context): Int = try {
        if (Build.VERSION.SDK_INT >= 29) (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else -1
    } catch (e: Exception) {
        -1
    }

    /** VPN-এর ৩০ সেকেন্ডের tick থেকে। অবস্থা বদলালে ফায়ারওয়ালের নিয়ম নতুন করে বসে */
    fun onTick(c: Context) {
        val ctx = c.applicationContext
        val j = cfgOf(ctx, CFG)
        if (!j.optBoolean("on")) {
            if (active) {
                active = false
                reason = ""
                FirewallVpnService.reload(ctx)
            }
            return
        }
        val limit = j.optInt("tempC", 40).coerceIn(32, 55) * 10
        val lowPct = j.optInt("lowPct", 15).coerceIn(5, 50)
        val onHot = j.optBoolean("onHot", true)
        val onLow = j.optBoolean("onLow", true)
        val b = batt(ctx)
        val th = thermal(ctx)
        val hotNow = onHot && ((b[0] >= limit) || Sampler.overheatNow || th >= 3)
        val lowNow = onLow && b[2] == 0 && b[1] in 0..lowPct
        // একবার চালু হলে একটু ঠান্ডা/চার্জ না হওয়া পর্যন্ত থাকে (বারবার চালু-বন্ধ ঠেকাতে)
        val hotKeep = onHot && active && ((b[0] > limit - 30) || Sampler.overheatNow || th >= 2)
        val lowKeep = onLow && active && b[2] == 0 && b[1] in 0..(lowPct + 4)
        val want = hotNow || lowNow || hotKeep || lowKeep
        if (want != active) {
            active = want
            reason = if (hotNow || hotKeep) "ফোন গরম" else if (lowNow || lowKeep) "ব্যাটারি কম" else ""
            FirewallVpnService.reload(ctx)
            if (want) {
                XNotify.show(
                    ctx, 7430, "ঠান্ডা মোড চালু ($reason)",
                    "সামনে নেই এমন অ্যাপের নেট বন্ধ করা হয়েছে। ফোন ঠিক হলে নিজে ফিরবে।", "cool_mode"
                )
            }
        }
    }

    /** যেসব অ্যাপের নেট এখন বন্ধ রাখতে হবে। অ্যাপ গার্ড বন্ধ থাকলে সামনের অ্যাপ বোঝা যায় না, তাই কিছুই করে না */
    fun extra(c: Context): Set<String> {
        if (!active || !GuardService.connected) return emptySet()
        val j = cfgOf(c, CFG)
        val keep = HashSet<String>()
        keep.addAll(strs(j, "exempt"))
        keep.addAll(Store.emergency(c))
        keep.add(c.packageName)
        GuardService.fgNow?.let { keep.add(it) }
        val out = HashSet<String>()
        try {
            for (ai in c.packageManager.getInstalledApplications(0)) {
                val p = ai.packageName
                if (p in keep) continue
                if ((ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) continue // সিস্টেম অ্যাপে হাত না
                out.add(p)
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun info(c: Context): Map<String, Any?> {
        val b = batt(c)
        val j = cfgOf(c, CFG)
        return mapOf(
            "on" to j.optBoolean("on"), "active" to active, "reason" to reason,
            "temp" to b[0], "batt" to b[1], "charging" to (b[2] == 1),
            "guard" to GuardService.connected, "fwRunning" to FirewallVpnService.running
        )
    }
}
