package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.log10

/**
 * তিনটা নতুন আলাদা সার্ভিসের সেটিংস ও কমন কাজ:
 *  - "lazy" = আলসে-লক (LazyService)
 *  - "beat" = নেট-হার্টবিট (BeatService)
 *  - "pet"  = ডেটা-পোষা (PetService)
 *  - "sense" = সেন্সর-পোষা (SenseService, SensorHub.kt): উল্টো রাখলে ফোকাস, ঝাঁকালে লাফ, অন্ধকারে ঘুম
 * প্রতিটার অন/অফ আলাদা। স্ক্রিনের ওপর আঁকার জন্য "অন্য অ্যাপের ওপর দেখানো" পারমিশন লাগে (বাবলের মতোই)।
 */
object Buddy {
    val KEYS = listOf("lazy", "beat", "pet", "sense")
    private val INT_OPTS = mapOf("lazyMin" to 45, "lazySteps" to 20, "senseFlipMin" to 25)
    private val BOOL_OPTS = mapOf("beatVib" to true, "senseFlip" to true, "senseShake" to true, "senseDark" to true, "senseSummary" to true)

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_buddy", Context.MODE_PRIVATE)

    fun on(c: Context, key: String): Boolean = sp(c).getBoolean(key, false)
    fun int(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun long(c: Context, key: String, def: Long): Long = sp(c).getLong(key, def)
    fun bool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun putInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun putLong(c: Context, key: String, v: Long) = sp(c).edit().putLong(key, v).apply()
    fun putOff(c: Context, key: String) = sp(c).edit().putBoolean(key, false).apply()


    // ---------------- পোষার রূপ, স্ট্রিক আর কোড ----------------

    /** রেফার কোডের SHA-256 (কোড সরাসরি লেখা নেই) */
    private const val CODE_SHA = "4b6f9b096fb0b2c368bfaa4ae10c6bde2e0b06b07c09f41a324a8f427771e20a"

    private val FORMS = listOf(
        "ছানা", "বাচ্চা", "কিশোর", "তরুণ", "সাহসী", "বীর",
        "যোদ্ধা", "জ্ঞানী", "রাজা", "মহারাজ", "দেবতা", "কিংবদন্তি"
    )

    /** কোড ঠিক হলে পোষা সুরক্ষিত: স্ট্রিক ভাঙে না, স্বাস্থ্য কমে না, বাড়ার কোনো সীমা নেই */
    fun applyCode(c: Context, code: String): Boolean {
        val h = MessageDigest.getInstance("SHA-256").digest(code.trim().toByteArray())
            .joinToString("") { "%02x".format(it) }
        if (h != CODE_SHA) return false
        sp(c).edit().putBoolean("petCode", true).apply()
        return true
    }

    fun codeOn(c: Context): Boolean = bool(c, "petCode", false)

    /** প্রতি ৯০ দিনে একটা বড় রূপ। ১২ রূপে প্রায় ৩ বছর, তারপর নাম ঘুরে আসে (২য় চক্র, ৩য় চক্র...) */
    fun petTier(streak: Int): Int = streak / 90

    fun petForm(streak: Int): String {
        val t = petTier(streak)
        val name = FORMS[t % FORMS.size]
        val cycle = t / FORMS.size
        return if (cycle == 0) name else "$name (${Insights.bn(cycle + 1)}য় চক্র)"
    }

    /** আকার ধীরে বাড়ে: ৭৬dp থেকে ১৪০dp, ১৮০০ দিনে (প্রায় ৫ বছর) পুরো আকার */
    fun petSizeDp(streak: Int): Int = 76 + minOf(streak, 1800) * 64 / 1800

    /** প্রতি ৭ দিনে নতুন সাজ (০ = সাজ নেই, ১-৬ = ছয় রকম), ঘুরে ঘুরে আসে */
    fun petAccessory(streak: Int): Int = (streak / 7) % 7

    /** প্রতি বড় রূপে রঙ ঘোরে */
    fun petHue(streak: Int): Int = (petTier(streak) * 47) % 360

    /** স্পিড (বাইট/সেকেন্ড) থেকে হার্টবিটের হার */
    fun bpmFor(bps: Float): Float {
        val k = (log10(1f + bps / 1024f) / 3f).coerceIn(0f, 1f)
        return 38f + 72f * k
    }

    fun fmtSpeed(bps: Float): String = when {
        bps < 1024f -> "${bps.toInt()} B/s"
        bps < 1024f * 1024f -> "${(bps / 1024f).toInt()} KB/s"
        else -> String.format("%.1f MB/s", bps / (1024f * 1024f))
    }

    fun canDraw(c: Context): Boolean = Bubbles.canDraw(c)
    fun openPermission(c: Context): Boolean = Bubbles.openPermission(c)

    private fun cls(key: String): Class<*> = when (key) {
        "lazy" -> LazyService::class.java
        "beat" -> BeatService::class.java
        "sense" -> SenseService::class.java
        else -> PetService::class.java
    }

    private fun startSvc(ctx: Context, key: String) {
        val i = Intent(ctx, cls(key))
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    }

    /** সার্ভিস চালু/বন্ধ। পারমিশন না থাকলে false (সুইচ বন্ধই থাকে) */
    fun set(c: Context, key: String, on: Boolean): Boolean {
        if (key !in KEYS) return false
        val ctx = c.applicationContext
        if (on && !canDraw(ctx)) {
            putOff(ctx, key)
            return false
        }
        sp(ctx).edit().putBoolean(key, on).apply()
        return try {
            if (on) startSvc(ctx, key) else ctx.stopService(Intent(ctx, cls(key)))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun setOpt(c: Context, key: String, value: Int) {
        val e = sp(c).edit()
        if (INT_OPTS.containsKey(key)) e.putInt(key, value.coerceIn(1, 1000))
        else if (BOOL_OPTS.containsKey(key)) e.putBoolean(key, value != 0)
        e.apply()
    }

    /** রিবুটের পর চালু থাকা সার্ভিস ফেরানো */
    fun restore(c: Context) {
        for (k in KEYS) {
            if (on(c, k) && canDraw(c)) {
                try {
                    startSvc(c.applicationContext, k)
                } catch (e: Exception) {
                }
            }
        }
    }

    fun state(c: Context): Map<String, Any> = mapOf(
        "canDraw" to canDraw(c),
        "lazy" to on(c, "lazy"),
        "beat" to on(c, "beat"),
        "pet" to on(c, "pet"),
        "sense" to on(c, "sense"),
        "senseFlip" to bool(c, "senseFlip", true),
        "senseShake" to bool(c, "senseShake", true),
        "senseDark" to bool(c, "senseDark", true),
        "senseFlipMin" to int(c, "senseFlipMin", 25),
        "senseSummary" to bool(c, "senseSummary", true),
        "sleepList" to SleepLog.asList(c, 7),
        "sleepAvg" to SleepLog.avg7(c),
        "senseRun" to SenseService.running,
        "lazyMin" to int(c, "lazyMin", 45),
        "lazySteps" to int(c, "lazySteps", 20),
        "beatVib" to bool(c, "beatVib", true),
        "petHealth" to int(c, "petHealth", 50),
        "petUsedMb" to int(c, "petUsedMb", 0),
        "petAllowMb" to int(c, "petAllowMb", 0),
        "sitMin" to (LazyService.sitMs / 60000L).toInt(),
        "steps" to LazyService.stepsTotal,
        "petStreak" to int(c, "petStreak", 0),
        "petCode" to codeOn(c),
        "petForm" to petForm(int(c, "petStreak", 0)),
        "petNext" to (7 - int(c, "petStreak", 0) % 7),
        "lazyRun" to LazyService.running,
        "beatRun" to BeatService.running,
        "petRun" to PetService.running,
    )

    @Suppress("DEPRECATION")
    fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    /** ফোরগ্রাউন্ড নোটিফিকেশন (সবচেয়ে কম গুরুত্বের, চুপচাপ) */
    fun foreground(s: Service, id: Int, ch: String, chName: String, title: String, text: String, route: String) {
        val nm = s.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(ch, chName, NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(
            s, id,
            Intent(s, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("route", route),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(s, ch) else Notification.Builder(s)
        val n = b.setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) s.startForeground(id, n, 0x40000000) else s.startForeground(id, n)
        } catch (e: Exception) {
        }
    }

    /** ভাসমান ভিউ টেনে সরানো; ছেড়ে দিলে জায়গা মনে রাখে। না টেনে চাপলে [onTap] */
    fun drag(
        ctx: Context, wm: WindowManager, v: View, lp: WindowManager.LayoutParams,
        keyX: String, keyY: String, snapEdge: Boolean, onTap: () -> Unit
    ) {
        val dm = ctx.resources.displayMetrics
        val slop = 6 * dm.density
        v.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f
            var dy = 0f
            var sx = 0
            var sy = 0
            var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = e.rawX
                        dy = e.rawY
                        sx = lp.x
                        sy = lp.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val ox = e.rawX - dx
                        val oy = e.rawY - dy
                        if (!moved && (abs(ox) > slop || abs(oy) > slop)) moved = true
                        if (moved) {
                            lp.x = (sx + ox).toInt().coerceIn(0, maxOf(0, dm.widthPixels - lp.width))
                            lp.y = (sy + oy).toInt().coerceIn(0, maxOf(0, dm.heightPixels - lp.height))
                            try {
                                wm.updateViewLayout(view, lp)
                            } catch (e2: Exception) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            onTap()
                        } else {
                            if (snapEdge) {
                                lp.x = if (lp.x + lp.width / 2 < dm.widthPixels / 2) 0 else maxOf(0, dm.widthPixels - lp.width)
                                try {
                                    wm.updateViewLayout(view, lp)
                                } catch (e2: Exception) {
                                }
                            }
                            putInt(ctx, keyX, lp.x)
                            putInt(ctx, keyY, lp.y)
                        }
                        return true
                    }
                }
                return false
            }
        })
    }
}
