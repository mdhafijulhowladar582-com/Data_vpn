package com.you.firewall

import android.content.ContentValues
import android.content.Context
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * কানেকশন লগ: ইঞ্জিনের ভেতর দিয়ে যাওয়া প্রতিটা TCP/UDP সংযোগের অ্যাপ, গন্তব্য (ডোমেইনসহ) ও বাইট।
 * ডোমেইন আসে তিন উপায়ে: TLS ClientHello-র SNI, HTTP-র Host লাইন, না হলে আগের DNS উত্তরের IP→নাম।
 * লেখা হয় ব্যাচে (৪০টা জমলে বা ৩০ সেকেন্ডের tick-এ)। চলমান সংযোগের বাইট tick-এ আংশিক সারি হিসেবে যায়।
 * শুধু ইঞ্জিনের অ্যাপ (engineApps) ধরা পড়ে, বাকি অ্যাপ VPN-এর ভেতর দিয়ে যায় না।
 */
object ConnLog {
    private class Row(
        val t: Long, val pkg: String, val host: String?, val ip: String,
        val port: Int, val up: Long, val down: Long, val fg: Int
    )

    private val queue = ConcurrentLinkedQueue<Row>()
    private val queued = java.util.concurrent.atomic.AtomicInteger(0)
    private val active: MutableSet<Flow> = ConcurrentHashMap.newKeySet()
    private val ipName = ConcurrentHashMap<String, String>()
    private val pkgCache = ConcurrentHashMap<Int, String>()
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r).also { it.isDaemon = true } }
    private val flushing = AtomicBoolean(false)
    @Volatile private var appCtx: Context? = null

    // ---------------- ইঞ্জিন থেকে ডাকা হয় ----------------

    /** নতুন সংযোগ শুরু। uid না জানা গেলে লগ হয় না (null) */
    fun start(c: Context, uid: Int, ip: String?, port: Int): Flow? {
        if (uid < 0 || ip == null) return null
        val ctx = c.applicationContext
        appCtx = ctx
        val f = Flow(pkgOf(ctx, uid), ip, port)
        active.add(f)
        return f
    }

    /** DNS উত্তর থেকে IP→নাম মনে রাখা, পরে ওই IP-তে সংযোগ এলে ডোমেইন বোঝা যাবে */
    fun onDns(name: String, reply: ByteArray) {
        try {
            if (reply.size < 12) return
            if ((reply[3].toInt() and 0x0F) != 0) return // ত্রুটির উত্তর
            val an = u16(reply, 6)
            if (an <= 0) return
            var i = skipName(reply, 12)
            if (i < 0) return
            i += 4 // প্রশ্নের type + class
            var n = 0
            while (n < an && i < reply.size) {
                i = skipName(reply, i)
                if (i < 0 || i + 10 > reply.size) return
                val type = u16(reply, i)
                val rdlen = u16(reply, i + 8)
                val d = i + 10
                if (d + rdlen > reply.size) return
                if (type == 1 && rdlen == 4) {
                    val ip = (reply[d].toInt() and 255).toString() + "." +
                        (reply[d + 1].toInt() and 255) + "." +
                        (reply[d + 2].toInt() and 255) + "." +
                        (reply[d + 3].toInt() and 255)
                    if (ipName.size > 4000) ipName.clear()
                    ipName[ip] = name.lowercase().trimEnd('.')
                }
                i = d + rdlen
                n++
            }
        } catch (e: Exception) {
        }
    }

    /** ৩০ সেকেন্ডের tick থেকে: চলমান সংযোগের জমা বাইট লেখা, তারপর ব্যাচ ডিস্কে */
    fun onTick(c: Context) {
        for (f in active) f.partial()
        flushAsync(c.applicationContext)
    }

    class Flow(private val pkg: String, private val ip: String, private val port: Int) {
        private val up = AtomicLong()
        private val down = AtomicLong()
        private val fg: Int = if (GuardService.fgNow == pkg) 1 else 0
        private val done = AtomicBoolean(false)
        private var buf: ByteArray? = null
        @Volatile private var sni: String? = null
        @Volatile private var sniDone = false

        fun addUp(n: Int) {
            up.addAndGet(n.toLong())
        }

        fun addDown(n: Int) {
            down.addAndGet(n.toLong())
        }

        /** অ্যাপের পাঠানো প্রথম কয়েকটা সেগমেন্ট থেকে সাইটের নাম পড়া (শুধু রিডার থ্রেড ডাকে) */
        fun onClientData(d: ByteArray) {
            if (sniDone || d.isEmpty()) return
            val b0 = d[0].toInt() and 255
            if (b0 == 0x16) {
                val old = buf
                val all = if (old == null) d else old + d
                buf = all
                val h = parseSni(all)
                if (h != null) {
                    sni = h
                    sniDone = true
                    buf = null
                } else {
                    val need = if (all.size >= 5) ((all[3].toInt() and 255) shl 8 or (all[4].toInt() and 255)) + 5 else 5
                    if (all.size >= need || all.size >= 4096) {
                        sniDone = true
                        buf = null
                    }
                }
            } else {
                sniDone = true
                val h = parseHttpHost(d)
                if (h != null) sni = h
            }
        }

        /** জমা বাইট আংশিক সারি হিসেবে লেখার লাইনে দেওয়া (সংযোগ চলতে থাকে) */
        fun partial() {
            if (done.get()) return
            emit()
        }

        fun finish() {
            if (!done.compareAndSet(false, true)) return
            active.remove(this)
            emit()
        }

        private fun emit() {
            val u = up.getAndSet(0)
            val d = down.getAndSet(0)
            if (u == 0L && d == 0L) return
            val host = sni ?: ipName[ip]
            queue.add(Row(System.currentTimeMillis(), pkg, host, ip, port, u, d, fg))
            if (queued.incrementAndGet() >= 40) {
                val ctx = appCtx
                if (ctx != null) flushAsync(ctx)
            }
        }
    }

    // ---------------- ডিস্কে লেখা ----------------

    private fun flushAsync(ctx: Context) {
        if (queue.isEmpty()) return
        if (!flushing.compareAndSet(false, true)) return
        try {
            io.execute {
                try {
                    val rows = ArrayList<Row>()
                    while (true) {
                        val r = queue.poll() ?: break
                        rows.add(r)
                    }
                    queued.set(0)
                    if (rows.isNotEmpty()) write(ctx, rows)
                } catch (e: Exception) {
                } finally {
                    flushing.set(false)
                }
            }
        } catch (e: Exception) {
            flushing.set(false)
        }
    }

    private fun write(ctx: Context, rows: List<Row>) {
        val db = XDb.get(ctx).writableDatabase
        db.beginTransaction()
        try {
            for (r in rows) {
                val v = ContentValues()
                v.put("t", r.t)
                v.put("pkg", r.pkg)
                v.put("host", r.host)
                v.put("ip", r.ip)
                v.put("port", r.port)
                v.put("up", r.up)
                v.put("down", r.down)
                v.put("fg", r.fg)
                db.insert("conn_log", null, v)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---------------- ইনস্পেক্টর পেজের জন্য প্রশ্ন ----------------

    /** অ্যাপ ধরে মোট: pkg, up, down, hosts, last */
    fun apps(ctx: Context, from: Long): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(ctx).readableDatabase.rawQuery(
            "SELECT pkg, SUM(up), SUM(down), COUNT(DISTINCT COALESCE(host, ip)), MAX(t) " +
                "FROM conn_log WHERE t >= ? GROUP BY pkg ORDER BY SUM(up) + SUM(down) DESC",
            arrayOf(from.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(
                    mapOf(
                        "pkg" to (it.getString(0) ?: ""),
                        "up" to it.getLong(1),
                        "down" to it.getLong(2),
                        "hosts" to it.getInt(3),
                        "last" to it.getLong(4)
                    )
                )
            }
        }
        return out
    }

    /** একটা অ্যাপ কোন কোন গন্তব্যে কথা বলেছে: host, ip, up, down, last, named */
    fun hosts(ctx: Context, pkg: String, from: Long): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(ctx).readableDatabase.rawQuery(
            "SELECT COALESCE(host, ip) AS h, MAX(host), SUM(up), SUM(down), MAX(t), SUM(fg) " +
                "FROM conn_log WHERE pkg = ? AND t >= ? GROUP BY h " +
                "ORDER BY SUM(up) + SUM(down) DESC LIMIT 200",
            arrayOf(pkg, from.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(
                    mapOf(
                        "host" to (it.getString(0) ?: ""),
                        "named" to (it.getString(1) != null),
                        "up" to it.getLong(2),
                        "down" to it.getLong(3),
                        "last" to it.getLong(4),
                        "fgRows" to it.getInt(5)
                    )
                )
            }
        }
        return out
    }

    fun clear(ctx: Context) {
        XDb.get(ctx).writableDatabase.delete("conn_log", null, null)
    }

    // ---------------- সহায়ক ----------------

    private fun pkgOf(ctx: Context, uid: Int): String = pkgCache.getOrPut(uid) {
        try {
            ctx.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "uid:$uid"
        } catch (e: Exception) {
            "uid:$uid"
        }
    }

    private fun u8(b: ByteArray, i: Int): Int = b[i].toInt() and 255
    private fun u16(b: ByteArray, i: Int): Int = (u8(b, i) shl 8) or u8(b, i + 1)

    private fun skipName(b: ByteArray, from: Int): Int {
        var i = from
        while (i < b.size) {
            val l = u8(b, i)
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return i + 2
            i += 1 + l
        }
        return -1
    }

    /** TLS ClientHello-র server_name। না পেলে বা অসম্পূর্ণ হলে null */
    private fun parseSni(d: ByteArray): String? {
        try {
            if (d.size < 48 || u8(d, 0) != 0x16 || u8(d, 5) != 0x01) return null
            var i = 5 + 4 + 2 + 32 // রেকর্ড হেডার, হ্যান্ডশেক হেডার, ভার্সন, random
            if (i >= d.size) return null
            i += 1 + u8(d, i) // session id
            if (i + 2 > d.size) return null
            i += 2 + u16(d, i) // cipher suites
            if (i + 1 > d.size) return null
            i += 1 + u8(d, i) // compression
            if (i + 2 > d.size) return null
            val extEnd = minOf(d.size, i + 2 + u16(d, i))
            i += 2
            while (i + 4 <= extEnd) {
                val type = u16(d, i)
                val len = u16(d, i + 2)
                i += 4
                if (i + len > extEnd) return null
                if (type == 0) {
                    // server_name_list: len(2) + type(1) + namelen(2) + name
                    if (len < 5 || u8(d, i + 2) != 0) return null
                    val nl = u16(d, i + 3)
                    if (i + 5 + nl > d.size || nl <= 0) return null
                    val name = String(d, i + 5, nl, Charsets.ISO_8859_1).lowercase()
                    return if (name.all { it.isLetterOrDigit() || it == '.' || it == '-' || it == '_' }) name else null
                }
                i += len
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** সাধারণ HTTP অনুরোধের Host লাইন */
    private fun parseHttpHost(d: ByteArray): String? {
        try {
            val n = minOf(d.size, 1024)
            val s = String(d, 0, n, Charsets.ISO_8859_1)
            val first = s.substring(0, minOf(8, s.length))
            val isHttp = first.startsWith("GET ") || first.startsWith("POST ") || first.startsWith("HEAD ") ||
                first.startsWith("PUT ") || first.startsWith("OPTIONS")
            if (!isHttp) return null
            val k = s.indexOf("\r\nHost:", ignoreCase = true)
            if (k < 0) return null
            val e = s.indexOf("\r\n", k + 2)
            val h = s.substring(k + 7, if (e < 0) s.length else e).trim().lowercase().substringBefore(':')
            return if (h.isNotEmpty() && h.length < 100) h else null
        } catch (e: Exception) {
        }
        return null
    }
}
