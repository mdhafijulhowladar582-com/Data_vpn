package com.you.firewall

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.net.ConnectivityManager
import java.util.Calendar

/**
 * স্ক্রিন টাইম হিসাব (UsageStatsManager, একই Usage access পারমিশন)।
 * - দিনের হিসাব UsageEvents থেকে (সঠিক)। ইভেন্ট যত দিন পর্যন্ত রাখা থাকে (সাধারণত ৭-১০ দিন),
 *   তার আগের দিনগুলো INTERVAL_DAILY থেকে নেওয়া হয় (আনুমানিক, আনলক/রাতের তথ্য ছাড়া)।
 */
object UsageUtil {
    class Result(val days: Int) {
        val starts = LongArray(days)
        val total = LongArray(days)
        val unlocks = LongArray(days)
        val night = LongArray(days)
        val nightLast = LongArray(days) // রাতের জানালায় সবশেষ ফোন চালানোর সময় (০ = নেই)
        val apps = HashMap<String, LongArray>()
    }

    private val launchable = HashMap<String, Boolean>()

    private fun isApp(c: Context, pkg: String): Boolean = synchronized(launchable) {
        launchable.getOrPut(pkg) {
            try {
                c.packageManager.getLaunchIntentForPackage(pkg) != null
            } catch (e: Exception) {
                false
            }
        }
    }

    /** offset 0 = আজ, -1 = গতকাল */
    private fun dayStart(offset: Int): Long {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun at(offset: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart(offset)
        c.set(Calendar.HOUR_OF_DAY, minute / 60)
        c.set(Calendar.MINUTE, minute % 60)
        return c.timeInMillis
    }

    /** শেষ [days] দিন (আজসহ)। ns/ne = ঘুমের জানালা (মিনিট), সমান হলে রাতের হিসাব বন্ধ */
    fun compute(c: Context, days: Int, ns: Int, ne: Int): Result {
        val r = Result(days)
        val now = System.currentTimeMillis()
        for (i in 0 until days) r.starts[i] = dayStart(i - (days - 1))

        val hasNight = ns != ne
        val ws = LongArray(days + 1)
        val we = LongArray(days + 1)
        if (hasNight) {
            for (k in -1 until days) {
                val off = k - (days - 1)
                ws[k + 1] = at(off, ns)
                we[k + 1] = if (ns < ne) at(off, ne) else at(off + 1, ne)
            }
        }

        fun add(pkg: String, s0: Long, e0: Long) {
            val s = maxOf(s0, r.starts[0])
            val e = minOf(e0, now)
            if (e <= s || !isApp(c, pkg)) return
            val arr = r.apps.getOrPut(pkg) { LongArray(days) }
            for (i in 0 until days) {
                val ds = r.starts[i]
                val de = if (i < days - 1) r.starts[i + 1] else Long.MAX_VALUE
                val o = minOf(e, de) - maxOf(s, ds)
                if (o > 0) {
                    arr[i] += o
                    r.total[i] += o
                }
            }
            if (hasNight) {
                for (k in 0 until days) {
                    val a = maxOf(s, ws[k + 1])
                    val b = minOf(e, we[k + 1])
                    if (b > a) {
                        r.night[k] += b - a
                        if (b > r.nightLast[k]) r.nightLast[k] = b
                    }
                }
            }
        }

        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val open = HashMap<String, Long>()
        var minTs = now
        try {
            val ev = usm.queryEvents(r.starts[0] - 3 * 3600_000L, now)
            val e = UsageEvents.Event()
            var first = true
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val t = e.timeStamp
                if (first) {
                    minTs = t
                    first = false
                }
                val p: String? = e.packageName
                when (e.eventType) {
                    1 -> { // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
                        if (p != null) open[p + "/" + e.className] = t
                    }
                    2 -> { // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
                        if (p != null) {
                            val st = open.remove(p + "/" + e.className)
                            if (st != null) add(p, st, t)
                        }
                    }
                    16, 26 -> { // স্ক্রিন বন্ধ / শাটডাউন
                        for ((k, st) in open) add(k.substringBefore('/'), st, t)
                        open.clear()
                    }
                    18 -> { // KEYGUARD_HIDDEN = আনলক
                        if (t >= r.starts[0]) {
                            for (i in days - 1 downTo 0) {
                                if (t >= r.starts[i]) {
                                    r.unlocks[i]++
                                    break
                                }
                            }
                        }
                    }
                }
            }
        } catch (ex: Exception) {
        }
        for ((k, st) in open) add(k.substringBefore('/'), st, now)

        // ইভেন্ট নেই এমন পুরনো দিন: দৈনিক সারাংশ থেকে
        try {
            for (i in 0 until days) {
                val ds = r.starts[i]
                val de = if (i < days - 1) r.starts[i + 1] else now
                if (de > minTs) continue
                val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, ds, de - 1)
                for (u in list) {
                    val ms = u.totalTimeInForeground
                    if (ms <= 0 || !isApp(c, u.packageName)) continue
                    if (Math.abs(u.firstTimeStamp - ds) > 4 * 3600_000L) continue
                    val arr = r.apps.getOrPut(u.packageName) { LongArray(days) }
                    arr[i] += ms
                    r.total[i] += ms
                }
            }
        } catch (ex: Exception) {
        }
        return r
    }

    class DataUse(val total: Long, val apps: HashMap<String, Long>)

    /**
     * [from] থেকে এখন পর্যন্ত মোবাইল ডেটা (বাইট)। [wifi] true হলে Wi-Fi-ও যোগ হয়।
     * [perApp] true হলে অ্যাপ (প্যাকেজ) ধরেও হিসাব। একই UID-র সব প্যাকেজ একই সংখ্যা পায়।
     */
    fun dataSince(c: Context, from: Long, wifi: Boolean, perApp: Boolean): DataUse {
        val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val to = System.currentTimeMillis()
        val types = if (wifi) intArrayOf(ConnectivityManager.TYPE_MOBILE, ConnectivityManager.TYPE_WIFI)
        else intArrayOf(ConnectivityManager.TYPE_MOBILE)
        var total = 0L
        val apps = HashMap<String, Long>()
        val uidPkgs = HashMap<Int, Array<String>?>()
        for (type in types) {
            try {
                val b = nsm.querySummaryForDevice(type, null, from, to)
                total += b.rxBytes + b.txBytes
            } catch (e: Exception) {
            }
            if (!perApp) continue
            try {
                val st = nsm.querySummary(type, null, from, to)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    if (b.uid < 0) continue
                    val pk = uidPkgs.getOrPut(b.uid) { c.packageManager.getPackagesForUid(b.uid) } ?: continue
                    val n = b.rxBytes + b.txBytes
                    for (p in pk) apps[p] = (apps[p] ?: 0L) + n
                }
                st.close()
            } catch (e: Exception) {
            }
        }
        return DataUse(total, apps)
    }
}
