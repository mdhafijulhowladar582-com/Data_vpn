package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** নিরাপত্তা সরঞ্জামের সাধারণ সাহায্যকারী: নোটিফিকেশন, ব্লক/অনুমতি দেওয়া */
object Safety {
    fun idNew(pkg: String) = 100000 + (pkg.hashCode() and 0xffff)
    fun idLeak(pkg: String) = 200000 + (pkg.hashCode() and 0xffff)
    fun idPerm(pkg: String) = 300000 + (pkg.hashCode() and 0xffff)
    const val ID_PANIC = 7710

    fun fmtBytes(b: Long): String = when {
        b < 1024L * 1024L -> "${b / 1024} KB"
        b < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun isUserApp(c: Context, pkg: String): Boolean = try {
        (c.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) == 0
    } catch (e: Exception) {
        false
    }

    /** অ্যাপের ইন্টারনেট পারমিশন আছে কিনা (না থাকলে নেট ব্লক নিয়ে প্রশ্নই অর্থহীন) */
    fun wantsInternet(c: Context, pkg: String): Boolean = try {
        val r = c.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions
        r == null || r.contains("android.permission.INTERNET")
    } catch (e: Exception) {
        true
    }

    @Suppress("DEPRECATION")
    fun post(
        c: Context, id: Int, channel: String, channelName: String,
        title: String, text: String, content: PendingIntent?,
        actions: List<Pair<String, PendingIntent>>
    ) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(channel, channelName, NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, channel)
            else Notification.Builder(c)
            b.setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setAutoCancel(true)
            if (content != null) b.setContentIntent(content)
            for ((t, pi) in actions) b.addAction(0, t, pi)
            nm.notify(id, b.build())
        } catch (e: Exception) {
        }
    }

    /** নোটিফিকেশনের বোতাম: NoticeReceiver-এ যায় */
    fun action(c: Context, id: Int, slot: Int, act: String, pkg: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, id * 4 + slot,
            Intent(c, NoticeReceiver::class.java).setAction(act).putExtra("pkg", pkg),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** অ্যাপের নিজের সেটিংস পেজ খোলা (পারমিশন দেখতে) */
    fun appSettings(c: Context, id: Int, pkg: String): PendingIntent =
        PendingIntent.getActivity(
            c, id * 4 + 3,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun removeFrom(j: JSONObject, key: String, pkg: String) {
        val a = j.optJSONArray(key) ?: return
        val n = JSONArray()
        for (i in 0 until a.length()) if (a.optString(i) != pkg) n.put(a.optString(i))
        j.put(key, n)
    }

    /** ওয়াইফাই ও মোবাইল দুটোতেই ব্লক */
    fun blockApp(c: Context, pkg: String) {
        Store.edit(c) { j ->
            val rules = j.optJSONObject("rules") ?: JSONObject().also { j.put("rules", it) }
            rules.put(pkg, JSONObject().put("wifi", true).put("mobile", true))
            removeFrom(j, "allowed", pkg)
        }
        FirewallVpnService.reload(c)
    }

    /** ব্লকলিস্টে নিয়ম মুছে দেয়, হোয়াইটলিস্টে অনুমতি তালিকায় তোলে */
    fun allowApp(c: Context, pkg: String) {
        Store.edit(c) { j ->
            j.optJSONObject("rules")?.remove(pkg)
            if (j.optString("mode", "blocklist") == "whitelist") {
                val a = j.optJSONArray("allowed") ?: JSONArray().also { j.put("allowed", it) }
                var has = false
                for (i in 0 until a.length()) if (a.optString(i) == pkg) has = true
                if (!has) a.put(pkg)
            }
        }
        FirewallVpnService.reload(c)
    }

    /** নতুন অ্যাপ: না বলা পর্যন্ত ব্লক রেখে প্রশ্নের নোটিফিকেশন */
    fun askNewApp(c: Context, pkg: String) {
        val id = idNew(pkg)
        val name = NetNotice.label(c, pkg)
        post(
            c, id, "fws_ask", "নতুন অ্যাপের প্রশ্ন",
            "$name ইনস্টল হয়েছে",
            "ইন্টারনেট দেব, না ব্লক? না বলা পর্যন্ত $name-এর নেট বন্ধ থাকবে।",
            appSettings(c, id, pkg),
            listOf(
                Pair("ইন্টারনেট দিন", action(c, id, 0, "NEW_ALLOW", pkg)),
                Pair("ব্লক থাকুক", action(c, id, 1, "NEW_BLOCK", pkg))
            )
        )
    }
}

/** ৩০ দিন খোলা হয়নি অথচ ডেটা খরচ করছে এমন অ্যাপ */
object Forgotten {
    const val DAYS = 30
    private const val MIN_BYTES = 1024L * 1024L // ৩০ দিনে ১ MB-র কম হলে ধরি না
    private const val DAY_MS = 86400000L

    /** [{pkg, name, bytes, days, never}] সবচেয়ে বেশি ডেটা আগে */
    fun scan(c: Context): List<Map<String, Any>> {
        val now = System.currentTimeMillis()
        val pm = c.packageManager
        val last = HashMap<String, Long>()
        try {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 400L * DAY_MS, now)) {
                if (u.lastTimeUsed > (last[u.packageName] ?: 0L)) last[u.packageName] = u.lastTimeUsed
            }
        } catch (e: Exception) {
        }
        val use = UsageUtil.dataSince(c, now - DAYS * DAY_MS, true, true)
        val out = ArrayList<Map<String, Any>>()
        for ((pkg, bytes) in use.apps) {
            if (bytes < MIN_BYTES || pkg == c.packageName) continue
            if (!Safety.isUserApp(c, pkg)) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue // খোলার মতো অ্যাপ নয়
            val installed = try {
                pm.getPackageInfo(pkg, 0).firstInstallTime
            } catch (e: Exception) {
                continue
            }
            if (now - installed < DAYS * DAY_MS) continue // ৩০ দিনও হয়নি
            val lu = last[pkg] ?: 0L
            if (lu > 0L && now - lu < DAYS * DAY_MS) continue // সম্প্রতি খোলা হয়েছে
            val never = lu <= 0L
            val days = ((now - (if (never) installed else lu)) / DAY_MS).toInt()
            out.add(
                mapOf(
                    "pkg" to pkg,
                    "name" to NetNotice.label(c, pkg),
                    "bytes" to bytes,
                    "days" to days,
                    "never" to never
                )
            )
        }
        out.sortByDescending { (it["bytes"] as Long) }
        return out
    }
}

/** আপডেটের পর কোনো অ্যাপ নতুন সংবেদনশীল পারমিশন চাইলে সতর্কতা */
object PermWatch {
    private val SENSITIVE = mapOf(
        "android.permission.CAMERA" to "ক্যামেরার",
        "android.permission.RECORD_AUDIO" to "মাইক্রোফোনের",
        "android.permission.ACCESS_FINE_LOCATION" to "লোকেশনের",
        "android.permission.ACCESS_COARSE_LOCATION" to "লোকেশনের",
        "android.permission.ACCESS_BACKGROUND_LOCATION" to "ব্যাকগ্রাউন্ড লোকেশনের",
        "android.permission.READ_CONTACTS" to "কন্টাক্টসের",
        "android.permission.READ_SMS" to "এসএমএসের",
        "android.permission.READ_CALL_LOG" to "কল লগের"
    )

    private fun sp(c: Context) = c.getSharedPreferences("fw_perm", Context.MODE_PRIVATE)

    private fun sensitiveOf(c: Context, pkg: String): Set<String>? = try {
        val r = c.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions
        val s = HashSet<String>()
        if (r != null) for (p in r) if (SENSITIVE.containsKey(p)) s.add(p)
        s
    } catch (e: Exception) {
        null
    }

    private fun join(l: List<String>): String = when (l.size) {
        1 -> l[0]
        2 -> "${l[0]} ও ${l[1]}"
        else -> l.dropLast(1).joinToString(", ") + " ও " + l.last()
    }

    /**
     * আগের রেকর্ডের সাথে মেলায়। রেকর্ড না থাকলে শুধু রেখে দেয় (প্রথমবার সতর্কতা নয়)।
     * নতুন পারমিশন পেলে (warn = true হলে) নোটিফিকেশন, আর true ফেরত।
     */
    fun check(c: Context, pkg: String, warn: Boolean): Boolean {
        if (pkg == c.packageName || !Safety.isUserApp(c, pkg)) return false
        val now = sensitiveOf(c, pkg) ?: return false
        val p = sp(c)
        val key = "p:$pkg"
        val old: Set<String>? = p.getStringSet(key, null)?.let { HashSet(it) }
        p.edit().putStringSet(key, HashSet(now)).apply()
        if (old == null || !warn) return false
        val added = now - old
        if (added.isEmpty()) return false
        val names = ArrayList<String>()
        for (a in added) {
            val n = SENSITIVE[a] ?: continue
            if (n !in names) names.add(n)
        }
        if (names.isEmpty()) return false
        val id = Safety.idPerm(pkg)
        val label = NetNotice.label(c, pkg)
        Safety.post(
            c, id, "fws_perm", "আপডেটে নতুন পারমিশন",
            "$label: নতুন পারমিশন",
            "$label অ্যাপ আপডেটের পর ${join(names)} অনুমতি চেয়েছে। দরকার না হলে পারমিশন বন্ধ করুন বা নেট ব্লক করুন।",
            Safety.appSettings(c, id, pkg),
            listOf(Pair("নেট ব্লক করুন", Safety.action(c, id, 0, "PERM_BLOCK", pkg)))
        )
        return true
    }

    /** সব ইনস্টল করা অ্যাপের রেকর্ড মেলানো/বানানো (সার্ভিস চালুর সময়, ব্যাকগ্রাউন্ড থ্রেডে)। সর্বোচ্চ ৫টা সতর্কতা */
    fun scanAll(c: Context, warn: Boolean) {
        var shown = 0
        try {
            for (ai in c.packageManager.getInstalledApplications(0)) {
                if (check(c, ai.packageName, warn && shown < 5)) shown++
            }
        } catch (e: Exception) {
        }
    }
}

/**
 * স্ক্রিন বন্ধ থাকা অবস্থায় কোনো অ্যাপ অনেক ডেটা পাঠালে সতর্কতা ("ব্লক করুন" বোতামসহ)।
 * ডেটা মাপা হয় NetworkStatsManager দিয়ে (Usage access লাগে), শুধু পাঠানো (upload) বাইট।
 */
object LeakWatch {
    private var base: HashMap<Int, Long>? = null
    private var baseDay = ""
    private val alerted = HashSet<Int>()
    @Volatile private var busy = false

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized
    fun screenOn() {
        base = null
        alerted.clear()
    }

    /** স্ক্রিন বন্ধ হলো: এখনকার মোট পাঠানো ডেটা ভিত্তি হিসেবে রাখি */
    fun screenOff(c: Context) {
        synchronized(this) {
            base = null
            alerted.clear()
        }
        poll(c)
    }

    private fun txByUid(c: Context): HashMap<Int, Long>? {
        return try {
            val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val from = cal.timeInMillis
            val to = System.currentTimeMillis()
            val m = HashMap<Int, Long>()
            var ok = false
            for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
                val st = try {
                    nsm.querySummary(type, null, from, to)
                } catch (e: Exception) {
                    continue
                }
                ok = true
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    if (b.uid < 10000) continue // সিস্টেম ও বিশেষ UID বাদ
                    m[b.uid] = (m[b.uid] ?: 0L) + b.txBytes
                }
                st.close()
            }
            if (ok) m else null
        } catch (e: Exception) {
            null
        }
    }

    /** স্ক্রিন বন্ধ থাকলে ৩০ সেকেন্ড পরপর ডাকা হয়। নিজেই ব্যাকগ্রাউন্ড থ্রেডে চলে */
    fun poll(c: Context) {
        if (busy) return
        busy = true
        val ctx = c.applicationContext
        Thread {
            try {
                val cur = txByUid(ctx) ?: return@Thread
                val day = today()
                val b: HashMap<Int, Long> = synchronized(this) {
                    val old = base
                    if (old == null) {
                        // স্ক্রিন বন্ধের শুরু: এখনকার মোটকে ভিত্তি ধরি
                        base = HashMap(cur)
                        baseDay = day
                        return@Thread
                    }
                    if (day != baseDay) { // মাঝরাতে গোনা শূন্য থেকে শুরু
                        base = HashMap()
                        baseDay = day
                    }
                    base!!
                }
                val limit = Store.load(ctx).optInt("leakMb", 10).coerceIn(1, 1000) * 1024L * 1024L
                for ((uid, tx) in cur) {
                    val sent = tx - (b[uid] ?: 0L)
                    if (sent < limit) continue
                    val fresh = synchronized(this) { alerted.add(uid) }
                    if (!fresh) continue
                    val pk = ctx.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: continue
                    if (pk == ctx.packageName) continue
                    val id = Safety.idLeak(pk)
                    val name = NetNotice.label(ctx, pk)
                    Safety.post(
                        ctx, id, "fws_leak", "স্ক্রিন বন্ধে ডেটা পাঠানো",
                        "$name স্ক্রিন বন্ধে ডেটা পাঠাচ্ছে",
                        "স্ক্রিন বন্ধ থাকা অবস্থায় $name প্রায় ${Safety.fmtBytes(sent)} পাঠিয়েছে। আপনি না চালালে ব্লক করে দিন।",
                        Safety.appSettings(ctx, id, pk),
                        listOf(Pair("ব্লক করুন", Safety.action(ctx, id, 0, "LEAK_BLOCK", pk)))
                    )
                }
            } catch (e: Exception) {
            } finally {
                busy = false
            }
        }.start()
    }
}

/** প্যানিক: এক ট্যাপে সব লক, ভল্টের চাবি মেমরি থেকে সরানো, অ্যাপ বন্ধ, চাইলে সব নেট বন্ধ */
object Panic {
    fun trigger(c: Context) {
        val ctx = c.applicationContext
        try { VaultManager.wipe(ctx) } catch (e: Exception) {}
        GuardService.unlockedPkg = null
        val net = Store.load(ctx).optBoolean("panicNet")
        if (net) {
            Store.edit(ctx) { it.put("blockAll", true) }
            if (FirewallVpnService.running) {
                FirewallVpnService.reload(ctx)
            } else if (VpnService.prepare(ctx) == null) {
                FirewallVpnService.start(ctx)
            }
        }
        MainActivity.closeNow()
        Alert.show(
            ctx, Safety.ID_PANIC, "প্যানিক চালু হয়েছিল",
            if (net) "সব লক, ভল্ট বন্ধ আর সব অ্যাপের নেট বন্ধ। নেট ফেরাতে অ্যাপ খুলে \"সব ব্লক\" বন্ধ করুন।"
            else "সব লক আর ভল্ট বন্ধ। অ্যাপ খুলতে পিন লাগবে।"
        )
    }
}
