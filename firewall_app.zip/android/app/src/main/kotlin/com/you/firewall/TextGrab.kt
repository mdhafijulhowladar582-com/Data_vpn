package com.you.firewall

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * লেখা তোলার বাটন: কপি করা যায় না এমন জায়গা থেকেও স্ক্রিনের লেখা তালিকা করে দেয়।
 * আলাদা অ্যাক্সেসিবিলিটি সার্ভিস (GuardService-এ হাত দেওয়া হয়নি, ওটা স্ক্রিনের লেখা পড়ে না)।
 * বাটন চাপলেই শুধু তখনকার স্ক্রিনের লেখা পড়া হয়। কিছু সেভ বা ইন্টারনেটে পাঠানো হয় না।
 */
object TextGrab {
    val styleNames = listOf("আলোর গোলক", "সাবানের বুদবুদ", "জাদুর চোখ", "জোনাকি তারা", "বিজলি-ছানা")

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_textgrab", Context.MODE_PRIVATE)

    fun on(c: Context): Boolean = sp(c).getBoolean("on", false)
    fun style(c: Context): Int = sp(c).getInt("style", 0).coerceIn(0, 4)

    fun set(c: Context, on: Boolean?, style: Int?) {
        val e = sp(c).edit()
        if (on != null) e.putBoolean("on", on)
        if (style != null) e.putInt("style", style.coerceIn(0, 4))
        e.apply()
        TextGrabService.inst?.sync()
    }

    fun serviceEnabled(c: Context): Boolean {
        if (TextGrabService.inst != null) return true
        val s: String = (try {
            Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        } catch (e: Exception) {
            null
        }) ?: return false
        val full = c.packageName + "/" + TextGrabService::class.java.name
        val short = c.packageName + "/.TextGrabService"
        return s.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    fun state(c: Context): Map<String, Any> = mapOf(
        "enabled" to serviceEnabled(c),
        "on" to on(c),
        "style" to style(c),
        "names" to styleNames,
    )

    fun openAccess(c: Context): Boolean = try {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }
}

class TextGrabService : AccessibilityService() {
    companion object {
        @Volatile
        var inst: TextGrabService? = null
    }

    private lateinit var wm: WindowManager
    private var btn: GrabButton? = null
    private var btnLp: WindowManager.LayoutParams? = null
    private var panel: View? = null

    private val density: Float get() = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()
    private fun screenW(): Int = resources.displayMetrics.widthPixels
    private fun screenH(): Int = resources.displayMetrics.heightPixels
    private fun sp() = getSharedPreferences("fw_textgrab", Context.MODE_PRIVATE)

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sync()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (::wm.isInitialized) {
            removeButton()
            closePanel()
        }
        inst = null
    }

    /** বাটন চালু/বন্ধ আর স্টাইল ঠিক করে */
    fun sync() {
        if (!::wm.isInitialized) return
        if (TextGrab.on(this)) {
            val st = TextGrab.style(this)
            val b = btn
            if (b == null) addButton(st) else b.style = st
        } else {
            removeButton()
            closePanel()
        }
    }

    private fun addButton(st: Int) {
        val size = dp(64)
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = sp().getInt("x", screenW() - size).coerceIn(0, maxOf(0, screenW() - size))
        lp.y = sp().getInt("y", dp(300)).coerceIn(0, maxOf(0, screenH() - size))
        val v = GrabButton(this)
        v.style = st
        v.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f
            var dy = 0f
            var sx = 0
            var sy = 0
            var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = e.rawX
                        dy = e.rawY
                        sx = lp.x
                        sy = lp.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val ox = e.rawX - dx
                        val oy = e.rawY - dy
                        if (!moved && (abs(ox) > dp(6) || abs(oy) > dp(6))) moved = true
                        if (moved) {
                            lp.x = (sx + ox).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                            lp.y = (sy + oy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                            try {
                                wm.updateViewLayout(view, lp)
                            } catch (e: Exception) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            onTap()
                        } else {
                            snap(view, lp)
                        }
                        return true
                    }
                }
                return false
            }
        })
        try {
            wm.addView(v, lp)
            btn = v
            btnLp = lp
        } catch (e: Exception) {
        }
    }

    private fun snap(v: View, lp: WindowManager.LayoutParams) {
        val target = if (lp.x + lp.width / 2 < screenW() / 2) 0 else maxOf(0, screenW() - lp.width)
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 200
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(v, lp)
            } catch (e: Exception) {
            }
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                sp().edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
        })
        a.start()
    }

    private fun removeButton() {
        btn?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        btn = null
        btnLp = null
    }

    private fun onTap() {
        btn?.tapFx()
        showPanel()
    }

    // ---------- স্ক্রিনের লেখা তোলা ----------

    private fun collect(): List<String> {
        val root: AccessibilityNodeInfo = (try {
            rootInActiveWindow
        } catch (e: Exception) {
            null
        }) ?: return emptyList()
        val out = LinkedHashSet<String>()
        walk(root, out, 0)
        return out.toList()
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (n == null || depth > 60 || out.size > 400) return
        try {
            if (n.isVisibleToUser && !n.isPassword) {
                val t = n.text?.toString()?.trim().orEmpty()
                val d = n.contentDescription?.toString()?.trim().orEmpty()
                val s = if (t.isNotEmpty()) t else d
                if (s.isNotEmpty()) out.add(s)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), out, depth + 1)
        } catch (e: Exception) {
        }
    }

    // ---------- তালিকার প্যানেল ----------

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setPadding(dp(12), dp(7), dp(12), dp(7))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#6D5BD0"))
        bg.cornerRadius = dp(16).toFloat()
        t.background = bg
        t.setOnClickListener { onClick() }
        return t
    }

    private fun copy(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", text))
            Toast.makeText(this, "কপি হয়েছে", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "কপি করা গেল না", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            closePanel()
        } catch (e: Exception) {
            Toast.makeText(this, "ব্রাউজার খোলা গেল না", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val lines = collect()
        val maxH = (screenH() * 0.68f).toInt()

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.argb(140, 0, 0, 0))
        root.setOnClickListener { closePanel() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        val cbg = GradientDrawable()
        cbg.setColor(Color.parseColor("#1E1B2E"))
        val rr = dp(22).toFloat()
        cbg.cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
        card.background = cbg
        card.setPadding(dp(14), dp(14), dp(14), dp(28))
        card.setOnClickListener { }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "স্ক্রিনের লেখা (${lines.size})"
        title.setTextColor(Color.parseColor("#F3F0FF"))
        title.textSize = 16f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (lines.isNotEmpty()) {
            val all = pill("সব কপি") { copy(lines.joinToString("\n")) }
            head.addView(all)
        }
        val x = pill("✕") { closePanel() }
        val xl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        xl.leftMargin = dp(8)
        head.addView(x, xl)
        card.addView(head)

        val sv = object : ScrollView(this) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
            }
        }
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        if (lines.isEmpty()) {
            val e = TextView(this)
            e.text = "কোনো লেখা পাওয়া যায়নি।\nছবির ভেতরের লেখা বা সুরক্ষিত অ্যাপের লেখা পড়া যায় না।"
            e.setTextColor(Color.parseColor("#C9C2E8"))
            e.textSize = 14f
            e.setPadding(0, dp(18), 0, dp(10))
            list.addView(e)
        }
        for (line in lines) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, dp(12), 0, dp(4))
            val tv = TextView(this)
            tv.text = line
            tv.setTextColor(Color.parseColor("#F3F0FF"))
            tv.textSize = 15f
            tv.maxLines = 6
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setOnClickListener {
                tv.maxLines = if (tv.maxLines == 6) Int.MAX_VALUE else 6
            }
            row.addView(tv)
            val acts = LinearLayout(this)
            acts.orientation = LinearLayout.HORIZONTAL
            acts.setPadding(0, dp(8), 0, 0)
            val enc = Uri.encode(line.take(1500))
            val b1 = pill("কপি") { copy(line) }
            val b2 = pill("অনুবাদ") { openUrl("https://translate.google.com/?sl=auto&tl=bn&op=translate&text=$enc") }
            val b3 = pill("গুগলে খুঁজুন") { openUrl("https://www.google.com/search?q=$enc") }
            val gap = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            gap.rightMargin = dp(8)
            acts.addView(b1, gap)
            acts.addView(b2, gap)
            acts.addView(b3)
            row.addView(acts)
            val div = View(this)
            div.setBackgroundColor(Color.parseColor("#33FFFFFF"))
            val dl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
            dl.topMargin = dp(10)
            row.addView(div, dl)
            list.addView(row)
        }
        sv.addView(list)
        card.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, lp)
            panel = root
        } catch (e: Exception) {
        }
    }

    private fun closePanel() {
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
    }
}

/** ভাসমান বাটনের ৫ স্টাইল। সব নিজে আঁকা, কোনো ছবি বা কপিরাইট করা চরিত্র নেই */
class GrabButton(c: Context) : View(c) {
    var style = 0
        set(v) {
            field = v
            invalidate()
        }

    private var t = 0f
    private var tapP = -1f
    private val d = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val tau = (2.0 * PI).toFloat()
    private val pif = PI.toFloat()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }
    private var tapAnim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        tapAnim?.cancel()
        super.onDetachedFromWindow()
    }

    fun tapFx() {
        tapAnim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 600
        a.addUpdateListener {
            tapP = it.animatedValue as Float
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                tapP = -1f
                invalidate()
            }
        })
        tapAnim = a
        a.start()
    }

    private fun col(s: String): Int = Color.parseColor(s)

    private fun fill(color: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
    }

    private fun stroke(color: Int, w: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = width * 0.30f
        when (style) {
            0 -> orb(cv, cx, cy, base)
            1 -> bubble(cv, cx, cy, base)
            2 -> eye(cv, cx, cy, base)
            3 -> star(cv, cx, cy, base)
            else -> pika(cv, cx, cy, base)
        }
        if (tapP >= 0f) {
            stroke(Color.argb((200 * (1f - tapP)).toInt().coerceIn(0, 255), 196, 181, 253), 3f * d)
            cv.drawCircle(cx, cy, base * (1.1f + tapP * 1.1f), p)
            p.style = Paint.Style.FILL
        }
    }

    // ১. আলোর গোলক: নিঃশ্বাসের মতো ফোলে-ছোট হয়, চারপাশে আলোর কণা ঘোরে
    private fun orb(cv: Canvas, cx: Float, cy: Float, base: Float) {
        val r = base * (1f + 0.09f * sin(tau * t))
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx, cy, r * 1.75f,
            intArrayOf(Color.argb(120, 167, 139, 250), Color.argb(0, 167, 139, 250)),
            floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r * 1.75f, p)
        p.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.35f, r * 1.25f,
            intArrayOf(col("#F3E8FF"), col("#8B5CF6"), col("#3B82F6")),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r, p)
        for (i in 0 until 4) {
            val a = tau * (t + i / 4f)
            val rr = r * (1.5f + 0.15f * sin(tau * t * 2f + i))
            val al = (170f + 80f * sin(tau * t * 2f + i)).toInt().coerceIn(0, 255)
            fill(Color.argb(al, 196, 181, 253))
            cv.drawCircle(cx + cos(a) * rr, cy + sin(a) * rr, d * 1.7f, p)
        }
    }

    // ২. সাবানের বুদবুদ: স্বচ্ছ, গায়ে রামধনুর আভা, হালকা দোলে
    private fun bubble(cv: Canvas, cx: Float, cy: Float, base: Float) {
        cv.save()
        cv.translate(2f * d * sin(tau * t * 2f), 3f * d * sin(tau * t))
        val r = base * 1.1f
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.35f, r * 1.3f,
            intArrayOf(Color.argb(40, 255, 255, 255), Color.argb(80, 120, 200, 255), Color.argb(140, 196, 150, 255)),
            floatArrayOf(0f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r, p)
        val colors = intArrayOf(
            col("#F87171"), col("#FBBF24"), col("#A3E635"), col("#34D399"),
            col("#38BDF8"), col("#818CF8"), col("#E879F9"), col("#F87171")
        )
        val sw = SweepGradient(cx, cy, colors, null)
        val m = Matrix()
        m.setRotate(360f * t, cx, cy)
        sw.setLocalMatrix(m)
        stroke(Color.WHITE, 2.6f * d)
        p.shader = sw
        cv.drawCircle(cx, cy, r, p)
        fill(Color.argb(200, 255, 255, 255))
        rect.set(cx - r * 0.62f, cy - r * 0.7f, cx - r * 0.1f, cy - r * 0.32f)
        cv.save()
        cv.rotate(-30f, cx - r * 0.36f, cy - r * 0.5f)
        cv.drawOval(rect, p)
        cv.restore()
        fill(Color.argb(150, 255, 255, 255))
        cv.drawCircle(cx + r * 0.45f, cy + r * 0.5f, r * 0.08f, p)
        cv.restore()
    }

    private fun eyeOpen(): Float {
        var o = 1f
        if (t in 0.86f..0.96f) {
            val x = (t - 0.86f) / 0.10f
            o = abs(cos(pif * x))
        }
        if (tapP >= 0f) o *= (0.12f + 0.88f * abs(cos(pif * tapP * 2f)))
        return o.coerceIn(0.02f, 1f)
    }

    // ৩. জাদুর চোখ: চারদিকে তাকায়, মাঝে মাঝে পলক ফেলে, চাপলে পলক
    private fun eye(cv: Canvas, cx: Float, cy: Float, base: Float) {
        val open = eyeOpen()
        val rw = base * 1.45f
        val rh = base * 0.95f * open
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx, cy, rw * 1.4f,
            intArrayOf(Color.argb(110, 139, 92, 246), Color.argb(0, 139, 92, 246)),
            floatArrayOf(0.4f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, rw * 1.4f, p)
        path.reset()
        path.moveTo(cx - rw, cy)
        path.quadTo(cx, cy - rh * 2f, cx + rw, cy)
        path.quadTo(cx, cy + rh * 2f, cx - rw, cy)
        path.close()
        fill(col("#F5F3FF"))
        cv.drawPath(path, p)
        cv.save()
        cv.clipPath(path)
        val ix = cx + rw * 0.18f * sin(tau * t)
        val ir = base * 0.82f
        fill(Color.WHITE)
        p.shader = RadialGradient(
            ix, cy, ir,
            intArrayOf(col("#C4B5FD"), col("#7C3AED"), col("#312E81")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(ix, cy, ir, p)
        fill(col("#0F0A1F"))
        cv.drawCircle(ix, cy, ir * 0.42f, p)
        fill(Color.WHITE)
        cv.drawCircle(ix - ir * 0.28f, cy - ir * 0.3f, ir * 0.16f, p)
        cv.restore()
        stroke(col("#4C1D95"), 2.4f * d)
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    // ৪. জোনাকি তারা: ধীরে দোলে, চারপাশে আলোর কণা ঘোরে ও মিটমিট করে
    private fun star(cv: Canvas, cx: Float, cy: Float, base: Float) {
        val big = base * 1.15f * (1f + 0.06f * sin(tau * t * 2f))
        val small = big * 0.46f
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx, cy, big * 1.9f,
            intArrayOf(Color.argb(140, 250, 240, 120), Color.argb(0, 250, 240, 120)),
            floatArrayOf(0.3f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, big * 1.9f, p)
        path.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) big else small
            val a = -pif / 2f + i * pif / 5f + 0.12f * sin(tau * t)
            val x = cx + cos(a) * rad
            val y = cy + sin(a) * rad
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx, cy, big,
            intArrayOf(col("#FEF9C3"), col("#FDE047"), col("#F59E0B")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawPath(path, p)
        stroke(col("#FBBF24"), 2.5f * d)
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL
        for (i in 0 until 7) {
            val a = tau * (t + i / 7f)
            val rx = big * 1.55f
            val ry = big * 1.35f
            val tw = 0.5f + 0.5f * sin(tau * t * 3f + i * 1.7f)
            fill(Color.argb((90f + 165f * tw).toInt().coerceIn(0, 255), 217, 249, 157))
            cv.drawCircle(cx + cos(a) * rx, cy + sin(a) * ry, d * (1.1f + 1.1f * tw), p)
        }
    }

    private fun bolt(cv: Canvas, ox: Float, oy: Float, s: Float, fillC: Int, strokeC: Int) {
        path.reset()
        path.moveTo(ox + 0.55f * s, oy)
        path.lineTo(ox + 0.10f * s, oy + 0.55f * s)
        path.lineTo(ox + 0.45f * s, oy + 0.55f * s)
        path.lineTo(ox + 0.30f * s, oy + 1.00f * s)
        path.lineTo(ox + 0.90f * s, oy + 0.40f * s)
        path.lineTo(ox + 0.55f * s, oy + 0.40f * s)
        path.lineTo(ox + 0.80f * s, oy)
        path.close()
        fill(fillC)
        cv.drawPath(path, p)
        stroke(strokeC, 1.4f * d)
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    private fun ear(cv: Canvas, bx: Float, by: Float, dir: Float, r: Float, wig: Float, yellow: Int, line: Int) {
        cv.save()
        cv.rotate(wig, bx, by)
        path.reset()
        path.moveTo(bx - dir * r * 0.28f, by)
        path.quadTo(bx + dir * r * 0.05f, by - r * 0.75f, bx + dir * r * 0.55f, by - r * 1.0f)
        path.quadTo(bx + dir * r * 0.62f, by - r * 0.35f, bx + dir * r * 0.30f, by + r * 0.05f)
        path.close()
        fill(yellow)
        cv.drawPath(path, p)
        cv.save()
        cv.clipPath(path)
        fill(col("#1F1A12"))
        cv.drawRect(bx - r * 2f, by - r * 1.3f, bx + r * 2f, by - r * 0.68f, p)
        cv.restore()
        stroke(line, 1.6f * d)
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL
        cv.restore()
    }

    // ৫. বিজলি-ছানা: নিজের আঁকা হলুদ, লাল-গালের চরিত্র। কান নড়ে, বিদ্যুৎ-লেজ দোলে, চাপলে গাল থেকে ঝিলিক ছোটে
    private fun pika(cv: Canvas, cx: Float, cy: Float, base: Float) {
        val r = base * 0.95f
        val fy = cy + r * 0.18f
        val yellow = col("#FACC15")
        val line = col("#B45309")
        val dark = col("#1F1A12")

        // লেজ
        cv.save()
        cv.rotate(8f * sin(tau * t * 2f), cx + r * 0.8f, fy + r * 0.2f)
        bolt(cv, cx + r * 0.75f, fy - r * 1.0f, r * 1.05f, col("#FDE047"), line)
        cv.restore()

        // কান
        val wig = 5f * sin(tau * t * 2f)
        ear(cv, cx - r * 0.5f, fy - r * 0.78f, -1f, r, wig, yellow, line)
        ear(cv, cx + r * 0.5f, fy - r * 0.78f, 1f, r, -wig, yellow, line)

        // মুখ
        rect.set(cx - r * 1.05f, fy - r * 0.88f, cx + r * 1.05f, fy + r * 0.88f)
        fill(Color.WHITE)
        p.shader = RadialGradient(
            cx - r * 0.2f, fy - r * 0.4f, r * 1.5f,
            intArrayOf(col("#FEF08A"), yellow), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawOval(rect, p)
        stroke(line, 1.6f * d)
        cv.drawOval(rect, p)
        p.style = Paint.Style.FILL

        // চোখ (পলক ফেলে)
        val open = eyeOpen()
        for (sd in intArrayOf(-1, 1)) {
            val ex = cx + sd * r * 0.42f
            val ey = fy - r * 0.12f
            val er = r * 0.13f
            rect.set(ex - er, ey - er * open, ex + er, ey + er * open)
            fill(dark)
            cv.drawOval(rect, p)
            if (open > 0.5f) {
                fill(Color.WHITE)
                cv.drawCircle(ex + er * 0.3f, ey - er * 0.35f, er * 0.38f, p)
            }
        }

        // নাক আর মুখ
        rect.set(cx - r * 0.07f, fy + r * 0.04f, cx + r * 0.07f, fy + r * 0.14f)
        fill(dark)
        cv.drawOval(rect, p)
        path.reset()
        path.moveTo(cx - r * 0.22f, fy + r * 0.22f)
        path.quadTo(cx - r * 0.11f, fy + r * 0.38f, cx, fy + r * 0.22f)
        path.quadTo(cx + r * 0.11f, fy + r * 0.38f, cx + r * 0.22f, fy + r * 0.22f)
        stroke(dark, 1.5f * d)
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL

        // লাল গাল
        fill(Color.argb(245, 239, 68, 68))
        cv.drawCircle(cx - r * 0.68f, fy + r * 0.3f, r * 0.2f, p)
        cv.drawCircle(cx + r * 0.68f, fy + r * 0.3f, r * 0.2f, p)

        // চাপলে গাল থেকে বিদ্যুতের ঝিলিক
        if (tapP >= 0f) {
            val al = (255f * (1f - tapP)).toInt().coerceIn(0, 255)
            for (sd in intArrayOf(-1, 1)) {
                val bx = cx + sd * (r * 0.9f + tapP * r * 0.8f) - r * 0.25f
                val by = fy - r * 0.1f - tapP * r * 0.5f
                bolt(
                    cv, bx, by, r * 0.8f,
                    Color.argb(al, 253, 224, 71), Color.argb(al, 245, 158, 11)
                )
            }
        }
    }
}
