package com.you.firewall

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import kotlin.math.sqrt

/**
 * ফোন জোরে ঝাঁকালে প্যানিক। শুধু স্ক্রিন চালু থাকলে সেন্সর শোনে (ব্যাটারি বাঁচাতে), আর ফায়ারওয়াল সার্ভিস
 * চালু থাকলে (সার্ভিসের tick আর স্ক্রিন-ইভেন্ট থেকে [sync] ডাকা হয়)। পকেটে হাঁটার ঝাঁকুনিতে যেন না লাগে,
 * তাই ২ সেকেন্ডে ৪টা জোরালো ঝাঁকুনি (৩g-র বেশি) লাগে।
 */
object Shake : SensorEventListener {
    private const val NEED = 4
    private const val WINDOW_MS = 2000L
    private const val MIN_GAP_MS = 180L
    private const val G_LIMIT = 3.0f
    private const val COOLDOWN_MS = 15000L

    @Volatile private var registered = false
    private var appCtx: Context? = null
    private val peaks = ArrayList<Long>()
    private var lastPeak = 0L
    private var lastFire = 0L

    fun sync(c: Context) {
        val ctx = c.applicationContext
        appCtx = ctx
        val want = Store.load(ctx).optBoolean("panicShake", false) &&
            (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        if (want && !registered) {
            val a = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            registered = sm.registerListener(this, a, SensorManager.SENSOR_DELAY_UI)
            peaks.clear()
        } else if (!want && registered) {
            stop()
        }
    }

    fun stop() {
        val ctx = appCtx ?: return
        try {
            (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        } catch (e: Exception) {
        }
        registered = false
        peaks.clear()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) /
            SensorManager.GRAVITY_EARTH
        if (g < G_LIMIT) return
        val now = System.currentTimeMillis()
        if (now - lastPeak < MIN_GAP_MS) return
        lastPeak = now
        peaks.add(now)
        peaks.removeAll { now - it > WINDOW_MS }
        if (peaks.size >= NEED && now - lastFire > COOLDOWN_MS) {
            lastFire = now
            peaks.clear()
            val ctx = appCtx ?: return
            try { Panic.trigger(ctx) } catch (ex: Exception) {}
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
