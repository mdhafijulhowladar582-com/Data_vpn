package com.you.firewall

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * দৈনিক/মাসিক মোবাইল ডেটা লিমিটের সেটিং ও হিসাব।
 * - সেটিং Dart থেকে আসে (cfg JSON-এর dl* ফিল্ড), এখানে শুধু পড়া হয়।
 * - "আরও X MB" আর সতর্কতা পাঠানো হয়েছে কিনা, এই অবস্থার মালিক Kotlin (আলাদা prefs কী "dl"),
 *   তাই Dart-এর সেভ এটা মুছতে পারে না।
 */
object DataLimit {
    const val MB = 1024L * 1024L

    class Cfg(
        val phoneMb: Long,
        val apps: Map<String, Long>,
        val warnPct: List<Int>,
        val warnMb: List<Long>,
        val cut: Boolean,
        val wifi: Boolean,
        val resetDay: Int,
        val exempt: Set<String>,
        val packMb: Long,
        val packDays: Int,
        val packStart: Long,
        val packStrict: Boolean
    ) {
        val pack: Boolean get() = packMb > 0 && packDays > 0 && packStart > 0
        val any: Boolean get() = phoneMb > 0 || apps.isNotEmpty() || pack
    }

    fun cfg(j: JSONObject): Cfg {
        val apps = HashMap<String, Long>()
        val ao = j.optJSONObject("dlApps")
        if (ao != null) {
            for (k in ao.keys()) {
                val v = ao.optLong(k, 0L)
                if (v > 0) apps[k] = v
            }
        }
        val wp = ArrayList<Int>()
        val wa = j.optJSONArray("dlWarnPct")
        if (wa != null) for (i in 0 until wa.length()) wp.add(wa.optInt(i))
        val wm = ArrayList<Long>()
        val wb = j.optJSONArray("dlWarnMb")
        if (wb != null) for (i in 0 until wb.length()) wm.add(wb.optLong(i))
        val ex = HashSet<String>()
        val ea = j.optJSONArray("dlExempt")
        if (ea != null) for (i in 0 until ea.length()) ex.add(ea.optString(i))
        return Cfg(
            j.optLong("dlPhoneMb", 0L),
            apps,
            wp,
            wm,
            j.optBoolean("dlCut"),
            j.optBoolean("dlWifi"),
            j.optInt("dlResetDay", 0),
            ex,
            j.optLong("dlPackMb", 0L),
            j.optInt("dlPackDays", 0),
            j.optLong("dlPackStart", 0L),
            j.optBoolean("dlPackStrict", true)
        )
    }

    /** গণনার শুরু: resetDay = 0 হলে আজ মাঝরাত, ১-২৮ হলে সবশেষ ওই তারিখের মাঝরাত */
    fun periodStart(resetDay: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (resetDay in 1..28) {
            c.set(Calendar.DAY_OF_MONTH, resetDay)
            if (c.timeInMillis > System.currentTimeMillis()) c.add(Calendar.MONTH, -1)
        }
        return c.timeInMillis
    }


    // ---------------- ডেটা প্যাক বাজেট ----------------

    const val DAY = 24L * 60L * 60L * 1000L

    fun dayStart(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /**
     * প্যাকের হিসাব (শুধু মোবাইল ডেটা)।
     * todayAllow = আজকের ন্যায্য ভাগ (আজ শুরুর বাকি ডেটা ÷ বাকি দিন);
     * lastDays = এই হারে চললে আর কত দিন চলবে (-1 = এখনও হিসাব করার মতো তথ্য নেই);
     * strict = প্যাকের ২৫% বা কম বাকি
     */
    class Budget(
        val active: Boolean,
        val used: Long,
        val remain: Long,
        val daysLeft: Int,
        val todayUsed: Long,
        val todayAllow: Long,
        val lastDays: Double,
        val strict: Boolean,
        val end: Long
    )

    fun budget(c: Context, dc: Cfg): Budget? {
        if (!dc.pack) return null
        val now = System.currentTimeMillis()
        val end = dc.packStart + dc.packDays * DAY
        val packB = dc.packMb * MB
        val used = UsageUtil.dataSince(c, dc.packStart, false, false).total
        val remain = packB - used
        if (now >= end) return Budget(false, used, remain, 0, 0L, 0L, -1.0, false, end)
        val day0 = dayStart()
        val todayFrom = if (day0 > dc.packStart) day0 else dc.packStart
        val todayUsed = if (todayFrom == dc.packStart) used else UsageUtil.dataSince(c, todayFrom, false, false).total
        var daysLeft = Math.ceil((end - day0).toDouble() / DAY).toInt()
        if (daysLeft < 1) daysLeft = 1
        val beforeToday = used - todayUsed
        val allowRaw = (packB - beforeToday) / daysLeft
        val allow = if (allowRaw < 0L) 0L else allowRaw
        val elapsed = now - dc.packStart
        val last = when {
            remain <= 0L -> 0.0
            used <= 0L || elapsed < 6L * 60L * 60L * 1000L -> -1.0
            else -> remain.toDouble() / (used.toDouble() / elapsed.toDouble()) / DAY
        }
        val strict = remain * 100L <= packB * 25L
        return Budget(true, used, remain, daysLeft, todayUsed, allow, last, strict, end)
    }

    // ---------------- Kotlin-মালিকানার অবস্থা ----------------

    private fun readState(c: Context): JSONObject = try {
        JSONObject(Store.prefs(c).getString("dl", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun writeState(c: Context, j: JSONObject) {
        Store.prefs(c).edit().putString("dl", j.toString()).apply()
    }

    /** পিরিয়ড বদলে গেলে অবস্থা নতুন করে শুরু (বাড়তি MB ও সতর্কতার তালিকা মুছে যায়) */
    @Synchronized
    fun state(c: Context, periodKey: Long): JSONObject {
        val j = readState(c)
        if (j.optLong("key", -1L) != periodKey) {
            val n = JSONObject()
                .put("key", periodKey)
                .put("extra", 0L)
                .put("warned", JSONArray())
            writeState(c, n)
            return n
        }
        return j
    }

    /** আজকের (বা এই মাসের) জন্য ফোনের লিমিটে আরও [mb] MB যোগ */
    @Synchronized
    fun addExtra(c: Context, mb: Long, resetDay: Int) {
        val j = state(c, periodStart(resetDay))
        j.put("extra", j.optLong("extra", 0L) + mb)
        // নতুন সীমার জন্য শতাংশ ও "শেষ" সতর্কতা আবার আসবে
        val old = j.optJSONArray("warned") ?: JSONArray()
        val keep = JSONArray()
        for (i in 0 until old.length()) {
            val s = old.optString(i)
            if (!s.startsWith("p") && s != "full") keep.put(s)
        }
        j.put("warned", keep)
        writeState(c, j)
    }

    fun isWarned(j: JSONObject, key: String): Boolean {
        val a = j.optJSONArray("warned") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == key) return true
        return false
    }

    @Synchronized
    fun markWarned(c: Context, periodKey: Long, keys: List<String>) {
        if (keys.isEmpty()) return
        val j = state(c, periodKey)
        val a = j.optJSONArray("warned") ?: JSONArray().also { j.put("warned", it) }
        for (k in keys) if (!isWarned(j, k)) a.put(k)
        writeState(c, j)
    }

    /** Dart-এর জন্য বর্তমান অবস্থা */
    fun status(c: Context): Map<String, Any> {
        val dc = cfg(Store.load(c))
        val from = periodStart(dc.resetDay)
        val st = state(c, from)
        val use = UsageUtil.dataSince(c, from, dc.wifi, dc.apps.isNotEmpty())
        val list = ArrayList<Map<String, Any>>()
        for ((pkg, b) in use.apps) {
            if (pkg in dc.apps) list.add(mapOf("pkg" to pkg, "used" to b))
        }
        val out = HashMap<String, Any>()
        out["used"] = use.total
        out["extra"] = st.optLong("extra", 0L)
        out["from"] = from
        out["apps"] = list
        val bg = try {
            budget(c, dc)
        } catch (e: Exception) {
            null
        }
        if (bg != null) {
            out["pack"] = mapOf(
                "active" to bg.active,
                "used" to bg.used,
                "remain" to bg.remain,
                "daysLeft" to bg.daysLeft,
                "todayUsed" to bg.todayUsed,
                "todayAllow" to bg.todayAllow,
                "lastDays" to bg.lastDays,
                "strict" to bg.strict,
                "end" to bg.end
            )
        }
        return out
    }
}
