package com.you.firewall

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * দৈনিক/মাসিক মোবাইল ডেটা লিমিটের সেটিং ও হিসাব।
 * - সেটিং Dart থেকে আসে (cfg JSON-এর dl* ফিল্ড), এখানে শুধু পড়া হয়।
 * - "আরও X MB" আর সতর্কতা পাঠানো হয়েছে কিনা, এই অবস্থার মালিক Kotlin (আলাদা prefs কী "dl"),
 *   তাই Dart-এর সেভ এটা মুছতে পারে না।
 */
object DataLimit {
    const val MB = 1024L * 1024L

    class Cfg(
        val phoneMb: Long,
        val apps: Map<String, Long>,
        val warnPct: List<Int>,
        val warnMb: List<Long>,
        val cut: Boolean,
        val wifi: Boolean,
        val resetDay: Int,
        val exempt: Set<String>
    ) {
        val any: Boolean get() = phoneMb > 0 || apps.isNotEmpty()
    }

    fun cfg(j: JSONObject): Cfg {
        val apps = HashMap<String, Long>()
        val ao = j.optJSONObject("dlApps")
        if (ao != null) {
            for (k in ao.keys()) {
                val v = ao.optLong(k, 0L)
                if (v > 0) apps[k] = v
            }
        }
        val wp = ArrayList<Int>()
        val wa = j.optJSONArray("dlWarnPct")
        if (wa != null) for (i in 0 until wa.length()) wp.add(wa.optInt(i))
        val wm = ArrayList<Long>()
        val wb = j.optJSONArray("dlWarnMb")
        if (wb != null) for (i in 0 until wb.length()) wm.add(wb.optLong(i))
        val ex = HashSet<String>()
        val ea = j.optJSONArray("dlExempt")
        if (ea != null) for (i in 0 until ea.length()) ex.add(ea.optString(i))
        return Cfg(
            j.optLong("dlPhoneMb", 0L),
            apps,
            wp,
            wm,
            j.optBoolean("dlCut"),
            j.optBoolean("dlWifi"),
            j.optInt("dlResetDay", 0),
            ex
        )
    }

    /** গণনার শুরু: resetDay = 0 হলে আজ মাঝরাত, ১-২৮ হলে সবশেষ ওই তারিখের মাঝরাত */
    fun periodStart(resetDay: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (resetDay in 1..28) {
            c.set(Calendar.DAY_OF_MONTH, resetDay)
            if (c.timeInMillis > System.currentTimeMillis()) c.add(Calendar.MONTH, -1)
        }
        return c.timeInMillis
    }

    // ---------------- Kotlin-মালিকানার অবস্থা ----------------

    private fun readState(c: Context): JSONObject = try {
        JSONObject(Store.prefs(c).getString("dl", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun writeState(c: Context, j: JSONObject) {
        Store.prefs(c).edit().putString("dl", j.toString()).apply()
    }

    /** পিরিয়ড বদলে গেলে অবস্থা নতুন করে শুরু (বাড়তি MB ও সতর্কতার তালিকা মুছে যায়) */
    @Synchronized
    fun state(c: Context, periodKey: Long): JSONObject {
        val j = readState(c)
        if (j.optLong("key", -1L) != periodKey) {
            val n = JSONObject()
                .put("key", periodKey)
                .put("extra", 0L)
                .put("warned", JSONArray())
            writeState(c, n)
            return n
        }
        return j
    }

    /** আজকের (বা এই মাসের) জন্য ফোনের লিমিটে আরও [mb] MB যোগ */
    @Synchronized
    fun addExtra(c: Context, mb: Long, resetDay: Int) {
        val j = state(c, periodStart(resetDay))
        j.put("extra", j.optLong("extra", 0L) + mb)
        // নতুন সীমার জন্য শতাংশ ও "শেষ" সতর্কতা আবার আসবে
        val old = j.optJSONArray("warned") ?: JSONArray()
        val keep = JSONArray()
        for (i in 0 until old.length()) {
            val s = old.optString(i)
            if (!s.startsWith("p") && s != "full") keep.put(s)
        }
        j.put("warned", keep)
        writeState(c, j)
    }

    fun isWarned(j: JSONObject, key: String): Boolean {
        val a = j.optJSONArray("warned") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == key) return true
        return false
    }

    @Synchronized
    fun markWarned(c: Context, periodKey: Long, keys: List<String>) {
        if (keys.isEmpty()) return
        val j = state(c, periodKey)
        val a = j.optJSONArray("warned") ?: JSONArray().also { j.put("warned", it) }
        for (k in keys) if (!isWarned(j, k)) a.put(k)
        writeState(c, j)
    }

    /** Dart-এর জন্য বর্তমান অবস্থা */
    fun status(c: Context): Map<String, Any> {
        val dc = cfg(Store.load(c))
        val from = periodStart(dc.resetDay)
        val st = state(c, from)
        val use = UsageUtil.dataSince(c, from, dc.wifi, dc.apps.isNotEmpty())
        val list = ArrayList<Map<String, Any>>()
        for ((pkg, b) in use.apps) {
            if (pkg in dc.apps) list.add(mapOf("pkg" to pkg, "used" to b))
        }
        return mapOf(
            "used" to use.total,
            "extra" to st.optLong("extra", 0L),
            "from" to from,
            "apps" to list
        )
    }
}
