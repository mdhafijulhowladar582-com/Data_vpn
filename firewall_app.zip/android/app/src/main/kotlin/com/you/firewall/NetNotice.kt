package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** অ্যাপ খুললে ইন্টারনেট বন্ধ থাকলে কারণসহ নোটিফিকেশন, আর "সাময়িক চালু" বোতাম */
object NetNotice {
    class R(val text: String, val canGrant: Boolean, val code: String = "rule")

    private const val CH = "fwn"
    private val lastAt = HashMap<String, Long>()

    private fun has(a: JSONArray?, pkg: String): Boolean {
        if (a == null) return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    private fun inSchedule(c: JSONObject): Boolean {
        if (!c.optBoolean("scheduleEnabled")) return false
        val s = c.optInt("schStart", 0)
        val e = c.optInt("schEnd", 360)
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    fun label(c: Context, pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    /** এই অ্যাপের ইন্টারনেট এখন বন্ধ থাকলে কারণ, না হলে null (FirewallVpnService.rebuild-এর নিয়মের হুবহু মিল) */
    fun reason(c: Context, pkg: String): R? {
        if (!FirewallVpnService.running) return null
        if (pkg == c.packageName) return null
        if (pkg in Store.emergency(c)) return null
        val focus = Store.focusActive(c)
        if (!focus && Store.tempAllowed(c).containsKey(pkg)) return null
        val cfg = Store.load(c)
        val lim = FirewallVpnService.limApps
        val net = FirewallVpnService.netNow
        val limText = "এই অ্যাপের ডেটা বা সময় লিমিট শেষ"

        if (cfg.optBoolean("blockAll")) return R("\"সব ব্লক\" চালু আছে", true, "all")
        if (inSchedule(cfg)) return R("ব্লকের সময়সূচি চলছে", true, "sched")
        if (FirewallVpnService.roamBlockOn) return R("রোমিং ব্লক চালু (মোবাইল ডেটা বন্ধ)", true, "roam")
        val wifiFree = FirewallVpnService.wifiOpenNow
        if (FirewallVpnService.dataCutOn) {
            val ex = DataLimit.cfg(cfg).exempt
            return if (pkg in ex && pkg !in lim) null
            else R(if (pkg in lim) limText else "ফোনের ডেটা লিমিট শেষ", true, if (pkg in lim) "applimit" else "data")
        }
        val wl = cfg.optString("mode", "blocklist") == "whitelist" && !wifiFree
        val prof = if (focus) null else Store.activeProfile(c)
        if (focus || prof != null || wl) {
            val list = if (focus) cfg.optJSONArray("focusAllowed")
            else if (prof != null) prof.optJSONArray("allowed")
            else cfg.optJSONArray("allowed")
            return if (has(list, pkg) && pkg !in lim) null
            else if (pkg in lim) R(limText, !focus, "applimit")
            else if (focus) R("ফোকাস চলছে, এই অ্যাপ অনুমতির বাইরে", false, "focus")
            else if (prof != null) R("${prof.optString("name")} চালু, এই অ্যাপ অনুমতির বাইরে", true, "profile")
            else R("হোয়াইটলিস্ট মোড, এই অ্যাপ অনুমতি তালিকায় নেই", true, "whitelist")
        }
        if (pkg in lim) return R(limText, true, "applimit")
        if (wifiFree) return null // Wi-Fi-তে সব খোলা
        val r = (cfg.optJSONObject("rules") ?: JSONObject()).optJSONObject(pkg) ?: return null
        val blocked = when (net) {
            "wifi" -> r.optBoolean("wifi")
            "mobile" -> r.optBoolean("mobile")
            else -> r.optBoolean("wifi") || r.optBoolean("mobile")
        }
        if (!blocked) return null
        val where = when (net) { "wifi" -> " (Wi-Fi)"; "mobile" -> " (মোবাইল ডেটা)"; else -> "" }
        return R("ব্লকলিস্টে আছে$where", true)
    }

    /** অ্যাপ সামনে এলে ডাকা হয়। একই অ্যাপে ১০ মিনিটে একবার */
    fun maybe(c: Context, pkg: String) {
        if (!FirewallVpnService.running) return
        if (!Store.load(c).optBoolean("noticeOn", true)) return
        val now = System.currentTimeMillis()
        synchronized(lastAt) {
            val l = lastAt[pkg]
            if (l != null && now - l < 10 * 60000L) return
        }
        if (Store.noticeMuted(c, pkg)) return
        val r = reason(c, pkg) ?: return
        synchronized(lastAt) { lastAt[pkg] = now }
        show(c, pkg, r)
    }

    private fun nid(pkg: String) = 5000 + (pkg.hashCode() and 0xffff)

    private fun grantAction(c: Context, pkg: String, slot: Int, min: Int): PendingIntent {
        val rc = nid(pkg) * 4 + slot
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (Store.load(c).optString("pinHash").isNotEmpty()) {
            // পিন সেট থাকলে আগে পিন/ফিঙ্গারপ্রিন্ট
            PendingIntent.getActivity(
                c, rc,
                Intent(c, LockActivity::class.java)
                    .putExtra("pkg", pkg).putExtra("grantMin", min)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                flags
            )
        } else {
            PendingIntent.getBroadcast(
                c, rc,
                Intent(c, NoticeReceiver::class.java)
                    .setAction("GRANT").putExtra("pkg", pkg).putExtra("min", min),
                flags
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun show(c: Context, pkg: String, r: R) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "ইন্টারনেট বন্ধের খবর", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val id = nid(pkg)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH)
            else Notification.Builder(c)
            val text = "কারণ: ${r.text}"
            b.setContentTitle("${label(c, pkg)}-এর ইন্টারনেট বন্ধ")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setAutoCancel(true)
            if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(30000L)
            if (r.canGrant) {
                b.addAction(0, "১৫ মিনিট চালু", grantAction(c, pkg, 0, 15))
                b.addAction(0, "৬০ মিনিট", grantAction(c, pkg, 1, 60))
            }
            val mute = PendingIntent.getBroadcast(
                c, id * 4 + 2,
                Intent(c, NoticeReceiver::class.java).setAction("MUTE").putExtra("pkg", pkg),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "আজ আর না", mute)
            nm.notify(id, b.build())
        } catch (e: Exception) {
        }
    }

    /** সাময়িক চালু দেওয়া (পিন যাচাইয়ের পরে বা পিন ছাড়া সরাসরি) */
    fun grant(c: Context, pkg: String, min: Int) {
        if (Store.focusActive(c)) return // ফোকাস চলাকালে ছাড় নেই
        Store.grantTemp(c, pkg, min)
        FirewallVpnService.reload(c)
        Alert.show(
            c, nid(pkg), "${label(c, pkg)} $min মিনিট চালু",
            "সময় শেষে নিজে আবার ব্লক হবে।"
        )
    }
}

class NoticeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pkg = i.getStringExtra("pkg") ?: return
        when (i.action) {
            "GRANT" -> NetNotice.grant(c, pkg, i.getIntExtra("min", 15))
            "MUTE" -> {
                Store.muteNotice(c, pkg)
                Alert.cancel(c, 5000 + (pkg.hashCode() and 0xffff))
            }
            "NEW_ALLOW" -> {
                Safety.allowApp(c, pkg)
                Alert.cancel(c, Safety.idNew(pkg))
            }
            "NEW_BLOCK" -> Alert.cancel(c, Safety.idNew(pkg))
            "LEAK_BLOCK" -> {
                Safety.blockApp(c, pkg)
                Alert.cancel(c, Safety.idLeak(pkg))
            }
            "PERM_BLOCK" -> {
                Safety.blockApp(c, pkg)
                Alert.cancel(c, Safety.idPerm(pkg))
            }
        }
    }
}
