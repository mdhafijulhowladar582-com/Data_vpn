package com.you.firewall

import android.annotation.TargetApi
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * ফাইল ভল্ট।
 * - প্রতিটা ফাইল AES-256-GCM, ২৫৬ KB চাঙ্কে (বড় ফাইলেও মেমরি কম লাগে)।
 * - একটা র‍্যান্ডম ডেটা-চাবি (DEK)। DEK-কে Android Keystore-এর চাবি দিয়ে মুড়ে prefs-এ রাখা হয়।
 * - ফাইলের তালিকা (নামসহ) আলাদা এনক্রিপ্টেড ফাইলে, তাই ডিস্কে আসল নাম দেখা যায় না।
 * - ব্যাকআপ কী = DEK নিজেই (FVK1-...)। Keystore চাবি হারালে এটা দিয়ে ফেরত আনা যায়।
 */
@TargetApi(23)
object VaultManager {
    private const val ALIAS = "firewall_vault_master"
    private const val PREFS = "vault_prefs"
    private const val CHUNK = 256 * 1024
    private val MAGIC = byteArrayOf(0x46, 0x56, 0x31) // "FV1"
    private val rnd = SecureRandom()
    private val lock = Any()

    @Volatile
    private var dekCache: ByteArray? = null

    fun supported() = Build.VERSION.SDK_INT >= 23

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun dir(c: Context): File = File(c.filesDir, "vault").also { it.mkdirs() }
    private fun tmpDir(c: Context): File = File(c.cacheDir, "vault_tmp").also { it.mkdirs() }
    private fun indexFile(c: Context) = File(dir(c), "index.bin")

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    // ---------- চাবি ----------

    private fun masterKey(create: Boolean): SecretKey? {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val ex = ks.getKey(ALIAS, null)
        if (ex is SecretKey) return ex
        if (!create) return null
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    private fun wrap(c: Context, dek: ByteArray) {
        val k = masterKey(true) ?: throw IllegalStateException("no master key")
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, k)
        val ct = ci.doFinal(dek)
        prefs(c).edit().putString("dek", b64(ci.iv) + ":" + b64(ct)).commit()
    }

    private fun unwrap(c: Context): ByteArray? {
        val s = prefs(c).getString("dek", null) ?: return null
        val k = masterKey(false) ?: throw IllegalStateException("master key lost")
        val p = s.split(":")
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, unb64(p[0])))
        return ci.doFinal(unb64(p[1]))
    }

    private fun dek(c: Context): ByteArray {
        val cached = dekCache
        if (cached != null) return cached
        return synchronized(lock) {
            val again = dekCache
            if (again != null) {
                again
            } else {
                var d: ByteArray? = unwrap(c)
                if (d == null) {
                    // ফাইল আছে অথচ চাবি নেই: নতুন চাবি বানালে পুরোনো ফাইল চিরতরে হারাবে
                    if (indexFile(c).exists()) throw IllegalStateException("need restore")
                    val n = ByteArray(32)
                    rnd.nextBytes(n)
                    wrap(c, n)
                    d = n
                }
                dekCache = d
                d
            }
        }
    }

    /** "unsupported" | "ready" | "restore" */
    fun status(c: Context): String {
        if (!supported()) return "unsupported"
        return try {
            dek(c)
            "ready"
        } catch (e: Exception) {
            "restore"
        }
    }

    // ---------- এনক্রিপশন ----------

    private fun gcm(mode: Int, key: ByteArray, iv: ByteArray): Cipher {
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return ci
    }

    private fun seal(key: ByteArray, data: ByteArray): ByteArray {
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        return iv + gcm(Cipher.ENCRYPT_MODE, key, iv).doFinal(data)
    }

    private fun unseal(key: ByteArray, blob: ByteArray): ByteArray {
        if (blob.size < 28) throw IOException("bad blob")
        val iv = blob.copyOfRange(0, 12)
        return gcm(Cipher.DECRYPT_MODE, key, iv).doFinal(blob, 12, blob.size - 12)
    }

    private fun chunkIv(prefix: ByteArray, idx: Int): ByteArray {
        val iv = ByteArray(12)
        System.arraycopy(prefix, 0, iv, 0, 8)
        iv[8] = (idx ushr 24).toByte()
        iv[9] = (idx ushr 16).toByte()
        iv[10] = (idx ushr 8).toByte()
        iv[11] = idx.toByte()
        return iv
    }

    private fun readFull(i: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = i.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    /** ফরম্যাট: "FV1" + ৮ বাইট prefix + [৪ বাইট দৈর্ঘ্য + চাঙ্ক]... শেষ চাঙ্কের AAD = 1 (ছাঁটাই ধরা পড়ে) */
    private fun encryptStream(key: ByteArray, input: InputStream, out: File): Long {
        val prefix = ByteArray(8)
        rnd.nextBytes(prefix)
        var total = 0L
        FileOutputStream(out).use { fo ->
            val dos = DataOutputStream(BufferedOutputStream(fo))
            dos.write(MAGIC)
            dos.write(prefix)
            var cur = ByteArray(CHUNK)
            var nxt = ByteArray(CHUNK)
            var curN = readFull(input, cur)
            var idx = 0
            while (true) {
                val nxtN = if (curN == CHUNK) readFull(input, nxt) else 0
                val last = nxtN == 0
                val ci = gcm(Cipher.ENCRYPT_MODE, key, chunkIv(prefix, idx))
                ci.updateAAD(byteArrayOf(if (last) 1 else 0))
                val ct = ci.doFinal(cur, 0, curN)
                dos.writeInt(ct.size)
                dos.write(ct)
                total += curN
                if (last) break
                val t = cur
                cur = nxt
                nxt = t
                curN = nxtN
                idx++
            }
            dos.flush()
            fo.fd.sync()
        }
        return total
    }

    private fun decryptStream(key: ByteArray, f: File, out: OutputStream) {
        val fileLen = f.length()
        DataInputStream(BufferedInputStream(FileInputStream(f))).use { di ->
            val m = ByteArray(3)
            di.readFully(m)
            if (!m.contentEquals(MAGIC)) throw IOException("bad file")
            val prefix = ByteArray(8)
            di.readFully(prefix)
            var consumed = 11L
            var idx = 0
            while (true) {
                val len = di.readInt()
                if (len < 16 || len > CHUNK + 16) throw IOException("bad chunk")
                val ct = ByteArray(len)
                di.readFully(ct)
                consumed += 4L + len
                val last = consumed >= fileLen
                val ci = gcm(Cipher.DECRYPT_MODE, key, chunkIv(prefix, idx))
                ci.updateAAD(byteArrayOf(if (last) 1 else 0))
                out.write(ci.doFinal(ct))
                if (last) break
                idx++
            }
        }
    }

    // ---------- তালিকা ----------

    private fun loadIndex(c: Context): JSONArray {
        val f = indexFile(c)
        if (!f.exists()) return JSONArray()
        val plain = unseal(dek(c), f.readBytes())
        return JSONArray(String(plain, Charsets.UTF_8))
    }

    private fun saveIndex(c: Context, a: JSONArray) {
        val blob = seal(dek(c), a.toString().toByteArray(Charsets.UTF_8))
        val tmp = File(dir(c), "index.tmp")
        FileOutputStream(tmp).use {
            it.write(blob)
            it.fd.sync()
        }
        if (!tmp.renameTo(indexFile(c))) throw IOException("index save failed")
    }

    fun meta(c: Context, id: String): JSONObject? {
        synchronized(lock) {
            val a = loadIndex(c)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optString("id") == id) return o
            }
        }
        return null
    }

    fun list(c: Context): List<Map<String, Any>> {
        val r = ArrayList<Map<String, Any>>()
        synchronized(lock) {
            val a = loadIndex(c)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                r.add(
                    mapOf(
                        "id" to o.optString("id"),
                        "name" to o.optString("name"),
                        "size" to o.optLong("size"),
                        "added" to o.optLong("added"),
                        "mime" to o.optString("mime")
                    )
                )
            }
        }
        return r.sortedByDescending { it["added"] as Long }
    }

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun newId(): String {
        val b = ByteArray(16)
        rnd.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    /** একটা ফাইল ভল্টে ঢোকায়। ব্যর্থ হলে আধা-লেখা ফাইল মুছে ফেলে। */
    fun add(c: Context, input: InputStream, rawName: String): Map<String, Any> {
        val name = rawName.replace('/', '_').ifBlank { "file" }
        val key = dek(c)
        val id = newId()
        val out = File(dir(c), "$id.enc")
        try {
            val size = encryptStream(key, input, out)
            synchronized(lock) {
                val a = loadIndex(c)
                a.put(
                    JSONObject()
                        .put("id", id)
                        .put("name", name)
                        .put("size", size)
                        .put("added", System.currentTimeMillis())
                        .put("mime", guessMime(name))
                )
                saveIndex(c, a)
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return mapOf("id" to id, "name" to name)
    }

    /** ভল্টের এনক্রিপ্ট করা ফাইল আবার ডিক্রিপ্ট করে আসল আকারের সাথে মেলায়। মিললেই শুধু অরিজিনাল মোছা নিরাপদ */
    fun verify(c: Context, id: String): Boolean {
        if (!Regex("[0-9a-f]{32}").matches(id)) return false
        return try {
            val want = meta(c, id)?.optLong("size", -1L) ?: -1L
            if (want < 0L) return false
            var n = 0L
            val sink = object : OutputStream() {
                override fun write(b: Int) {
                    n++
                }

                override fun write(b: ByteArray, off: Int, len: Int) {
                    n += len
                }
            }
            decryptStream(dek(c), File(dir(c), "$id.enc"), sink)
            n == want
        } catch (e: Exception) {
            false
        }
    }

    fun delete(c: Context, id: String): Boolean {
        if (!Regex("[0-9a-f]{32}").matches(id)) return false
        synchronized(lock) {
            val a = loadIndex(c)
            val n = JSONArray()
            var found = false
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optString("id") == id) found = true else n.put(o)
            }
            if (!found) return false
            saveIndex(c, n)
        }
        File(dir(c), "$id.enc").delete()
        File(tmpDir(c), "$id.tmp").delete()
        return true
    }

    // ---------- খোলা / শেয়ার ----------

    /** ডিক্রিপ্ট করা অস্থায়ী কপি (cache-এ)। দেখা শেষে cleanTemp মোছে। */
    fun prepareTemp(c: Context, id: String): File {
        if (!Regex("[0-9a-f]{32}").matches(id)) throw FileNotFoundException()
        if (meta(c, id) == null) throw FileNotFoundException()
        val t = File(tmpDir(c), "$id.tmp")
        if (t.exists()) return t
        val part = File(tmpDir(c), "$id.part")
        try {
            FileOutputStream(part).use { decryptStream(dek(c), File(dir(c), "$id.enc"), it) }
            if (!part.renameTo(t)) throw IOException("temp failed")
        } catch (e: Exception) {
            part.delete()
            throw e
        }
        return t
    }

    fun cleanTemp(c: Context) {
        tmpDir(c).listFiles()?.forEach { it.delete() }
    }

    /** প্যানিক: মেমরি থেকে চাবি সরানো আর ডিক্রিপ্ট করা অস্থায়ী কপি মোছা */
    fun wipe(c: Context) {
        synchronized(lock) {
            dekCache = null // চলমান কাজের হাতে থাকা কপি নষ্ট না করতে শুধু রেফারেন্স ছাড়ি
        }
        cleanTemp(c)
    }

    private fun uriFor(c: Context, id: String, name: String): Uri =
        Uri.parse("content://${c.packageName}.vault/$id/${Uri.encode(name)}")

    fun viewIntent(c: Context, id: String): Intent {
        val e = meta(c, id) ?: throw FileNotFoundException()
        prepareTemp(c, id)
        return Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(c, id, e.optString("name")), e.optString("mime"))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    fun shareIntent(c: Context, id: String): Intent {
        val e = meta(c, id) ?: throw FileNotFoundException()
        prepareTemp(c, id)
        val send = Intent(Intent.ACTION_SEND)
            .setType(e.optString("mime"))
            .putExtra(Intent.EXTRA_STREAM, uriFor(c, id, e.optString("name")))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return Intent.createChooser(send, e.optString("name"))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    // ---------- ব্যাকআপ কী ----------

    fun backupKey(c: Context): String =
        "FVK1-" + Base64.encodeToString(dek(c), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)

    /** ঠিক চাবি হলে Keystore-এ আবার মুড়ে রাখে। ভুল হলে false। */
    fun restoreKey(c: Context, text: String): Boolean {
        val t = text.trim()
        if (!t.startsWith("FVK1-")) return false
        val k = try {
            Base64.decode(t.substring(5), Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
        } catch (e: Exception) {
            return false
        }
        if (k.size != 32) return false
        synchronized(lock) {
            val f = indexFile(c)
            if (f.exists()) {
                try {
                    unseal(k, f.readBytes())
                } catch (e: Exception) {
                    return false
                }
            }
            wrap(c, k)
            dekCache = k
        }
        return true
    }
}
