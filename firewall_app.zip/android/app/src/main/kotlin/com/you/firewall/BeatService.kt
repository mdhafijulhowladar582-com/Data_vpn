package com.you.firewall

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.PI
import kotlin.math.sin

/**
 * নেট-হার্টবিট: ভাসমান হৃদস্পন্দনের রেখা (ECG)।
 * নেট স্পিড কম হলে ধীরে চলে, বাড়লে দ্রুত। কোনো অ্যাপ সামনে না থেকেও (বা স্ক্রিন বন্ধ থাকতেও) চুপিচুপি
 * ডেটা পাঠালে (LiveNet-এর "সন্দেহজনক") রেখা লাল হয়ে পাগলের মতো লাফায় আর ফোন একটু কাঁপে।
 */
class BeatService : Service() {
    companion object {
        @Volatile
        var running = false
        private const val ID = 7424 // 7421 আগে থেকেই Extras.ID_REPORT-এর
        private const val PANIC_MS = 20_000L
        private const val VIB_GAP_MS = 120_000L
    }

    private lateinit var wm: WindowManager
    private var view: BeatView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null

    private var lastTotal = -1L
    private var lastAt = 0L
    private var speed = 0f
    private var panicUntil = 0L
    private val lastVib = HashMap<String, Long>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Buddy.foreground(this, ID, "fw_beat", "নেট-হার্টবিট", "নেট-হার্টবিট চালু", "বন্ধ করতে অ্যাপের নতুন সার্ভিস পেজে সুইচ বন্ধ করুন", "buddy")
        if (!Buddy.canDraw(this) || !Buddy.on(this, "beat")) {
            Buddy.putOff(this, "beat")
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (view == null) addView()
        ui.removeCallbacks(tickR)
        ui.post(tickR)
        if (bgThread == null) {
            val t = HandlerThread("beat-scan")
            t.start()
            bgThread = t
            bg = Handler(t.looper)
            bg?.postDelayed(scanR, 4000)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        bg?.removeCallbacksAndMessages(null)
        bgThread?.quitSafely()
        bgThread = null
        bg = null
        view?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        view = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun addView() {
        val dm = resources.displayMetrics
        val w = dp(150)
        val h = dp(54)
        val params = WindowManager.LayoutParams(
            w, h, Buddy.overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = Buddy.int(this, "beatX", dp(12)).coerceIn(0, maxOf(0, dm.widthPixels - w))
        params.y = Buddy.int(this, "beatY", dp(90)).coerceIn(0, maxOf(0, dm.heightPixels - h))
        val v = BeatView(this)
        Buddy.drag(this, wm, v, params, "beatX", "beatY", false) { }
        try {
            wm.addView(v, params)
            view = v
            lp = params
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun bpmFor(bps: Float): Float = Buddy.bpmFor(bps)

    private fun fmt(bps: Float): String = Buddy.fmtSpeed(bps)

    private val tickR = object : Runnable {
        override fun run() {
            val v = view ?: return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val screen = pm.isInteractive
            if (screen) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastAt >= 1000L) {
                    val tot = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
                    if (lastTotal >= 0L && tot >= lastTotal && lastAt > 0L) {
                        speed = (tot - lastTotal) * 1000f / (now - lastAt)
                    }
                    lastTotal = tot
                    lastAt = now
                }
                val panic = System.currentTimeMillis() < panicUntil
                v.panic = panic
                v.bpm = if (panic) 190f else bpmFor(speed)
                v.speedText = fmt(speed)
                v.step(0.05f)
                ui.postDelayed(this, 50)
            } else {
                // স্ক্রিন বন্ধ: আঁকা বন্ধ, শুধু মাঝে মাঝে ঘুরে দেখে
                lastTotal = -1L
                ui.postDelayed(this, 2000)
            }
        }
    }

    /** প্রতি ১২ সেকেন্ডে কোন অ্যাপ চুপিচুপি ডেটা পাঠাচ্ছে দেখে */
    private val scanR = object : Runnable {
        override fun run() {
            try {
                val rows = LiveNet.sample(this@BeatService)
                val bad = rows.filter { it.suspicious && !it.system }.maxByOrNull { it.bps }
                if (bad != null) ui.post { panic(bad.label, bad.pkg) }
            } catch (e: Exception) {
            }
            bg?.postDelayed(this, 12_000)
        }
    }

    private fun panic(label: String, pkg: String) {
        panicUntil = System.currentTimeMillis() + PANIC_MS
        Buddy.putLong(this, "beatPanicUntil", panicUntil) // হোম স্ক্রিন উইজেটও লাল দেখায়
        PetWidget.refreshAll(this)
        view?.label = "$label চুপিচুপি ডেটা পাঠাচ্ছে"
        val now = System.currentTimeMillis()
        if (Buddy.bool(this, "beatVib", true) && now - (lastVib[pkg] ?: 0L) > VIB_GAP_MS) {
            lastVib[pkg] = now
            try {
                val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(250)
                }
            } catch (e: Exception) {
            }
        }
    }
}

class BeatView(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val n = 90
    private val buf = FloatArray(n)
    private var head = 0
    private var phase = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val rnd = java.util.Random()
    private val pif = PI.toFloat()

    var bpm = 40f
    var panic = false
    var speedText = ""
    var label = ""

    fun step(dtSec: Float) {
        phase += dtSec * bpm / 60f
        while (phase >= 1f) phase -= 1f
        var v = wave(phase)
        if (panic) v = v * (1.2f + rnd.nextFloat() * 0.8f) + (rnd.nextFloat() - 0.5f) * 0.5f
        buf[head] = v
        head = (head + 1) % n
        invalidate()
    }

    private fun wave(x: Float): Float = when {
        x < 0.08f -> 0f
        x < 0.20f -> 0.12f * sin((x - 0.08f) / 0.12f * pif)
        x < 0.28f -> 0f
        x < 0.31f -> -0.18f * ((x - 0.28f) / 0.03f)
        x < 0.35f -> -0.18f + 1.18f * ((x - 0.31f) / 0.04f)
        x < 0.39f -> 1.0f - 1.35f * ((x - 0.35f) / 0.04f)
        x < 0.43f -> -0.35f + 0.35f * ((x - 0.39f) / 0.04f)
        x < 0.58f -> 0f
        x < 0.74f -> 0.22f * sin((x - 0.58f) / 0.16f * pif)
        else -> 0f
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val line = if (panic) Color.parseColor("#F87171") else Color.parseColor("#34D399")

        rect.set(0f, 0f, w, h)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(185, 12, 12, 20)
        cv.drawRoundRect(rect, 14f * d, 14f * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Color.argb(120, Color.red(line), Color.green(line), Color.blue(line))
        cv.drawRoundRect(rect, 14f * d, 14f * d, p)

        val pad = 8f * d
        val y0 = h * 0.60f
        val amp = h * 0.40f
        path.reset()
        var lx = 0f
        var ly = 0f
        for (i in 0 until n) {
            val idx = (head + i) % n
            val x = pad + i * (w - 2f * pad) / (n - 1)
            val y = (y0 - buf[idx] * amp).coerceIn(3f * d, h - 3f * d)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            lx = x
            ly = y
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.2f * d
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(Color.argb(0, Color.red(line), Color.green(line), Color.blue(line)), line),
            floatArrayOf(0.05f, 0.9f), Shader.TileMode.CLAMP
        )
        cv.drawPath(path, p)

        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(90, Color.red(line), Color.green(line), Color.blue(line))
        cv.drawCircle(lx, ly, 6f * d, p)
        p.color = Color.WHITE
        cv.drawCircle(lx, ly, 2.2f * d, p)

        p.textSize = 9f * d
        if (panic && label.isNotEmpty()) {
            p.color = Color.parseColor("#FCA5A5")
            cv.drawText(label.take(26), pad, 11f * d, p)
        } else {
            p.color = Color.argb(170, 200, 210, 220)
            cv.drawText(speedText, pad, 11f * d, p)
        }
    }
}
