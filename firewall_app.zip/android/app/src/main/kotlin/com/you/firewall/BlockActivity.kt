package com.you.firewall

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** "সময় শেষ" / "ফোকাস চলছে" স্ক্রিন। কয়েক সেকেন্ড পর নিজেই হোমে পাঠায়। */
class BlockActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val goHomeRun = Runnable { goHome() }
    private lateinit var msg: TextView
    private lateinit var sub: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#0F172A"))
        root.setPadding(dp(32), dp(32), dp(32), dp(32))

        msg = TextView(this)
        msg.setTextColor(Color.WHITE)
        msg.textSize = 22f
        msg.gravity = Gravity.CENTER
        root.addView(msg)

        sub = TextView(this)
        sub.setTextColor(Color.parseColor("#94A3B8"))
        sub.textSize = 14f
        sub.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        root.addView(sub, lp)

        val btn = Button(this)
        btn.text = "হোমে যান"
        btn.setOnClickListener { goHome() }
        val bp = LinearLayout.LayoutParams(dp(220), LinearLayout.LayoutParams.WRAP_CONTENT)
        bp.topMargin = dp(28)
        root.addView(btn, bp)

        setContentView(root)
        show(intent)
    }

    private fun show(i: Intent) {
        val pkg = i.getStringExtra("pkg") ?: ""
        val reason = i.getStringExtra("reason")
        if (reason == "focus") {
            msg.text = "🎯 ফোকাস চলছে"
            sub.text = "${label(pkg)} এখন বন্ধ। ফোকাস শেষ হলে খুলতে পারবেন।"
        } else if (reason == "trade") {
            val left = Ctl.tradeLockLeftMs(this)
            val h = left / 3600000L
            val m = (left % 3600000L) / 60000L
            msg.text = "🛑 আজ আর না"
            sub.text = "${label(pkg)} ট্রেড ব্লকারে লক। আর ${h} ঘণ্টা ${m} মিনিট পর খুলবে।"
        } else if (reason == "ttg") {
            msg.text = "🥇 ট্রেড টাইম গার্ড"
            sub.text = "${label(pkg)} এখন বন্ধ। ট্রেডের সময় ${TradeTime.windowText(this)}।"
        } else if (reason == "bed") {
            msg.text = "🌙 ঘুমের সময়"
            sub.text = "${label(pkg)} এখন বন্ধ। সকালে খুলবে।"
        } else if (reason == "parent") {
            msg.text = "⏳ আজকের সময় শেষ"
            sub.text = "${label(pkg)}-এর আজকের সময়সীমা শেষ।"
        } else {
            msg.text = "⏳ সময় শেষ"
            sub.text = "${label(pkg)}-এর আজকের লিমিট শেষ।"
        }
        h.removeCallbacks(goHomeRun)
        h.postDelayed(goHomeRun, 2500)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        show(i)
    }

    private fun goHome() {
        h.removeCallbacks(goHomeRun)
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    override fun onDestroy() {
        h.removeCallbacks(goHomeRun)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }
}
