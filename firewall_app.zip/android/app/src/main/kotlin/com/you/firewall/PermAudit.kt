package com.you.firewall

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager

/**
 * পারমিশন অডিটর: কোন অ্যাপে কোন সংবেদনশীল পারমিশন দেওয়া আছে, অ্যাপটা শেষ কবে খোলা হয়েছে, আর ৩০ দিনে
 * নেটে কত ডেটা পাঠিয়েছে/এনেছে, এই তিনটা মিলিয়ে "সন্দেহের" স্তর বলে। এটা ম্যালওয়্যার ধরা নয়, শুধু
 * "ক্ষমতা আছে, ব্যবহার নেই, তবু নেটে কথা বলছে" ধরনের সন্দেহজনক ছাঁচ খোঁজা।
 *
 * স্তর (high / mid / low):
 *  - high: ১৪+ দিন খোলা হয়নি, ১ MB+ ডেটা গেছে, আর পারমিশনের ওজন ৪+
 *  - mid: ১৪+ দিন খোলা হয়নি আর ওজন ৪+ (নেট কম), অথবা ওজন ৮+ আর ৭+ দিন খোলা হয়নি আর ২০০ MB+ ডেটা
 *  - low: বাকি সব
 * Usage access না থাকলে খোলার সময় আর ডেটা জানা যায় না, তখন সবাই low আর পেজ অনুমতি চায়।
 */
object PermAudit {
    private class P(val perm: String, val label: String, val w: Int)

    private val LIST = listOf(
        P("android.permission.ACCESS_BACKGROUND_LOCATION", "ব্যাকগ্রাউন্ড লোকেশন", 3),
        P("android.permission.READ_SMS", "এসএমএস পড়া", 3),
        P("android.permission.READ_CALL_LOG", "কল লগ", 3),
        P("android.permission.RECORD_AUDIO", "মাইক্রোফোন", 2),
        P("android.permission.CAMERA", "ক্যামেরা", 2),
        P("android.permission.ACCESS_FINE_LOCATION", "সঠিক লোকেশন", 2),
        P("android.permission.READ_CONTACTS", "কন্টাক্টস", 2),
        P("android.permission.ACCESS_COARSE_LOCATION", "আনুমানিক লোকেশন", 1)
    )
    private const val DAY = 86400000L
    private const val MB = 1024L * 1024L

    /** পেজের জন্য: সবচেয়ে সন্দেহজনক আগে। প্রতিটা: pkg, name, score, level, perms, unusedDays, bytes, reasons */
    fun scan(c: Context): List<Map<String, Any>> {
        val now = System.currentTimeMillis()
        val pm = c.packageManager

        val last = HashMap<String, Long>()
        var usageOk = false
        try {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val l = usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, now - 400L * DAY, now)
            usageOk = l != null && l.isNotEmpty()
            if (l != null) for (u in l) if (u.lastTimeUsed > (last[u.packageName] ?: 0L)) last[u.packageName] = u.lastTimeUsed
        } catch (e: Exception) {
        }
        var data: Map<String, Long> = emptyMap()
        if (usageOk) {
            try { data = UsageUtil.dataSince(c, now - 30 * DAY, true, true).apps } catch (e: Exception) {}
        }

        val out = ArrayList<Map<String, Any>>()
        val pkgs = try {
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        } catch (e: Exception) {
            emptyList<PackageInfo>()
        }
        for (pi in pkgs) {
            val pkg = pi.packageName
            if (pkg == c.packageName || !Safety.isUserApp(c, pkg)) continue
            val req = pi.requestedPermissions ?: continue
            val flags = pi.requestedPermissionsFlags ?: continue
            val granted = HashSet<String>()
            for (i in req.indices) {
                if (i < flags.size && (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) granted.add(req[i])
            }
            val got = LIST.filter { it.perm in granted }.toMutableList()
            // সঠিক লোকেশন থাকলে আনুমানিক আলাদা গোনা হয় না
            if (got.any { it.perm.endsWith("ACCESS_FINE_LOCATION") }) got.removeAll { it.perm.endsWith("ACCESS_COARSE_LOCATION") }
            if (got.isEmpty()) continue
            val weight = got.sumOf { it.w }

            var unused = -1 // -1 = জানা নেই
            if (usageOk) {
                val lu = last[pkg] ?: 0L
                val ref = if (lu > 0L) lu else pi.firstInstallTime
                unused = ((now - ref) / DAY).toInt().coerceAtLeast(0)
            }
            val bytes = data[pkg] ?: 0L

            val level = when {
                unused < 0 -> "low"
                unused >= 14 && bytes >= MB && weight >= 4 -> "high"
                unused >= 14 && weight >= 4 -> "mid"
                weight >= 8 && unused >= 7 && bytes >= 200 * MB -> "mid"
                else -> "low"
            }
            val score = weight + (if (unused >= 30) 4 else if (unused >= 14) 2 else 0) +
                (if (bytes >= 500 * MB) 3 else if (bytes >= 50 * MB) 2 else if (bytes >= MB) 1 else 0)

            val reasons = ArrayList<String>()
            if (unused >= 14) reasons.add("$unused দিন ধরে খোলা হয়নি, অথচ এই পারমিশনগুলো দেওয়া আছে।")
            if (bytes >= MB) reasons.add("গত ৩০ দিনে ${Safety.fmtBytes(bytes)} ডেটা খরচ করেছে।")
            if (got.any { it.perm.endsWith("BACKGROUND_LOCATION") }) reasons.add("ব্যাকগ্রাউন্ডেও লোকেশন পায়, অ্যাপ বন্ধ থাকলেও।")
            if (reasons.isEmpty()) reasons.add("পারমিশনগুলো দেওয়া আছে, তবে ব্যবহারের ছাঁচে সন্দেহজনক কিছু নেই।")

            out.add(
                mapOf(
                    "pkg" to pkg, "name" to NetNotice.label(c, pkg), "score" to score, "level" to level,
                    "perms" to got.map { it.label }, "unusedDays" to unused, "bytes" to bytes, "reasons" to reasons,
                    "usageOk" to usageOk
                )
            )
        }
        out.sortByDescending { it["score"] as Int }
        return out
    }
}
