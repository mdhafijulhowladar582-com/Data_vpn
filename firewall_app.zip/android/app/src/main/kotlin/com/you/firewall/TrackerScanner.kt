package com.you.firewall

import android.content.Context
import android.content.pm.PackageManager

/**
 * ইনস্টল করা অ্যাপের ভেতরের কম্পোনেন্টের (Activity/Service/Receiver/Provider) নাম
 * পরিচিত বিজ্ঞাপন/ট্র্যাকার SDK-র প্যাকেজ-নামের সাথে মেলায়।
 * এটা স্ট্যাটিক মিল: কোড আছে কিনা বলে, চালানোর সময় ডেটা পাঠাচ্ছে কিনা বলে না।
 */
object TrackerScanner {
    // প্যাকেজ-প্রিফিক্স -> দেখানোর নাম
    private val SIGS: List<Pair<String, String>> = listOf(
        "com.google.android.gms.ads" to "Google AdMob",
        "com.google.ads" to "Google Ads",
        "com.google.android.gms.measurement" to "Google Analytics",
        "com.google.firebase.analytics" to "Firebase Analytics",
        "com.google.android.gms.analytics" to "Google Analytics",
        "com.facebook.ads" to "Facebook Audience Network",
        "com.facebook.appevents" to "Facebook Analytics",
        "com.applovin" to "AppLovin",
        "com.unity3d.ads" to "Unity Ads",
        "com.unity3d.services" to "Unity Ads",
        "com.ironsource" to "ironSource",
        "com.vungle" to "Vungle",
        "com.chartboost" to "Chartboost",
        "com.mbridge" to "Mintegral",
        "com.mintegral" to "Mintegral",
        "com.inmobi" to "InMobi",
        "com.mopub" to "MoPub",
        "com.startapp" to "StartApp",
        "com.adcolony" to "AdColony",
        "com.fyber" to "Fyber",
        "com.bytedance.sdk.openadsdk" to "Pangle (TikTok Ads)",
        "com.pangle" to "Pangle (TikTok Ads)",
        "com.smaato" to "Smaato",
        "com.tapjoy" to "Tapjoy",
        "net.pubnative" to "PubNative",
        "com.yandex.mobile.ads" to "Yandex Ads",
        "com.my.target" to "myTarget",
        "com.appsflyer" to "AppsFlyer",
        "com.adjust.sdk" to "Adjust",
        "com.flurry" to "Flurry",
        "com.amplitude" to "Amplitude",
        "com.mixpanel" to "Mixpanel",
        "io.branch" to "Branch",
        "com.kochava" to "Kochava",
        "com.singular" to "Singular",
        "com.segment.analytics" to "Segment",
        "com.onesignal" to "OneSignal",
        "com.clevertap" to "CleverTap",
        "com.moengage" to "MoEngage",
        "com.microsoft.appcenter.analytics" to "AppCenter Analytics",
        "com.crashlytics" to "Crashlytics",
        "io.fabric" to "Fabric",
        "com.umeng" to "Umeng",
        "com.taboola" to "Taboola",
        "com.outbrain" to "Outbrain",
        "com.criteo" to "Criteo",
        "com.digitalturbine" to "Digital Turbine",
        "com.ogury" to "Ogury",
        "com.iab.omid" to "IAB OM SDK",
    )

    private val FLAGS = intArrayOf(
        PackageManager.GET_ACTIVITIES,
        PackageManager.GET_SERVICES,
        PackageManager.GET_RECEIVERS,
        PackageManager.GET_PROVIDERS,
    )

    /** [{pkg, trackers: [নাম...]}] শুধু যাদের অন্তত একটা ট্র্যাকার আছে */
    fun scan(ctx: Context): List<Map<String, Any>> {
        val pm = ctx.packageManager
        val out = ArrayList<Map<String, Any>>()
        val pkgs = try {
            pm.getInstalledApplications(0).map { it.packageName }
        } catch (e: Exception) {
            emptyList()
        }
        for (pkg in pkgs) {
            if (pkg == ctx.packageName) continue
            val found = LinkedHashSet<String>()
            for (f in FLAGS) {
                // বড় অ্যাপে একসাথে সব চাইলে ব্যর্থ হতে পারে, তাই ধরন ধরে আলাদা আলাদা
                val names: List<String> = try {
                    val pi = pm.getPackageInfo(pkg, f)
                    when (f) {
                        PackageManager.GET_ACTIVITIES -> pi.activities?.map { it.name }
                        PackageManager.GET_SERVICES -> pi.services?.map { it.name }
                        PackageManager.GET_RECEIVERS -> pi.receivers?.map { it.name }
                        else -> pi.providers?.map { it.name }
                    } ?: emptyList()
                } catch (e: Exception) {
                    emptyList()
                }
                for (n in names) {
                    for ((prefix, label) in SIGS) {
                        if (n.startsWith(prefix)) {
                            found.add(label)
                            break
                        }
                    }
                }
            }
            if (found.isNotEmpty()) {
                out.add(mapOf("pkg" to pkg, "trackers" to found.toList()))
            }
        }
        return out
    }
}
