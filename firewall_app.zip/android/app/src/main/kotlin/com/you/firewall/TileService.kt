package com.you.firewall

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class FirewallTile : TileService() {

    override fun onStartListening() {
        render(FirewallVpnService.running)
    }

    override fun onClick() {
        if (FirewallVpnService.running) {
            FirewallVpnService.stop(this)
            render(false)
        } else if (VpnService.prepare(this) == null) {
            FirewallVpnService.start(this)
            render(true)
        } else {
            // প্রথমবার VPN অনুমতি লাগবে, অ্যাপ খুলে দিই
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(
                    PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
                )
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        }
    }

    private fun render(on: Boolean) {
        qsTile?.let {
            it.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            it.updateTile()
        }
    }
}
