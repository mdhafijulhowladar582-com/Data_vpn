package com.you.firewall

import android.content.Context

/**
 * পোষার হিসাব: ভাসমান পোষা (PetService) আর হোম স্ক্রিন উইজেট (PetWidget) দুজনেই এখান থেকে নেয়।
 * দিনের শেষ হিসাব একবারই হওয়া দরকার, তাই [refresh] এক সময়ে একজনই চালায়।
 *
 * স্ট্রিক = টানা যত দিন ডেটা নিজের ভাগের মধ্যে থেকেছে। ভাগ পেরোলে স্ট্রিক শূন্য।
 * রেফার কোড চালু থাকলে স্ট্রিক কখনো ভাঙে না (প্রতি দিন বাড়ে), স্বাস্থ্য কমে না।
 */
object PetCore {
    private const val MB = 1024L * 1024L

    class Snap(
        val health: Int, val ratio: Int, val usedMb: Int, val allowMb: Int,
        val streak: Int, val mood: Int
    )

    /** ratioPct = আজকের খরচ ÷ আজকের ভাগ × ১০০ */
    fun moodOf(ratioPct: Int): Int = when {
        ratioPct <= 50 -> 0
        ratioPct <= 90 -> 1
        ratioPct <= 100 -> 2
        else -> 3
    }

    /** হিসাব না চালিয়ে শেষ সেভ করা অবস্থা */
    fun last(c: Context): Snap {
        val ratio = Buddy.int(c, "petRatio", 0)
        return Snap(
            Buddy.int(c, "petHealth", 50), ratio,
            Buddy.int(c, "petUsedMb", 0), Buddy.int(c, "petAllowMb", 0),
            Buddy.int(c, "petStreak", 0), moodOf(ratio)
        )
    }

    @Synchronized
    fun refresh(c: Context): Snap {
        val ctx = c.applicationContext
        val today = DataLimit.dayStart()
        val saved = Buddy.long(ctx, "petDay", 0L)
        val code = Buddy.codeOn(ctx)
        var health = Buddy.int(ctx, "petHealth", 50)
        var streak = Buddy.int(ctx, "petStreak", 0)
        if (saved != 0L && saved != today) {
            // নতুন দিন: আগের দিনের শেষ হিসাবে স্বাস্থ্য আর স্ট্রিক বদলায়
            val r = Buddy.int(ctx, "petRatio", 0)
            val delta = when {
                r <= 80 -> 12
                r <= 100 -> 4
                r <= 130 -> -8
                else -> -15
            }
            health = (health + if (code && delta < 0) 0 else delta).coerceIn(0, 100)
            val gap = ((today - saved + DataLimit.DAY / 2) / DataLimit.DAY).toInt().coerceAtLeast(1)
            streak = when {
                code -> streak + gap // কোড থাকলে মাঝে বন্ধ থাকা দিনও গোনা হয়, কিছুই ভাঙে না
                r <= 100 -> streak + 1
                else -> 0
            }
            Buddy.putInt(ctx, "petHealth", health)
            Buddy.putInt(ctx, "petStreak", streak)
        }
        Buddy.putLong(ctx, "petDay", today)

        val used = UsageUtil.dataSince(ctx, today, false, false).total
        val cfg = DataLimit.cfg(Store.load(ctx))
        val b = DataLimit.budget(ctx, cfg)
        val allow = when {
            b != null && b.active && b.todayAllow > 0L -> b.todayAllow
            cfg.phoneMb > 0L -> cfg.phoneMb * MB / 30L
            else -> 300L * MB
        }
        val ratio = ((used * 100L) / maxOf(1L, allow)).toInt().coerceIn(0, 999)
        Buddy.putInt(ctx, "petRatio", ratio)
        Buddy.putInt(ctx, "petUsedMb", (used / MB).toInt())
        Buddy.putInt(ctx, "petAllowMb", (allow / MB).toInt())
        return Snap(health, ratio, (used / MB).toInt(), (allow / MB).toInt(), streak, moodOf(ratio))
    }
}
