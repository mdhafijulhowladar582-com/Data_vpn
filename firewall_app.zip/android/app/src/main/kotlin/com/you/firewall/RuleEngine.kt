package com.you.firewall

import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList

/**
 * নতুন ফিচারগুলোর জন্য একটা সাধারণ ইভেন্ট-বাস। VPN সার্ভিস ও Collector ইভেন্ট ছাড়ে ([emit]),
 * ফিচার নিজেকে [register] করে শুনে। ধাপ ২-৪-এ ব্ল্যাক বক্স, অটোমেশন ইত্যাদি এখানেই জুড়বে।
 * ধাপ ০-এ কেউ রেজিস্টার করে না, তাই কিছুই ঘটে না।
 */
object RuleEngine {
    const val TICK = "tick" // প্রতি ৩০ সেকেন্ডে (VPN চালু থাকলে)

    fun interface Rule {
        fun onEvent(c: Context, kind: String, data: Map<String, Any?>)
    }

    private val rules = CopyOnWriteArrayList<Rule>()

    fun register(r: Rule) {
        if (!rules.contains(r)) rules.add(r)
    }

    fun unregister(r: Rule) {
        rules.remove(r)
    }

    /** একটা রুলের ভুল বাকিদের থামায় না */
    fun emit(c: Context, kind: String, data: Map<String, Any?> = emptyMap()) {
        for (r in rules) {
            try {
                r.onEvent(c, kind, data)
            } catch (e: Exception) {
            }
        }
    }
}
