package com.you.firewall

import android.annotation.TargetApi
import android.app.Activity
import android.content.DialogInterface
import android.graphics.Color
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * পকেট গার্ডের পিন স্ক্রিন। লক স্ক্রিনের ওপরেও খোলে (নোটিফিকেশনের full-screen intent থেকে)।
 * ঠিক পিন বা ফিঙ্গারপ্রিন্টে সাইরেন ও গার্ড দুটোই বন্ধ হয়। Flutter ইঞ্জিন লাগে না, তাই তাৎক্ষণিক খোলে।
 */
class PocketAlarmActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var titleV: TextView
    private lateinit var subV: TextView
    private lateinit var errV: TextView
    private lateinit var box: EditText
    private var done = false
    private var cancel: CancellationSignal? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#450A0A"))
        root.setPadding(dp(32), dp(32), dp(32), dp(32))

        titleV = TextView(this)
        titleV.setTextColor(Color.WHITE)
        titleV.textSize = 22f
        titleV.gravity = Gravity.CENTER
        root.addView(titleV)

        subV = TextView(this)
        subV.setTextColor(Color.parseColor("#FCA5A5"))
        subV.textSize = 15f
        subV.gravity = Gravity.CENTER
        subV.setPadding(0, dp(8), 0, 0)
        root.addView(subV)

        box = EditText(this)
        box.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        box.hint = "পিন দিন"
        box.setHintTextColor(Color.GRAY)
        box.setTextColor(Color.WHITE)
        box.gravity = Gravity.CENTER
        box.imeOptions = EditorInfo.IME_ACTION_DONE
        box.setOnEditorActionListener { _, _, _ ->
            verify()
            true
        }
        val lp = LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(24)
        root.addView(box, lp)

        errV = TextView(this)
        errV.setTextColor(Color.parseColor("#FBBF24"))
        errV.gravity = Gravity.CENTER
        root.addView(errV)

        val ok = Button(this)
        ok.text = "বন্ধ করুন"
        ok.setOnClickListener { verify() }
        root.addView(ok, LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT))

        if (Store.load(this).optBoolean("bio") && Build.VERSION.SDK_INT >= 28) {
            val bio = Button(this)
            bio.text = "ফিঙ্গারপ্রিন্ট"
            bio.setOnClickListener { startBio() }
            root.addView(bio, LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        setContentView(root)
        tick.run()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (done) return
            when (PocketGuard.state) {
                PocketGuard.S_OFF -> {
                    finishQuiet()
                    return
                }
                PocketGuard.S_ARMING -> {
                    titleV.text = "⏳ পকেট গার্ড চালু হচ্ছে"
                    val left = ((PocketGuard.armEndsAt - System.currentTimeMillis() + 999) / 1000).toInt()
                    subV.text = "$left সেকেন্ড বাকি। বন্ধ করতে পিন দিন"
                }
                PocketGuard.S_ARMED -> {
                    titleV.text = "🛡 পকেট গার্ড চালু আছে"
                    subV.text = "বন্ধ করতে পিন দিন"
                }
                PocketGuard.S_GRACE -> {
                    titleV.text = "🚨 " + PocketGuard.lastReason
                    val left = ((PocketGuard.graceEndsAt - System.currentTimeMillis() + 999) / 1000).toInt()
                    subV.text = "পিন না দিলে $left সেকেন্ডে সাইরেন বাজবে"
                }
                else -> {
                    titleV.text = "🚨 সাইরেন বাজছে"
                    subV.text = PocketGuard.lastReason + "। থামাতে পিন দিন"
                }
            }
            h.postDelayed(this, 400)
        }
    }

    private fun verify() {
        val r = PinUtil.check(this, Store.load(this).optString("pinHash"), box.text.toString(), "পকেট গার্ড বন্ধ করা")
        box.setText("")
        when (r) {
            0 -> success()
            2 -> errV.text = "অনেকবার ভুল, ${PinUtil.leftSec(this)} সেকেন্ড পরে চেষ্টা করুন"
            else -> errV.text = "ভুল পিন"
        }
    }

    private fun success() {
        if (done) return
        done = true
        PocketGuard.disarm(this)
        cancel?.cancel()
        finish()
    }

    private fun finishQuiet() {
        if (done) return
        done = true
        cancel?.cancel()
        finish()
    }

    @TargetApi(28)
    private fun startBio() {
        try {
            cancel?.cancel()
            val cs = CancellationSignal()
            cancel = cs
            val p = BiometricPrompt.Builder(this)
                .setTitle("পকেট গার্ড বন্ধ করুন")
                .setNegativeButton("পিন দিন", mainExecutor, DialogInterface.OnClickListener { _, _ -> })
                .build()
            p.authenticate(cs, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    success()
                }
            })
        } catch (e: Exception) {
        }
    }

    // পেছনে গেলে শুধু স্ক্রিন সরে, অ্যালার্ম/গার্ড চলতেই থাকে
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        cancel?.cancel()
        super.onDestroy()
    }
}
