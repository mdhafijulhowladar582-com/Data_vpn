package com.you.firewall

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

/**
 * আলসে-লক: অনেকক্ষণ (সেটিংসে ঠিক করা সময়) পা না চালিয়ে ফোন চালালে স্ক্রিন ঝাপসা হয়ে যায়
 * আর বলে "২০ পা হাঁটো"। পা গোনা হয় ফোনের অ্যাক্সিলেরোমিটার দিয়ে (কোনো পারমিশন লাগে না)।
 * ফোন পকেটে বা হাতে নিয়ে হাঁটলে ধরে। সময় গোনা হয় শুধু স্ক্রিন জ্বলা অবস্থায়।
 * জরুরি দরকারে "ছুটি" বাটন চেপে ধরলে ১০ মিনিট লক আসে না।
 */
class LazyService : Service(), SensorEventListener {
    companion object {
        @Volatile
        var running = false

        /** স্ক্রিন জ্বলা অবস্থায় কত সময় পা না চালিয়ে কেটেছে (মিলিসেকেন্ড) */
        @Volatile
        var sitMs = 0L

        /** সার্ভিস চালুর পর মোট গোনা পা */
        @Volatile
        var stepsTotal = 0
        private const val ID = 7423
        private const val TICK_MS = 5000L
        private const val WALK_WINDOW_MS = 60_000L
        private const val LEAVE_MS = 10 * 60_000L
    }

    private lateinit var wm: WindowManager
    private lateinit var sm: SensorManager
    private val ui = Handler(Looper.getMainLooper())

    private var overlay: View? = null
    private var counter: TextView? = null
    private var bar: ProgressBar? = null
    private var locked = false
    private var lockSteps = 0

    // পা গোনার হিসাব
    private var grav = 0f
    private var smooth = 0f
    private var lastPeakAt = 0L
    private var chain = 0
    private var above = false
    private var lastStepAt = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Buddy.foreground(this, ID, "fw_lazy", "আলসে-লক", "আলসে-লক চালু", "বন্ধ করতে অ্যাপের নতুন সার্ভিস পেজে সুইচ বন্ধ করুন", "buddy")
        if (!Buddy.canDraw(this) || !Buddy.on(this, "lazy")) {
            Buddy.putOff(this, "lazy")
            stopSelf()
            return START_NOT_STICKY
        }
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc == null) {
            Toast.makeText(this, "এই ফোনে মুভমেন্ট সেন্সর নেই, আলসে-লক চলবে না", Toast.LENGTH_LONG).show()
            Buddy.putOff(this, "lazy")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI)
            running = true
            sitMs = 0L
            ui.postDelayed(tickR, TICK_MS)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        sitMs = 0L
        try {
            sm.unregisterListener(this)
        } catch (e: Exception) {
        }
        ui.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /**
     * গড় মাধ্যাকর্ষণ বাদ দিয়ে ঝাঁকুনির মান বের করে। হাঁটলে ঝাঁকুনি সীমা (১.৩) পার করে উঠে-নামে।
     * টাইপ করা বা টেবিলে রাখা ফোনে এত ঝাঁকুনি হয় না। পরপর ৩টা পা না মিললে গোনা হয় না।
     */
    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val mag = sqrt(x * x + y * y + z * z)
        grav = if (grav == 0f) mag else grav * 0.92f + mag * 0.08f
        smooth = smooth * 0.6f + (mag - grav) * 0.4f
        val now = SystemClock.elapsedRealtime()
        val th = 1.3f
        if (smooth > th && !above) {
            above = true
            if (now - lastPeakAt in 280L..1200L) chain++ else chain = 1
            lastPeakAt = now
            when {
                chain == 3 -> addSteps(3, now)
                chain > 3 -> addSteps(1, now)
            }
        } else if (smooth < th * 0.5f) {
            above = false
        }
    }

    private fun addSteps(n: Int, now: Long) {
        stepsTotal += n
        lastStepAt = now
        if (locked) {
            lockSteps += n
            ui.post { updateOverlay() }
        }
    }

    private val tickR = object : Runnable {
        override fun run() {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val screen = pm.isInteractive
            val now = SystemClock.elapsedRealtime()
            if (lastStepAt != 0L && now - lastStepAt < WALK_WINDOW_MS) {
                sitMs = 0L
            } else if (screen && !locked) {
                sitMs += TICK_MS
            }
            val needMs = Buddy.int(this@LazyService, "lazyMin", 45) * 60_000L
            val leaveUntil = Buddy.long(this@LazyService, "lazyLeaveUntil", 0L)
            if (!locked && screen && sitMs >= needMs && System.currentTimeMillis() > leaveUntil) {
                lock()
            }
            ui.postDelayed(this, TICK_MS)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun need(): Int = Buddy.int(this, "lazySteps", 20)

    private fun lock() {
        if (locked) return
        lockSteps = 0
        val n = need()

        val root = FrameLayout(this)
        val blur = Build.VERSION.SDK_INT >= 31
        root.setBackgroundColor(if (blur) Color.argb(120, 20, 16, 40) else Color.argb(225, 20, 16, 40))
        root.isClickable = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(28), dp(28), dp(28))

        fun tv(text: String, size: Float, color: String, bold: Boolean): TextView {
            val t = TextView(this)
            t.text = text
            t.textSize = size
            t.setTextColor(Color.parseColor(color))
            t.gravity = Gravity.CENTER
            if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
            return t
        }

        col.addView(tv("🚶", 64f, "#FFFFFF", false))
        col.addView(tv("অনেকক্ষণ বসে আছো", 22f, "#FFFFFF", true))
        val sub = tv("$n পা হাঁটো, তারপর ঝাপসা ভাব কেটে যাবে", 15f, "#D9D3F5", false)
        sub.setPadding(0, dp(8), 0, dp(24))
        col.addView(sub)

        val c = tv("0 / $n", 40f, "#A7F3D0", true)
        col.addView(c)
        counter = c

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = n
        pb.progress = 0
        val pl = LinearLayout.LayoutParams(dp(240), ViewGroup.LayoutParams.WRAP_CONTENT)
        pl.topMargin = dp(14)
        col.addView(pb, pl)
        bar = pb

        val tip = tv("ফোন পকেটে বা হাতে নিয়ে হাঁটো", 13f, "#B8B0E0", false)
        tip.setPadding(0, dp(14), 0, dp(40))
        col.addView(tip)

        val leave = tv("জরুরি ছুটি (১০ মিনিট)\nচেপে ধরে রাখো", 13f, "#FFFFFF", false)
        leave.setPadding(dp(18), dp(10), dp(18), dp(10))
        val lbg = GradientDrawable()
        lbg.setColor(Color.argb(60, 255, 255, 255))
        lbg.cornerRadius = dp(18).toFloat()
        leave.background = lbg
        leave.setOnLongClickListener {
            Buddy.putLong(this, "lazyLeaveUntil", System.currentTimeMillis() + LEAVE_MS)
            unlock(false)
            true
        }
        col.addView(leave)

        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            Buddy.overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 60
        }
        try {
            wm.addView(root, lp)
            overlay = root
            locked = true
        } catch (e: Exception) {
            counter = null
            bar = null
        }
    }

    private fun updateOverlay() {
        val n = need()
        counter?.text = "${minOf(lockSteps, n)} / $n"
        bar?.progress = minOf(lockSteps, n)
        if (lockSteps >= n) unlock(true)
    }

    private fun unlock(done: Boolean) {
        removeOverlay()
        locked = false
        sitMs = 0L
        lastStepAt = SystemClock.elapsedRealtime()
        if (done) {
            Toast.makeText(this, "বাহ! ঝাপসা কেটে গেছে 🎉", Toast.LENGTH_SHORT).show()
            try {
                val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(120)
                }
            } catch (e: Exception) {
            }
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        overlay = null
        counter = null
        bar = null
        locked = false
    }
}
