package com.you.firewall

import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.sqlite.SQLiteDatabase
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

/**
 * ব্ল্যাক বক্সের স্যাম্পলার: ফোনের অবস্থার একটা ছবি (ব্যাটারি, তাপ, RAM, থার্মাল, সামনের অ্যাপ, ডেটা) নিয়ে
 * `samples` টেবিলে রাখে। VPN-এর ৩০ সেকেন্ডের tick-এ ডাকা হয় (মিহি), আর ফায়ারওয়াল বন্ধ থাকলে
 * Guardian-এর ১৫ মিনিটের জব থেকে (মোটা)। ৫ মিনিটের "রিং বাফার" আলাদা নেই: টেবিলে ২৪ ঘণ্টা থাকে,
 * ঘটনা ধরা পড়লে শেষ ৫ মিনিটের সারি ইনসিডেন্টে কপি হয় (দেখুন [Triggers])।
 */
object Sampler {
    class S(
        val t: Long, val batt: Int, val temp: Int, val charging: Boolean, val memFree: Long,
        val lowMem: Boolean, val thermal: Int, val screen: Boolean, val fg: String, val rx: Long, val tx: Long
    )

    /** ফোনের নিজের রায় (ডেটাবেসে যায় না, শুধু সর্বশেষ মান): ব্যাটারি "অতিরিক্ত গরম" জানিয়েছে কিনা, আর থার্মাল হেডরুম */
    @Volatile var overheatNow = false
    @Volatile var headroom = Float.NaN // ০.০ = ঠান্ডা, ১.০ = ফোন গতি কমানোর সীমায়। NaN = ফোন দেয় না

    @Volatile private var lastRx = -1L
    @Volatile private var lastTx = -1L
    @Volatile private var lastT = 0L

    fun enabled(c: Context): Boolean = Store.load(c).optBoolean("blackBox", true)

    /** একটা স্যাম্পল নিয়ে ডিস্কে লেখে। ৯ সেকেন্ডের কম ব্যবধানে দুবার নেয় না */
    fun take(c: Context, coarse: Boolean = false): S? {
        val ctx = c.applicationContext
        val now = System.currentTimeMillis()
        if (now - lastT < 9000L) return null
        lastT = now

        val bi: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batt = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
        val temp = bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1 // দশমিক ডিগ্রি (৩৫০ = ৩৫.০°C)
        val plug = bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = plug != 0
        // ব্যাটারির স্বাস্থ্য: ফোন নিজের ভেতরের সীমা পেরোলে OVERHEAT বলে (প্রতিটা ফোনের নিজের মাপে ঠিক করা)
        overheatNow = (bi?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN) ?: 0) ==
            BatteryManager.BATTERY_HEALTH_OVERHEAT

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val memFreeMb = mi.availMem / (1024 * 1024)

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1
        val screen = pm.isInteractive
        headroom = try {
            if (Build.VERSION.SDK_INT >= 30) pm.getThermalHeadroom(10) else Float.NaN
        } catch (e: Exception) {
            Float.NaN
        }

        val fg = if (screen) (GuardService.fgNow ?: "") else ""

        // মোট ডেটা (ডিভাইস জুড়ে)। রিবুটে শূন্য হয়ে যায়, তাই কমলে এই দফা ০
        val rxNow = TrafficStats.getTotalRxBytes()
        val txNow = TrafficStats.getTotalTxBytes()
        var drx = 0L
        var dtx = 0L
        if (lastRx >= 0 && rxNow >= lastRx && rxNow != TrafficStats.UNSUPPORTED.toLong()) drx = rxNow - lastRx
        if (lastTx >= 0 && txNow >= lastTx && txNow != TrafficStats.UNSUPPORTED.toLong()) dtx = txNow - lastTx
        lastRx = rxNow
        lastTx = txNow
        if (coarse) { drx = 0; dtx = 0 } // ১৫ মিনিট পরপর, ব্যবধান অনিশ্চিত

        val s = S(now, batt, temp, charging, memFreeMb, mi.lowMemory, thermal, screen, fg, drx, dtx)
        val v = ContentValues()
        v.put("t", s.t)
        v.put("batt", s.batt)
        v.put("temp", s.temp)
        v.put("charging", if (s.charging) 1 else 0)
        v.put("mem_free", s.memFree)
        v.put("low_mem", if (s.lowMem) 1 else 0)
        v.put("thermal", s.thermal)
        v.put("screen", if (s.screen) 1 else 0)
        v.put("fg", s.fg)
        v.put("rx", s.rx)
        v.put("tx", s.tx)
        XDb.get(ctx).writableDatabase.insertWithOnConflict("samples", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        return s
    }

    /** [from, to] ব্যবধানের স্যাম্পল, পুরনো আগে */
    fun range(c: Context, from: Long, to: Long = Long.MAX_VALUE): List<S> {
        val out = ArrayList<S>()
        XDb.get(c).readableDatabase.rawQuery(
            "SELECT t, batt, temp, charging, mem_free, low_mem, thermal, screen, fg, rx, tx " +
                "FROM samples WHERE t >= ? AND t <= ? ORDER BY t ASC",
            arrayOf(from.toString(), to.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(
                    S(
                        it.getLong(0), it.getInt(1), it.getInt(2), it.getInt(3) != 0, it.getLong(4),
                        it.getInt(5) != 0, it.getInt(6), it.getInt(7) != 0, it.getString(8) ?: "",
                        it.getLong(9), it.getLong(10)
                    )
                )
            }
        }
        return out
    }
}
