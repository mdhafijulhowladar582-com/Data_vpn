package com.you.firewall

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * ডেটা-পোষা: স্ক্রিনের কোণে ছোট একটা পোষা প্রাণী।
 * আজকের মোবাইল ডেটা খরচ বনাম আজকের ন্যায্য ভাগ (প্যাক বাজেট থাকলে ওটা, না থাকলে ডেটা লিমিটের ৩০ ভাগের এক ভাগ,
 * তাও না থাকলে দিনে ৩০০ MB) দেখে মেজাজ বদলায়। প্রতি দিনের শেষ হিসাবে স্বাস্থ্য (০-১০০) বাড়ে-কমে:
 * ডেটা বাঁচালে মোটা আর খুশি, বেশি পোড়ালে রোগা আর মনমরা।
 * টানা যত দিন ভাগের মধ্যে থাকে (স্ট্রিক), পোষা তত বড় হয়, প্রতি ৭ দিনে নতুন সাজ, প্রতি ৯০ দিনে নতুন রূপ ও রঙ।
 * হিসাবের সব কাজ [PetCore]-এ।
 */
class PetService : Service() {
    companion object {
        @Volatile
        var running = false

        /** সেন্সর-পোষা (SenseService) এই হাত ধরে পোষাকে নাড়ায় */
        @Volatile
        var inst: PetService? = null
        private const val ID = 7422
    }

    private lateinit var wm: WindowManager
    private var view: PetView? = null
    private var params: WindowManager.LayoutParams? = null
    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null

    // সেন্সরের অবস্থা: base = চলতে থাকা (ঘুম), temp = অল্প সময়ের (খুশির লাফ)
    private var baseMode = SensorHub.M_NONE
    private var tempMode = SensorHub.M_NONE
    private val clearTemp = Runnable {
        tempMode = SensorHub.M_NONE
        applyMode()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        inst = this
        if (SenseService.dark) baseMode = SensorHub.M_SLEEP
    }

    private fun applyMode() {
        view?.act = if (tempMode != SensorHub.M_NONE) tempMode else baseMode
    }

    /** চলতে থাকা অবস্থা বদলানো (যেমন অন্ধকারে ঘুম) */
    fun setBase(m: Int) {
        ui.post {
            baseMode = m
            applyMode()
        }
    }

    /** [ms] মিলিসেকেন্ডের জন্য একটা অবস্থা দেখানো, তারপর আগেরটায় ফেরা */
    fun react(m: Int, ms: Long) {
        ui.post {
            tempMode = m
            applyMode()
            ui.removeCallbacks(clearTemp)
            ui.postDelayed(clearTemp, ms)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Buddy.foreground(this, ID, "fw_pet", "ডেটা-পোষা", "ডেটা-পোষা চালু", "বন্ধ করতে অ্যাপের নতুন সার্ভিস পেজে সুইচ বন্ধ করুন", "buddy")
        if (!Buddy.canDraw(this) || !Buddy.on(this, "pet")) {
            Buddy.putOff(this, "pet")
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (view == null) addView()
        if (bgThread == null) {
            val t = HandlerThread("pet-poll")
            t.start()
            bgThread = t
            bg = Handler(t.looper)
            bg?.post(pollR)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        if (inst === this) inst = null
        ui.removeCallbacksAndMessages(null)
        bg?.removeCallbacksAndMessages(null)
        bgThread?.quitSafely()
        bgThread = null
        bg = null
        view?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        view = null
        params = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun addView() {
        val dm = resources.displayMetrics
        val streak = Buddy.int(this, "petStreak", 0)
        val size = dp(Buddy.petSizeDp(streak))
        val p = WindowManager.LayoutParams(
            size, size, Buddy.overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = Buddy.int(this, "petX", dm.widthPixels - size).coerceIn(0, maxOf(0, dm.widthPixels - size))
        p.y = Buddy.int(this, "petY", dp(420)).coerceIn(0, maxOf(0, dm.heightPixels - size))
        val v = PetView(this)
        v.health = Buddy.int(this, "petHealth", 50)
        v.mood = PetCore.moodOf(Buddy.int(this, "petRatio", 0))
        v.look = streak
        v.act = if (tempMode != SensorHub.M_NONE) tempMode else baseMode
        Buddy.drag(this, wm, v, p, "petX", "petY", true) { onTap() }
        try {
            wm.addView(v, p)
            view = v
            params = p
        } catch (e: Exception) {
            stopSelf()
        }
    }

    /** স্ট্রিক বাড়লে পোষার আকারও বাড়ে। জানালার বাঁ-ওপরের কোণ ঠিক রেখে বড় হয়, পর্দার বাইরে গেলে ভেতরে টেনে আনে */
    private fun applySize(streak: Int) {
        val p = params ?: return
        val v = view ?: return
        val px = dp(Buddy.petSizeDp(streak))
        if (p.width == px) return
        val dm = resources.displayMetrics
        p.width = px
        p.height = px
        p.x = p.x.coerceIn(0, maxOf(0, dm.widthPixels - px))
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - px))
        try {
            wm.updateViewLayout(v, p)
        } catch (e: Exception) {
        }
    }

    private fun onTap() {
        val used = Buddy.int(this, "petUsedMb", 0)
        val allow = Buddy.int(this, "petAllowMb", 0)
        val streak = Buddy.int(this, "petStreak", 0)
        val say = when (view?.mood ?: 1) {
            0 -> "আজ কম ডেটা খরচ, আমি দারুণ খুশি!"
            1 -> "ঠিকঠাক চলছে। এভাবেই চলুক।"
            2 -> "ভাগের প্রায় শেষ, একটু সামলে।"
            else -> "আজকের ভাগ পেরিয়ে গেছে, আমার মন খারাপ।"
        }
        val code = if (Buddy.codeOn(this)) "\n🔓 কোড চালু: স্ট্রিক কখনো ভাঙবে না" else ""
        val last = SleepLog.recent(this, 1).firstOrNull()
        val sleep = if (last != null) "\n🌙 শেষ ঘুম প্রায় ${SleepLog.fmt(last.min)}" else ""
        Toast.makeText(
            this,
            "আজ $used MB / $allow MB\n$say\nস্ট্রিক ${Insights.bn(streak)} দিন, রূপ: ${Buddy.petForm(streak)}$code$sleep",
            Toast.LENGTH_LONG
        ).show()
    }

    private val pollR = object : Runnable {
        override fun run() {
            try {
                val s = PetCore.refresh(this@PetService)
                ui.post {
                    view?.health = s.health
                    view?.mood = s.mood
                    view?.look = s.streak
                    applySize(s.streak)
                }
                PetWidget.refreshAll(this@PetService)
            } catch (e: Exception) {
            }
            bg?.postDelayed(this, 60_000)
        }
    }
}

/** পোষা প্রাণীর ছবি: নিজে আঁকা নরম গোল জীব। স্বাস্থ্য বেশি হলে মোটা, কম হলে রোগা; মেজাজ অনুযায়ী মুখ বদলায় */
class PetView(c: Context) : View(c) {
    var health = 50
        set(v) {
            field = v.coerceIn(0, 100)
            invalidate()
        }
    var mood = 1
        set(v) {
            field = v.coerceIn(0, 3)
            invalidate()
        }

    /** স্ট্রিকের দিন সংখ্যা: এর থেকে রঙ আর সাজ ঠিক হয় */
    var look = 0
        set(v) {
            field = v.coerceAtLeast(0)
            invalidate()
        }

    /** সেন্সরের অবস্থা: ০ = সাধারণ, ১ = ঘুমন্ত (চোখ বন্ধ, z z), ২ = খুশির লাফ */
    var act = 0
        set(v) {
            field = v.coerceIn(0, 2)
            invalidate()
        }

    private var t = 0f
    private val d = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val tau = (2.0 * PI).toFloat()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    /** রঙের ঘূর্ণি (hue) [deg] ডিগ্রি সরানো */
    private fun shift(c: Int, deg: Float): Int {
        if (deg == 0f) return c
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[0] = (hsv[0] + deg) % 360f
        return Color.HSVToColor(hsv)
    }

    private fun lerp(a: Int, b: Int, k: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun blink(): Float {
        val x = (t * 1.0f) % 1f
        return if (x in 0.90f..0.97f) {
            val k = (x - 0.90f) / 0.07f
            abs(cos(PI.toFloat() * k)).coerceIn(0.08f, 1f)
        } else 1f
    }

    override fun onDraw(cv: Canvas) {
        // ঘুমালে শান্ত মুখ, খুশির লাফে সবচেয়ে খুশি মুখ; নইলে ডেটার মেজাজ
        val mood = when (act) {
            2 -> 0
            1 -> 1
            else -> this.mood
        }
        val w = width.toFloat()
        val cx = w / 2f
        val base = w * 0.30f
        val hk = health / 100f
        // মেজাজ খারাপ হলে রং ফ্যাকাশে
        val sad = if (mood >= 3) 0.55f else if (mood == 2) 0.25f else 0f
        val deg = Buddy.petHue(look).toFloat()
        val body1 = lerp(shift(Color.parseColor("#86EFAC"), deg), Color.parseColor("#CBD5E1"), sad)
        val body2 = lerp(shift(Color.parseColor("#34D399"), deg), Color.parseColor("#94A3B8"), sad)

        val speed = if (mood == 0) 2f else if (mood == 1) 1f else 0.5f
        val bob = if (mood == 0) 3f * d * abs(sin(tau * t * speed)) else 1.5f * d * sin(tau * t * speed)
        val cy = w * 0.58f - bob

        val rx = base * (0.78f + 0.62f * hk)
        val ry = base * (0.92f + 0.10f * hk)

        // ছায়া
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(60, 0, 0, 0)
        rect.set(cx - rx * 0.9f, w * 0.58f + ry * 0.85f, cx + rx * 0.9f, w * 0.58f + ry * 1.0f + 3f * d)
        cv.drawOval(rect, p)

        // কান
        p.color = body2
        for (sd in intArrayOf(-1, 1)) {
            path.reset()
            val bx = cx + sd * rx * 0.55f
            val by = cy - ry * 0.7f
            path.moveTo(bx - sd * rx * 0.28f, by + ry * 0.1f)
            path.lineTo(bx + sd * rx * 0.12f, by - ry * 0.6f)
            path.lineTo(bx + sd * rx * 0.38f, by + ry * 0.25f)
            path.close()
            cv.drawPath(path, p)
        }

        // শরীর
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        p.shader = RadialGradient(cx - rx * 0.3f, cy - ry * 0.4f, rx * 1.6f, body1, body2, Shader.TileMode.CLAMP)
        cv.drawOval(rect, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.color = lerp(shift(Color.parseColor("#059669"), deg), Color.parseColor("#64748B"), sad)
        cv.drawOval(rect, p)
        p.style = Paint.Style.FILL

        // চোখ
        val ob = if (act == 1) 0.08f else blink()
        val ey = cy - ry * 0.12f
        val er = rx * 0.13f
        for (sd in intArrayOf(-1, 1)) {
            val ex = cx + sd * rx * 0.38f
            rect.set(ex - er, ey - er * 1.3f * ob, ex + er, ey + er * 1.3f * ob)
            p.color = Color.parseColor("#1F2937")
            cv.drawOval(rect, p)
            if (ob > 0.5f) {
                p.color = Color.WHITE
                cv.drawCircle(ex + er * 0.3f, ey - er * 0.4f, er * 0.38f, p)
            }
            if (mood >= 2) {
                // ভুরু: চিন্তিত/মন খারাপ
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.6f * d
                p.strokeCap = Paint.Cap.ROUND
                p.color = Color.parseColor("#1F2937")
                val tilt = if (mood == 3) er * 1.1f else er * 0.6f
                cv.drawLine(ex - er * 1.2f, ey - er * 2.1f + sd * tilt * (-1f), ex + er * 1.2f, ey - er * 2.1f + sd * tilt, p)
                p.style = Paint.Style.FILL
            }
        }
        if (mood == 3) {
            // চোখের জল
            p.color = Color.argb(200, 125, 211, 252)
            val ty = ey + er * 1.8f + 4f * d * ((t * 2f) % 1f)
            cv.drawCircle(cx + rx * 0.38f + er * 0.4f, ty, er * 0.45f, p)
        }

        // গাল (খুশি হলে লাল)
        if (mood <= 1) {
            p.color = Color.argb(if (mood == 0) 170 else 90, 251, 113, 133)
            cv.drawCircle(cx - rx * 0.66f, cy + ry * 0.22f, rx * 0.13f, p)
            cv.drawCircle(cx + rx * 0.66f, cy + ry * 0.22f, rx * 0.13f, p)
        }

        // মুখ
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#1F2937")
        val my = cy + ry * 0.28f
        path.reset()
        when (mood) {
            0 -> {
                path.moveTo(cx - rx * 0.28f, my)
                path.quadTo(cx, my + ry * 0.42f, cx + rx * 0.28f, my)
            }
            1 -> {
                path.moveTo(cx - rx * 0.16f, my)
                path.quadTo(cx, my + ry * 0.16f, cx + rx * 0.16f, my)
            }
            2 -> {
                path.moveTo(cx - rx * 0.16f, my + ry * 0.04f)
                path.lineTo(cx + rx * 0.16f, my + ry * 0.04f)
            }
            else -> {
                path.moveTo(cx - rx * 0.2f, my + ry * 0.16f)
                path.quadTo(cx, my - ry * 0.1f, cx + rx * 0.2f, my + ry * 0.16f)
            }
        }
        cv.drawPath(path, p)
        p.style = Paint.Style.FILL

        // প্রতি ৭ দিনে নতুন সাজ (ছয় রকম, ঘুরে ঘুরে আসে)
        val headTop = cy - ry
        when (Buddy.petAccessory(look)) {
            1 -> { // ফিতা
                p.color = Color.parseColor("#FB7185")
                for (sd in intArrayOf(-1, 1)) {
                    path.reset()
                    val bx = cx + rx * 0.5f
                    val yb = headTop + ry * 0.12f
                    path.moveTo(bx, yb)
                    path.lineTo(bx + sd * rx * 0.34f, yb - ry * 0.2f)
                    path.lineTo(bx + sd * rx * 0.34f, yb + ry * 0.2f)
                    path.close()
                    cv.drawPath(path, p)
                }
                cv.drawCircle(cx + rx * 0.5f, headTop + ry * 0.12f, rx * 0.07f, p)
            }
            2 -> { // চশমা
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.8f * d
                p.color = Color.parseColor("#1F2937")
                val gr = er * 1.7f
                cv.drawCircle(cx - rx * 0.38f, ey, gr, p)
                cv.drawCircle(cx + rx * 0.38f, ey, gr, p)
                cv.drawLine(cx - rx * 0.38f + gr, ey, cx + rx * 0.38f - gr, ey, p)
                p.style = Paint.Style.FILL
            }
            3 -> { // টুপি
                p.color = Color.parseColor("#3B82F6")
                rect.set(cx - rx * 0.62f, headTop - ry * 0.5f, cx + rx * 0.62f, headTop + ry * 0.5f)
                cv.drawArc(rect, 180f, 180f, true, p)
                p.color = Color.parseColor("#1D4ED8")
                rect.set(cx - rx * 0.8f, headTop, cx + rx * 0.8f, headTop + ry * 0.12f)
                cv.drawRoundRect(rect, 3f * d, 3f * d, p)
            }
            4 -> { // মুকুট
                p.color = Color.parseColor("#FACC15")
                val bw = rx * 0.6f
                val bh = ry * 0.38f
                val yb = headTop + ry * 0.06f
                path.reset()
                path.moveTo(cx - bw, yb)
                path.lineTo(cx - bw, yb - bh)
                path.lineTo(cx - bw * 0.5f, yb - bh * 0.4f)
                path.lineTo(cx, yb - bh * 1.15f)
                path.lineTo(cx + bw * 0.5f, yb - bh * 0.4f)
                path.lineTo(cx + bw, yb - bh)
                path.lineTo(cx + bw, yb)
                path.close()
                cv.drawPath(path, p)
            }
            5 -> { // জ্যোতির বলয়
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.2f * d
                p.color = Color.argb(220, 253, 224, 71)
                rect.set(cx - rx * 0.42f, headTop - ry * 0.32f, cx + rx * 0.42f, headTop - ry * 0.1f)
                cv.drawOval(rect, p)
                p.style = Paint.Style.FILL
            }
            6 -> { // ফুল
                val fx = cx + rx * 0.62f
                val fy = headTop + ry * 0.2f
                val pr = rx * 0.09f
                p.color = Color.parseColor("#F9A8D4")
                for (k in 0 until 5) {
                    val ang = tau * k / 5f
                    cv.drawCircle(fx + cos(ang) * pr * 1.4f, fy + sin(ang) * pr * 1.4f, pr, p)
                }
                p.color = Color.parseColor("#FDE047")
                cv.drawCircle(fx, fy, pr * 0.8f, p)
            }
        }
        p.style = Paint.Style.FILL

        // ঘুমালে ওপরে উঠতে থাকা z
        if (act == 1) {
            p.style = Paint.Style.FILL
            p.textSize = 10f * d
            for (k in 0..1) {
                val ph = (t + k * 0.5f) % 1f
                p.color = Color.argb((230 * (1f - ph)).toInt().coerceIn(0, 255), 71, 85, 105)
                cv.drawText(if (k == 0) "z" else "Z", cx + rx * (0.6f + 0.3f * ph), cy - ry * (0.9f + 0.8f * ph), p)
            }
        }

        // খুব খুশি হলে ছোট তারা
        if (mood == 0) {
            val a = 0.5f + 0.5f * sin(tau * t * 2f)
            p.color = Color.argb((120 + 120 * a).toInt().coerceIn(0, 255), 253, 224, 71)
            cv.drawCircle(cx + rx * 1.0f, cy - ry * 1.0f, 2.2f * d, p)
            cv.drawCircle(cx - rx * 1.05f, cy - ry * 0.55f, 1.6f * d, p)
        }
    }
}
