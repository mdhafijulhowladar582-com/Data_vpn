package com.you.firewall

import android.content.Context
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * ধাপ ৫ (ল্যাব): চার্জার লিডারবোর্ড আর Wi-Fi সিগন্যাল ম্যাপ। অবস্থা আলাদা SharedPreferences-এ ("fw_lab")।
 *
 * চার্জার: একটা চার্জারের নাম "এখন লাগানো" দিয়ে রাখলে, চার্জ হওয়ার সময় স্ক্রিন বন্ধ আর ব্যাটারি ৮০%-এর নিচে থাকলে
 * প্রতি ৩০ সেকেন্ডে চার্জিং কারেন্ট (mA) মেপে গড় জমায়। শর্ত একই রাখা হয় যাতে চার্জারগুলো তুলনীয় হয়।
 * Wi-Fi: ঘরের কোণে দাঁড়িয়ে "মাপো" চাপলে ~৪ সেকেন্ডে সিগন্যাল শক্তি (dBm) আর লিংক স্পিড মেপে জমায়।
 */
object Lab {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_lab", Context.MODE_PRIVATE)

    private fun obj(c: Context, k: String): JSONObject = try {
        JSONObject(sp(c).getString(k, "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    // ======================= চার্জার লিডারবোর্ড =======================

    /** mA। কিছু ফোন µA দেয়, কিছু mA, তাই বড় সংখ্যা হলে ১০০০ দিয়ে ভাগ। কারেন্টের চিহ্ন ফোনভেদে উল্টো, তাই abs */
    private fun currentMa(c: Context): Int {
        return try {
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val v = abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            (if (v > 20000L) v / 1000L else v).toInt()
        } catch (e: Exception) {
            0
        }
    }

    private fun level(c: Context): Int = try {
        (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (e: Exception) {
        -1
    }

    private fun charging(c: Context): Boolean = try {
        (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).isCharging
    } catch (e: Exception) {
        false
    }

    private fun screenOn(c: Context): Boolean = try {
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
    } catch (e: Exception) {
        true
    }

    fun chargerActive(c: Context): String = sp(c).getString("chgActive", "") ?: ""

    fun chargerSetActive(c: Context, name: String) {
        val n = name.trim()
        sp(c).edit().putString("chgActive", n).apply()
        if (n.isNotEmpty()) {
            val o = obj(c, "chg")
            if (!o.has(n)) {
                o.put(n, JSONObject().put("sum", 0L).put("n", 0).put("max", 0))
                sp(c).edit().putString("chg", o.toString()).apply()
            }
        }
    }

    fun chargerDelete(c: Context, name: String) {
        val o = obj(c, "chg")
        o.remove(name)
        sp(c).edit().putString("chg", o.toString()).apply()
        if (chargerActive(c) == name) sp(c).edit().putString("chgActive", "").apply()
    }

    fun chargerReset(c: Context, name: String) {
        val o = obj(c, "chg")
        if (o.has(name)) o.put(name, JSONObject().put("sum", 0L).put("n", 0).put("max", 0))
        sp(c).edit().putString("chg", o.toString()).apply()
    }

    /** VPN tick (৩০ সেকেন্ড)। শর্ত না মিললে কিছুই জমে না */
    @Synchronized
    fun onTick(c: Context) {
        try {
            val ctx = c.applicationContext
            val name = chargerActive(ctx)
            if (name.isEmpty() || !charging(ctx) || screenOn(ctx)) return
            val lv = level(ctx)
            if (lv < 0 || lv > 80) return
            val ma = currentMa(ctx)
            if (ma <= 0) return
            val o = obj(ctx, "chg")
            val e = o.optJSONObject(name) ?: JSONObject().put("sum", 0L).put("n", 0).put("max", 0)
            e.put("sum", e.optLong("sum") + ma).put("n", e.optInt("n") + 1).put("max", maxOf(e.optInt("max"), ma))
            o.put(name, e)
            sp(ctx).edit().putString("chg", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    /** {chargers:[{name, avg, max, n}] (গড় অনুযায়ী বড় থেকে ছোট), active, live:{ma, charging, level, screenOn}} */
    fun chargerState(c: Context): Map<String, Any?> {
        val ctx = c.applicationContext
        val o = obj(ctx, "chg")
        val list = ArrayList<Map<String, Any>>()
        for (k in o.keys()) {
            val e = o.optJSONObject(k) ?: continue
            val n = e.optInt("n")
            list.add(mapOf("name" to k, "avg" to (if (n > 0) (e.optLong("sum") / n).toInt() else 0), "max" to e.optInt("max"), "n" to n))
        }
        list.sortByDescending { it["avg"] as Int }
        return mapOf(
            "chargers" to list,
            "active" to chargerActive(ctx),
            "live" to mapOf("ma" to currentMa(ctx), "charging" to charging(ctx), "level" to level(ctx), "screenOn" to screenOn(ctx))
        )
    }

    // ======================= Wi-Fi সিগন্যাল ম্যাপ =======================

    private fun spots(c: Context): JSONArray = try {
        JSONArray(sp(c).getString("spots", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    fun wifiSpots(c: Context): List<Map<String, Any?>> {
        val a = spots(c.applicationContext)
        val out = ArrayList<Map<String, Any?>>()
        for (i in 0 until a.length()) {
            val s = a.optJSONObject(i) ?: continue
            out.add(mapOf("name" to s.optString("name"), "rssi" to s.optInt("rssi"), "speed" to s.optInt("speed"), "t" to s.optLong("t"), "ssid" to s.optString("ssid")))
        }
        out.sortByDescending { it["rssi"] as Int }
        return out
    }

    /** ~৪ সেকেন্ড ধরে ৫টা মাপ নিয়ে গড়। ব্যাকগ্রাউন্ড থ্রেড থেকে ডাকতে হবে। ফেরত {ok, rssi, speed, reason?} */
    @Suppress("DEPRECATION")
    fun wifiMeasure(c: Context, name: String): Map<String, Any?> {
        val ctx = c.applicationContext
        val n = name.trim()
        if (n.isEmpty()) return mapOf("ok" to false, "reason" to "জায়গার নাম দিন")
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
        var sumR = 0
        var sumS = 0
        var cnt = 0
        for (i in 0 until 5) {
            try {
                val ci = wm.connectionInfo
                val r = ci?.rssi ?: -127
                if (r in -126..0) {
                    sumR += r
                    sumS += maxOf(0, ci?.linkSpeed ?: 0)
                    cnt++
                }
            } catch (e: Exception) {
            }
            if (i < 4) Thread.sleep(800)
        }
        if (cnt == 0) return mapOf("ok" to false, "reason" to "Wi-Fi-তে যুক্ত নেই")
        val rssi = sumR / cnt
        val speed = sumS / cnt
        val ssid = try { WifiGuard.ssidNow(ctx) ?: "" } catch (e: Exception) { "" }
        val a = spots(ctx)
        val keep = JSONArray()
        for (i in 0 until a.length()) {
            val s = a.optJSONObject(i) ?: continue
            if (s.optString("name") != n) keep.put(s)
        }
        keep.put(JSONObject().put("name", n).put("rssi", rssi).put("speed", speed).put("t", System.currentTimeMillis()).put("ssid", ssid))
        sp(ctx).edit().putString("spots", keep.toString()).apply()
        return mapOf("ok" to true, "rssi" to rssi, "speed" to speed)
    }

    fun wifiSpotDelete(c: Context, name: String) {
        val ctx = c.applicationContext
        val a = spots(ctx)
        val keep = JSONArray()
        for (i in 0 until a.length()) {
            val s = a.optJSONObject(i) ?: continue
            if (s.optString("name") != name) keep.put(s)
        }
        sp(ctx).edit().putString("spots", keep.toString()).apply()
    }

    fun wifiSpotsClear(c: Context) {
        sp(c.applicationContext).edit().putString("spots", "[]").apply()
    }
}
