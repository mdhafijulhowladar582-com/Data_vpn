package com.you.firewall

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** কুইক সেটিংসে "প্যানিক" টাইল: এক ট্যাপে সব লক, ভল্ট বন্ধ। পিন লাগে না, কারণ এটা শুধু নিরাপদ দিকে যায় */
class PanicTile : TileService() {

    override fun onStartListening() {
        qsTile?.let {
            it.state = Tile.STATE_INACTIVE
            it.updateTile()
        }
    }

    override fun onClick() {
        Panic.trigger(this)
    }
}
