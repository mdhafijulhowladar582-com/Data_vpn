package com.you.firewall

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process
import android.view.WindowManager
import android.content.ActivityNotFoundException
import android.provider.OpenableColumns
import android.provider.Settings
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.VpnService
import android.os.Build
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : FlutterFragmentActivity() {
    private var pending: MethodChannel.Result? = null
    private var pickResult: MethodChannel.Result? = null
    private var pickDelete = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "firewall/vpn")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getApps" -> Thread {
                        val pm = packageManager
                        val list = pm.getInstalledApplications(0)
                            .filter { it.packageName != packageName }
                            .map {
                                mapOf(
                                    "name" to pm.getApplicationLabel(it).toString(),
                                    "pkg" to it.packageName,
                                    "system" to ((it.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                                )
                            }
                            .sortedBy { (it["name"] as String).lowercase() }
                        runOnUiThread { result.success(list) }
                    }.start()

                    "getIcon" -> {
                        val pkg = call.argument<String>("pkg") ?: ""
                        Thread {
                            val bytes: ByteArray? = try {
                                val d = packageManager.getApplicationIcon(pkg)
                                val bmp = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
                                d.setBounds(0, 0, 72, 72)
                                d.draw(Canvas(bmp))
                                val o = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
                                o.toByteArray()
                            } catch (e: Exception) {
                                null
                            }
                            runOnUiThread { result.success(bytes) }
                        }.start()
                    }

                    "start" -> {
                        val i = VpnService.prepare(this)
                        if (i != null) {
                            pending = result
                            startActivityForResult(i, 100)
                        } else {
                            FirewallVpnService.start(this)
                            result.success(true)
                        }
                    }

                    "stop" -> {
                        if (Store.focusActive(this)) {
                            result.success(false) // ফোকাস চলছে
                        } else {
                            FirewallVpnService.stop(this)
                            result.success(true)
                        }
                    }

                    "isRunning" -> result.success(FirewallVpnService.running)

                    "loadConfig" ->
                        result.success(Store.prefs(this).getString("cfg", "") ?: "")

                    "saveConfig" -> {
                        val j = try {
                            JSONObject(call.argument<String>("json") ?: "{}")
                        } catch (e: Exception) {
                            JSONObject()
                        }
                        // enabled ও focusUntil-এর মালিক Kotlin, Dart-এর পুরোনো মান দিয়ে বদলানো যাবে না
                        val old = Store.load(this)
                        j.put("enabled", old.optBoolean("enabled"))
                        j.put("focusUntil", old.optLong("focusUntil", 0L))
                        if (Store.focusActive(this) && old.has("focusAllowed")) {
                            j.put("focusAllowed", old.get("focusAllowed")) // ফোকাসে অনুমতি তালিকা বদলানো যাবে না
                        }
                        Store.save(this, j)
                        FirewallVpnService.reload(this)
                        result.success(null)
                    }

                    "getLogs" -> result.success(synchronized(FirewallVpnService.logs) {
                        ArrayList(FirewallVpnService.logs)
                    })

                    "clearLogs" -> {
                        FirewallVpnService.logs.clear()
                        FirewallVpnService.blockedCount = 0
                        result.success(null)
                    }

                    "hasUsageAccess" -> result.success(hasUsage())

                    "openUsageAccess" -> {
                        startActivity(
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(null)
                    }

                    "openAppSettings" -> {
                        startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.parse("package:$packageName")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(null)
                    }

                    "getUsage" -> {
                        val from = (call.argument<Number>("from") ?: 0).toLong()
                        Thread {
                            val r: List<Map<String, Any>> = try {
                                usage(from)
                            } catch (e: Exception) {
                                emptyList()
                            }
                            runOnUiThread { result.success(r) }
                        }.start()
                    }

                    "getScreenTime" -> {
                        val days = (call.argument<Int>("days") ?: 7).coerceIn(1, 30)
                        val ns = call.argument<Int>("ns") ?: 0
                        val ne = call.argument<Int>("ne") ?: 0
                        Thread {
                            val m: Map<String, Any> = try {
                                val r = UsageUtil.compute(this, days, ns, ne)
                                mapOf(
                                    "starts" to r.starts.toList(),
                                    "total" to r.total.toList(),
                                    "unlocks" to r.unlocks.toList(),
                                    "night" to r.night.toList(),
                                    "nightLast" to r.nightLast.toList(),
                                    "apps" to r.apps.map { mapOf("pkg" to it.key, "d" to it.value.toList()) }
                                )
                            } catch (e: Exception) {
                                emptyMap()
                            }
                            runOnUiThread { result.success(m) }
                        }.start()
                    }

                    "getDataStatus" -> Thread {
                        val m: Map<String, Any> = try {
                            DataLimit.status(this)
                        } catch (e: Exception) {
                            emptyMap()
                        }
                        runOnUiThread { result.success(m) }
                    }.start()

                    "addDataExtra" -> {
                        val mb = (call.argument<Int>("mb") ?: 0).coerceIn(0, 100000)
                        if (mb > 0) {
                            DataLimit.addExtra(this, mb.toLong(), DataLimit.cfg(Store.load(this)).resetDay)
                            FirewallVpnService.reload(this)
                        }
                        result.success(true)
                    }

                    "isGuardEnabled" -> result.success(guardEnabled())

                    "openAccessibility" -> {
                        startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(null)
                    }

                    "startFocus" -> {
                        val min = (call.argument<Int>("minutes") ?: 25).coerceIn(1, 600)
                        if (VpnService.prepare(this) != null) {
                            result.success(false)
                        } else {
                            Store.startFocus(this, min)
                            FirewallVpnService.start(this)
                            result.success(true)
                        }
                    }

                    "endFocus" -> {
                        Store.endFocus(this)
                        FirewallVpnService.reload(this)
                        result.success(true)
                    }

                    "getFocus" -> result.success(
                        mapOf(
                            "until" to Store.focusUntil(this),
                            "hist" to Store.focusHist(this)
                        )
                    )

                    "vaultStatus" -> Thread {
                        val st = try {
                            VaultManager.status(this)
                        } catch (e: Exception) {
                            "restore"
                        }
                        runOnUiThread { result.success(st) }
                    }.start()

                    "vaultList" -> Thread {
                        val r: List<Map<String, Any>> = try {
                            VaultManager.list(this)
                        } catch (e: Exception) {
                            emptyList()
                        }
                        runOnUiThread { result.success(r) }
                    }.start()

                    "vaultPick" -> {
                        if (pickResult != null) {
                            result.success(null)
                        } else {
                            pickResult = result
                            pickDelete = call.argument<Boolean>("deleteOriginal") ?: false
                            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                                .addCategory(Intent.CATEGORY_OPENABLE)
                                .setType("*/*")
                                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                                .addFlags(
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                )
                            startActivityForResult(i, 101)
                        }
                    }

                    "vaultOpen", "vaultShare" -> {
                        val id = call.argument<String>("id") ?: ""
                        val share = call.method == "vaultShare"
                        Thread {
                            var i: Intent? = null
                            try {
                                i = if (share) VaultManager.shareIntent(this, id) else VaultManager.viewIntent(this, id)
                            } catch (e: Exception) {
                            }
                            val fin = i
                            runOnUiThread {
                                if (fin == null) {
                                    result.success("error")
                                } else {
                                    try {
                                        startActivity(fin)
                                        result.success("ok")
                                    } catch (e: ActivityNotFoundException) {
                                        result.success("no_app")
                                    } catch (e: Exception) {
                                        result.success("error")
                                    }
                                }
                            }
                        }.start()
                    }

                    "vaultDelete" -> {
                        val id = call.argument<String>("id") ?: ""
                        Thread {
                            val ok = try {
                                VaultManager.delete(this, id)
                            } catch (e: Exception) {
                                false
                            }
                            runOnUiThread { result.success(ok) }
                        }.start()
                    }

                    "vaultBackupKey" -> Thread {
                        val k = try {
                            VaultManager.backupKey(this)
                        } catch (e: Exception) {
                            ""
                        }
                        runOnUiThread { result.success(k) }
                    }.start()

                    "vaultRestoreKey" -> {
                        val k = call.argument<String>("key") ?: ""
                        Thread {
                            val ok = try {
                                VaultManager.restoreKey(this, k)
                            } catch (e: Exception) {
                                false
                            }
                            runOnUiThread { result.success(ok) }
                        }.start()
                    }

                    "vaultClean" -> Thread {
                        try {
                            VaultManager.cleanTemp(this)
                        } catch (e: Exception) {
                        }
                        runOnUiThread { result.success(null) }
                    }.start()

                    "setSecure" -> {
                        if (call.argument<Boolean>("on") == true) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        }
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    private fun displayName(u: android.net.Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment ?: "file"
    }

    private fun guardEnabled(): Boolean {
        val l = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return l.split(':').any { it.contains(packageName) && it.contains("GuardService") }
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** অ্যাপ অনুযায়ী Wi-Fi ও মোবাইল ডেটা (বাইট), from থেকে এখন পর্যন্ত */
    private fun usage(from: Long): List<Map<String, Any>> {
        val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val to = System.currentTimeMillis()
        val acc = HashMap<String, LongArray>()
        val types = listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)
        for ((idx, type) in types.withIndex()) {
            val st = try {
                nsm.querySummary(type, null, from, to)
            } catch (e: Exception) {
                continue
            }
            val b = NetworkStats.Bucket()
            while (st.hasNextBucket()) {
                st.getNextBucket(b)
                if (b.uid < 0) continue
                val pkg = packageManager.getPackagesForUid(b.uid)?.firstOrNull() ?: "uid:${b.uid}"
                val a = acc.getOrPut(pkg) { LongArray(2) }
                a[idx] += b.rxBytes + b.txBytes
            }
            st.close()
        }
        return acc.map { mapOf("pkg" to it.key, "wifi" to it.value[0], "mobile" to it.value[1]) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 100) {
            if (resultCode == Activity.RESULT_OK) {
                FirewallVpnService.start(this)
                pending?.success(true)
            } else {
                pending?.success(false)
            }
            pending = null
        } else if (requestCode == 101) {
            val res = pickResult
            pickResult = null
            val del = pickDelete
            if (res == null) return
            if (resultCode != Activity.RESULT_OK || data == null) {
                res.success(null)
                return
            }
            val uris = ArrayList<android.net.Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            }
            if (uris.isEmpty()) {
                val d = data.data
                if (d != null) uris.add(d)
            }
            Thread {
                var added = 0
                var failed = 0
                var deleted = 0
                for (u in uris) {
                    try {
                        val name = displayName(u)
                        val st = contentResolver.openInputStream(u) ?: throw java.io.IOException("no stream")
                        st.use { VaultManager.add(this, it, name) }
                        added++
                        if (del) {
                            try {
                                if (android.provider.DocumentsContract.deleteDocument(contentResolver, u)) deleted++
                            } catch (e: Exception) {
                            }
                        }
                    } catch (e: Exception) {
                        failed++
                    }
                }
                runOnUiThread {
                    res.success(mapOf("added" to added, "failed" to failed, "deleted" to deleted))
                }
            }.start()
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
