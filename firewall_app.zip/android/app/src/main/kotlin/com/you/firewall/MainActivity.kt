package com.you.firewall

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process
import android.provider.Settings
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.VpnService
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "firewall/vpn")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getApps" -> Thread {
                        val pm = packageManager
                        val list = pm.getInstalledApplications(0)
                            .filter { it.packageName != packageName }
                            .map {
                                mapOf(
                                    "name" to pm.getApplicationLabel(it).toString(),
                                    "pkg" to it.packageName,
                                    "system" to ((it.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                                )
                            }
                            .sortedBy { (it["name"] as String).lowercase() }
                        runOnUiThread { result.success(list) }
                    }.start()

                    "getIcon" -> {
                        val pkg = call.argument<String>("pkg") ?: ""
                        Thread {
                            val bytes: ByteArray? = try {
                                val d = packageManager.getApplicationIcon(pkg)
                                val bmp = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
                                d.setBounds(0, 0, 72, 72)
                                d.draw(Canvas(bmp))
                                val o = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
                                o.toByteArray()
                            } catch (e: Exception) {
                                null
                            }
                            runOnUiThread { result.success(bytes) }
                        }.start()
                    }

                    "start" -> {
                        val i = VpnService.prepare(this)
                        if (i != null) {
                            pending = result
                            startActivityForResult(i, 100)
                        } else {
                            FirewallVpnService.start(this)
                            result.success(true)
                        }
                    }

                    "stop" -> {
                        FirewallVpnService.stop(this)
                        result.success(null)
                    }

                    "isRunning" -> result.success(FirewallVpnService.running)

                    "loadConfig" ->
                        result.success(Store.prefs(this).getString("cfg", "") ?: "")

                    "saveConfig" -> {
                        val j = try {
                            JSONObject(call.argument<String>("json") ?: "{}")
                        } catch (e: Exception) {
                            JSONObject()
                        }
                        // enabled-এর মালিক Kotlin, Dart-এর পুরোনো মান দিয়ে বদলানো যাবে না
                        j.put("enabled", Store.load(this).optBoolean("enabled"))
                        Store.save(this, j)
                        FirewallVpnService.reload(this)
                        result.success(null)
                    }

                    "getLogs" -> result.success(synchronized(FirewallVpnService.logs) {
                        ArrayList(FirewallVpnService.logs)
                    })

                    "clearLogs" -> {
                        FirewallVpnService.logs.clear()
                        FirewallVpnService.blockedCount = 0
                        result.success(null)
                    }

                    "hasUsageAccess" -> result.success(hasUsage())

                    "openUsageAccess" -> {
                        startActivity(
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(null)
                    }

                    "getUsage" -> {
                        val from = (call.argument<Number>("from") ?: 0).toLong()
                        Thread {
                            val r: List<Map<String, Any>> = try {
                                usage(from)
                            } catch (e: Exception) {
                                emptyList()
                            }
                            runOnUiThread { result.success(r) }
                        }.start()
                    }

                    else -> result.notImplemented()
                }
            }
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** অ্যাপ অনুযায়ী Wi-Fi ও মোবাইল ডেটা (বাইট), from থেকে এখন পর্যন্ত */
    private fun usage(from: Long): List<Map<String, Any>> {
        val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val to = System.currentTimeMillis()
        val acc = HashMap<String, LongArray>()
        val types = listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)
        for ((idx, type) in types.withIndex()) {
            val st = try {
                nsm.querySummary(type, null, from, to)
            } catch (e: Exception) {
                continue
            }
            val b = NetworkStats.Bucket()
            while (st.hasNextBucket()) {
                st.getNextBucket(b)
                if (b.uid < 0) continue
                val pkg = packageManager.getPackagesForUid(b.uid)?.firstOrNull() ?: "uid:${b.uid}"
                val a = acc.getOrPut(pkg) { LongArray(2) }
                a[idx] += b.rxBytes + b.txBytes
            }
            st.close()
        }
        return acc.map { mapOf("pkg" to it.key, "wifi" to it.value[0], "mobile" to it.value[1]) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 100) {
            if (resultCode == Activity.RESULT_OK) {
                FirewallVpnService.start(this)
                pending?.success(true)
            } else {
                pending?.success(false)
            }
            pending = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
