package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import org.json.JSONObject

/**
 * গেস্ট মোড: কেউ ফোন চাইলে চালু করুন। বেছে দেওয়া অ্যাপ ছাড়া সব অ্যাপ পিন দিয়ে লক (GuardService ধরে),
 * ফায়ারওয়াল অ্যাপ বন্ধ হয়ে যায় (খুলতে পিন লাগে, লুকানো এলাকা ও ভল্ট গেস্ট মোড চলতে খোলে না)।
 * চালু করতে পিন লাগে না (নিরাপদ দিকে যায়), বন্ধ করতে পিন/ফিঙ্গারপ্রিন্ট লাগে।
 * অবস্থা আলাদা SharedPreferences-এ, তাই Dart-এর সেভে মুছে যায় না।
 */
object Guest {
    const val ID = 7720

    private fun sp(c: Context) = c.getSharedPreferences("fw_guest", Context.MODE_PRIVATE)

    fun isOn(c: Context): Boolean = sp(c).getBoolean("on", false)

    fun allowed(cfg: JSONObject, pkg: String): Boolean {
        val a = cfg.optJSONArray("guestApps") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    /** পিন না থাকলে চালু হয় না (বন্ধ করার পথ থাকবে না)। ফেরত = চালু হলো কিনা */
    fun enable(c: Context): Boolean {
        val ctx = c.applicationContext
        if (Store.load(ctx).optString("pinHash").isEmpty()) return false
        sp(ctx).edit().putBoolean("on", true).apply()
        try { VaultManager.wipe(ctx) } catch (e: Exception) {}
        GuardService.unlockedPkg = null
        MainActivity.closeNow()
        showNotice(ctx)
        return true
    }

    fun disable(c: Context) {
        val ctx = c.applicationContext
        sp(ctx).edit().putBoolean("on", false).apply()
        GuardService.unlockedPkg = null
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
        } catch (e: Exception) {
        }
    }

    fun offIntent(c: Context): Intent =
        Intent(c, LockActivity::class.java)
            .putExtra("guestOff", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** স্থায়ী নোটিফিকেশন, "বন্ধ করুন" বোতাম পিনের স্ক্রিন খোলে */
    @Suppress("DEPRECATION")
    fun showNotice(c: Context) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("fws_guest", "গেস্ট মোড", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val pi = PendingIntent.getActivity(
                c, 7720, offIntent(c), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "fws_guest") else Notification.Builder(c)
            b.setContentTitle("গেস্ট মোড চালু")
                .setContentText("বেছে দেওয়া অ্যাপ ছাড়া সব লক। বন্ধ করতে পিন লাগবে।")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .setContentIntent(pi)
                .addAction(0, "গেস্ট মোড বন্ধ করুন", pi)
            nm.notify(ID, b.build())
        } catch (e: Exception) {
        }
    }
}

/** কুইক সেটিংসে "গেস্ট" টাইল */
class GuestTile : TileService() {

    override fun onStartListening() {
        render()
    }

    override fun onClick() {
        if (Guest.isOn(this)) {
            launch(Guest.offIntent(this)) // পিন চাইবে
            return
        }
        if (Store.load(this).optString("pinHash").isEmpty()) {
            Toast.makeText(this, "গেস্ট মোডের জন্য আগে অ্যাপে পিন দিন", Toast.LENGTH_LONG).show()
            return
        }
        if (!GuardService.connected) {
            Toast.makeText(this, "গেস্ট মোডের জন্য অ্যাপ গার্ড চালু থাকতে হবে", Toast.LENGTH_LONG).show()
            return
        }
        Guest.enable(this)
        render()
    }

    private fun launch(i: Intent) {
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 2, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun render() {
        qsTile?.let {
            it.state = if (Guest.isOn(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            it.updateTile()
        }
    }
}
