package com.you.firewall

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * ভুল পিনের ইতিহাস + চোরের ছবি।
 * ইতিহাস আলাদা SharedPreferences-এ (Dart-এর সেভে মুছে যায় না), ছবি এনক্রিপ্ট হয়ে ভল্টে।
 * পরপর ৩, ৬, ৯... বার ভুল হলে (সুইচ চালু ও ক্যামেরার অনুমতি থাকলে) সামনের ক্যামেরায় ছবি তোলে।
 * ছবি তোলা হয় যখন অ্যাপের কোনো স্ক্রিন (পিন চাওয়ার স্ক্রিন) সামনে আছে, তাই ব্যাকগ্রাউন্ড ক্যামেরা নিষেধে আটকায় না।
 */
object Intruder {
    private const val MAX = 200
    private val busy = AtomicBoolean(false)

    private fun sp(c: Context) = c.getSharedPreferences("fw_intruder", Context.MODE_PRIVATE)

    private fun loadLog(c: Context): JSONArray = try {
        JSONArray(sp(c).getString("log", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveLog(c: Context, a: JSONArray) {
        sp(c).edit().putString("log", a.toString()).apply()
    }

    @Synchronized
    private fun addEntry(c: Context, where: String, n: Int): String {
        val id = System.currentTimeMillis().toString() + "_" + n
        val a = loadLog(c)
        a.put(JSONObject().put("id", id).put("t", System.currentTimeMillis()).put("where", where).put("n", n).put("vid", ""))
        // পুরনো এন্ট্রি ছাঁটা (ছবিসহ এন্ট্রি ছাঁটলে ভল্টের ছবিও থেকে যায়, তাই শুধু লগ ছাঁটি)
        val out = if (a.length() > MAX) {
            val b = JSONArray()
            for (i in a.length() - MAX until a.length()) b.put(a.get(i))
            b
        } else a
        saveLog(c, out)
        return id
    }

    @Synchronized
    private fun setPhoto(c: Context, entryId: String, vid: String) {
        val a = loadLog(c)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("id") == entryId) {
                o.put("vid", vid)
                break
            }
        }
        saveLog(c, a)
    }

    /** নতুন থেকে পুরনো ক্রমে */
    @Synchronized
    fun list(c: Context): List<Map<String, Any>> {
        val a = loadLog(c)
        val out = ArrayList<Map<String, Any>>()
        for (i in a.length() - 1 downTo 0) {
            val o = a.optJSONObject(i) ?: continue
            val vid = o.optString("vid")
            var has = false
            if (vid.isNotEmpty()) {
                try {
                    has = VaultManager.meta(c, vid) != null
                } catch (e: Exception) {
                }
            }
            out.add(
                mapOf(
                    "id" to o.optString("id"),
                    "t" to o.optLong("t"),
                    "where" to o.optString("where"),
                    "n" to o.optInt("n"),
                    "vid" to vid,
                    "photo" to has
                )
            )
        }
        return out
    }

    /** ইতিহাস মোছা। deletePhotos = true হলে ভল্টের চোরের ছবিগুলোও যায় */
    @Synchronized
    fun clear(c: Context, deletePhotos: Boolean) {
        if (deletePhotos) {
            val a = loadLog(c)
            for (i in 0 until a.length()) {
                val vid = a.optJSONObject(i)?.optString("vid") ?: ""
                if (vid.isNotEmpty()) {
                    try {
                        VaultManager.delete(c, vid)
                    } catch (e: Exception) {
                    }
                }
            }
        }
        saveLog(c, JSONArray())
    }

    /** PinUtil.recordFail থেকে ডাকা হয়: ভুল পিন লিখে রাখে, ৩-এর গুণিতকে ছবি তোলে */
    fun onWrongPin(c: Context, where: String, fails: Int) {
        val ctx = c.applicationContext
        val id = addEntry(ctx, where, fails)
        if (fails % 3 != 0) return
        if (!Store.load(ctx).optBoolean("intruderPhoto")) return
        if (!VaultManager.supported()) return
        if (ctx.checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) return
        capture(ctx) { jpeg ->
            if (jpeg != null) {
                try {
                    val name = "intruder_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                    val r = VaultManager.add(ctx, ByteArrayInputStream(jpeg), name)
                    setPhoto(ctx, id, r["id"] as? String ?: "")
                } catch (e: Exception) {
                }
            }
        }
    }

    /**
     * পকেট গার্ড: ইতিহাসে এন্ট্রি লিখে সামনের ক্যামেরায় ছবি তুলে ভল্টে রাখে। n = 0, তাই ইতিহাসের পেজে "ভুল পিন"
     * না লিখে [where] দেখায়। ক্যামেরার অনুমতি না থাকলে শুধু এন্ট্রি থাকে। ছবি তোলা চলে ফোরগ্রাউন্ড সার্ভিসের ভেতর থেকে।
     */
    fun snap(c: Context, where: String) {
        val ctx = c.applicationContext
        val id = addEntry(ctx, where, 0)
        if (!VaultManager.supported()) return
        if (ctx.checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) return
        capture(ctx) { jpeg ->
            if (jpeg != null) {
                try {
                    val name = "pocket_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
                    val r = VaultManager.add(ctx, ByteArrayInputStream(jpeg), name)
                    setPhoto(ctx, id, r["id"] as? String ?: "")
                } catch (e: Exception) {
                }
            }
        }
    }

    /** সামনের ক্যামেরায় প্রিভিউ ছাড়া একটা ছবি। ব্যর্থ হলে done(null)। সবসময় ৬ সেকেন্ডের মধ্যে শেষ */
    @SuppressLint("MissingPermission")
    private fun capture(ctx: Context, done: (ByteArray?) -> Unit) {
        if (!busy.compareAndSet(false, true)) return
        val finished = AtomicBoolean(false)
        val thread = HandlerThread("fw-intruder")
        thread.start()
        val h = Handler(thread.looper)
        var cam: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var reader: ImageReader? = null
        var tex: SurfaceTexture? = null
        var psurf: Surface? = null

        fun finish(data: ByteArray?) {
            if (!finished.compareAndSet(false, true)) return
            try { session?.close() } catch (e: Exception) {}
            try { cam?.close() } catch (e: Exception) {}
            try { reader?.close() } catch (e: Exception) {}
            try { psurf?.release() } catch (e: Exception) {}
            try { tex?.release() } catch (e: Exception) {}
            try { thread.quitSafely() } catch (e: Exception) {}
            busy.set(false)
            Thread {
                try {
                    done(data)
                } catch (e: Exception) {
                }
            }.start()
        }

        try {
            val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var camId: String? = null
            for (i in mgr.cameraIdList) {
                val f = mgr.getCameraCharacteristics(i).get(CameraCharacteristics.LENS_FACING)
                if (f == CameraCharacteristics.LENS_FACING_FRONT) {
                    camId = i
                    break
                }
            }
            if (camId == null) {
                finish(null)
                return
            }
            val ch = mgr.getCameraCharacteristics(camId)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (map == null) {
                finish(null)
                return
            }
            val js = map.getOutputSizes(ImageFormat.JPEG)?.sortedBy { it.width.toLong() * it.height }
            val ps = map.getOutputSizes(SurfaceTexture::class.java)?.sortedBy { it.width.toLong() * it.height }
            if (js.isNullOrEmpty() || ps.isNullOrEmpty()) {
                finish(null)
                return
            }
            val jsize = js.firstOrNull { it.width >= 1000 } ?: js.last()
            val psize = ps.firstOrNull { it.width >= 320 } ?: ps.last()
            val sensor = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 270

            val rd = ImageReader.newInstance(jsize.width, jsize.height, ImageFormat.JPEG, 1)
            reader = rd
            rd.setOnImageAvailableListener({ r ->
                var bytes: ByteArray? = null
                try {
                    val img = r.acquireLatestImage()
                    if (img != null) {
                        val buf = img.planes[0].buffer
                        val b = ByteArray(buf.remaining())
                        buf.get(b)
                        bytes = b
                        img.close()
                    }
                } catch (e: Exception) {
                }
                finish(bytes)
            }, h)

            val ts = SurfaceTexture(10)
            ts.setDefaultBufferSize(psize.width, psize.height)
            tex = ts
            val pf = Surface(ts)
            psurf = pf

            h.postDelayed({ finish(null) }, 6000)

            mgr.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    cam = d
                    if (finished.get()) {
                        try { d.close() } catch (e: Exception) {}
                        return
                    }
                    try {
                        @Suppress("DEPRECATION")
                        d.createCaptureSession(listOf(pf, rd.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                session = s
                                if (finished.get()) return
                                try {
                                    // কয়েক ফ্রেম চলতে দিই, যাতে এক্সপোজার ঠিক হয়ে ছবি অন্ধকার না আসে
                                    val pr = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                    pr.addTarget(pf)
                                    s.setRepeatingRequest(pr.build(), null, h)
                                    h.postDelayed({
                                        try {
                                            val st = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                                            st.addTarget(rd.surface)
                                            st.set(CaptureRequest.JPEG_ORIENTATION, sensor)
                                            s.capture(st.build(), null, h)
                                        } catch (e: Exception) {
                                            finish(null)
                                        }
                                    }, 800)
                                } catch (e: Exception) {
                                    finish(null)
                                }
                            }

                            override fun onConfigureFailed(s: CameraCaptureSession) {
                                finish(null)
                            }
                        }, h)
                    } catch (e: Exception) {
                        finish(null)
                    }
                }

                override fun onDisconnected(d: CameraDevice) {
                    finish(null)
                }

                override fun onError(d: CameraDevice, error: Int) {
                    finish(null)
                }
            }, h)
        } catch (e: Exception) {
            finish(null)
        }
    }
}
