package com.you.firewall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Store.load(c).optBoolean("enabled")) return
        if (VpnService.prepare(c) == null) {
            FirewallVpnService.start(c)
        } else {
            Guardian.lostPermission(c)
        }
    }
}
