package com.you.firewall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Guest.isOn(c)) Guest.showNotice(c) // গেস্ট মোড রিবুটেও চালু থাকে
        if (Bubbles.wanted(c) && Bubbles.canDraw(c)) Bubbles.start(c) // বাবল রিবুটেও ফেরে
        if (Wow.wanted(c)) Wow.apply(c) // ডট ও ভয়েস অ্যালার্ট রিবুটেও ফেরে
        Buddy.restore(c) // আলসে-লক, হার্টবিট, পোষা রিবুটেও ফেরে
        if (!Store.load(c).optBoolean("enabled")) return
        if (VpnService.prepare(c) == null) {
            FirewallVpnService.start(c)
        } else {
            Guardian.lostPermission(c)
        }
    }
}
