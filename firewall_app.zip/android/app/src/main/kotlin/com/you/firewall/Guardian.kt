package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper

/** জরুরি সতর্কতা নোটিফিকেশন (ফায়ারওয়াল বন্ধ হলে) */
object Alert {
    private const val CH = "fwa"

    fun show(c: Context, id: Int, title: String, text: String) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "Firewall বন্ধ হওয়ার সতর্কতা", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH)
            else Notification.Builder(c)
            nm.notify(
                id,
                b.setContentTitle(title)
                    .setContentText(text)
                    .setStyle(Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (e: Exception) {
        }
    }

    /** রিপোর্ট ও সন্দেহজনক-চেষ্টার নোটিফিকেশন। ট্যাপ করলে [route] পেজ খোলে */
    fun report(c: Context, id: Int, title: String, text: String, route: String? = "report") {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("fwr", "Firewall রিপোর্ট ও সতর্কতা", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val launch = Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (route != null) launch.putExtra("route", route)
            val pi = PendingIntent.getActivity(
                c, id, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "fwr")
            else Notification.Builder(c)
            nm.notify(
                id,
                b.setContentTitle(title)
                    .setContentText(text)
                    .setStyle(Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (e: Exception) {
        }
    }

    fun cancel(c: Context, id: Int) {
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
        } catch (e: Exception) {
        }
    }
}

/**
 * পাহারাদার: ফায়ারওয়াল চালু থাকার কথা, অথচ VPN নেই (সিস্টেম মেরে দিয়েছে বা অন্য VPN কেড়ে নিয়েছে)।
 * আগে নিজে আবার চালু করার চেষ্টা, না পারলে সতর্কতা। প্রতি ১৫ মিনিটে একবার নিজে থেকেও যাচাই করে।
 */
object Guardian {
    private const val JOB_ID = 7701
    const val ALERT_ID = 7702
    private val h = Handler(Looper.getMainLooper())

    fun schedule(c: Context) {
        try {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val info = JobInfo.Builder(JOB_ID, ComponentName(c, GuardianJob::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js.schedule(info)
        } catch (e: Exception) {
        }
    }

    fun cancel(c: Context) {
        try {
            (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB_ID)
        } catch (e: Exception) {
        }
        Alert.cancel(c, ALERT_ID)
    }

    /** সময় বা ডেটা লিমিট বা সময়সূচি সেট করা আছে কিনা (এগুলো VPN ছাড়া কাজ করে না) */
    fun hasLimits(c: Context): Boolean {
        val cfg = Store.load(c)
        if ((cfg.optJSONObject("limits")?.length() ?: 0) > 0) return true
        if (cfg.optBoolean("scheduleEnabled")) return true
        return DataLimit.cfg(cfg).any
    }

    private fun suffix(c: Context): String =
        if (hasLimits(c)) " ডেটা/সময় লিমিট আর সময়সূচি এখন কাজ করছে না।" else ""

    /** অনুমতি চলে গেছে (অন্য VPN চালু হয়েছে বা সিস্টেম কেড়েছে) */
    fun lostPermission(c: Context) {
        Alert.show(
            c, ALERT_ID, "Firewall বন্ধ হয়ে গেছে",
            "অন্য VPN চালু হয়েছে বা অনুমতি সরে গেছে। অ্যাপ খুলে আবার চালু করুন।" + suffix(c)
        )
    }

    /** চালু থাকার কথা কিন্তু নেই: আবার চালু করার চেষ্টা, না পারলে সতর্কতা */
    fun ensure(c: Context, done: (() -> Unit)? = null) {
        val ctx = c.applicationContext
        if (!Store.load(ctx).optBoolean("enabled") || FirewallVpnService.running) {
            if (done != null) h.post { done() }
            return
        }
        if (VpnService.prepare(ctx) != null) {
            lostPermission(ctx)
            if (done != null) h.post { done() }
            return
        }
        FirewallVpnService.start(ctx)
        h.postDelayed({
            if (FirewallVpnService.running) {
                Alert.show(
                    ctx, ALERT_ID, "Firewall আবার চালু হয়েছে",
                    "কিছুক্ষণ বন্ধ ছিল, নিজে আবার চালু হয়েছে। ঘন ঘন হলে ব্যাটারি সেটিংস দেখুন।"
                )
            } else {
                Alert.show(
                    ctx, ALERT_ID, "Firewall বন্ধ আছে",
                    "নিজে চালু হতে পারেনি। ট্যাপ করে অ্যাপ খুলে চালু করুন।" + suffix(ctx)
                )
            }
            done?.invoke()
        }, 4000)
    }
}

class GuardianJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        try {
            Insights.weeklyCheck(this)
        } catch (e: Exception) {
        }
        Guardian.ensure(this) { jobFinished(p, false) }
        return true
    }

    override fun onStopJob(p: JobParameters): Boolean = false
}
