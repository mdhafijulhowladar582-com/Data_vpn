package com.you.firewall

import android.content.Context

/**
 * "কেন?" ডিটেকটিভ: একটা সময়ের ব্যবধানের স্যাম্পল আর কানেকশন লগ মিলিয়ে বাংলায় সম্ভাব্য কারণ বলে।
 * এটা অনুমান, প্রমাণ নয়: তাই ভাষা "সম্ভবত"। কারণ খুঁজে না পেলে সেটাই সৎভাবে বলে।
 */
object Analyzer {
    private fun label(c: Context, pkg: String): String = if (pkg.isEmpty()) "?" else NetNotice.label(c, pkg)

    private fun mb(b: Long): String = if (b >= 1024L * 1024 * 1024) String.format("%.1f GB", b / 1073741824.0)
    else String.format("%.0f MB", b / 1048576.0)

    /** সামনে সবচেয়ে বেশি স্যাম্পলে থাকা অ্যাপ (স্ক্রিন চালু অবস্থায়), না থাকলে null */
    private fun topFg(list: List<Sampler.S>): Pair<String, Int>? {
        val m = HashMap<String, Int>()
        for (s in list) if (s.screen && s.fg.isNotEmpty()) m[s.fg] = (m[s.fg] ?: 0) + 1
        return m.maxByOrNull { it.value }?.toPair()
    }

    /** কানেকশন লগে এই ব্যবধানে সবচেয়ে বেশি ডেটা খাওয়া অ্যাপ: (pkg, বাইট) */
    private fun topNet(c: Context, from: Long): List<Pair<String, Long>> = try {
        ConnLog.apps(c, from).map { (it["pkg"] as String) to ((it["up"] as Long) + (it["down"] as Long)) }
            .filter { it.second > 0 }.take(3)
    } catch (e: Exception) {
        emptyList()
    }

    /**
     * [type]: "battery" | "heat" | "mem" | "data" | "now" (এখনকার সার্বিক ছবি)।
     * ফেরত: প্রথম লাইন সারসংক্ষেপ, বাকি লাইনে ক্রমানুসারে কারণ।
     */
    fun explain(c: Context, type: String, win: List<Sampler.S>): String {
        if (win.size < 2) return "বিশ্লেষণের মতো যথেষ্ট স্যাম্পল নেই। ফায়ারওয়াল চালু রেখে কিছুক্ষণ পরে আবার দেখুন।"
        val first = win.first()
        val last = win.last()
        val mins = ((last.t - first.t) / 60000L).coerceAtLeast(1)
        val reasons = ArrayList<String>()
        val screenOnN = win.count { it.screen }
        val screenOff = screenOnN * 2 < win.size
        val maxTemp = win.maxOf { it.temp }
        val top = topFg(win)
        val net = topNet(c, first.t)
        val totalData = win.sumOf { it.rx + it.tx }

        val head = when (type) {
            "battery" -> "$mins মিনিটে ব্যাটারি ${first.batt}% থেকে ${last.batt}% (${first.batt - last.batt}% কমেছে)।"
            "heat" -> "ফোনের তাপ ${String.format("%.1f", maxTemp / 10.0)}°C পর্যন্ত উঠেছে।"
            "mem" -> "খালি RAM কমে ${win.minOf { it.memFree }} MB-তে নেমেছে।"
            "data" -> "$mins মিনিটে মোট ${mb(totalData)} ডেটা গেছে।"
            else -> "গত $mins মিনিটের সারাংশ: ব্যাটারি ${first.batt}% → ${last.batt}%, সর্বোচ্চ তাপ ${String.format("%.1f", maxTemp / 10.0)}°C।"
        }

        // ---- সামনের অ্যাপ ----
        if (top != null && top.second * 3 >= win.size) {
            val share = top.second * 100 / win.size
            val n = label(c, top.first)
            when (type) {
                "battery", "heat", "now" -> reasons.add("$n বেশিরভাগ সময় সামনে ছিল ($share%)। গেম, ভিডিও বা ক্যামেরা-জাতীয় অ্যাপ হলে ব্যাটারি ও তাপ দুটোই বাড়ে।")
                "mem" -> reasons.add("$n সামনে খোলা ছিল, ভারী অ্যাপ RAM খেয়ে ফেলতে পারে।")
            }
        }

        // ---- স্ক্রিন বন্ধ অথচ ক্ষয় ----
        if ((type == "battery" || type == "now") && screenOff && !last.charging && first.batt - last.batt >= 2) {
            reasons.add("স্ক্রিন বেশিরভাগ সময় বন্ধ ছিল, তবু ব্যাটারি কমেছে। সম্ভবত কোনো অ্যাপ ব্যাকগ্রাউন্ডে কাজ করছে।")
        }

        // ---- ডেটা ----
        if (net.isNotEmpty() && (type != "mem")) {
            val (p, b) = net[0]
            if (b >= 5L * 1024 * 1024) {
                reasons.add("নেট ব্যবহারে এগিয়ে ${label(c, p)} (${mb(b)})।" +
                    if (screenOff) " স্ক্রিন বন্ধ থাকতেও এত ডেটা সন্দেহজনক।" else "")
            }
        } else if (type == "data" || (type == "now" && totalData > 30L * 1024 * 1024)) {
            reasons.add("কোন অ্যাপ ডেটা খেল তা বলা যাচ্ছে না। কানেকশন লগ শুধু ইঞ্জিনে যোগ করা অ্যাপ দেখে, বাকি অ্যাপের হিসাব শুধু মোট।")
        }
        if ((type == "heat" || type == "battery") && totalData > 50L * 1024 * 1024) {
            reasons.add("এই সময়ে ${mb(totalData)} ডেটা গেছে। টানা ডাউনলোড/আপলোডে মডেম গরম হয়, ব্যাটারিও যায়।")
        }

        // ---- তাপ ----
        if (type == "heat" || type == "now") {
            if (last.charging || win.any { it.charging }) reasons.add("ফোন চার্জে ছিল। চার্জিং নিজেই তাপ বাড়ায়, বিশেষ করে সাথে গেম/ভিডিও চললে।")
            if (Sampler.overheatNow) reasons.add("ফোনের ব্যাটারি নিজেই 'অতিরিক্ত গরম' জানিয়েছে। এটা ব্যাটারির নিজের নিরাপদ সীমা পেরোনোর সংকেত, তাই চার্জ বা ভারী কাজ থামিয়ে ঠান্ডা করুন।")
            if (win.any { it.thermal >= 3 }) reasons.add("সিস্টেমের নিজস্ব থার্মাল স্ট্যাটাস 'গুরুতর' বা তার ওপরে উঠেছে, ফোন নিজেই গতি কমাচ্ছে।")
            if (screenOff && maxTemp >= 400) reasons.add("স্ক্রিন বন্ধ অথচ গরম, ভেতরে কোনো প্রসেস বা নেট কাজ চলছে হতে পারে।")
        }

        // ---- RAM ----
        if (type == "mem" || type == "now") {
            if (win.any { it.lowMem }) reasons.add("সিস্টেম নিজেই 'কম মেমরি' জানিয়েছে, ব্যাকগ্রাউন্ড অ্যাপ বন্ধ হতে পারে।")
        }

        if (reasons.isEmpty()) reasons.add("স্পষ্ট কোনো কারণ ধরা পড়েনি। সম্ভবত স্বাভাবিক ব্যবহার। ঘটনা বারবার ঘটলে আবার দেখুন।")
        val sb = StringBuilder(head)
        for ((i, r) in reasons.withIndex()) sb.append("\n").append(i + 1).append(". ").append(r)
        return sb.toString()
    }
}
