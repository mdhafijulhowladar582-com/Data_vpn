package com.you.firewall

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * সেন্সর-পোষার দুটো হিসাব:
 *  1) ঘুমের সময়: লম্বা অন্ধকার সময়কে রাতের ঘুম ধরে দিনওয়ারি জমানো (আন্দাজ, কারণ আলোর সেন্সর শুধু অন্ধকার বোঝে, ঘুম নয়)
 *  2) তুললে সারাংশ: ফোন যতক্ষণ উল্টো বা অন্ধকারে ছিল, ততক্ষণে কত মোবাইল ডেটা গেল আর কোন অ্যাপ বেশি খেল
 * সবই ফোনের ভেতরেই থাকে, কোথাও পাঠানো হয় না।
 */
object SleepLog {
    /** এর চেয়ে ছোট অন্ধকার সময়কে ঘুম ধরা হয় না (পকেট, ব্যাগ ইত্যাদি বাদ) */
    const val MIN_SLEEP_MIN = 120

    /** এর চেয়ে লম্বা অন্ধকার ঘুম নয়, ড্রয়ার বা ব্যাগে ফোন পড়ে ছিল ধরে বাদ */
    const val MAX_SLEEP_MIN = 16 * 60

    /** মাঝে এতক্ষণের মধ্যে আলো এসে আবার অন্ধকার হলে একই ঘুম (রাতে বাথরুম, ফোন দেখা) */
    const val GAP_MS = 20L * 60_000L

    private const val KEEP_DAYS = 14

    private fun key(ms: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    /** ঘুম শুরুর সময় রাত ৬টা থেকে ভোর ৫টার মধ্যে হলে তবেই রাতের ঘুম */
    private fun isNight(startMs: Long): Boolean {
        val h = Calendar.getInstance().apply { timeInMillis = startMs }.get(Calendar.HOUR_OF_DAY)
        return h >= 18 || h < 5
    }

    /** একটা শেষ হওয়া অন্ধকার সময় জমা। ঘুম হলে মিনিট ফেরত, নইলে 0 */
    @Synchronized
    fun record(c: Context, startMs: Long, endMs: Long): Int {
        val min = ((endMs - startMs) / 60_000L).toInt()
        if (min < MIN_SLEEP_MIN || min > MAX_SLEEP_MIN || !isNight(startMs)) return 0
        val m = load(c)
        val k = key(endMs) // যেদিন উঠলো সেদিনের নামে জমা
        m[k] = (m[k] ?: 0) + min
        // সবচেয়ে পুরনোগুলো ফেলে শুধু শেষ ১৪ দিন রাখা
        val keys = m.keys.sorted()
        if (keys.size > KEEP_DAYS) for (old in keys.take(keys.size - KEEP_DAYS)) m.remove(old)
        save(c, m)
        return min
    }

    private fun load(c: Context): MutableMap<String, Int> {
        val out = HashMap<String, Int>()
        val raw = c.applicationContext.getSharedPreferences("fw_buddy", Context.MODE_PRIVATE).getString("sleepLog", "") ?: ""
        for (part in raw.split(',')) {
            val kv = part.split('=')
            if (kv.size != 2) continue
            val v = kv[1].toIntOrNull() ?: continue
            out[kv[0]] = v
        }
        return out
    }

    private fun save(c: Context, m: Map<String, Int>) {
        val s = m.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${it.value}" }
        c.applicationContext.getSharedPreferences("fw_buddy", Context.MODE_PRIVATE).edit().putString("sleepLog", s).apply()
    }

    class Day(val key: String, val min: Int)

    /** শেষ [n] দিনের ঘুম, নতুন আগে */
    fun recent(c: Context, n: Int): List<Day> =
        load(c).entries.sortedByDescending { it.key }.take(n).map { Day(it.key, it.value) }

    /** শেষ ৭ দিনের গড় (যে দিনগুলোর হিসাব আছে শুধু সেগুলোর), না থাকলে 0 */
    fun avg7(c: Context): Int {
        val l = recent(c, 7)
        return if (l.isEmpty()) 0 else l.sumOf { it.min } / l.size
    }

    /** "৭ ঘণ্টা ১০ মিনিট" */
    fun fmt(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h == 0 -> "${Insights.bn(m)} মিনিট"
            m == 0 -> "${Insights.bn(h)} ঘণ্টা"
            else -> "${Insights.bn(h)} ঘণ্টা ${Insights.bn(m)} মিনিট"
        }
    }

    /** ডার্টের জন্য: ["yyyyMMdd:মিনিট", ...] নতুন আগে */
    fun asList(c: Context, n: Int): List<String> = recent(c, n).map { "${it.key}:${it.min}" }

    // ---------------- তুললে ডেটা সারাংশ ----------------

    @Suppress("DEPRECATION")
    private fun hasUsage(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) {
        false
    }

    private fun fmtBytes(b: Long): String = when {
        b < 1024L -> "${b} B"
        b < 1024L * 1024L -> "${b / 1024L} KB"
        else -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
    }

    /**
     * [fromMs] থেকে এখন পর্যন্ত মোবাইল ডেটার সারাংশ (দুই লাইন)। Usage access না থাকলে null।
     * একই UID-র অ্যাপগুলো একই সংখ্যা পেতে পারে (অ্যান্ড্রয়েডের হিসাবের সীমা)।
     */
    fun dataLine(c: Context, fromMs: Long): String? {
        val ctx = c.applicationContext
        if (!hasUsage(ctx)) return null
        val use = try {
            UsageUtil.dataSince(ctx, fromMs, false, true)
        } catch (e: Exception) {
            return null
        }
        val pm = ctx.packageManager
        var topName: String? = null
        var topBytes = 0L
        for ((pkg, b) in use.apps) {
            if (pkg == ctx.packageName) continue
            if (b > topBytes) {
                topBytes = b
                topName = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) {
                    pkg
                }
            }
        }
        val head = "মোবাইল ডেটা গেছে ${fmtBytes(use.total)}"
        return if (topName != null && topBytes >= 512L * 1024L) {
            "$head\nসবচেয়ে বেশি: $topName (${fmtBytes(topBytes)})"
        } else head
    }
}
