package com.you.firewall

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews

/**
 * হোম স্ক্রিন উইজেট: পোষা আর নেট-হার্টবিট অ্যাপ না খুলেই দেখা যায়।
 * উইজেট নিজে চলে না, তাই পোষার ছবি আর হার্টবিটের রেখা ছবি এঁকে বসানো হয়।
 * আপডেট হয় ডেটা-পোষা সার্ভিস চালু থাকলে প্রতি মিনিটে, না থাকলে ফোনের নিয়মে প্রায় আধা ঘণ্টায়।
 * হার্টবিটের স্পিড দুই আপডেটের মাঝের গড়। সন্দেহজনক ডেটা ধরা পড়লে (নেট-হার্টবিট চালু থাকলে) রেখা লাল।
 */
class PetWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val app = c.applicationContext
        val pr = goAsync()
        Thread {
            try {
                PetCore.refresh(app) // সার্ভিস বন্ধ থাকলেও দিনের হিসাব আর স্ট্রিক এগোয়
            } catch (e: Exception) {
            }
            Handler(Looper.getMainLooper()).post {
                try {
                    render(app, m, ids)
                } catch (e: Exception) {
                } finally {
                    pr.finish()
                }
            }
        }.start()
    }

    companion object {
        private const val PI_FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        /** যেকোনো থ্রেড থেকে ডাকা যায়; আঁকা হয় মেইন থ্রেডে */
        fun refreshAll(c: Context) {
            try {
                val app = c.applicationContext
                val m = AppWidgetManager.getInstance(app)
                val ids = m.getAppWidgetIds(ComponentName(app, PetWidget::class.java))
                if (ids.isEmpty()) return
                Handler(Looper.getMainLooper()).post {
                    try {
                        render(app, m, ids)
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
        }

        /** হোম স্ক্রিনে বসানোর অনুরোধ (লঞ্চার সমর্থন না করলে false) */
        fun pin(c: Context): Boolean = try {
            val m = AppWidgetManager.getInstance(c.applicationContext)
            if (Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported) {
                m.requestPinAppWidget(ComponentName(c.applicationContext, PetWidget::class.java), null, null)
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }

        private fun id(c: Context, name: String): Int =
            c.resources.getIdentifier(name, "id", c.packageName)

        private fun open(c: Context): PendingIntent = PendingIntent.getActivity(
            c, 15,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("route", "buddy"),
            PI_FLAGS
        )

        /** দুই আপডেটের মাঝে মোট কত বাইট গেছে ÷ সময়। ২০ সেকেন্ডের কম ব্যবধানে আগের মানই থাকে */
        private fun speed(c: Context): Float {
            val tot = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
            if (tot < 0L) return 0f
            val now = System.currentTimeMillis()
            val lastTot = Buddy.long(c, "wTot", -1L)
            val lastAt = Buddy.long(c, "wAt", 0L)
            var sp = Buddy.long(c, "wSpeed", 0L)
            val dt = now - lastAt
            if (lastTot < 0L || tot < lastTot || dt <= 0L) {
                // প্রথমবার বা রিবুটের পর: শুধু শুরুর মান ধরে রাখা
                Buddy.putLong(c, "wTot", tot)
                Buddy.putLong(c, "wAt", now)
                sp = 0L
                Buddy.putLong(c, "wSpeed", 0L)
            } else if (dt >= 20_000L) {
                sp = (tot - lastTot) * 1000L / dt
                Buddy.putLong(c, "wTot", tot)
                Buddy.putLong(c, "wAt", now)
                Buddy.putLong(c, "wSpeed", sp)
            }
            return sp.toFloat()
        }

        private fun draw(v: View, w: Int, h: Int): Bitmap {
            v.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
            )
            v.layout(0, 0, w, h)
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(b))
            return b
        }

        private fun render(c: Context, m: AppWidgetManager, ids: IntArray) {
            val s = PetCore.last(c)
            val sp = speed(c)
            val d = c.resources.displayMetrics.density

            val pv = PetView(c)
            pv.health = s.health
            pv.mood = s.mood
            pv.look = s.streak
            val petBmp = draw(pv, (110 * d).toInt(), (110 * d).toInt())

            val panic = System.currentTimeMillis() < Buddy.long(c, "beatPanicUntil", 0L)
            val bv = BeatView(c)
            bv.panic = panic
            bv.bpm = if (panic) 190f else Buddy.bpmFor(sp)
            bv.speedText = Buddy.fmtSpeed(sp)
            bv.label = "চুপিচুপি ডেটা যাচ্ছে!"
            for (i in 0 until 90) bv.step(0.05f)
            val beatBmp = draw(bv, (260 * d).toInt(), (64 * d).toInt())

            val say = when (s.mood) {
                0 -> "আজ দারুণ খুশি"
                1 -> "ঠিকঠাক চলছে"
                2 -> "ভাগের প্রায় শেষ"
                else -> "আজকের ভাগ পেরিয়েছে"
            }
            val v = RemoteViews(c.packageName, c.resources.getIdentifier("widget_pet", "layout", c.packageName))
            v.setImageViewBitmap(id(c, "wp_pet"), petBmp)
            v.setImageViewBitmap(id(c, "wp_beat"), beatBmp)
            v.setTextViewText(id(c, "wp_title"), "${Buddy.petForm(s.streak)} · স্ট্রিক ${Insights.bn(s.streak)} দিন")
            v.setTextViewText(id(c, "wp_line1"), "আজ ${Insights.bn(s.usedMb)} / ${Insights.bn(s.allowMb)} MB")
            v.setTextViewText(id(c, "wp_line2"), if (Buddy.codeOn(c)) "$say 🔓" else say)
            v.setOnClickPendingIntent(id(c, "wp_root"), open(c))
            m.updateAppWidget(ids, v)
        }
    }
}
