package com.you.firewall

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale

/**
 * সব অ্যাপের (সিস্টেমসহ) লাইভ নেট স্পিড। ফ্লোটিং ডট, রাডার আর ভয়েস অ্যালার্ট তিনটাই এখান থেকে ডেটা নেয়।
 * NetworkStatsManager (Usage access) ব্যবহার হয়, তাই কমপক্ষে ১০ সেকেন্ডের ব্যবধানে দুবারের মোট ধরে গড় স্পিড বের হয় (আনুমানিক)।
 * "সন্দেহজনক" = স্ক্রিন বন্ধ, অথবা অ্যাপটা সামনে খোলা নেই, তবু ৪ KB/s-এর বেশি নেট খাচ্ছে।
 */
object LiveNet {
    private const val MIN_WINDOW_MS = 10_000L
    private const val MAX_WINDOW_MS = 120_000L
    const val SUSPECT_BPS = 4096.0

    class Row(
        val pkg: String, val label: String, val bps: Double, val today: Long,
        val fg: Boolean, val suspicious: Boolean, val system: Boolean
    )

    @Volatile var rated = false

    private var baseAt = 0L
    private var baseDay = -1
    private var base = HashMap<String, Long>()
    private var last: List<Row> = emptyList()
    private val uidPkg = HashMap<Int, String>()
    private val labels = HashMap<String, String>()

    private fun dayKey(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    @Synchronized
    fun sample(c: Context): List<Row> {
        val ctx = c.applicationContext
        val now = SystemClock.elapsedRealtime()
        val day = dayKey()
        val fresh = baseAt != 0L && day == baseDay
        if (fresh && now - baseAt < MIN_WINDOW_MS) return last
        val cur = totals(ctx) ?: return last
        val useRate = fresh && now - baseAt < MAX_WINDOW_MS
        val dt = if (useRate) (now - baseAt) / 1000.0 else 1.0
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val screen = pm.isInteractive
        val fgPkg = GuardService.fgNow
        val out = ArrayList<Row>()
        for ((p, bytes) in cur) {
            if (p == ctx.packageName) continue
            var bps = 0.0
            if (useRate) {
                val before = base[p]
                if (before != null && bytes > before) bps = (bytes - before) / dt
            }
            val isFg = screen && p == fgPkg
            val susp = bps >= SUSPECT_BPS && !isFg
            out.add(Row(p, labelOf(ctx, p), bps, bytes, isFg, susp, isSystem(ctx, p)))
        }
        base = cur
        baseAt = now
        baseDay = day
        rated = useRate
        last = out
        return out
    }

    private fun labelOf(c: Context, pkg: String): String = labels.getOrPut(pkg) {
        if (pkg.startsWith("uid:")) "সিস্টেম সার্ভিস"
        else try {
            c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    private fun isSystem(c: Context, pkg: String): Boolean = pkg.startsWith("uid:") || try {
        (c.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
    } catch (e: Exception) {
        false
    }

    /** আজ মাঝরাত থেকে এখন পর্যন্ত প্রতিটা অ্যাপের মোট বাইট। Usage access না থাকলে null */
    private fun totals(c: Context): HashMap<String, Long>? {
        return try {
            val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val from = cal.timeInMillis
            val to = System.currentTimeMillis()
            val byUid = HashMap<Int, Long>()
            var ok = false
            for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
                val st = try {
                    nsm.querySummary(type, null, from, to)
                } catch (e: Exception) {
                    continue
                }
                ok = true
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    if (b.uid < 0) continue
                    byUid[b.uid] = (byUid[b.uid] ?: 0L) + b.rxBytes + b.txBytes
                }
                st.close()
            }
            if (!ok) return null
            val out = HashMap<String, Long>()
            for ((uid, bytes) in byUid) {
                val pkg = uidPkg.getOrPut(uid) {
                    c.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "uid:$uid"
                }
                out[pkg] = (out[pkg] ?: 0L) + bytes
            }
            out
        } catch (e: Exception) {
            null
        }
    }
}

/** ফ্লোটিং ডট, রাডার আর ভয়েস অ্যালার্টের সেটিংস ও সাধারণ কাজ */
object Wow {
    private val NEVER_BLOCK = setOf("android", "com.android.systemui")

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_wow", Context.MODE_PRIVATE)

    fun dotOn(c: Context) = sp(c).getBoolean("dot", false)
    fun voiceOn(c: Context) = sp(c).getBoolean("voice", false)
    fun quiet(c: Context) = sp(c).getBoolean("quiet", true)
    fun wanted(c: Context) = dotOn(c) || voiceOn(c)

    fun setCfg(c: Context, key: String, on: Boolean) {
        if (key != "dot" && key != "voice" && key != "quiet") return
        sp(c).edit().putBoolean(key, on).apply()
        apply(c)
    }

    fun disableAll(c: Context) {
        sp(c).edit().putBoolean("dot", false).putBoolean("voice", false).apply()
    }

    /** সেটিংস অনুযায়ী সার্ভিস চালু বা বন্ধ। চালু থাকলে আবার ডাকলে সার্ভিস নিজেকে নতুন করে সাজায় */
    fun apply(c: Context) {
        val ctx = c.applicationContext
        try {
            if (wanted(ctx)) {
                val i = Intent(ctx, WowService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } else {
                ctx.stopService(Intent(ctx, WowService::class.java))
            }
        } catch (e: Exception) {
        }
    }

    fun state(c: Context): Map<String, Any> = mapOf(
        "dot" to dotOn(c),
        "voice" to voiceOn(c),
        "quiet" to quiet(c),
        "canDraw" to Bubbles.canDraw(c),
        "running" to WowService.running
    )

    fun radar(c: Context): Map<String, Any> {
        val rows = LiveNet.sample(c)
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        val sorted = rows.sortedWith(
            compareByDescending<LiveNet.Row> { it.suspicious }
                .thenByDescending { it.bps }
                .thenByDescending { it.today }
        ).take(40)
        val list = sorted.map {
            mapOf<String, Any>(
                "pkg" to it.pkg, "label" to it.label, "bps" to it.bps, "today" to it.today,
                "fg" to it.fg, "susp" to it.suspicious, "system" to it.system
            )
        }
        return mapOf("rated" to LiveNet.rated, "screen" to pm.isInteractive, "apps" to list)
    }

    /** "ok", "self" (এই অ্যাপ নিজে), "core" (ফোনের মূল সিস্টেম), "bad" */
    fun block(c: Context, pkg: String): String {
        if (pkg.isEmpty() || pkg.startsWith("uid:")) return "bad"
        if (pkg == c.packageName) return "self"
        if (pkg in NEVER_BLOCK) return "core"
        return try {
            Safety.blockApp(c, pkg)
            "ok"
        } catch (e: Exception) {
            "bad"
        }
    }

    /** ভয়েস পরীক্ষা: বাংলা ভয়েস থাকলে বাংলায়, নইলে ইংরেজিতে বলে */
    fun testVoice(c: Context) {
        val ctx = c.applicationContext
        Handler(Looper.getMainLooper()).post {
            var t: TextToSpeech? = null
            t = TextToSpeech(ctx) { st ->
                val tts = t
                if (st == TextToSpeech.SUCCESS && tts != null) {
                    val bn = tts.setLanguage(Locale("bn", "BD")) >= 0
                    if (!bn) tts.setLanguage(Locale.US)
                    tts.speak(
                        if (bn) "সতর্ক! একটি অজানা অ্যাপ নেটে ঢুকতে চাইছে" else "Warning! An unknown app is using the internet",
                        TextToSpeech.QUEUE_FLUSH, null, "wowtest"
                    )
                    Handler(Looper.getMainLooper()).postDelayed({ tts.shutdown() }, 8000)
                }
            }
        }
    }
}

/** ডটের ছবি: নেট বাড়লে বড় আর লাল, শান্ত থাকলে ছোট আর সবুজ */
class DotView(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2f * d
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
    }
    var level = 0f
        private set
    var pkg: String? = null
        private set
    private var label = ""
    private var speed = "শান্ত"
    private var pulse = 0f

    private val pulser = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 700
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener {
            pulse = it.animatedValue as Float
            if (level > 0.6f) invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulser.start()
    }

    override fun onDetachedFromWindow() {
        pulser.cancel()
        super.onDetachedFromWindow()
    }

    fun show(p: String?, name: String, bps: Double) {
        pkg = p
        label = if (p == null) "" else if (name.length > 10) name.substring(0, 10) else name
        speed = if (p == null) "শান্ত" else fmtSpeed(bps)
        val target = if (p == null) 0f
        else (Math.log10(1.0 + bps / 1024.0) / 3.0).toFloat().coerceIn(0.08f, 1f)
        ValueAnimator.ofFloat(level, target).apply {
            duration = 500
            addUpdateListener {
                level = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun fmtSpeed(b: Double): String = when {
        b >= 1048576 -> String.format(Locale.US, "%.1f MB/s", b / 1048576.0)
        else -> String.format(Locale.US, "%.0f KB/s", b / 1024.0)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height * 0.40f
        val r = (14f + level * 26f) * d + (if (level > 0.6f) pulse * 4f * d else 0f)
        val green = Color.rgb(0x2E, 0xCC, 0x71)
        val amber = Color.rgb(0xF3, 0x9C, 0x12)
        val red = Color.rgb(0xE7, 0x4C, 0x3C)
        val col = if (level < 0.5f) mix(green, amber, level / 0.5f) else mix(amber, red, (level - 0.5f) / 0.5f)
        fill.color = col
        fill.alpha = 225
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, edge)
        txt.textSize = 11f * d
        if (label.isNotEmpty()) canvas.drawText(label, cx, height - 20f * d, txt)
        txt.textSize = 10f * d
        canvas.drawText(speed, cx, height - 7f * d, txt)
    }
}

/**
 * ফ্লোটিং ডট + ভয়েস অ্যালার্টের সার্ভিস।
 *  - ডট: এই মুহূর্তে সবচেয়ে বেশি নেট খাওয়া অ্যাপ। ট্যাপ = রাডার খোলা। টেনে নিচের লাল জোনে ছাড়লে ওই অ্যাপের নেট ব্লক
 *  - ভয়েস: সন্দেহজনক অ্যাপ টানা দুবার ধরা পড়লে নোটিফিকেশন আর কথা বলা (একই অ্যাপ নিয়ে ১০ মিনিটে একবার)
 */
class WowService : Service() {
    companion object {
        @Volatile var running = false
        private const val CH = "fw_wow"
        private const val ID = 7412
        private const val ACT_STOP = "com.you.firewall.WOW_STOP"
        private const val TICK_MS = 4000L
        private const val REPEAT_MS = 10 * 60 * 1000L
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var density = 1f
    private var dot: DotView? = null
    private var dotLp: WindowManager.LayoutParams? = null
    private var zone: TextView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsBn = false
    private val streak = HashMap<String, Int>()
    private val spoken = HashMap<String, Long>()
    @Volatile private var busy = false

    private val tick = object : Runnable {
        override fun run() {
            doTick()
            ui.postDelayed(this, TICK_MS)
        }
    }

    private fun dp(v: Int) = (v * density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACT_STOP) {
            Wow.disableAll(this)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Wow.wanted(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (Wow.voiceOn(this)) initTts() else releaseTts()
        syncDot()
        ui.removeCallbacks(tick)
        ui.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacks(tick)
        removeDot()
        hideZone()
        releaseTts()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "ডট ও ভয়েস অ্যালার্ট", NotificationManager.IMPORTANCE_MIN))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("route", "radar"),
            flags
        )
        val stop = PendingIntent.getService(this, 4, Intent(this, WowService::class.java).setAction(ACT_STOP), flags)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val n = b.setContentTitle("নেট পাহারা চালু")
            .setContentText("ডট বা ভয়েস অ্যালার্ট চলছে। ট্যাপে রাডার খুলবে")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "বন্ধ করুন", stop).build())
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, 0x40000000) else startForeground(ID, n)
        } catch (e: Exception) {
        }
    }

    // ---------- ভয়েস ----------

    private fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(applicationContext) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                ttsBn = t.setLanguage(Locale("bn", "BD")) >= 0
                if (!ttsBn) t.setLanguage(Locale.US)
                ttsReady = true
            }
        }
    }

    private fun releaseTts() {
        try {
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ttsReady = false
    }

    private fun quietNow(): Boolean {
        if (!Wow.quiet(this)) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h in 0..5
    }

    private fun alert(r: LiveNet.Row) {
        val bn = "${r.label} অ্যাপ গোপনে নেট খাচ্ছে (${String.format(Locale.US, "%.0f", r.bps / 1024.0)} KB/s)"
        XNotify.show(this, 7440 + (Math.abs(r.pkg.hashCode()) % 50), "সন্দেহজনক নেট ব্যবহার", bn, "radar")
        if (Wow.voiceOn(this) && ttsReady && !quietNow()) {
            val line = if (ttsBn) "সতর্ক! ${r.label} অ্যাপ গোপনে নেট ব্যবহার করছে"
            else "Warning! ${r.label} is using the internet in the background"
            try {
                tts?.speak(line, TextToSpeech.QUEUE_ADD, null, "wow")
            } catch (e: Exception) {
            }
        }
    }

    // ---------- টিক ----------

    private fun doTick() {
        if (busy) return
        busy = true
        val ctx = applicationContext
        Thread {
            val rows = try {
                LiveNet.sample(ctx)
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                busy = false
                if (running) onRows(rows)
            }
        }.start()
    }

    private fun onRows(rows: List<LiveNet.Row>) {
        val top = rows.filter { it.bps >= 1024.0 }.maxByOrNull { it.bps }
        dot?.show(top?.pkg, top?.label ?: "", top?.bps ?: 0.0)

        val now = SystemClock.elapsedRealtime()
        val suspects = rows.filter { it.suspicious }.map { it.pkg }.toSet()
        for (k in streak.keys.toList()) if (k !in suspects) streak.remove(k)
        for (r in rows) {
            if (!r.suspicious) continue
            val n = (streak[r.pkg] ?: 0) + 1
            streak[r.pkg] = n
            val lastAt = spoken[r.pkg] ?: 0L
            if (n >= 2 && (lastAt == 0L || now - lastAt > REPEAT_MS)) {
                spoken[r.pkg] = now
                alert(r)
            }
        }
    }

    // ---------- ডট ----------

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun syncDot() {
        if (Wow.dotOn(this) && Bubbles.canDraw(this)) {
            if (dot == null) addDot()
        } else {
            removeDot()
        }
    }

    private fun removeDot() {
        dot?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        dot = null
        dotLp = null
    }

    private fun addDot() {
        val w = dp(100)
        val h = dp(110)
        val lp = WindowManager.LayoutParams(
            w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val sp = getSharedPreferences("fw_wow", Context.MODE_PRIVATE)
        lp.x = sp.getInt("dotx", screenW() - w).coerceIn(0, screenW() - w)
        lp.y = sp.getInt("doty", dp(260)).coerceIn(0, screenH() - h)

        val v = DotView(this)
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (dx * dx + dy * dy) > slop * slop) {
                        moved = true
                        showZone()
                    }
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, screenW() - w)
                        lp.y = (startY + dy).toInt().coerceIn(0, screenH() - h)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                        }
                        zoneHover(overZone(e.rawX, e.rawY))
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        val hit = e.action == MotionEvent.ACTION_UP && overZone(e.rawX, e.rawY)
                        hideZone()
                        if (hit) blockTop(v.pkg)
                        snapBack(v, lp, w)
                    } else if (e.action == MotionEvent.ACTION_UP) {
                        openRadar()
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, lp)
            dot = v
            dotLp = lp
            v.show(null, "", 0.0)
        } catch (e: Exception) {
        }
    }

    private fun snapBack(v: View, lp: WindowManager.LayoutParams, w: Int) {
        val target = if (lp.x + w / 2 < screenW() / 2) 0 else screenW() - w
        getSharedPreferences("fw_wow", Context.MODE_PRIVATE).edit().putInt("doty", lp.y).putInt("dotx", target).apply()
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 160
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(v, lp)
            } catch (e: Exception) {
            }
        }
        a.start()
    }

    private fun openRadar() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("route", "radar")
            )
        } catch (e: Exception) {
        }
    }

    private fun blockTop(pkg: String?) {
        if (pkg == null) {
            toast("এখন কেউ নেট খাচ্ছে না")
            return
        }
        when (Wow.block(this, pkg)) {
            "ok" -> {
                toast("ব্লক করা হলো: " + (try {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) {
                    pkg
                }))
                buzz()
            }
            "self" -> toast("এটা এই অ্যাপ নিজেই, ব্লক করা যায় না")
            "core" -> toast("ফোনের মূল সিস্টেম, ব্লক করা যায় না")
            else -> toast("ব্লক করা গেল না")
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val vb = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            else vb.vibrate(80)
        } catch (e: Exception) {
        }
    }

    private fun toast(m: String) {
        try {
            Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    // ---------- ব্লক জোন (টানার সময় নিচে আসে) ----------

    private fun showZone() {
        if (zone != null) return
        val tv = TextView(this)
        tv.text = "এখানে ছেড়ে দিন: নেট ব্লক"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.gravity = Gravity.CENTER
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(0xCCB71C1C.toInt())
            setStroke(dp(2), Color.WHITE)
        }
        val lp = WindowManager.LayoutParams(
            dp(240), dp(80), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = dp(48)
        try {
            wm.addView(tv, lp)
            zone = tv
        } catch (e: Exception) {
        }
    }

    private fun hideZone() {
        zone?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        zone = null
    }

    private fun overZone(x: Float, y: Float): Boolean {
        val z = zone ?: return false
        val loc = IntArray(2)
        z.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + z.width && y >= loc[1] && y <= loc[1] + z.height
    }

    private fun zoneHover(on: Boolean) {
        val z = zone ?: return
        (z.background as? GradientDrawable)?.setColor(if (on) 0xFFD50000.toInt() else 0xCCB71C1C.toInt())
        z.text = if (on) "ছেড়ে দিন, ব্লক হবে" else "এখানে ছেড়ে দিন: নেট ব্লক"
    }
}
