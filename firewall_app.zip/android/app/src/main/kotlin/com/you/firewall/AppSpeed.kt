package com.you.firewall

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * অ্যাপ-ভিত্তিক লাইভ স্পিড (শীর্ষ ৩)। অন্য অ্যাপের ট্রাফিক TrafficStats দিয়ে দেখা যায় না (Android 7+),
 * তাই NetworkStatsManager (Usage access) ব্যবহার হয়। সিস্টেম এই পরিসংখ্যান কয়েক সেকেন্ড পরপর হালনাগাদ করে,
 * তাই কমপক্ষে ১৫ সেকেন্ডের ব্যবধানে দুবারের মোট ধরে গড় স্পিড বের করা হয় (আনুমানিক)।
 */
object AppSpeed {
    private const val MIN_WINDOW_MS = 15_000L
    private const val MAX_WINDOW_MS = 120_000L
    private const val MIN_BPS = 512.0

    private var baseAt = 0L
    private var baseDay = ""
    private var base = HashMap<String, Long>()
    private var last: List<Map<String, Any>> = emptyList()
    private val uidPkg = HashMap<Int, String>()

    @Synchronized
    fun sample(c: Context): List<Map<String, Any>> {
        val now = SystemClock.elapsedRealtime()
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val fresh = baseAt != 0L && day == baseDay
        if (fresh && now - baseAt < MIN_WINDOW_MS) return last
        val cur = totals(c) ?: return last
        if (fresh && now - baseAt < MAX_WINDOW_MS) {
            val dt = (now - baseAt) / 1000.0
            val l = ArrayList<Pair<String, Double>>()
            for ((p, b) in cur) {
                val before = base[p] ?: continue
                val d = b - before
                if (d > 0 && d / dt >= MIN_BPS) l.add(Pair(p, d / dt))
            }
            l.sortByDescending { it.second }
            last = l.take(3).map { mapOf<String, Any>("pkg" to it.first, "bps" to it.second) }
        } else {
            last = emptyList()
        }
        base = cur
        baseAt = now
        baseDay = day
        return last
    }

    private fun totals(c: Context): HashMap<String, Long>? {
        return try {
            val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val from = cal.timeInMillis
            val to = System.currentTimeMillis()
            val byUid = HashMap<Int, Long>()
            for (type in listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
                val st = try {
                    nsm.querySummary(type, null, from, to)
                } catch (e: Exception) {
                    continue
                }
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    if (b.uid < 0) continue
                    byUid[b.uid] = (byUid[b.uid] ?: 0L) + b.rxBytes + b.txBytes
                }
                st.close()
            }
            val out = HashMap<String, Long>()
            for ((uid, bytes) in byUid) {
                val pkg = uidPkg.getOrPut(uid) {
                    c.packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "uid:$uid"
                }
                out[pkg] = (out[pkg] ?: 0L) + bytes
            }
            out
        } catch (e: Exception) {
            null
        }
    }
}
