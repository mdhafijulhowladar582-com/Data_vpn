package com.you.firewall

import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.PowerManager
import java.net.InetSocketAddress
import java.net.Socket

/**
 * নেটের মান মাপা: প্রতি ৩০ সেকেন্ডে (VPN-এর tick-এ) একটা ছোট TCP সংযোগের সময়।
 * সকেট protect() করা, তাই VPN-এর ভেতর না ঢুকে আসল নেটওয়ার্কের মান মাপে।
 * শুধু স্ক্রিন চালু থাকলে মাপে (ব্যাটারি বাঁচাতে)। টানা খারাপ হলে একটা সতর্কতা।
 */
object NetQuality {
    private const val SLOW_MS = 800L
    private const val ALERT_GAP_MS = 15L * 60 * 1000
    private val TARGETS = listOf("1.1.1.1", "8.8.8.8")
    private val recent = ArrayDeque<Long>() // -1 = ব্যর্থ
    @Volatile private var running = false
    @Volatile private var lastAlert = 0L

    /** tick-এর থ্রেড আটকায় না, আলাদা থ্রেডে চলে */
    fun onTick(c: Context) {
        try {
            val ctx = c.applicationContext
            if (!Store.load(ctx).optBoolean("qualityWatch", false)) return
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) return
            if (c !is VpnService) return
            if (running) return
            running = true
            Thread {
                try {
                    measure(ctx, c)
                } catch (e: Exception) {
                } finally {
                    running = false
                }
            }.also { it.isDaemon = true }.start()
        } catch (e: Exception) {
        }
    }

    private fun netLabel(c: Context): String {
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val cap = cm.getNetworkCapabilities(n) ?: continue
                if (cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi"
                if (cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "mobile"
            }
        } catch (e: Exception) {
        }
        return "none"
    }

    private fun measure(ctx: Context, svc: VpnService) {
        val net = netLabel(ctx)
        var ms = -1L
        if (net != "none") {
            for (t in TARGETS) {
                val s = Socket()
                try {
                    svc.protect(s)
                    val t0 = System.nanoTime()
                    s.connect(InetSocketAddress(t, 443), 3000)
                    ms = (System.nanoTime() - t0) / 1_000_000
                    break
                } catch (e: Exception) {
                } finally {
                    try { s.close() } catch (e: Exception) {}
                }
            }
        }
        val now = System.currentTimeMillis()
        val v = ContentValues()
        v.put("t", now)
        v.put("net", net)
        v.put("ms", if (ms < 0) 0L else ms)
        v.put("ok", if (ms < 0) 0 else 1)
        XDb.get(ctx).writableDatabase.insertWithOnConflict(
            "net_ping", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE
        )
        judge(ctx, ms, net, now)
    }

    /** শেষ ৪টা মাপের (২ মিনিট) মধ্যে ৩টা ব্যর্থ বা ধীর হলে সতর্কতা */
    private fun judge(ctx: Context, ms: Long, net: String, now: Long) {
        var bad = 0
        var full = false
        synchronized(recent) {
            recent.addLast(ms)
            while (recent.size > 4) recent.removeFirst()
            bad = recent.count { it < 0 || it > SLOW_MS }
            full = recent.size >= 4
        }
        if (!full) return
        if (bad >= 3 && now - lastAlert > ALERT_GAP_MS) {
            lastAlert = now
            val where = when (net) {
                "wifi" -> "Wi-Fi"
                "mobile" -> "মোবাইল ডেটা"
                else -> "নেট"
            }
            XNotify.show(
                ctx, 7002, "নেট খারাপ চলছে",
                "$where-এ গত ২ মিনিট ধরে সংযোগ ধীর বা মাঝে মাঝে বন্ধ। নেটের মান পেজে বিস্তারিত দেখুন।", "quality"
            )
        }
    }

    /** পেজের জন্য: [since] থেকে সর্বশেষ ৬০০টা মাপ, নতুন আগে */
    fun list(c: Context, since: Long): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(c).readableDatabase.rawQuery(
            "SELECT t, net, ms, ok FROM net_ping WHERE t >= ? ORDER BY t DESC LIMIT 600",
            arrayOf(since.toString())
        ).use {
            while (it.moveToNext()) {
                out.add(
                    mapOf(
                        "t" to it.getLong(0), "net" to (it.getString(1) ?: ""),
                        "ms" to it.getLong(2), "ok" to (it.getInt(3) != 0)
                    )
                )
            }
        }
        return out
    }
}
