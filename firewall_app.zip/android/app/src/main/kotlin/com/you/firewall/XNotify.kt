package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * নতুন টুলসের সতর্কতা (স্ক্যাম আটকানো, নেট সমস্যা)। আলাদা চ্যানেল, যাতে পুরনো সতর্কতার সাথে না মেশে।
 * [route] দিলে ট্যাপে অ্যাপ খুলে ওই ফিচারের পেজে যায় (মেনু রেজিস্ট্রির id)।
 */
object XNotify {
    private const val CH = "fwx"

    fun show(c: Context, id: Int, title: String, text: String, route: String? = null) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "নতুন টুলসের সতর্কতা", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val launch = Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (route != null) launch.putExtra("route", route)
            val pi = PendingIntent.getActivity(
                c, id, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else Notification.Builder(c)
            nm.notify(
                id,
                b.setContentTitle(title)
                    .setContentText(text)
                    .setStyle(Notification.BigTextStyle().bigText(text))
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (e: Exception) {
        }
    }
}
