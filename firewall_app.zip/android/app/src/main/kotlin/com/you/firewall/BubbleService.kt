package com.you.firewall

import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * ফ্লোটিং বাবল: বাছা অ্যাপগুলোর ছোট গোল আইকন স্ক্রিনের ওপর ভাসে।
 *  - টেনে সরানো যায়, ছাড়লে কিনারায় লেগে যায়
 *  - ট্যাপ = অ্যাপ খোলা (বাবল শুধু শর্টকাট, অ্যাপ বাবলের ভেতরে চলে না)
 *  - লং-প্রেস = মেনু: নেট বন্ধ/চালু, আজকের ডেটা, অ্যাপ লক/আনলক
 * ব্লক ও লক সরাসরি মূল কনফিগে লেখা হয়, তাই ফায়ারওয়াল ও অ্যাপ গার্ড নিজেরাই ধরে নেয়।
 */
object Bubbles {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_bubble", Context.MODE_PRIVATE)

    fun pkgs(c: Context): List<String> = try {
        val a = JSONArray(sp(c).getString("pkgs", "[]") ?: "[]")
        (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
    } catch (e: Exception) {
        emptyList()
    }

    fun setPkgs(c: Context, list: List<String>) {
        sp(c).edit().putString("pkgs", JSONArray(list.distinct()).toString()).apply()
    }

    fun wanted(c: Context): Boolean = sp(c).getBoolean("on", false)

    fun canDraw(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    fun y(c: Context, pkg: String, def: Int): Int = sp(c).getInt("y_$pkg", def)
    fun saveY(c: Context, pkg: String, v: Int) = sp(c).edit().putInt("y_$pkg", v).apply()

    fun start(c: Context): Boolean {
        val ctx = c.applicationContext
        if (!canDraw(ctx)) return false
        sp(ctx).edit().putBoolean("on", true).apply()
        return try {
            val i = Intent(ctx, BubbleService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop(c: Context) {
        val ctx = c.applicationContext
        sp(ctx).edit().putBoolean("on", false).apply()
        try {
            ctx.stopService(Intent(ctx, BubbleService::class.java))
        } catch (e: Exception) {
        }
    }

    fun openPermission(c: Context): Boolean = try {
        c.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (e: Exception) {
        false
    }

    // ---------- ছোট উইন্ডো (ফ্রিফর্ম) ----------

    fun mini(c: Context): Boolean = sp(c).getBoolean("mini", false)
    fun miniSize(c: Context): Int = sp(c).getInt("msize", 1).coerceIn(0, 2)
    fun setMini(c: Context, on: Boolean, size: Int) {
        sp(c).edit().putBoolean("mini", on).putInt("msize", size.coerceIn(0, 2)).apply()
    }

    /** ফোন ফ্রিফর্ম উইন্ডো পারে কিনা: সিস্টেমে থাকলে অথবা ডেভেলপার অপশনে চালু থাকলে true */
    fun freeformSupported(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val f = try {
            c.packageManager.hasSystemFeature("android.software.freeform_window_management")
        } catch (e: Exception) {
            false
        }
        val g = try {
            Settings.Global.getInt(c.contentResolver, "enable_freeform_support", 0) == 1
        } catch (e: Exception) {
            false
        }
        return f || g
    }

    fun state(c: Context): Map<String, Any> = mapOf(
        "on" to wanted(c),
        "running" to BubbleService.running,
        "canDraw" to canDraw(c),
        "pkgs" to pkgs(c),
        "mini" to mini(c),
        "msize" to miniSize(c),
        "freeform" to freeformSupported(c)
    )

    // ---------- ফায়ারওয়াল কন্ট্রোল (মূল কনফিগে) ----------

    private fun arr(j: JSONObject, k: String): List<String> {
        val a = j.optJSONArray(k) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it) }
    }

    fun isBlocked(c: Context, pkg: String): Boolean {
        val j = Store.load(c)
        if (j.optString("mode") == "whitelist") return !arr(j, "allowed").contains(pkg)
        val r = j.optJSONObject("rules")?.optJSONObject(pkg) ?: return false
        return r.optBoolean("wifi") || r.optBoolean("mobile")
    }

    fun setBlocked(c: Context, pkg: String, on: Boolean) {
        Store.edit(c) { j ->
            if (j.optString("mode") == "whitelist") {
                val l = arr(j, "allowed").filter { it != pkg }.toMutableList()
                if (!on) l.add(pkg)
                j.put("allowed", JSONArray(l))
            } else {
                val r = j.optJSONObject("rules") ?: JSONObject().also { j.put("rules", it) }
                if (on) r.put(pkg, JSONObject().put("wifi", true).put("mobile", true)) else r.remove(pkg)
            }
        }
        FirewallVpnService.reload(c)
    }

    fun isLocked(c: Context, pkg: String): Boolean = arr(Store.load(c), "lockedApps").contains(pkg)

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        Store.edit(c) { j ->
            val l = arr(j, "lockedApps").filter { it != pkg }.toMutableList()
            if (on) l.add(pkg)
            j.put("lockedApps", JSONArray(l))
        }
    }

    /**
     * বাবল থেকে শুধু কড়া দিকে (ব্লক, লক) যাওয়া যায়। ঢিলে করা (নেট চালু, আনলক) তখনই, যখন পিন সেট নেই,
     * ফোকাস চলছে না আর ট্রেড লক নেই। নইলে বাবল দিয়ে পিন এড়ানো যেত।
     */
    fun canRelax(c: Context): Boolean =
        Store.load(c).optString("pinHash").isEmpty() && !Store.focusActive(c) && Ctl.tradeLockLeftMs(c) <= 0L

    /** আজ মাঝরাত থেকে এ অ্যাপের মোট ডেটা (মোবাইল + Wi-Fi), বাইটে। না পেলে -1 */
    fun todayBytes(c: Context, pkg: String): Long = try {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        UsageUtil.dataSince(c, cal.timeInMillis, true, true).apps[pkg] ?: 0L
    } catch (e: Exception) {
        -1L
    }
}

class BubbleService : Service() {
    companion object {
        @Volatile var running = false
        private const val CH = "fw_bubble"
        private const val ID = 7411
        private const val ACT_STOP = "com.you.firewall.BUBBLE_STOP"
    }

    private lateinit var wm: WindowManager
    private val bubbles = LinkedHashMap<String, View>()
    private var menu: View? = null
    private val ui = Handler(Looper.getMainLooper())
    private var density = 1f

    private fun dp(v: Int) = (v * density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACT_STOP) {
            Bubbles.stop(this)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Bubbles.canDraw(this)) {
            Bubbles.stop(this)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        sync()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        closeMenu()
        for (v in bubbles.values) try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
        bubbles.clear()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "ফ্লোটিং বাবল", NotificationManager.IMPORTANCE_MIN))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("route", "bubble"),
            flags
        )
        val stop = PendingIntent.getService(this, 2, Intent(this, BubbleService::class.java).setAction(ACT_STOP), flags)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val n = b.setContentTitle("ফ্লোটিং বাবল চালু")
            .setContentText("বন্ধ করতে নিচের বাটন চাপুন")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "বন্ধ করুন", stop).build())
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, 0x40000000) else startForeground(ID, n)
        } catch (e: Exception) {
        }
    }

    /** তালিকা অনুযায়ী বাবল যোগ/বাদ */
    private fun sync() {
        val want = Bubbles.pkgs(this).filter {
            try {
                packageManager.getPackageInfo(it, 0)
                true
            } catch (e: Exception) {
                false
            }
        }
        for (p in bubbles.keys.toList()) if (p !in want) {
            try {
                wm.removeView(bubbles[p])
            } catch (e: Exception) {
            }
            bubbles.remove(p)
        }
        want.forEachIndexed { i, p -> if (!bubbles.containsKey(p)) addBubble(p, i) }
        if (want.isEmpty()) {
            Bubbles.stop(this)
            stopSelf()
        }
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble(pkg: String, index: Int) {
        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = screenW() - size
        lp.y = Bubbles.y(this, pkg, dp(150) + index * dp(62)).coerceIn(0, screenH() - size)

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFFFFFFFF.toInt())
            setStroke(dp(2), 0x33000000)
        }
        val iv = ImageView(this)
        try {
            iv.setImageDrawable(packageManager.getApplicationIcon(pkg))
        } catch (e: Exception) {
        }
        val box = FrameLayout(this)
        box.background = ring
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        box.elevation = dp(6).toFloat()
        box.addView(iv, FrameLayout.LayoutParams(-1, -1))

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longDone = false
        val longRun = Runnable {
            longDone = true
            showMenu(pkg, lp, size)
        }
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    closeMenu()
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    longDone = false
                    ui.postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (dx * dx + dy * dy) > slop * slop) {
                        moved = true
                        ui.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, screenW() - size)
                        lp.y = (startY + dy).toInt().coerceIn(0, screenH() - size)
                        try {
                            wm.updateViewLayout(box, lp)
                        } catch (ex: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longRun)
                    if (moved) {
                        snap(box, lp, size)
                        Bubbles.saveY(this, pkg, lp.y)
                    } else if (!longDone && e.action == MotionEvent.ACTION_UP) {
                        if (Bubbles.mini(this)) launchMini(pkg) else launch(pkg)
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(box, lp)
            bubbles[pkg] = box
        } catch (e: Exception) {
        }
    }

    /** ছাড়লে কাছের কিনারায় লেগে যায় */
    private fun snap(v: View, lp: WindowManager.LayoutParams, size: Int) {
        val target = if (lp.x + size / 2 < screenW() / 2) 0 else screenW() - size
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 160
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            try {
                wm.updateViewLayout(v, lp)
            } catch (e: Exception) {
            }
        }
        a.start()
    }

    private fun launch(pkg: String) {
        try {
            val li = packageManager.getLaunchIntentForPackage(pkg)
            if (li == null) {
                toast("অ্যাপ খোলা গেল না")
            } else {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(li)
            }
        } catch (e: Exception) {
            toast("অ্যাপ খোলা গেল না")
        }
    }

    /**
     * ছোট উইন্ডোতে খোলা। ফোন ফ্রিফর্ম না পারলে সাধারণভাবে ফুলস্ক্রিনে খোলে আর কারণ জানায়।
     * পারলেও কিছু অ্যাপ (ব্যাংক, গেম, ক্যামেরা) ছোট হতে চায় না, তারা ফুলস্ক্রিনেই খুলবে।
     */
    private fun launchMini(pkg: String) {
        if (!Bubbles.freeformSupported(this)) {
            toast("এই ফোনে ছোট উইন্ডো চালু নেই, ফুলস্ক্রিনে খুলছে")
            launch(pkg)
            return
        }
        try {
            val li = packageManager.getLaunchIntentForPackage(pkg)
            if (li == null) {
                toast("অ্যাপ খোলা গেল না")
                return
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val w = screenW()
            val h = screenH()
            val f = when (Bubbles.miniSize(this)) {
                0 -> floatArrayOf(0.60f, 0.40f)
                2 -> floatArrayOf(0.95f, 0.75f)
                else -> floatArrayOf(0.80f, 0.55f)
            }
            val bw = (w * f[0]).toInt()
            val bh = (h * f[1]).toInt()
            val left = (w - bw) / 2
            val top = (h * 0.10f).toInt()
            val o = ActivityOptions.makeBasic()
            o.setLaunchBounds(Rect(left, top, left + bw, top + bh))
            try {
                // লুকানো API: কিছু ফোনে কাজ করে, না করলে চুপচাপ বাদ (5 = ফ্রিফর্ম)
                ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Integer.TYPE).invoke(o, 5)
            } catch (e: Throwable) {
            }
            startActivity(li, o.toBundle())
        } catch (e: Exception) {
            toast("ছোট উইন্ডোতে খোলা গেল না")
            launch(pkg)
        }
    }

    private fun toast(m: String) {
        try {
            Toast.makeText(this, m, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
        }
    }

    // ---------------- লং-প্রেস মেনু ----------------

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun fmt(b: Long): String = when {
        b < 0 -> "পাওয়া যায়নি"
        b < 1024L * 1024 -> "${b / 1024} KB"
        b < 1024L * 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
        else -> String.format("%.2f GB", b / 1073741824.0)
    }

    private fun btn(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 15f
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(0xFF2E2E2E.toInt())
        t.background = bg
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun showMenu(pkg: String, bl: WindowManager.LayoutParams, bsize: Int) {
        closeMenu()
        val blocked = Bubbles.isBlocked(this, pkg)
        val locked = Bubbles.isLocked(this, pkg)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(14), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(0xFF1B1B1B.toInt())
        card.background = bg
        card.elevation = dp(10).toFloat()

        val title = TextView(this)
        title.text = label(pkg)
        title.textSize = 17f
        title.setTextColor(0xFFFFFFFF.toInt())
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        card.addView(title)

        val usage = TextView(this)
        usage.text = "আজ ডেটা: হিসাব হচ্ছে…"
        usage.textSize = 13f
        usage.setTextColor(0xFFB0B0B0.toInt())
        card.addView(usage)

        if (blocked && !FirewallVpnService.running) {
            val w = TextView(this)
            w.text = "ফায়ারওয়াল বন্ধ আছে, তাই ব্লক কাজ করছে না"
            w.textSize = 12f
            w.setTextColor(0xFFFFB74D.toInt())
            card.addView(w)
        }

        card.addView(btn(if (blocked) "✅ নেট চালু করো" else "🚫 নেট বন্ধ করো") {
            if (blocked && !Bubbles.canRelax(this)) {
                toast("পিন বা ফোকাস চালু আছে। নেট চালু করতে অ্যাপ খুলে পিন দিন")
            } else {
                Bubbles.setBlocked(this, pkg, !blocked)
                var m = if (blocked) "নেট চালু হলো" else "নেট বন্ধ হলো"
                if (!blocked && !FirewallVpnService.running) m += " (কিন্তু ফায়ারওয়াল বন্ধ, আগে চালু করুন)"
                toast(m)
            }
            closeMenu()
        })
        card.addView(btn(if (locked) "🔓 লক খোলো" else "🔒 অ্যাপ লক করো") {
            if (locked && !Bubbles.canRelax(this)) {
                toast("পিন বা ফোকাস চালু আছে। লক খুলতে অ্যাপ খুলে পিন দিন")
            } else {
                Bubbles.setLocked(this, pkg, !locked)
                toast(if (locked) "লক খোলা হলো" else "অ্যাপ লক হলো")
            }
            closeMenu()
        })
        card.addView(btn("🪟 ছোট উইন্ডোতে খোলো") {
            closeMenu()
            launchMini(pkg)
        })
        card.addView(btn("✕ বাবল সরাও") {
            Bubbles.setPkgs(this, Bubbles.pkgs(this).filter { it != pkg })
            closeMenu()
            sync()
        })

        val w = dp(240)
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val left = bl.x + bsize / 2 < screenW() / 2
        lp.x = if (left) bl.x + bsize + dp(8) else bl.x - w - dp(8)
        lp.x = lp.x.coerceIn(0, screenW() - w)
        lp.y = bl.y.coerceIn(0, (screenH() - dp(320)).coerceAtLeast(0))

        card.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) {
                closeMenu()
                true
            } else false
        }
        try {
            wm.addView(card, lp)
            menu = card
        } catch (e: Exception) {
            return
        }

        Thread {
            val b = Bubbles.todayBytes(this, pkg)
            ui.post {
                if (menu === card) {
                    usage.text = if (b < 0) "আজ ডেটা: ইউসেজ অ্যাক্সেস দিন" else "আজ ডেটা: ${fmt(b)} (মোবাইল + Wi-Fi)"
                }
            }
        }.start()
    }

    private fun closeMenu() {
        val m = menu ?: return
        menu = null
        try {
            wm.removeView(m)
        } catch (e: Exception) {
        }
    }
}
