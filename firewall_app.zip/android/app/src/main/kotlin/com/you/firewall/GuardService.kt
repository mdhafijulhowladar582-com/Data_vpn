package com.you.firewall

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import org.json.JSONObject

/**
 * অ্যাপ গার্ড: কোন অ্যাপ সামনে এল সেটা ধরে।
 *  1. ফোকাসে নিষিদ্ধ বা দৈনিক সময়সীমা শেষ অ্যাপ হলে "সময় শেষ" স্ক্রিন (BlockActivity) দেখিয়ে হোমে পাঠায়।
 *  2. লক করা অ্যাপ হলে LockActivity (পিন/ফিঙ্গারপ্রিন্ট) খোলে।
 * VPN-ভিত্তিক ইন্টারনেট ব্লক আলাদাভাবে আগের মতোই চলে; দুটো একসাথে কাজ করে।
 * পিন সেট না থাকলে অ্যাপ লক হয় না (বের হওয়ার পথ থাকবে না)।
 */
class GuardService : AccessibilityService() {

    companion object {
        @Volatile var connected = false
        @Volatile var unlockedPkg: String? = null

        fun unlock(pkg: String) {
            unlockedPkg = pkg
        }

        private val skipPkgs = setOf("android", "com.android.systemui")
        private val phoneish = setOf("com.android.phone", "com.android.server.telecom", "com.android.incallui")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var registered = false

    @Volatile private var fgPkg: String? = null
    @Volatile private var usage: Map<String, Long> = emptyMap()
    @Volatile private var usageAt = 0L
    @Volatile private var usageBusy = false

    private var sys: Set<String> = emptySet() // হোম লঞ্চার, ডায়ালার (কখনো ব্লক হয় না)
    private var ime: Set<String> = emptySet()
    private var sysAt = 0L

    private var lastPkg = ""
    private var lastAt = 0L
    private var lastBlockPkg = ""
    private var lastBlockAt = 0L

    private val screenR = ScreenReceiver { on ->
        if (!on) {
            unlockedPkg = null
            fgPkg = null
        }
    }

    private val watch = object : Runnable {
        override fun run() {
            recheck()
            handler.postDelayed(this, 10000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        if (!registered) {
            registered = true
            registerReceiver(
                screenR,
                IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) }
            )
        }
        handler.removeCallbacks(watch)
        handler.postDelayed(watch, 10000)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAll()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun stopAll() {
        connected = false
        unlockedPkg = null
        fgPkg = null
        handler.removeCallbacksAndMessages(null)
        if (registered) {
            registered = false
            try { unregisterReceiver(screenR) } catch (e: Exception) {}
        }
    }

    override fun onInterrupt() {}

    // ---------------- সিস্টেম প্যাকেজ ----------------

    private fun refreshSys() {
        val now = System.currentTimeMillis()
        if (now - sysAt < 60000 && sys.isNotEmpty()) return
        sysAt = now
        val s = HashSet<String>(phoneish)
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in packageManager.queryIntentActivities(i, 0)) s.add(r.activityInfo.packageName)
        } catch (e: Exception) {
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val tm = getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
                val d = tm.defaultDialerPackage
                if (d != null) s.add(d)
            } catch (e: Exception) {
            }
        }
        sys = s
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            ime = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
        }
    }

    // ---------------- সিদ্ধান্ত ----------------

    private fun isLocked(cfg: JSONObject, pkg: String): Boolean {
        if (cfg.optString("pinHash").isEmpty()) return false
        val a = cfg.optJSONArray("lockedApps") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    /** "focus" = ফোকাসে নিষিদ্ধ, "limit" = দৈনিক সময়সীমা শেষ, null = ঠিক আছে */
    private fun blockReason(pkg: String, cfg: JSONObject): String? {
        if (cfg.optLong("focusUntil", 0L) > System.currentTimeMillis()) {
            val a = cfg.optJSONArray("focusAllowed")
            var ok = false
            if (a != null) {
                for (i in 0 until a.length()) {
                    if (a.optString(i) == pkg) {
                        ok = true
                        break
                    }
                }
            }
            if (!ok) return "focus"
        }
        val m = cfg.optJSONObject("limits")?.optInt(pkg, 0) ?: 0
        if (m > 0 && (usage[pkg] ?: 0L) >= m * 60000L) return "limit"
        return null
    }

    private fun hasLimit(cfg: JSONObject, pkg: String): Boolean =
        (cfg.optJSONObject("limits")?.optInt(pkg, 0) ?: 0) > 0

    /** আজকের ব্যবহার ব্যাকগ্রাউন্ডে নতুন করে গোনা; শেষে সামনের অ্যাপ আবার যাচাই */
    private fun refreshUsage() {
        if (usageBusy) return
        usageBusy = true
        Thread {
            try {
                val m = HashMap<String, Long>()
                for ((k, v) in UsageUtil.compute(this, 1, 0, 0).apps) m[k] = v[0]
                usage = m
                usageAt = System.currentTimeMillis()
                handler.post { recheck(false) }
            } catch (e: Exception) {
            } finally {
                usageBusy = false
            }
        }.start()
    }

    private fun maybeRefresh(pkg: String, cfg: JSONObject) {
        if (hasLimit(cfg, pkg) && System.currentTimeMillis() - usageAt > 8000) refreshUsage()
    }

    /** সামনের অ্যাপ এখনো ঠিক আছে কিনা (সময় শেষ হলো বা ফোকাস শুরু হলো) */
    private fun recheck(refresh: Boolean = true) {
        val p = fgPkg ?: return
        val cfg = Store.load(this)
        if (refresh) maybeRefresh(p, cfg)
        val r = blockReason(p, cfg) ?: return
        unlockedPkg = null
        block(p, r)
    }

    private fun block(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastBlockPkg && now - lastBlockAt < 1500) return
        lastBlockPkg = pkg
        lastBlockAt = now
        try {
            startActivity(
                Intent(this, BlockActivity::class.java)
                    .putExtra("pkg", pkg)
                    .putExtra("reason", reason)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
            )
        } catch (ex: Exception) {
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg in skipPkgs) return // নিজের লক/ব্লক স্ক্রিন, নোটিফিকেশন শেড
        refreshSys()
        if (pkg in ime) return
        if (pkg in sys) { // হোম বা ডায়ালারে গেলে আগের অ্যাপ ছাড়া হলো
            fgPkg = null
            unlockedPkg = null
            return
        }
        fgPkg = pkg
        val cfg = Store.load(this)

        val reason = blockReason(pkg, cfg)
        if (reason != null) {
            unlockedPkg = null
            block(pkg, reason)
            return
        }
        maybeRefresh(pkg, cfg)

        if (pkg == unlockedPkg) return
        unlockedPkg = null // অন্য অ্যাপে গেলে আগের আনলক শেষ
        if (!isLocked(cfg, pkg)) return
        val now = System.currentTimeMillis()
        if (pkg == lastPkg && now - lastAt < 700) return
        lastPkg = pkg
        lastAt = now
        try {
            startActivity(
                Intent(this, LockActivity::class.java)
                    .putExtra("pkg", pkg)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
            )
        } catch (ex: Exception) {
        }
    }
}
