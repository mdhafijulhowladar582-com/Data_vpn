package com.you.firewall

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import org.json.JSONObject

/**
 * অ্যাপ গার্ড: কোন অ্যাপ সামনে এল সেটা ধরে।
 *  1. ফোকাসে নিষিদ্ধ বা দৈনিক সময়সীমা শেষ অ্যাপ হলে "সময় শেষ" স্ক্রিন (BlockActivity) দেখিয়ে হোমে পাঠায়।
 *  2. লক করা অ্যাপ হলে LockActivity (পিন/ফিঙ্গারপ্রিন্ট) খোলে।
 * VPN-ভিত্তিক ইন্টারনেট ব্লক আলাদাভাবে আগের মতোই চলে; দুটো একসাথে কাজ করে।
 * পিন সেট না থাকলে অ্যাপ লক হয় না (বের হওয়ার পথ থাকবে না)।
 */
class GuardService : AccessibilityService() {

    companion object {
        @Volatile var connected = false
        @Volatile var unlockedPkg: String? = null
        @Volatile var fgNow: String? = null // এখন সামনে কোন অ্যাপ (ব্যাকগ্রাউন্ড ব্লকের জন্য)

        fun unlock(pkg: String) {
            unlockedPkg = pkg
        }

        // পারমিশন ডায়ালগ খুললে আনলক মুছে বারবার PIN চাইত, তাই এগুলোও বাদ
        private val skipPkgs = setOf(
            "android", "com.android.systemui",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller"
        )
        private val phoneish = setOf("com.android.phone", "com.android.server.telecom", "com.android.incallui")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var registered = false

    @Volatile private var fgPkg: String? = null
        set(v) {
            val old = field
            field = v
            fgNow = v
            if (old != v) bgChanged(old, v)
        }

    /** ব্যাকগ্রাউন্ড-ব্লক তালিকার কোনো অ্যাপ সামনে এলে বা গেলে ফায়ারওয়াল নিয়ম নতুন করে বসে */
    private fun bgChanged(a: String?, b: String?) {
        if (CoolMode.active) { // ঠান্ডা মোডে সামনের অ্যাপ বদলালে নিয়ম নতুন করে বসে
            FirewallVpnService.reload(this)
            return
        }
        val arr = Store.load(this).optJSONArray("bgBlock") ?: return
        for (i in 0 until arr.length()) {
            val p = arr.optString(i)
            if (p == a || p == b) {
                FirewallVpnService.reload(this)
                return
            }
        }
    }
    @Volatile private var usage: Map<String, Long> = emptyMap()
    @Volatile private var usageAt = 0L
    @Volatile private var usageBusy = false

    private var sys: Set<String> = emptySet() // হোম লঞ্চার, ডায়ালার (কখনো ব্লক হয় না)
    private var ime: Set<String> = emptySet()
    private var sysAt = 0L

    private var lastPkg = ""
    private var lastAt = 0L
    private var lastBlockPkg = ""
    private var lastBlockAt = 0L

    private val screenR = ScreenReceiver { on ->
        if (!on) {
            unlockedPkg = null
            fgPkg = null
        }
    }

    private val watch = object : Runnable {
        override fun run() {
            recheck()
            handler.postDelayed(this, 10000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        FirewallVpnService.reload(this)
        if (!registered) {
            registered = true
            registerReceiver(
                screenR,
                IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) }
            )
        }
        handler.removeCallbacks(watch)
        handler.postDelayed(watch, 10000)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAll()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun stopAll() {
        hideCover()
        connected = false
        FirewallVpnService.reload(this)
        unlockedPkg = null
        fgPkg = null
        handler.removeCallbacksAndMessages(null)
        if (registered) {
            registered = false
            try { unregisterReceiver(screenR) } catch (e: Exception) {}
        }
    }

    override fun onInterrupt() {}

    // ---------------- লক-স্ক্রিন আসার আগে ঢাকনা ----------------
    // TYPE_ACCESSIBILITY_OVERLAY অ্যাক্সেসিবিলিটি সার্ভিসের নিজের অধিকার, আলাদা পারমিশন লাগে না।
    // কোনো কারণে না বসলে আগের মতোই (ঢাকনা ছাড়া) লক-স্ক্রিন খোলে।

    private var cover: View? = null
    private var coverPkg: String? = null
    private val hideCoverRun = Runnable { hideCover() }

    private fun showCover(pkg: String) {
        if (cover != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(this)
            v.setBackgroundColor(Color.parseColor("#0F172A"))
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            wm.addView(v, lp)
            cover = v
            coverPkg = pkg
            // LockActivity না এলেও আটকে থাকবে না
            handler.removeCallbacks(hideCoverRun)
            handler.postDelayed(hideCoverRun, 1500)
        } catch (e: Exception) {
            cover = null
            coverPkg = null
        }
    }

    private fun hideCover() {
        handler.removeCallbacks(hideCoverRun)
        val v = cover ?: return
        cover = null
        coverPkg = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }

    // ---------------- সিস্টেম প্যাকেজ ----------------

    private fun refreshSys() {
        val now = System.currentTimeMillis()
        if (now - sysAt < 60000 && sys.isNotEmpty()) return
        sysAt = now
        val s = HashSet<String>(phoneish)
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in packageManager.queryIntentActivities(i, 0)) s.add(r.activityInfo.packageName)
        } catch (e: Exception) {
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val tm = getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
                val d = tm.defaultDialerPackage
                if (d != null) s.add(d)
            } catch (e: Exception) {
            }
        }
        sys = s
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            ime = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
        }
    }

    // ---------------- সিদ্ধান্ত ----------------

    private fun isLocked(cfg: JSONObject, pkg: String): Boolean {
        if (cfg.optString("pinHash").isEmpty()) return false
        // গেস্ট মোডে বেছে দেওয়া অ্যাপ ছাড়া সব লক
        if (Guest.isOn(this) && !Guest.allowed(cfg, pkg)) return true
        val a = cfg.optJSONArray("lockedApps") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == pkg) return true
        return false
    }

    /** "focus" = ফোকাসে নিষিদ্ধ, "limit" = দৈনিক সময়সীমা শেষ, null = ঠিক আছে */
    private fun blockReason(pkg: String, cfg: JSONObject): String? {
        if (Store.focusActive(this)) {
            val a = cfg.optJSONArray("focusAllowed")
            var ok = false
            if (a != null) {
                for (i in 0 until a.length()) {
                    if (a.optString(i) == pkg) {
                        ok = true
                        break
                    }
                }
            }
            if (!ok) return "focus"
        }
        val m = cfg.optJSONObject("limits")?.optInt(pkg, 0) ?: 0
        if (m > 0 && (usage[pkg] ?: 0L) >= m * 60000L) return "limit"
        // ধাপ ৪: ট্রেড ব্লকার ও প্যারেন্টাল (ভুল হলেও পুরনো যাচাই থামে না)
        try {
            if (Ctl.tradeBlocked(this, pkg)) return "trade"
            val pr = Ctl.parentalReason(this, pkg, usage[pkg] ?: 0L)
            if (pr != null) return pr
            val tt = TradeTime.reason(this, pkg)
            if (tt != null) return tt
        } catch (e: Exception) {
        }
        return null
    }

    private fun hasLimit(cfg: JSONObject, pkg: String): Boolean =
        (cfg.optJSONObject("limits")?.optInt(pkg, 0) ?: 0) > 0 ||
            (try { Ctl.parentalHas(this, pkg) } catch (e: Exception) { false })

    /** আজকের ব্যবহার ব্যাকগ্রাউন্ডে নতুন করে গোনা; শেষে সামনের অ্যাপ আবার যাচাই */
    private fun refreshUsage() {
        if (usageBusy) return
        usageBusy = true
        Thread {
            try {
                val m = HashMap<String, Long>()
                for ((k, v) in UsageUtil.compute(this, 1, 0, 0).apps) m[k] = v[0]
                usage = m
                usageAt = System.currentTimeMillis()
                handler.post { recheck(false) }
            } catch (e: Exception) {
            } finally {
                usageBusy = false
            }
        }.start()
    }

    private fun maybeRefresh(pkg: String, cfg: JSONObject) {
        if (hasLimit(cfg, pkg) && System.currentTimeMillis() - usageAt > 8000) refreshUsage()
    }

    /** সামনের অ্যাপ এখনো ঠিক আছে কিনা (সময় শেষ হলো বা ফোকাস শুরু হলো) */
    private fun recheck(refresh: Boolean = true) {
        val p = fgPkg ?: return
        val cfg = Store.load(this)
        if (refresh) maybeRefresh(p, cfg)
        val r = blockReason(p, cfg) ?: return
        unlockedPkg = null
        block(p, r)
    }

    private fun block(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastBlockPkg && now - lastBlockAt < 1500) return
        lastBlockPkg = pkg
        lastBlockAt = now
        try {
            startActivity(
                Intent(this, BlockActivity::class.java)
                    .putExtra("pkg", pkg)
                    .putExtra("reason", reason)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
            )
        } catch (ex: Exception) {
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) {
            // নিজের মূল স্ক্রিনে (MainActivity) গেলে আগের আনলক শেষ। লক/ব্লক স্ক্রিন নিজে বাদ
            val cn = e.className?.toString() ?: ""
            if (cn.endsWith(".MainActivity")) unlockedPkg = null
            if (cn.endsWith(".LockActivity")) hideCover() // লক-স্ক্রিন এসে গেছে, ঢাকনা সরাই
            return
        }
        if (pkg in skipPkgs) return // নোটিফিকেশন শেড, পারমিশন ডায়ালগ
        if (cover != null && pkg != coverPkg) hideCover() // অন্য অ্যাপে গেলে ঢাকনা সরাই
        refreshSys()
        if (pkg in ime) return
        if (pkg in sys) { // হোম বা ডায়ালারে গেলে আগের অ্যাপ ছাড়া হলো
            fgPkg = null
            unlockedPkg = null
            return
        }
        val wasFg = fgPkg
        fgPkg = pkg
        if (wasFg != pkg) try { Ctl.tradeOpened(this, pkg) } catch (ex: Exception) {} // ধাপ ৪: ট্রেড অ্যাপ খোলার গণনা
        val cfg = Store.load(this)

        val reason = blockReason(pkg, cfg)
        if (reason != null) {
            unlockedPkg = null
            block(pkg, reason)
            return
        }
        maybeRefresh(pkg, cfg)
        try { NetNotice.maybe(applicationContext, pkg) } catch (ex: Exception) {}

        if (pkg == unlockedPkg) return
        unlockedPkg = null // অন্য অ্যাপে গেলে আগের আনলক শেষ
        if (!isLocked(cfg, pkg)) return
        val now = System.currentTimeMillis()
        if (pkg == lastPkg && now - lastAt < 700) return
        lastPkg = pkg
        lastAt = now
        showCover(pkg)
        try {
            startActivity(
                Intent(this, LockActivity::class.java)
                    .putExtra("pkg", pkg)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    )
            )
        } catch (ex: Exception) {
            hideCover()
        }
    }
}
