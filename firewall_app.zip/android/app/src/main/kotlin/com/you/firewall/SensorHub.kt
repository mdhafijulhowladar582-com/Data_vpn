package com.you.firewall

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.VpnService
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * সেন্সর-পোষা: ফোনের সেন্সর শুনে পোষা প্রাণীকে নাড়ায়। সবই কোনো পারমিশন ছাড়া (সারাংশে ডেটা দেখাতে শুধু Usage access লাগে):
 *  - উল্টো রাখলে ফোকাস: স্ক্রিন নিচে করে টেবিলে রাখলে ফোকাস মোড চালু, তুললে বন্ধ (শুধু নিজে চালানোটা)
 *  - ঝাঁকালে পোষা খুশিতে লাফায়
 *  - অন্ধকারে পোষা ঘুমায়, আলো এলে জাগে; লম্বা অন্ধকার সময় রাতের ঘুম হিসেবে জমা হয় ([SleepLog])
 *  - তুললে সারাংশ: ফোন ৫ মিনিটের বেশি উল্টো থাকলে বা ঘুম শেষ হলে, ওই সময়ে কত ডেটা গেল তা একটা টোস্টে দেখায়
 * পোষার মুখ বদলানোর কাজ [PetService]-এ। এখানে শুধু সেন্সর পড়া আর সিদ্ধান্ত।
 */
object SensorHub {
    const val M_NONE = 0
    const val M_SLEEP = 1
    const val M_JOY = 2
}

class SenseService : Service(), SensorEventListener {
    companion object {
        @Volatile
        var running = false

        /** এখন অন্ধকার ধরা আছে কিনা (PetService চালু হলে এটা দেখে ঘুমিয়ে শুরু করে) */
        @Volatile
        var dark = false

        /** ফোন এখন উল্টো রাখা কিনা */
        @Volatile
        var flipped = false
        private const val ID = 7424
        private const val FLIP_HOLD_MS = 2500L
        private const val DARK_HOLD_MS = 8000L
        private const val DARK_LUX = 4f
        private const val LIGHT_LUX = 25f
        private const val SHAKE_G = 2.6f
        private const val SHAKE_GAP_MS = 1500L

        /** উল্টো রাখা এর চেয়ে কম সময় হলে সারাংশ দেখাই না */
        private const val SUMMARY_MIN_MS = 5L * 60_000L
    }

    private lateinit var sm: SensorManager
    private val ui = Handler(Looper.getMainLooper())
    private var registered = false
    private var screenRegistered = false
    private var lightSensor: Sensor? = null

    private var downSince = 0L
    private var lastShake = 0L
    private var focusByUs = false
    private var darkPending = false

    // উল্টো রাখার শুরুর দেয়ালঘড়ির সময় (ডেটা সারাংশের জন্য)
    private var flipAtWall = 0L

    // ঘুমের হিসাব: sleepStart = অন্ধকার শুরু (০ = চলছে না), sleepBright = আলো আসার সময় (০ = এখনো অন্ধকার)
    private var sleepStart = 0L
    private var sleepBright = 0L

    private val screenR = ScreenReceiver { on -> onScreen(on) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Buddy.foreground(this, ID, "fw_sense", "সেন্সর-পোষা", "সেন্সর-পোষা চালু", "বন্ধ করতে অ্যাপের নতুন সার্ভিস পেজে সুইচ বন্ধ করুন", "buddy")
        if (!Buddy.canDraw(this) || !Buddy.on(this, "sense")) {
            Buddy.putOff(this, "sense")
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (!registered) {
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val light = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
            lightSensor = light
            try {
                if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI)
                if (light != null) sm.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL)
                registered = true
            } catch (e: Exception) {
            }
        }
        if (!screenRegistered) {
            try {
                registerReceiver(
                    screenR,
                    IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) }
                )
                screenRegistered = true
            } catch (e: Exception) {
            }
            // আগের বার অসমাপ্ত থাকা ঘুমের হিসাব ফিরিয়ে আনা; পরের আলোর খবরেই ঠিক হয়ে যাবে
            sleepStart = Buddy.long(this, "sleepStart", 0L)
            sleepBright = Buddy.long(this, "sleepBright", 0L)
            if (sleepStart != 0L && sleepBright != 0L) {
                ui.removeCallbacks(sleepR)
                ui.postDelayed(sleepR, 5000L)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        if (registered) {
            try {
                sm.unregisterListener(this)
            } catch (e: Exception) {
            }
            registered = false
        }
        if (screenRegistered) {
            try {
                unregisterReceiver(screenR)
            } catch (e: Exception) {
            }
            screenRegistered = false
        }
        ui.removeCallbacksAndMessages(null)
        darkPending = false
        dark = false
        flipped = false
        PetService.inst?.setBase(SensorHub.M_NONE)
        super.onDestroy()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> onAccel(e.values[0], e.values[1], e.values[2])
            Sensor.TYPE_LIGHT -> onLight(e.values[0], wallOf(e))
        }
    }

    /**
     * সেন্সরের ইভেন্ট ফোন ঘুমন্ত থাকলে দেরিতে পৌঁছাতে পারে। তাই ইভেন্টের নিজের টাইমস্ট্যাম্প থেকে আসল সময় বের করি।
     * টাইমস্ট্যাম্প অস্বাভাবিক হলে (উল্টো বা ১২ ঘণ্টার বেশি পুরনো) এখনকার সময় ধরি।
     */
    private fun wallOf(e: SensorEvent): Long {
        val ageMs = (SystemClock.elapsedRealtimeNanos() - e.timestamp) / 1_000_000L
        val a = if (ageMs < 0L || ageMs > 12L * 3600_000L) 0L else ageMs
        return System.currentTimeMillis() - a
    }

    /** বার্তা ভেতরে তৈরি করে (পেছনের থ্রেডে, ডেটা হিসাবে সময় লাগে), তারপর টোস্ট দেখানো */
    private fun toastAsync(build: () -> String?) {
        val ctx = applicationContext
        Thread {
            val msg = try {
                build()
            } catch (e: Exception) {
                null
            }
            if (msg != null) {
                ui.post {
                    try {
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                    }
                }
            }
        }.start()
    }

    // ---------------- স্ক্রিন জ্বললে/নিভলে ----------------

    private fun onScreen(on: Boolean) {
        if (on) {
            // রাতে ফোন চালালে সেটা ঘুমের মাঝে আলোর বাধা। ২০ মিনিটের মধ্যে আবার অন্ধকার হলে ঘুম জোড়া লাগবে
            if (sleepStart != 0L && sleepBright == 0L && Buddy.bool(this, "senseDark", true)) {
                sleepBright = System.currentTimeMillis()
                saveSleepState()
                ui.removeCallbacks(sleepR)
                ui.postDelayed(sleepR, SleepLog.GAP_MS + 5000L)
            }
        } else {
            // আলোর সেন্সর শুধু মান বদলালে খবর দেয়। নিভে যাওয়ার পর নতুন মান পেতে সেন্সরটা আবার চালু করি
            ui.postDelayed({ refreshLight() }, 1500L)
        }
    }

    private fun refreshLight() {
        val l = lightSensor ?: return
        if (!registered) return
        try {
            sm.unregisterListener(this, l)
            sm.registerListener(this, l, SensorManager.SENSOR_DELAY_NORMAL)
        } catch (e: Exception) {
        }
    }

    // ---------------- ঝাঁকুনি আর উল্টো রাখা ----------------

    private fun onAccel(x: Float, y: Float, z: Float) {
        val now = SystemClock.elapsedRealtime()

        // ঝাঁকুনি: মোট টান ২.৬ গুণ অভিকর্ষের বেশি হলে
        if (Buddy.bool(this, "senseShake", true)) {
            val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            if (g > SHAKE_G && now - lastShake > SHAKE_GAP_MS) {
                lastShake = now
                PetService.inst?.react(SensorHub.M_JOY, 3000L)
            }
        }

        // উল্টো রাখা: স্ক্রিন নিচে, ফোন প্রায় সমতল (z প্রায় -৯.৮)
        if (!Buddy.bool(this, "senseFlip", true)) {
            downSince = 0L
            if (flipped) stopFlip()
            return
        }
        val down = z < -8.3f && abs(x) < 2.5f && abs(y) < 2.5f
        if (down) {
            if (downSince == 0L) downSince = now
            else if (!flipped && now - downSince >= FLIP_HOLD_MS) startFlip(now)
        } else {
            downSince = 0L
            if (flipped && z > -6f) stopFlip()
        }
    }

    private fun startFlip(now: Long) {
        flipped = true
        focusByUs = false
        // উল্টো রাখার আসল শুরু: ২.৫ সেকেন্ড ধরে থাকার আগের মুহূর্ত
        flipAtWall = System.currentTimeMillis() - (now - downSince)
        // আগে থেকে ফোকাস চললে বা VPN-এর অনুমতি না থাকলে কিছু বদলাই না
        if (Store.focusActive(this)) return
        if (VpnService.prepare(this) != null) return
        val min = Buddy.int(this, "senseFlipMin", 25).coerceIn(1, 600)
        try {
            Store.startFocus(this, min)
            FirewallVpnService.start(this)
            focusByUs = true
            PetService.inst?.react(SensorHub.M_JOY, 2500L)
        } catch (e: Exception) {
        }
    }

    private fun stopFlip() {
        flipped = false
        if (focusByUs) {
            focusByUs = false
            // শুধু নিজে চালানো ফোকাসটাই বন্ধ করি, তার মধ্যে অন্যটা শুরু হয়ে থাকলে ছুঁই না
            if (Store.focusActive(this)) {
                try {
                    Store.endFocus(this)
                    FirewallVpnService.reload(this)
                    PetService.inst?.react(SensorHub.M_JOY, 2500L)
                } catch (e: Exception) {
                }
            }
        }
        // তুললে ডেটা সারাংশ: ৫ মিনিটের বেশি উল্টো থাকলে
        val from = flipAtWall
        flipAtWall = 0L
        if (from != 0L && Buddy.bool(this, "senseSummary", true)) {
            val ms = System.currentTimeMillis() - from
            if (ms >= SUMMARY_MIN_MS) {
                val ctx = applicationContext
                toastAsync {
                    val d = SleepLog.dataLine(ctx, from)
                    if (d == null) null
                    else "📱 ফোন উল্টো ছিল ${SleepLog.fmt((ms / 60_000L).toInt())}\n$d"
                }
            }
        }
    }

    // ---------------- অন্ধকার: পোষার ঘুম আর রাতের ঘুমের হিসাব ----------------

    private val darkR = Runnable {
        if (darkPending) {
            darkPending = false
            dark = true
            PetService.inst?.setBase(SensorHub.M_SLEEP)
        }
    }

    private fun clearDark() {
        darkPending = false
        ui.removeCallbacks(darkR)
        if (dark) {
            dark = false
            PetService.inst?.setBase(SensorHub.M_NONE)
        }
    }

    private fun saveSleepState() {
        Buddy.putLong(this, "sleepStart", sleepStart)
        Buddy.putLong(this, "sleepBright", sleepBright)
    }

    /** আলো আসার পর ২০ মিনিট কেটে গেলে ঘুম শেষ ধরে হিসাব জমানো */
    private val sleepR = Runnable {
        if (sleepStart != 0L && sleepBright != 0L &&
            System.currentTimeMillis() - sleepBright >= SleepLog.GAP_MS
        ) {
            finishSleep()
        }
    }

    private fun finishSleep() {
        val s = sleepStart
        val e = if (sleepBright != 0L) sleepBright else System.currentTimeMillis()
        sleepStart = 0L
        sleepBright = 0L
        saveSleepState()
        if (s == 0L) return
        val min = SleepLog.record(this, s, e)
        if (min > 0 && Buddy.bool(this, "senseSummary", true)) {
            val ctx = applicationContext
            toastAsync {
                val d = SleepLog.dataLine(ctx, s)
                val head = "🌙 গত রাতে প্রায় ${SleepLog.fmt(min)} অন্ধকারে ছিল (আন্দাজ ঘুম)"
                if (d == null) head else "$head\n$d"
            }
        }
    }

    private fun trackSleep(lux: Float, t: Long) {
        if (lux <= DARK_LUX) {
            if (sleepStart == 0L) {
                sleepStart = t
                sleepBright = 0L
            } else if (sleepBright != 0L) {
                if (t - sleepBright <= SleepLog.GAP_MS) {
                    // অল্প সময়ের আলো, ঘুম চলছে
                    sleepBright = 0L
                } else {
                    // অনেকক্ষণ আলো ছিল, আগের ঘুম শেষ, নতুন অন্ধকার শুরু
                    finishSleep()
                    sleepStart = t
                    sleepBright = 0L
                }
            }
            saveSleepState()
        } else if (lux >= LIGHT_LUX) {
            if (sleepStart != 0L && sleepBright == 0L) {
                sleepBright = t
                saveSleepState()
                ui.removeCallbacks(sleepR)
                ui.postDelayed(sleepR, SleepLog.GAP_MS + 5000L)
            }
        }
    }

    private fun onLight(lux: Float, wall: Long) {
        if (!Buddy.bool(this, "senseDark", true)) {
            if (dark || darkPending) clearDark()
            return
        }
        trackSleep(lux, wall)
        if (lux <= DARK_LUX) {
            if (!dark && !darkPending) {
                darkPending = true
                ui.postDelayed(darkR, DARK_HOLD_MS)
            }
        } else if (lux >= LIGHT_LUX) {
            clearDark()
        }
    }
}
