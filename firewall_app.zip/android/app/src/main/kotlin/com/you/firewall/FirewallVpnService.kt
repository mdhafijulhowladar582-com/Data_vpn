package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import org.json.JSONObject
import java.io.FileInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Calendar

/** কনফিগ সেভ/লোড (Dart, boot, tile সবাই এখান থেকে পড়ে) */
object Store {
    fun prefs(c: Context) = c.getSharedPreferences("fw", Context.MODE_PRIVATE)

    fun load(c: Context): JSONObject = try {
        JSONObject(prefs(c).getString("cfg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun save(c: Context, j: JSONObject) {
        prefs(c).edit().putString("cfg", j.toString()).apply()
    }

    fun setEnabled(c: Context, v: Boolean) {
        val j = load(c)
        j.put("enabled", v)
        save(c, j)
    }
}

/**
 * ব্লক করার কৌশল: যে অ্যাপের ট্রাফিক VPN-এ ঢোকে, আমরা সেটা পড়ে ফেলে দিই (কোথাও পাঠাই না)।
 *  - ব্লকলিস্ট: শুধু ব্লক করা অ্যাপগুলো VPN-এ ঢোকে (addAllowedApplication)
 *  - হোয়াইটলিস্ট / সব ব্লক: সবাই ঢোকে, শুধু অনুমতিপ্রাপ্ত (এবং এই অ্যাপ) বাইরে (addDisallowedApplication)
 */
class FirewallVpnService : VpnService() {

    companion object {
        @Volatile var running = false
        @Volatile var blockedCount = 0
        val logs: MutableList<Map<String, Any>> =
            java.util.Collections.synchronizedList(ArrayList())

        private fun send(c: Context, action: String, fg: Boolean) {
            val i = Intent(c, FirewallVpnService::class.java).setAction(action)
            try {
                if (fg && Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
            }
        }

        fun start(c: Context) {
            Store.setEnabled(c, true)
            send(c, "START", true)
        }

        fun stop(c: Context) {
            Store.setEnabled(c, false)
            send(c, "STOP", false)
        }

        fun reload(c: Context) {
            if (running) send(c, "RELOAD", false)
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private val handler = Handler(Looper.getMainLooper())
    private var registered = false
    private var screenOn = true
    private var net = "unknown"
    private var lastSched = false
    private var lastKey = ""
    private var lastAt = 0L

    private val cm by lazy { getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    private val nm by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    private val screenR = ScreenReceiver { on ->
        screenOn = on
        if (Store.load(this).optBoolean("screenOffBlock")) handler.post { rebuild() }
    }

    private val pkgR = PackageReceiver { pkg -> handler.post { onNewPackage(pkg) } }

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = netChanged()
        override fun onLost(network: Network) = netChanged()
        override fun onCapabilitiesChanged(network: Network, c: NetworkCapabilities) = netChanged()
    }

    private val tick = object : Runnable {
        override fun run() {
            val s = inSchedule(Store.load(this@FirewallVpnService))
            if (s != lastSched) rebuild()
            nm.notify(1, notif("ব্লক চেষ্টা: $blockedCount"))
            handler.postDelayed(this, 30000)
        }
    }

    // ---------------- lifecycle ----------------

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null && !Store.load(this).optBoolean("enabled")) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == "STOP") {
            shutdown()
            return START_NOT_STICKY
        }
        goForeground()
        running = true
        setup()
        rebuild()
        return START_STICKY
    }

    override fun onRevoke() {
        Store.setEnabled(this, false)
        shutdown()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("fw", "Firewall", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = notif("চালু")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(1, n)
        }
    }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "fw")
        else Notification.Builder(this)
        return b.setContentTitle("Firewall চালু")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun setup() {
        if (registered) return
        registered = true
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        registerReceiver(
            screenR,
            IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) }
        )
        registerReceiver(
            pkgR,
            IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        )
        net = detectNet()
        try {
            cm.registerNetworkCallback(NetworkRequest.Builder().build(), netCb)
        } catch (e: Exception) {
        }
        handler.postDelayed(tick, 30000)
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        if (registered) {
            registered = false
            try { unregisterReceiver(screenR) } catch (e: Exception) {}
            try { unregisterReceiver(pkgR) } catch (e: Exception) {}
            try { cm.unregisterNetworkCallback(netCb) } catch (e: Exception) {}
        }
        try { tun?.close() } catch (e: Exception) {}
        tun = null
        running = false
    }

    private fun shutdown() {
        cleanup()
        stopForeground(true)
        stopSelf()
    }

    // ---------------- নেটওয়ার্ক ----------------

    private fun detectNet(): String {
        var wifi = false
        var mob = false
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true
            else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) mob = true
        }
        return if (wifi) "wifi" else if (mob) "mobile" else "unknown"
    }

    private fun netChanged() {
        handler.postDelayed({
            val n = detectNet()
            if (n != net) {
                net = n
                rebuild()
            }
        }, 500)
    }

    // ---------------- নিয়ম থেকে VPN বানানো ----------------

    private fun inSchedule(c: JSONObject): Boolean {
        if (!c.optBoolean("scheduleEnabled")) return false
        val s = c.optInt("schStart", 0)
        val e = c.optInt("schEnd", 360)
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    private fun allow(b: Builder, pkg: String): Boolean = try {
        b.addAllowedApplication(pkg); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    private fun disallow(b: Builder, pkg: String) {
        try { b.addDisallowedApplication(pkg) } catch (e: PackageManager.NameNotFoundException) {}
    }

    @Synchronized
    private fun rebuild() {
        try {
            val cfg = Store.load(this)
            val sched = inSchedule(cfg)
            lastSched = sched
            val blockAll = cfg.optBoolean("blockAll") ||
                (cfg.optBoolean("screenOffBlock") && !screenOn) || sched

            val b = Builder()
                .setSession("Firewall")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addAddress("fd00:8::2", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)

            var needVpn = true
            if (blockAll) {
                disallow(b, packageName)
            } else if (cfg.optString("mode", "blocklist") == "whitelist") {
                disallow(b, packageName)
                val a = cfg.optJSONArray("allowed")
                if (a != null) for (i in 0 until a.length()) disallow(b, a.getString(i))
            } else {
                val rules = cfg.optJSONObject("rules") ?: JSONObject()
                var n = 0
                for (pkg in rules.keys()) {
                    val r = rules.getJSONObject(pkg)
                    val blocked = when (net) {
                        "wifi" -> r.optBoolean("wifi")
                        "mobile" -> r.optBoolean("mobile")
                        else -> r.optBoolean("wifi") || r.optBoolean("mobile")
                    }
                    if (blocked && allow(b, pkg)) n++
                }
                needVpn = n > 0
            }

            val old = tun
            tun = if (needVpn) b.establish() else null
            try { old?.close() } catch (e: Exception) {}

            val t = tun
            if (t != null) startReader(t)
            else if (needVpn) { // establish null = VPN অনুমতি চলে গেছে
                Store.setEnabled(this, false)
                shutdown()
            }
        } catch (e: SecurityException) {
            Store.setEnabled(this, false)
            shutdown()
        } catch (e: Exception) {
        }
    }

    private fun onNewPackage(pkg: String) {
        val cfg = Store.load(this)
        if (!cfg.optBoolean("blockNew") || cfg.optString("mode", "blocklist") != "blocklist") return
        if (pkg == packageName) return
        val rules = cfg.optJSONObject("rules") ?: JSONObject().also { cfg.put("rules", it) }
        rules.put(pkg, JSONObject().put("wifi", true).put("mobile", true))
        Store.save(this, cfg)
        rebuild()
    }

    // ---------------- ট্রাফিক পড়ে ফেলে দেওয়া + লগ ----------------

    private fun startReader(pfd: ParcelFileDescriptor) {
        Thread {
            try {
                val inp = FileInputStream(pfd.fileDescriptor)
                val buf = ByteArray(32767)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    if (n > 0) logPacket(buf, n)
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun logPacket(b: ByteArray, n: Int) {
        if (n < 20 || ((b[0].toInt() shr 4) and 15) != 4) return // শুধু IPv4 লগ
        val ihl = (b[0].toInt() and 15) * 4
        val proto = b[9].toInt() and 255
        val src = InetAddress.getByAddress(b.copyOfRange(12, 16))
        val dst = InetAddress.getByAddress(b.copyOfRange(16, 20))
        var sp = 0
        var dp = 0
        if ((proto == 6 || proto == 17) && n >= ihl + 4) {
            sp = ((b[ihl].toInt() and 255) shl 8) or (b[ihl + 1].toInt() and 255)
            dp = ((b[ihl + 2].toInt() and 255) shl 8) or (b[ihl + 3].toInt() and 255)
        }
        var pkg = "?"
        if (Build.VERSION.SDK_INT >= 29 && dp != 0) {
            try {
                val uid = cm.getConnectionOwnerUid(
                    proto, InetSocketAddress(src, sp), InetSocketAddress(dst, dp)
                )
                val p = packageManager.getPackagesForUid(uid)
                if (p != null && p.isNotEmpty()) pkg = p[0]
            } catch (e: Exception) {
            }
        }
        val target = "${dst.hostAddress}:$dp"
        val key = "$pkg>$target"
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastAt < 3000) return
        lastKey = key
        lastAt = now
        blockedCount++
        val p = when (proto) { 6 -> "TCP"; 17 -> "UDP"; 1 -> "ICMP"; else -> "IP$proto" }
        logs.add(mapOf("time" to now, "pkg" to pkg, "dst" to target, "proto" to p))
        while (logs.size > 300) logs.removeAt(0)
    }
}
