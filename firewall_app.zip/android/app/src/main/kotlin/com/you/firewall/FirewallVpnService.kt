package com.you.firewall

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.SystemClock
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Calendar

/** কনফিগ সেভ/লোড (Dart, boot, tile সবাই এখান থেকে পড়ে) */
object Store {
    fun prefs(c: Context) = c.getSharedPreferences("fw", Context.MODE_PRIVATE)

    fun load(c: Context): JSONObject = try {
        JSONObject(prefs(c).getString("cfg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun save(c: Context, j: JSONObject) {
        prefs(c).edit().putString("cfg", j.toString()).apply()
    }

    /** কনফিগ পড়া-বদলানো-লেখা একসাথে (লক দিয়ে), যাতে দুই থ্রেডের বদল একে অপরকে মুছে না দেয় */
    @Synchronized
    fun edit(c: Context, f: (JSONObject) -> Unit) {
        val j = load(c)
        f(j)
        save(c, j)
    }

    fun setEnabled(c: Context, v: Boolean) {
        edit(c) { it.put("enabled", v) }
    }

    /** চালু থাকা মোড (ট্রেডিং, ঘুম ইত্যাদি): {name, allowed[]}। না থাকলে null */
    fun activeProfile(c: Context): JSONObject? {
        val cfg = load(c)
        val n = cfg.optString("activeMode")
        if (n.isEmpty()) return null
        val p = cfg.optJSONObject("profiles")?.optJSONObject(n) ?: return null
        return JSONObject().put("name", n).put("allowed", p.optJSONArray("allowed") ?: JSONArray())
    }

    // ---- সাময়িক চালু (আলাদা কী, Dart-এর সেভে মুছে যায় না) ----

    /** এখনো চালু থাকা সাময়িক ছাড়: pkg -> শেষ হওয়ার সময় */
    fun tempAllowed(c: Context): Map<String, Long> {
        val now = System.currentTimeMillis()
        val m = HashMap<String, Long>()
        try {
            val o = JSONObject(prefs(c).getString("temp", "{}") ?: "{}")
            for (k in o.keys()) {
                val t = o.optLong(k, 0L)
                if (t > now) m[k] = t
            }
        } catch (e: Exception) {
        }
        return m
    }

    fun grantTemp(c: Context, pkg: String, min: Int) {
        val o = JSONObject()
        for ((k, v) in tempAllowed(c)) o.put(k, v)
        o.put(pkg, System.currentTimeMillis() + min * 60000L)
        prefs(c).edit().putString("temp", o.toString()).apply()
    }

    /** "আজ আর না": ২৪ ঘণ্টা এই অ্যাপের নোটিফিকেশন বন্ধ */
    fun muteNotice(c: Context, pkg: String) {
        val now = System.currentTimeMillis()
        val o = try {
            JSONObject(prefs(c).getString("mute", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val keep = JSONObject()
        for (k in o.keys()) if (o.optLong(k, 0L) > now) keep.put(k, o.optLong(k))
        keep.put(pkg, now + 24L * 3600000L)
        prefs(c).edit().putString("mute", keep.toString()).apply()
    }

    fun noticeMuted(c: Context, pkg: String): Boolean = try {
        JSONObject(prefs(c).getString("mute", "{}") ?: "{}").optLong(pkg, 0L) > System.currentTimeMillis()
    } catch (e: Exception) {
        false
    }

    /** জরুরি অ্যাপ: কখনো ব্লক হয় না (ডায়ালার, মেসেজ আর নিজের বাছা অ্যাপ) */
    fun emergency(c: Context): Set<String> {
        val s = HashSet<String>()
        val a = load(c).optJSONArray("emergency")
        if (a != null) for (i in 0 until a.length()) s.add(a.optString(i))
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val tm = c.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
                tm.defaultDialerPackage?.let { s.add(it) }
            } catch (e: Exception) {
            }
        }
        try {
            android.provider.Telephony.Sms.getDefaultSmsPackage(c)?.let { s.add(it) }
        } catch (e: Exception) {
        }
        return s
    }

    // ---- ফোকাস (মালিক Kotlin, Dart পুরনো মান দিয়ে মুছতে পারে না) ----

    fun focusUntil(c: Context): Long = load(c).optLong("focusUntil", 0L)

    /** রিবুটের গোনা (API 24+)। না পেলে -1 */
    fun bootCount(c: Context): Int = try {
        android.provider.Settings.Global.getInt(c.contentResolver, "boot_count")
    } catch (e: Exception) {
        -1
    }

    /**
     * ফোকাসে বাকি সময় (মিলিসেকেন্ড)। একই বুটে হলে elapsedRealtime দিয়ে মাপা হয়,
     * তাই ফোনের তারিখ-সময় বদলালে ফোকাস ভাঙে না। রিবুটের পর ওয়াল-ক্লকে ফেরে।
     */
    fun focusLeftMs(c: Context): Long {
        val until = focusUntil(c)
        if (until <= 0L) return 0L
        val p = prefs(c)
        val endEl = p.getLong("focusEndEl", 0L)
        val startEl = p.getLong("focusStartEl", 0L)
        val el = SystemClock.elapsedRealtime()
        if (endEl > 0L && el >= startEl && p.getInt("focusBoot", -2) == bootCount(c)) {
            return maxOf(0L, endEl - el)
        }
        return maxOf(0L, until - System.currentTimeMillis())
    }

    fun focusActive(c: Context): Boolean = focusLeftMs(c) > 0L

    /** ঘড়ি বদলালে focusUntil (যেটা Dart ও অন্যরা পড়ে) আসল বাকি সময়ের সাথে মিলিয়ে দেয় */
    @Synchronized
    fun focusSync(c: Context) {
        val left = focusLeftMs(c)
        val j = load(c)
        val until = j.optLong("focusUntil", 0L)
        if (until <= 0L) return
        if (left <= 0L) return // শেষ হওয়ার কাজ focusEnd টাইমার করে
        val want = System.currentTimeMillis() + left
        if (kotlin.math.abs(want - until) > 2000L) {
            j.put("focusUntil", want)
            save(c, j)
        }
    }

    private fun hist(c: Context): JSONArray = try {
        JSONArray(prefs(c).getString("focusHist", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    fun focusHist(c: Context): List<Map<String, Any>> {
        val a = hist(c)
        val l = ArrayList<Map<String, Any>>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            l.add(mapOf("t" to o.optLong("t"), "m" to o.optInt("m"), "early" to o.optBoolean("early")))
        }
        return l
    }

    @Synchronized
    fun startFocus(c: Context, min: Int) {
        val now = System.currentTimeMillis()
        val j = load(c)
        j.put("focusUntil", now + min * 60000L)
        save(c, j)
        val el = SystemClock.elapsedRealtime()
        prefs(c).edit()
            .putLong("focusStartEl", el)
            .putLong("focusEndEl", el + min * 60000L)
            .putInt("focusBoot", bootCount(c))
            .apply()
        val a = hist(c)
        a.put(JSONObject().put("t", now).put("m", min).put("early", false))
        val keep = JSONArray()
        for (i in maxOf(0, a.length() - 60) until a.length()) keep.put(a.get(i))
        prefs(c).edit().putString("focusHist", keep.toString()).apply()
    }

    @Synchronized
    fun endFocus(c: Context) {
        val j = load(c)
        val now = System.currentTimeMillis()
        val wasActive = focusLeftMs(c) > 0L
        prefs(c).edit().remove("focusStartEl").remove("focusEndEl").remove("focusBoot").apply()
        if (wasActive) {
            val a = hist(c)
            if (a.length() > 0) {
                val o = a.getJSONObject(a.length() - 1)
                o.put("m", ((now - o.optLong("t")) / 60000L).toInt())
                o.put("early", true)
                prefs(c).edit().putString("focusHist", a.toString()).apply()
            }
        }
        j.put("focusUntil", 0L)
        save(c, j)
    }
}

/**
 * ব্লক করার কৌশল: যে অ্যাপের ট্রাফিক VPN-এ ঢোকে, আমরা সেটা পড়ে ফেলে দিই (কোথাও পাঠাই না)।
 *  - ব্লকলিস্ট: শুধু ব্লক করা অ্যাপগুলো VPN-এ ঢোকে (addAllowedApplication)
 *  - হোয়াইটলিস্ট / সব ব্লক: সবাই ঢোকে, শুধু অনুমতিপ্রাপ্ত (এবং এই অ্যাপ) বাইরে (addDisallowedApplication)
 */
class FirewallVpnService : VpnService() {

    companion object {
        @Volatile var running = false
        @Volatile var blockedCount = 0
        // নোটিফিকেশনে কারণ বলার জন্য rebuild-এর শেষ অবস্থা
        @Volatile var netNow = "unknown"
        @Volatile var limApps: Set<String> = emptySet()
        @Volatile var dataCutOn = false
        @Volatile var roamBlockOn = false // রোমিংয়ে মোবাইল ডেটা কাটা চলছে
        @Volatile var wifiOpenNow = false // Wi-Fi-তে সব খোলা চলছে
        val logs: MutableList<Map<String, Any>> =
            java.util.Collections.synchronizedList(ArrayList())

        private fun send(c: Context, action: String, fg: Boolean) {
            val i = Intent(c, FirewallVpnService::class.java).setAction(action)
            try {
                if (fg && Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
            }
        }

        fun start(c: Context) {
            Store.setEnabled(c, true)
            send(c, "START", true)
            Guardian.schedule(c)
        }

        fun stop(c: Context) {
            if (Store.focusActive(c)) return // ফোকাস চলাকালে বন্ধ করা যাবে না
            Store.setEnabled(c, false)
            send(c, "STOP", false)
            Guardian.cancel(c)
        }

        fun reload(c: Context) {
            if (running) send(c, "RELOAD", false)
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var engine: Engine? = null // নিজস্ব ইঞ্জিন (সুইচ চালু ও অ্যাপ বাছা থাকলে)
    private var lastSig = "" // শেষ VPN-এর গঠন, একই হলে VPN আবার বানাই না (সংযোগ না কাটতে)
    private val sigSet = java.util.TreeSet<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var registered = false
    @Volatile private var stopping = false // আমরা নিজে ইচ্ছা করে বন্ধ করছি
    private var screenOn = true
    private var net = "unknown"
    private var roaming = false
    private var lastSched = false
    private var lastKey = ""
    private var lastAt = 0L
    private var lastFocus = false
    private var establishRetry = 0
    @Volatile private var overLimit: Set<String> = emptySet()
    @Volatile private var dataCut = false // ফোনের ডেটা লিমিট পূর্ণ ও কাট চালু
    @Volatile private var dataApps: Set<String> = emptySet() // অ্যাপ ডেটা লিমিট পূর্ণ ও কাট চালু
    @Volatile private var dataBusy = false
    @Volatile private var dataFast = false // সীমার ৮০%+ হলে ৫ সেকেন্ডে চেক
    @Volatile private var todayBytes = -1L // আজকের মোট ডেটা (নোটিফিকেশনের জন্য), -1 = জানা নেই
    private var baseText = "চালু"
    private var speedText = ""
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastAtMs = 0L

    private val cm by lazy { getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    private val nm by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    private val screenR = ScreenReceiver { on ->
        screenOn = on
        if (on) {
            // স্ক্রিন চালু হতেই একবার হিসাব মিলিয়ে নেওয়া
            handler.post {
                checkLimits(Store.load(this))
                refreshToday()
            }
        }
        val c0 = Store.load(this)
        if (c0.optBoolean("leakWatch", true)) {
            if (on) LeakWatch.screenOn() else LeakWatch.screenOff(this)
        }
        if (c0.optBoolean("screenOffBlock") || (c0.optJSONArray("screenOffApps")?.length() ?: 0) > 0) {
            handler.post { rebuild() }
        }
    }

    private val timeR = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // ফোনের তারিখ/সময় বদলেছে: ফোকাসের আসল বাকি সময় ধরে রাখা, শেষ হওয়ার টাইমার নতুন করে বসানো
            Store.focusSync(this@FirewallVpnService)
            handler.post {
                scheduleFocusEnd()
                rebuild()
            }
        }
    }

    private val pkgR = PackageReceiver { pkg -> handler.post { onNewPackage(pkg) } }

    // অ্যাপ আপডেট হলে নতুন সংবেদনশীল পারমিশন মেলানো
    private val pkgU = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            val ctx = this@FirewallVpnService.applicationContext
            val warn = Store.load(ctx).optBoolean("permWatch", true)
            Thread { PermWatch.check(ctx, pkg, warn) }.start()
        }
    }

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = netChanged()
        override fun onLost(network: Network) = netChanged()
        override fun onCapabilitiesChanged(network: Network, c: NetworkCapabilities) = netChanged()
    }

    private val tick = object : Runnable {
        override fun run() {
            Store.focusSync(this@FirewallVpnService)
            val cfg = Store.load(this@FirewallVpnService)
            val s = inSchedule(cfg)
            val f = Store.focusActive(this@FirewallVpnService)
            if (s != lastSched || f != lastFocus) rebuild()
            if (screenOn) checkLimits(cfg) // স্ক্রিন বন্ধে অ্যাপের ব্যবহার বাড়ে না, ভারী হিসাব বাদ
            if (!screenOn && cfg.optBoolean("leakWatch", true)) LeakWatch.poll(this@FirewallVpnService)
            val pn = Store.activeProfile(this@FirewallVpnService)?.optString("name")
            baseText = if (f) "ফোকাস চলছে" else if (pn != null) "$pn চালু" else "ব্লক চেষ্টা: $blockedCount"
            refreshNotif()
            if (screenOn) refreshToday()
            Stats.flush(this@FirewallVpnService)
            if (screenOn) FirewallWidget.refresh(this@FirewallVpnService)
            handler.postDelayed(this, 30000)
        }
    }

    private val speedTick = object : Runnable {
        override fun run() {
            if (screenOn && Store.load(this@FirewallVpnService).optBoolean("liveStat", true)) {
                val rx = TrafficStats.getTotalRxBytes()
                val tx = TrafficStats.getTotalTxBytes()
                val now = SystemClock.elapsedRealtime()
                if (lastAtMs > 0 && rx >= 0 && tx >= 0 && now > lastAtMs) {
                    val dt = (now - lastAtMs) / 1000.0
                    speedText = "↓ ${fmtS((rx - lastRx) / dt)} ↑ ${fmtS((tx - lastTx) / dt)}"
                }
                lastRx = rx
                lastTx = tx
                lastAtMs = now
                refreshNotif()
            } else {
                lastAtMs = 0L
                speedText = ""
            }
            handler.postDelayed(this, 5000)
        }
    }

    private val dataTick = object : Runnable {
        override fun run() {
            checkData()
            handler.postDelayed(this, if (dataFast) 5000L else 30000L)
        }
    }

    private val tempEnd = Runnable { rebuild() }

    /** ইঞ্জিন চালুর পর ৩০ সেকেন্ডে "নেট চলছে" নিশ্চিত না হলে নিজে বন্ধ */
    private val confirmEnd = Runnable {
        val cfg = Store.load(this)
        val by = cfg.optLong("engineConfirmBy", 0L)
        if (by != 0L && System.currentTimeMillis() >= by) {
            val wasOn = cfg.optBoolean("engineOn")
            Store.edit(this) {
                it.put("engineOn", false)
                it.put("engineConfirmBy", 0L)
            }
            if (wasOn) {
                EngineStats.add("নিশ্চিত হয়নি, ইঞ্জিন নিজে বন্ধ")
                note(41, "ইঞ্জিন বন্ধ করা হয়েছে", "নিশ্চিত না করায় নিজে বন্ধ। অ্যাপের নেট আগের মতো চলবে।", true)
                rebuild()
            }
        }
    }

    private val focusEnd = Runnable {
        rebuild()
        note(2, "ফোকাস শেষ", "ভালো কাজ! ইন্টারনেট আবার আগের নিয়মে।")
    }

    // ---------------- lifecycle ----------------

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null && !Store.load(this).optBoolean("enabled")) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == "STOP") {
            shutdown()
            return START_NOT_STICKY
        }
        stopping = false
        goForeground()
        running = true
        FirewallWidget.refresh(this)
        setup()
        rebuild()
        checkLimits(Store.load(this))
        checkData()
        return START_STICKY
    }

    override fun onRevoke() {
        Store.setEnabled(this, false)
        shutdown()
        Guardian.lostPermission(applicationContext)
    }

    override fun onDestroy() {
        // চালু থাকার কথা, কিন্তু আমরা নিজে বন্ধ করিনি: সিস্টেম মেরেছে
        val unexpected = !stopping && Store.load(this).optBoolean("enabled")
        cleanup()
        super.onDestroy()
        if (unexpected) Guardian.ensure(applicationContext)
    }

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("fw", "Firewall", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel("fwd", "ডেটা সতর্কতা", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val n = notif("চালু")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(1, n)
        }
    }

    private fun fmtS(bps: Double): String = when {
        bps < 1024.0 -> "${bps.toInt()} B/s"
        bps < 1024.0 * 1024.0 -> "${(bps / 1024.0).toInt()} KB/s"
        else -> String.format(java.util.Locale.US, "%.1f MB/s", bps / (1024.0 * 1024.0))
    }

    /** নোটিফিকেশনে অবস্থা + লাইভ স্পিড + আজকের ডেটা */
    private fun refreshNotif() {
        var t = baseText
        if (Store.load(this).optBoolean("liveStat", true)) {
            if (speedText.isNotEmpty()) t += " • $speedText"
            if (todayBytes >= 0) t += " • আজ ${fmtB(todayBytes)}"
        }
        try { nm.notify(1, notif(t)) } catch (e: Exception) {}
    }

    /** আজকের মোট ডেটা ব্যাকগ্রাউন্ডে গোনা (Usage access না থাকলে বাদ) */
    private fun refreshToday() {
        if (!Store.load(this).optBoolean("liveStat", true)) return
        Thread {
            val v = try {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                UsageUtil.dataSince(this, cal.timeInMillis, true, false).total
            } catch (e: Exception) {
                -1L
            }
            todayBytes = if (v > 0) v else -1L
        }.start()
    }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "fw")
        else Notification.Builder(this)
        return b.setContentTitle("Firewall চালু")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun setup() {
        if (registered) return
        registered = true
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        registerReceiver(
            screenR,
            IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_SCREEN_OFF) }
        )
        registerReceiver(
            timeR,
            IntentFilter(Intent.ACTION_TIME_CHANGED).apply { addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        )
        registerReceiver(
            pkgR,
            IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        )
        registerReceiver(
            pkgU,
            IntentFilter(Intent.ACTION_PACKAGE_REPLACED).apply { addDataScheme("package") }
        )
        val appCtx = applicationContext
        val permWarn = Store.load(this).optBoolean("permWatch", true)
        Thread { PermWatch.scanAll(appCtx, permWarn) }.start()
        net = detectNet()
        roaming = detectRoam()
        try {
            cm.registerNetworkCallback(NetworkRequest.Builder().build(), netCb)
        } catch (e: Exception) {
        }
        handler.postDelayed(tick, 30000)
        handler.postDelayed(dataTick, 30000)
        handler.postDelayed(speedTick, 5000)
        refreshToday()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        Stats.flush(this)
        if (registered) {
            registered = false
            try { unregisterReceiver(screenR) } catch (e: Exception) {}
            try { unregisterReceiver(pkgR) } catch (e: Exception) {}
            try { unregisterReceiver(pkgU) } catch (e: Exception) {}
            try { unregisterReceiver(timeR) } catch (e: Exception) {}
            try { cm.unregisterNetworkCallback(netCb) } catch (e: Exception) {}
        }
        try { engine?.stop() } catch (e: Exception) {}
        engine = null
        lastSig = ""
        try { tun?.close() } catch (e: Exception) {}
        tun = null
        running = false
        FirewallWidget.refresh(this)
    }

    private fun shutdown() {
        stopping = true
        cleanup()
        stopForeground(true)
        stopSelf()
    }

    // ---------------- নেটওয়ার্ক ----------------

    private fun detectNet(): String {
        var wifi = false
        var mob = false
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true
            else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) mob = true
        }
        return if (wifi) "wifi" else if (mob) "mobile" else "unknown"
    }

    /** মোবাইল ডেটা রোমিংয়ে আছে কিনা (Wi-Fi থাকলে নয়) */
    private fun detectRoam(): Boolean {
        var wifi = false
        var roam = false
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true
            else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
                !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING)
            ) roam = true
        }
        return roam && !wifi
    }

    private fun netChanged() {
        handler.postDelayed({
            val n = detectNet()
            val r = detectRoam()
            if (n != net || r != roaming) {
                net = n
                roaming = r
                rebuild()
            }
        }, 500)
    }

    /** ব্যাকগ্রাউন্ডে ইন্টারনেট বন্ধ রাখা অ্যাপের মধ্যে যেগুলো এখন সামনে নেই (গার্ড চালু থাকলেই বোঝা যায়) */
    private fun bgBlocked(cfg: JSONObject): Set<String> {
        val a = cfg.optJSONArray("bgBlock") ?: return emptySet()
        if (!GuardService.connected) return emptySet()
        val fg = GuardService.fgNow
        val s = HashSet<String>()
        for (i in 0 until a.length()) {
            val p = a.optString(i)
            if (p != fg) s.add(p)
        }
        return s
    }

    /** স্ক্রিন বন্ধ থাকলে যে বাছা অ্যাপগুলোর নেট বন্ধ */
    private fun screenOffSet(cfg: JSONObject): Set<String> {
        if (screenOn) return emptySet()
        return strList(cfg.optJSONArray("screenOffApps")).toSet()
    }

    // ---------------- নিয়ম থেকে VPN বানানো ----------------

    private fun inSchedule(c: JSONObject): Boolean {
        if (!c.optBoolean("scheduleEnabled")) return false
        val s = c.optInt("schStart", 0)
        val e = c.optInt("schEnd", 360)
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    private fun allow(b: Builder, pkg: String): Boolean = try {
        b.addAllowedApplication(pkg); sigSet.add("a:$pkg"); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    private fun disallow(b: Builder, pkg: String) {
        try { b.addDisallowedApplication(pkg); sigSet.add("d:$pkg") } catch (e: PackageManager.NameNotFoundException) {}
    }

    private fun strList(a: JSONArray?): List<String> {
        val r = ArrayList<String>()
        if (a != null) for (i in 0 until a.length()) {
            val v = a.optString(i)
            if (v.isNotEmpty()) r.add(v)
        }
        return r
    }

    /** ইঞ্জিন যে DNS সার্ভারে প্রশ্ন পাঠাবে: আসল নেটওয়ার্কের (VPN বাদে) DNS */
    private fun upstreamDns(): List<InetAddress> {
        val r = ArrayList<InetAddress>()
        try {
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                val lp = cm.getLinkProperties(n) ?: continue
                for (a in lp.dnsServers) if (a is Inet4Address && a !in r) r.add(a)
            }
        } catch (e: Exception) {
        }
        if (r.isEmpty()) {
            try {
                r.add(InetAddress.getByAddress(byteArrayOf(1, 1, 1, 1)))
                r.add(InetAddress.getByAddress(byteArrayOf(8, 8, 8, 8)))
            } catch (e: Exception) {
            }
        }
        return r
    }

    private fun startEngine(t: ParcelFileDescriptor, uids: Set<Int>, builtin: Boolean, custom: List<String>) {
        val e = Engine(
            this, t, uids, cm, DomainFilter(builtin, custom),
            { upstreamDns() },
            { b, n -> logPacket(b, n) },
            { handler.post { engineFatal() } }
        )
        engine = e
        e.start()
    }

    /** ইঞ্জিনে বারবার ত্রুটি: সুইচ বন্ধ করে বাছা অ্যাপের নেট আগের মতো সরাসরি */
    private fun engineFatal() {
        val cfg = Store.load(this)
        if (!cfg.optBoolean("engineOn")) return
        Store.edit(this) {
            it.put("engineOn", false)
            it.put("engineConfirmBy", 0L)
        }
        EngineStats.add("⚠ বারবার ত্রুটি, ইঞ্জিন নিজে বন্ধ")
        note(41, "ইঞ্জিন বন্ধ হয়েছে", "বারবার ত্রুটির কারণে নিজে বন্ধ। অ্যাপের নেট আগের মতো চলবে।", true)
        rebuild()
    }

    private fun scheduleConfirmEnd() {
        handler.removeCallbacks(confirmEnd)
        val by = Store.load(this).optLong("engineConfirmBy", 0L)
        if (by == 0L) return
        val left = by - System.currentTimeMillis()
        if (left > 0) handler.postDelayed(confirmEnd, left + 300) else handler.post(confirmEnd)
    }

    @Synchronized
    private fun rebuild() {
        try {
            val cfg = Store.load(this)
            val sched = inSchedule(cfg)
            lastSched = sched
            val focus = Store.focusActive(this)
            lastFocus = focus
            scheduleFocusEnd()
            scheduleTempEnd()
            scheduleConfirmEnd()
            sigSet.clear()
            val roamCut = cfg.optBoolean("roamBlock") && roaming && net == "mobile"
            roamBlockOn = roamCut
            val wifiFree = cfg.optBoolean("wifiOpen") && net == "wifi"
            wifiOpenNow = wifiFree
            val blockAll = cfg.optBoolean("blockAll") ||
                (cfg.optBoolean("screenOffBlock") && !screenOn) || sched || roamCut

            val b = Builder()
                .setSession("Firewall")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)

            var needVpn = true
            // ডেটা লিমিটের কাট শুধু ওই নেটওয়ার্কে, যেটা গোনা হয় (মোবাইল সবসময়, Wi-Fi শুধু গুনলে)
            val dc = DataLimit.cfg(cfg)
            val dataNet = net != "wifi" || dc.wifi
            val dataBlock = dataCut && dataNet
            // সময়সীমা বা ডেটা সীমা শেষ হওয়া অ্যাপ সবসময় ব্লক
            val lim0 = if (dataNet) overLimit + dataApps else overLimit
            val lim = lim0 + bgBlocked(cfg) + screenOffSet(cfg) // ব্যাকগ্রাউন্ড ও স্ক্রিন-বন্ধ ব্লকও "সবসময় ব্লক" দলে
            netNow = net
            limApps = lim0
            // নিজস্ব ইঞ্জিন (অ্যান্ড্রয়েড ১০+): বাছা অ্যাপ VPN-এর ভেতরে থাকে, কিন্তু ব্লক না হয়ে ইঞ্জিন দিয়ে যায়
            val engApps: Set<String> =
                if (Build.VERSION.SDK_INT >= 29 && cfg.optBoolean("engineOn")) strList(cfg.optJSONArray("engineApps")).toSet()
                else emptySet()
            val fwdPk = LinkedHashSet<String>()
            fun exemptOrEngine(p: String) {
                if (p in engApps && p !in lim) fwdPk.add(p) else disallow(b, p)
            }
            dataCutOn = dataBlock
            // সাময়িক চালু (ফোকাসে নয়) আর জরুরি অ্যাপ সবসময় VPN-এর বাইরে, মানে ব্লক হয় না
            val prof = if (focus) null else Store.activeProfile(this)
            val pass: Set<String> =
                (if (focus) emptySet<String>() else Store.tempAllowed(this).keys) + Store.emergency(this)
            if (blockAll) {
                disallow(b, packageName)
                for (p in pass) disallow(b, p)
            } else if (dataBlock) {
                // ফোনের ডেটা শেষ: জরুরি ছাড়ের অ্যাপ ছাড়া সব ব্লক
                disallow(b, packageName)
                for (p in dc.exempt) if (p !in lim) exemptOrEngine(p)
                for (p in pass) disallow(b, p)
            } else if (focus || prof != null ||
                (cfg.optString("mode", "blocklist") == "whitelist" && !wifiFree)
            ) {
                // ফোকাসে: শুধু focusAllowed বাইরে থাকে (বাকি সব ব্লক)
                disallow(b, packageName)
                for (p in pass) disallow(b, p)
                val a = if (focus) cfg.optJSONArray("focusAllowed")
                else if (prof != null) prof.optJSONArray("allowed")
                else cfg.optJSONArray("allowed")
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val p = a.getString(i)
                        if (p !in lim) exemptOrEngine(p)
                    }
                }
            } else {
                val rules = cfg.optJSONObject("rules") ?: JSONObject()
                val toBlock = LinkedHashSet<String>()
                // Wi-Fi-তে সব খোলা থাকলে অ্যাপ-ভিত্তিক নিয়ম বাদ (সময়/ডেটা লিমিট আর ব্যাকগ্রাউন্ড ব্লক থাকে)
                for (pkg in (if (wifiFree) emptyList<String>() else rules.keys().asSequence().toList())) {
                    val r = rules.getJSONObject(pkg)
                    val blocked = when (net) {
                        "wifi" -> r.optBoolean("wifi")
                        "mobile" -> r.optBoolean("mobile")
                        else -> r.optBoolean("wifi") || r.optBoolean("mobile")
                    }
                    if (blocked) toBlock.add(pkg)
                }
                toBlock.addAll(lim)
                toBlock.removeAll(pass)
                var n = 0
                for (pkg in toBlock) if (allow(b, pkg)) n++
                // ইঞ্জিনের অ্যাপ: ব্লক বা জরুরি নয় এমনগুলো VPN-এ ঢুকে ইঞ্জিনে যাবে
                for (pkg in engApps) {
                    if (pkg !in toBlock && pkg !in pass && allow(b, pkg)) {
                        fwdPk.add(pkg)
                        n++
                    }
                }
                needVpn = n > 0
            }

            val fwdUids = HashSet<Int>()
            for (p in fwdPk) {
                try { fwdUids.add(packageManager.getApplicationInfo(p, 0).uid) } catch (e: Exception) {}
            }
            val engOn = needVpn && fwdUids.isNotEmpty()
            val builtin = cfg.optBoolean("engineBuiltin", true)
            val custom = strList(cfg.optJSONArray("engineDomains")) +
                (if (cfg.optBoolean("engineBlockDoh", false)) DomainFilter.DOH else emptyList())
            if (engOn) b.addDnsServer("10.8.0.1")
            // ইঞ্জিন চালু থাকলেও IPv6 টানেলে ঢোকানো হয় (ইঞ্জিন IPv6 ফেলে দেয়), নইলে ফিল্টার এড়িয়ে বেরোয়
            b.addAddress("fd00:8::2", 128)
            b.addRoute("::", 0)
            val sig = sigSet.joinToString(",") + "|" + needVpn + "|" + engOn + "|" + builtin + "|" +
                custom.sorted().joinToString("+") + "|" + fwdUids.sorted().joinToString("+")
            val same = sig == lastSig &&
                ((needVpn && tun != null) || (!needVpn && tun == null)) &&
                (!engOn || engine?.isAlive == true)
            if (same) return
            lastSig = ""

            val oldEng = engine
            engine = null
            try { oldEng?.stop() } catch (e: Exception) {}
            val old = tun
            tun = if (needVpn) b.establish() else null
            try { old?.close() } catch (e: Exception) {}

            val t = tun
            if (t != null) {
                lastSig = sig
                establishRetry = 0
                if (engOn) startEngine(t, fwdUids, builtin, custom) else startReader(t)
            } else if (needVpn) {
                // establish null: অনুমতি সত্যিই গেছে, নাকি সাময়িক ব্যর্থতা? অনুমতি থাকলে ৩ বার আবার চেষ্টা
                val granted = try { VpnService.prepare(this) == null } catch (e: Exception) { false }
                if (granted && establishRetry < 3) {
                    establishRetry++
                    lastSig = ""
                    handler.postDelayed({ rebuild() }, 2000L * establishRetry)
                } else {
                    establishRetry = 0
                    Store.setEnabled(this, false)
                    shutdown()
                    Guardian.lostPermission(applicationContext)
                }
            }
        } catch (e: SecurityException) {
            Store.setEnabled(this, false)
            shutdown()
            Guardian.lostPermission(applicationContext)
        } catch (e: Exception) {
            android.util.Log.w("FW", "rebuild ব্যর্থ", e)
        }
    }

    // ---------------- অ্যাপ টাইম লিমিট ও ফোকাস ----------------

    private fun scheduleFocusEnd() {
        handler.removeCallbacks(focusEnd)
        val left = Store.focusLeftMs(this)
        if (left > 0) handler.postDelayed(focusEnd, left + 300)
    }

    private fun scheduleTempEnd() {
        handler.removeCallbacks(tempEnd)
        val t = Store.tempAllowed(this).values.minOrNull() ?: return
        val left = t - System.currentTimeMillis()
        if (left > 0) handler.postDelayed(tempEnd, left + 300)
    }

    private fun checkLimits(cfg: JSONObject) {
        val lim = cfg.optJSONObject("limits")
        if (lim == null || lim.length() == 0) {
            if (overLimit.isNotEmpty()) {
                overLimit = emptySet()
                rebuild()
            }
            return
        }
        Thread {
            val used = try {
                UsageUtil.compute(this, 1, 0, 0).apps
            } catch (e: Exception) {
                return@Thread
            }
            val now = HashSet<String>()
            for (pkg in lim.keys()) {
                val m = lim.optInt(pkg, 0)
                if (m <= 0) continue
                val ms = used[pkg]?.get(0) ?: 0L
                if (ms >= m * 60000L) now.add(pkg)
            }
            handler.post {
                if (now != overLimit) {
                    val newly = now - overLimit
                    overLimit = now
                    for (p in newly) note(1000 + (p.hashCode() and 0xffff), "সময়সীমা শেষ", "${label(p)}-এর আজকের লিমিট শেষ, ইন্টারনেট বন্ধ")
                    rebuild()
                }
            }
        }.start()
    }

    private fun fmtB(b: Long): String =
        if (b < 1024L * 1024L * 1024L) "${b / DataLimit.MB} MB"
        else String.format(java.util.Locale.US, "%.2f GB", b / (1024.0 * 1024.0 * 1024.0))

    private class Msg(val id: Int, val title: String, val text: String)

    private fun checkData() {
        if (dataBusy) return
        val dc = DataLimit.cfg(Store.load(this))
        if (!dc.any) {
            dataFast = false
            if (dataCut || dataApps.isNotEmpty()) {
                dataCut = false
                dataApps = emptySet()
                rebuild()
            }
            return
        }
        dataBusy = true
        Thread {
            try {
                val from = DataLimit.periodStart(dc.resetDay)
                val st = DataLimit.state(this, from)
                val extra = st.optLong("extra", 0L)
                val use = UsageUtil.dataSince(this, from, dc.wifi, dc.apps.isNotEmpty())
                val used = use.total
                val limB = if (dc.phoneMb > 0) (dc.phoneMb + extra) * DataLimit.MB else 0L
                val phoneOver = limB > 0 && used >= limB

                var fast = limB > 0 && used * 100 >= limB * 80
                val over = HashSet<String>()
                for ((pkg, mb) in dc.apps) {
                    val lb = mb * DataLimit.MB
                    val u = use.apps[pkg] ?: 0L
                    if (u >= lb) over.add(pkg)
                    if (u * 100 >= lb * 80) fast = true
                }

                val msgs = ArrayList<Msg>()
                val keys = ArrayList<String>()
                val period = if (dc.resetDay == 0) "আজকের" else "এই মাসের"
                if (limB > 0) {
                    for (pct in dc.warnPct) {
                        if (pct !in 1..99) continue
                        val k = "p$pct"
                        if (used * 100 >= limB * pct && !DataLimit.isWarned(st, k)) {
                            keys.add(k)
                            msgs.add(Msg(3000 + pct, "ডেটা সতর্কতা", "$period লিমিটের $pct% শেষ (${fmtB(used)} / ${fmtB(limB)})"))
                        }
                    }
                    if (phoneOver && !DataLimit.isWarned(st, "full")) {
                        keys.add("full")
                        msgs.add(
                            Msg(
                                3100, "ডেটা লিমিট শেষ",
                                if (dc.cut) "মোবাইল ডেটা বন্ধ (জরুরি অ্যাপ ছাড়া)। আরও নিতে Firewall অ্যাপ খুলুন"
                                else "$period লিমিট পার হয়েছে (${fmtB(used)})"
                            )
                        )
                    }
                }
                for (m in dc.warnMb) {
                    if (m <= 0) continue
                    val k = "m$m"
                    if (used >= m * DataLimit.MB && !DataLimit.isWarned(st, k)) {
                        keys.add(k)
                        msgs.add(Msg(3200 + (m % 1000).toInt(), "ডেটা সতর্কতা", "$period ডেটা খরচ ${fmtB(used)} ছুঁয়েছে"))
                    }
                }
                for (pkg in over) {
                    val k = "a:$pkg"
                    if (!DataLimit.isWarned(st, k)) {
                        keys.add(k)
                        msgs.add(
                            Msg(
                                4000 + (pkg.hashCode() and 0xffff), "অ্যাপের ডেটা লিমিট শেষ",
                                if (dc.cut) "${label(pkg)}-এর ডেটা বন্ধ" else "${label(pkg)}-এর লিমিট পার হয়েছে"
                            )
                        )
                    }
                }
                DataLimit.markWarned(this, from, keys)

                val cutNow = dc.cut && phoneOver
                val appsNow: Set<String> = if (dc.cut) over else emptySet()
                handler.post {
                    for (m in msgs) note(m.id, m.title, m.text, true)
                    val changed = cutNow != dataCut || appsNow != dataApps
                    dataCut = cutNow
                    dataApps = appsNow
                    val wasFast = dataFast
                    dataFast = fast
                    if (changed) rebuild()
                    if (fast && !wasFast) { // ৫ সেকেন্ডের চক্রে নামা
                        handler.removeCallbacks(dataTick)
                        handler.postDelayed(dataTick, 5000L)
                    }
                }
            } catch (e: Exception) {
            } finally {
                dataBusy = false
            }
        }.start()
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun note(id: Int, title: String, text: String, high: Boolean = false) {
        try {
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, if (high) "fwd" else "fw")
            else Notification.Builder(this)
            nm.notify(
                id,
                b.setContentTitle(title)
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (e: Exception) {
        }
    }

    private fun onNewPackage(pkg: String) {
        if (pkg == packageName) return
        val appCtx = applicationContext
        Thread { PermWatch.check(appCtx, pkg, false) }.start() // নতুন অ্যাপের পারমিশন রেকর্ড
        val cfg = Store.load(this)
        val blocklist = cfg.optString("mode", "blocklist") == "blocklist"
        if (cfg.optBoolean("askNew") && Safety.wantsInternet(this, pkg)) {
            // না বলা পর্যন্ত ব্লক (হোয়াইটলিস্টে এমনিতেই ব্লক), তারপর প্রশ্নের নোটিফিকেশন
            if (blocklist) {
                Store.edit(this) { j ->
                    val rules = j.optJSONObject("rules") ?: JSONObject().also { j.put("rules", it) }
                    rules.put(pkg, JSONObject().put("wifi", true).put("mobile", true))
                }
                rebuild()
            }
            Safety.askNewApp(this, pkg)
            return
        }
        if (!cfg.optBoolean("blockNew") || !blocklist) return
        Store.edit(this) { j ->
            val rules = j.optJSONObject("rules") ?: JSONObject().also { j.put("rules", it) }
            rules.put(pkg, JSONObject().put("wifi", true).put("mobile", true))
        }
        rebuild()
    }

    // ---------------- ট্রাফিক পড়ে ফেলে দেওয়া + লগ ----------------

    private fun startReader(pfd: ParcelFileDescriptor) {
        Thread {
            try {
                val inp = FileInputStream(pfd.fileDescriptor)
                val buf = ByteArray(32767)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    if (n > 0) logPacket(buf, n)
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun logPacket(b: ByteArray, n: Int) {
        if (n < 20 || ((b[0].toInt() shr 4) and 15) != 4) return // শুধু IPv4 লগ
        val ihl = (b[0].toInt() and 15) * 4
        val proto = b[9].toInt() and 255
        val src = InetAddress.getByAddress(b.copyOfRange(12, 16))
        val dst = InetAddress.getByAddress(b.copyOfRange(16, 20))
        var sp = 0
        var dp = 0
        if ((proto == 6 || proto == 17) && n >= ihl + 4) {
            sp = ((b[ihl].toInt() and 255) shl 8) or (b[ihl + 1].toInt() and 255)
            dp = ((b[ihl + 2].toInt() and 255) shl 8) or (b[ihl + 3].toInt() and 255)
        }
        var pkg = "?"
        if (Build.VERSION.SDK_INT >= 29 && dp != 0) {
            try {
                val uid = cm.getConnectionOwnerUid(
                    proto, InetSocketAddress(src, sp), InetSocketAddress(dst, dp)
                )
                val p = packageManager.getPackagesForUid(uid)
                if (p != null && p.isNotEmpty()) pkg = p[0]
            } catch (e: Exception) {
            }
        }
        val target = "${dst.hostAddress}:$dp"
        val key = "$pkg>$target"
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastAt < 3000) return
        lastKey = key
        lastAt = now
        blockedCount++
        if (pkg != "?") Stats.hit(this, pkg) { NetNotice.reason(this, pkg)?.code ?: "other" }
        val p = when (proto) { 6 -> "TCP"; 17 -> "UDP"; 1 -> "ICMP"; else -> "IP$proto" }
        logs.add(mapOf("time" to now, "pkg" to pkg, "dst" to target, "proto" to p))
        while (logs.size > 300) logs.removeAt(0)
    }
}
