package com.you.firewall

import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.CancellationSignal
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Dart-এর lock_service.dart-এর হ্যাশের হুবহু মিল (p2$salt$hash, PBKDF2-HMAC-SHA256, ২০০০০ বার) */
object PinUtil {
    private const val ITERS = 20000

    // ভুল গোনা ও লকের সময় ফোনে সেভ থাকে (force-stop করলেও যায় না)। Kotlin ও Dart একই গোনা ব্যবহার করে।
    private fun sp(c: Context) = c.getSharedPreferences("fw_pin", Context.MODE_PRIVATE)

    /** লকের বাকি সেকেন্ড। একই বুটে elapsedRealtime, রিবুটের পর ওয়াল-ক্লক দিয়ে মাপে */
    fun leftSec(c: Context): Int {
        val p = sp(c)
        val endEl = p.getLong("endEl", 0L)
        if (endEl <= 0L) return 0
        val el = SystemClock.elapsedRealtime()
        val d = if (el >= p.getLong("setEl", 0L) && p.getInt("boot", -2) == Store.bootCount(c)) {
            endEl - el
        } else {
            p.getLong("endWall", 0L) - System.currentTimeMillis()
        }
        return if (d > 0) ((d + 999) / 1000).toInt() else 0
    }

    @Synchronized
    fun recordOk(c: Context) {
        sp(c).edit().putInt("fails", 0).remove("endEl").remove("endWall").remove("setEl").remove("boot").apply()
    }

    /** ভুল পিন গুনে রাখে। ৫ ভুলের গুণিতকে লক বসায়। ফেরত = লকের বাকি সেকেন্ড (০ = লক নেই) */
    @Synchronized
    fun recordFail(c: Context, where: String = ""): Int {
        val p = sp(c)
        val fails = p.getInt("fails", 0) + 1
        val e = p.edit().putInt("fails", fails)
        if (fails % 5 == 0) {
            val step = minOf(5, fails / 5 - 1)
            val secs = minOf(900, 30 * (1 shl step))
            val el = SystemClock.elapsedRealtime()
            e.putLong("setEl", el)
                .putLong("endEl", el + secs * 1000L)
                .putLong("endWall", System.currentTimeMillis() + secs * 1000L)
                .putInt("boot", Store.bootCount(c))
        }
        e.apply()
        try {
            Intruder.onWrongPin(c, where, fails) // ইতিহাসে লেখা, ৩-এর গুণিতকে ছবি
        } catch (ex: Exception) {
        }
        return leftSec(c)
    }

    private fun pbkdf2(pin: String, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(pin.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        mac.update(salt)
        mac.update(byteArrayOf(0, 0, 0, 1))
        var u = mac.doFinal()
        val out = u.copyOf()
        for (i in 1 until ITERS) {
            u = mac.doFinal(u)
            for (j in out.indices) out[j] = (out[j].toInt() xor u[j].toInt()).toByte()
        }
        return out
    }

    private fun matches(pin: String, stored: String): Boolean {
        if (pin.isEmpty() || stored.isEmpty()) return false
        if (stored.startsWith("p2$")) {
            val p = stored.split("$")
            if (p.size != 3) return false
            return try {
                MessageDigest.isEqual(
                    pbkdf2(pin, Base64.decode(p[1], Base64.URL_SAFE)),
                    Base64.decode(p[2], Base64.URL_SAFE)
                )
            } catch (e: Exception) {
                false
            }
        }
        // পুরনো দুর্বল হ্যাশ
        var h = 7L
        for (ch in pin) h = (h * 31 + ch.code) and 0x7fffffffL
        return h.toString() == stored
    }

    /** 0 = ঠিক, 1 = ভুল, 2 = সাময়িক লক */
    fun check(c: Context, stored: String, pin: String, where: String = ""): Int {
        if (leftSec(c) > 0) return 2
        if (matches(pin, stored)) {
            recordOk(c)
            return 0
        }
        return if (recordFail(c, where) > 0) 2 else 1
    }
}

/** লক করা অ্যাপের ওপর খোলা পিন/ফিঙ্গারপ্রিন্ট স্ক্রিন (Flutter ইঞ্জিন ছাড়া, তাই দ্রুত) */
class LockActivity : Activity() {
    private var target = ""
    private var unlocked = false
    private var bioStarted = false
    private var cancel: CancellationSignal? = null
    private lateinit var titleView: TextView
    private lateinit var errView: TextView
    private lateinit var box: EditText
    private lateinit var okBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        target = intent.getStringExtra("pkg") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#0F172A"))
        root.setPadding(dp(32), dp(32), dp(32), dp(32))

        titleView = TextView(this)
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 20f
        titleView.gravity = Gravity.CENTER
        root.addView(titleView)

        box = EditText(this)
        box.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        box.hint = "পিন দিন"
        box.setHintTextColor(Color.GRAY)
        box.setTextColor(Color.WHITE)
        box.gravity = Gravity.CENTER
        box.imeOptions = EditorInfo.IME_ACTION_DONE
        box.setOnEditorActionListener { _, _, _ ->
            verify()
            true
        }
        val lp = LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(24)
        root.addView(box, lp)

        errView = TextView(this)
        errView.setTextColor(Color.parseColor("#F87171"))
        errView.gravity = Gravity.CENTER
        root.addView(errView)

        okBtn = Button(this)
        okBtn.text = "খুলুন"
        okBtn.setOnClickListener { verify() }
        root.addView(okBtn, LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT))

        if (Store.load(this).optBoolean("bio") && Build.VERSION.SDK_INT >= 28) {
            val bio = Button(this)
            bio.text = "ফিঙ্গারপ্রিন্ট"
            bio.setOnClickListener { startBio() }
            root.addView(bio, LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        val home = Button(this)
        home.text = "হোমে যান"
        home.setOnClickListener { goHome() }
        root.addView(home, LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        val gm = intent.getIntExtra("grantMin", 0)
        titleView.text = if (intent.getBooleanExtra("guestOff", false)) "👤 গেস্ট মোড বন্ধ করবেন?"
        else if (intent.getBooleanExtra("stopFw", false)) "🛡 ফায়ারওয়াল বন্ধ করবেন?"
        else if (gm > 0) "🔓 " + label(target) + " • " + gm + " মিনিট ইন্টারনেট চালু?"
        else "🔒 " + label(target)
        errView.text = ""
        box.setText("")
        bioStarted = false
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        target = i.getStringExtra("pkg") ?: ""
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (!bioStarted && !unlocked && Build.VERSION.SDK_INT >= 28 &&
            Store.load(this).optBoolean("bio")
        ) {
            bioStarted = true
            startBio()
        }
    }

    private fun verify() {
        val where = if (intent.getBooleanExtra("guestOff", false)) "গেস্ট মোড বন্ধ করা"
        else if (intent.getBooleanExtra("stopFw", false)) "ফায়ারওয়াল বন্ধ করা"
        else "অ্যাপ লক: " + label(target)
        val r = PinUtil.check(this, Store.load(this).optString("pinHash"), box.text.toString(), where)
        box.setText("")
        when (r) {
            0 -> success()
            2 -> errView.text = "অনেকবার ভুল, ${PinUtil.leftSec(this)} সেকেন্ড পরে চেষ্টা করুন"
            else -> errView.text = "ভুল পিন"
        }
    }

    private fun success() {
        if (unlocked) return
        unlocked = true
        val gm = intent.getIntExtra("grantMin", 0)
        if (intent.getBooleanExtra("guestOff", false)) Guest.disable(this)
        else if (intent.getBooleanExtra("stopFw", false)) FirewallVpnService.stop(this) // ফোকাস চললে stop নিজেই আটকায়
        else if (gm > 0) NetNotice.grant(this, target, gm)
        else GuardService.unlock(target)
        cancel?.cancel()
        finish()
    }

    @TargetApi(28)
    private fun startBio() {
        try {
            cancel?.cancel()
            val cs = CancellationSignal()
            cancel = cs
            val p = BiometricPrompt.Builder(this)
                .setTitle("অ্যাপ আনলক")
                .setNegativeButton("পিন দিন", mainExecutor, DialogInterface.OnClickListener { _, _ -> })
                .build()
            p.authenticate(cs, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    success()
                }
            })
        } catch (e: Exception) {
        }
    }

    private fun goHome() {
        cancel?.cancel()
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }
}
