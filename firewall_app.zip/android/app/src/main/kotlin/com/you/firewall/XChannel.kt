package com.you.firewall

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * নতুন ফিচারের জন্য আলাদা চ্যানেল ("firewall/x")। MainActivity-র বড় "firewall/vpn" চ্যানেলে হাত না দিয়ে
 * নতুন মেথড এখানেই যোগ হবে।
 */
object XChannel {
    const val NAME = "firewall/x"
    private val main = Handler(Looper.getMainLooper())

    private fun longArg(call: io.flutter.plugin.common.MethodCall, k: String): Long =
        (call.argument<Number>(k) ?: 0).toLong()

    /** ভারী কাজ আলাদা থ্রেডে, ফল মেইন থ্রেডে। ত্রুটি হলে খালি/false, অ্যাপ ক্র্যাশ করে না */
    private fun bg(result: MethodChannel.Result, f: () -> Any) {
        Thread {
            val r: Any? = try {
                f()
            } catch (e: Exception) {
                null
            }
            main.post { result.success(r) }
        }.start()
    }

    fun register(engine: FlutterEngine, c: Context, activity: android.app.Activity? = null) {
        val ctx = c.applicationContext
        MethodChannel(engine.dartExecutor.binaryMessenger, NAME).setMethodCallHandler { call, result ->
            when (call.method) {
                "dbInfo" -> Thread {
                    val r: Map<String, Any> = try {
                        XDb.get(ctx).info()
                    } catch (e: Exception) {
                        mapOf("ok" to false)
                    }
                    main.post { result.success(r) }
                }.start()

                // ---- ধাপ ১: কানেকশন লগ ----
                "connApps" -> bg(result) { ConnLog.apps(ctx, longArg(call, "from")) }
                "connHosts" -> bg(result) {
                    ConnLog.hosts(ctx, call.argument<String>("pkg") ?: "", longArg(call, "from"))
                }
                "connClear" -> bg(result) { ConnLog.clear(ctx); true }

                // ---- স্ক্যাম গার্ড ----
                "scamHits" -> bg(result) { Scam.hits(ctx) }
                "scamSeen" -> bg(result) { Scam.markSeen(ctx); true }
                "scamClear" -> bg(result) { Scam.clearHits(ctx); true }
                "scamUsers" -> bg(result) { Scam.users(ctx) }
                "scamSet" -> bg(result) {
                    Scam.setUser(ctx, call.argument<String>("host") ?: "", call.argument<String>("kind") ?: "block")
                    true
                }
                "scamRemove" -> bg(result) { Scam.removeUser(ctx, call.argument<String>("host") ?: ""); true }

                // ---- নেটের মান ----
                "qualityList" -> bg(result) { NetQuality.list(ctx, longArg(call, "since")) }

                // ---- ব্ল্যাক বক্স ----
                "bbSamples" -> bg(result) {
                    Sampler.range(ctx, longArg(call, "since")).map {
                        mapOf(
                            "t" to it.t, "batt" to it.batt, "temp" to it.temp, "charging" to it.charging,
                            "mem" to it.memFree, "lowMem" to it.lowMem, "thermal" to it.thermal,
                            "screen" to it.screen, "fg" to it.fg, "data" to (it.rx + it.tx)
                        )
                    }
                }
                "bbIncidents" -> bg(result) { Triggers.list(ctx) }
                "bbSeen" -> bg(result) { Triggers.markSeen(ctx); true }
                "bbClear" -> bg(result) { Triggers.clear(ctx); true }
                // "এখন কেন?": শেষ ১০ মিনিটের সার্বিক বিশ্লেষণ (type না দিলে সবকিছু মিলিয়ে)
                "bbWhy" -> bg(result) {
                    val now = System.currentTimeMillis()
                    val type = call.argument<String>("type") ?: "now"
                    Analyzer.explain(ctx, type, Sampler.range(ctx, now - 10 * 60 * 1000L, now))
                }

                // ---- ধাপ ৩: পারমিশন অডিটর ----
                "permScan" -> bg(result) { PermAudit.scan(ctx) }
                "openPkgSettings" -> {
                    try {
                        ctx.startActivity(
                            android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.parse("package:" + (call.argument<String>("pkg") ?: ""))
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }

                // ---- ধাপ ৩: পাবলিক Wi-Fi ----
                "wifiState" -> bg(result) { WifiGuard.state(ctx) }
                "wifiTrust" -> bg(result) {
                    WifiGuard.setTrusted(ctx, call.argument<String>("ssid") ?: "", call.argument<Boolean>("on") == true)
                    true
                }
                "wifiSeen" -> bg(result) { WifiGuard.markSeen(ctx); true }
                "wifiAskPerm" -> {
                    // লোকেশন অনুমতির ডায়ালগ (SSID পড়তে লাগে)। ফল Dart পাশ আবার পড়ে দেখে
                    try {
                        activity?.requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 7301)
                        result.success(activity != null)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                "openLocationSettings" -> {
                    try {
                        ctx.startActivity(
                            android.content.Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }

                // ---- ধাপ ৪: কন্ট্রোল ----
                "ctlGet" -> bg(result) { Ctl.get(ctx, call.argument<String>("name") ?: "") }
                "ctlSet" -> bg(result) {
                    Ctl.set(ctx, call.argument<String>("name") ?: "", call.argument<String>("json") ?: "")
                }
                "autoActive" -> bg(result) { Ctl.autoActive(ctx) }
                "tradeInfo" -> bg(result) { Ctl.tradeInfo(ctx) }
                "tradeAdd" -> bg(result) { Ctl.tradeAdd(ctx, call.argument<String>("kind") ?: "trade") }

                // ---- ধাপ ৫: ল্যাব ----
                "chargerState" -> bg(result) { Lab.chargerState(ctx) }
                "chargerActive" -> bg(result) { Lab.chargerSetActive(ctx, call.argument<String>("name") ?: ""); true }
                "chargerDelete" -> bg(result) { Lab.chargerDelete(ctx, call.argument<String>("name") ?: ""); true }
                "chargerReset" -> bg(result) { Lab.chargerReset(ctx, call.argument<String>("name") ?: ""); true }
                "wifiSpots" -> bg(result) { Lab.wifiSpots(ctx) }
                "wifiMeasure" -> bg(result) { Lab.wifiMeasure(ctx, call.argument<String>("name") ?: "") }
                "wifiSpotDelete" -> bg(result) { Lab.wifiSpotDelete(ctx, call.argument<String>("name") ?: ""); true }
                "wifiSpotsClear" -> bg(result) { Lab.wifiSpotsClear(ctx); true }

                // ---- পকেট গার্ড ----
                "pocketState" -> bg(result) { PocketGuard.info(ctx) }
                "pocketCfg" -> bg(result) { PocketGuard.setCfg(ctx, call.argument<String>("json") ?: ""); true }
                "pocketArm" -> bg(result) { PocketGuard.arm(ctx) }
                // কাউন্টডাউনের সময় ভুলে চালু করলে পিন ছাড়াই বাতিল। চালু হয়ে গেলে শুধু পিন দিয়ে বন্ধ
                "pocketCancelArm" -> bg(result) {
                    if (PocketGuard.state == PocketGuard.S_ARMING) {
                        PocketGuard.disarm(ctx)
                        true
                    } else false
                }
                "pocketDisarmAsk" -> {
                    try {
                        ctx.startActivity(
                            android.content.Intent(ctx, PocketAlarmActivity::class.java)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        )
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                "pocketTest" -> bg(result) { Siren.test(ctx); true }
                "pocketLogClear" -> bg(result) { PocketGuard.clearLog(ctx); true }

                // ---- রাতের ডেটা চোর / ঠান্ডা মোড ----
                "nightInfo" -> bg(result) { NightWatch.info(ctx) }
                "nightBlock" -> bg(result) { Safety.blockApp(ctx, call.argument<String>("pkg") ?: ""); true }
                "coolInfo" -> bg(result) { CoolMode.info(ctx) }

                // ---- ফ্লোটিং বাবল ----
                "bubbleState" -> bg(result) { Bubbles.state(ctx) }
                "bubbleSet" -> bg(result) {
                    val a = org.json.JSONArray(call.argument<String>("json") ?: "[]")
                    Bubbles.setPkgs(ctx, (0 until a.length()).map { a.optString(it) })
                    // চালু থাকলে বাবল সাথে সাথে বদলায়
                    if (Bubbles.wanted(ctx) && Bubbles.canDraw(ctx)) Bubbles.start(ctx)
                    true
                }
                "bubbleMini" -> bg(result) {
                    Bubbles.setMini(ctx, call.argument<Boolean>("on") == true, call.argument<Int>("size") ?: 1)
                    true
                }
                "bubbleStart" -> bg(result) { Bubbles.start(ctx) }
                "bubbleStop" -> bg(result) { Bubbles.stop(ctx); true }
                "bubbleAskPerm" -> result.success(Bubbles.openPermission(ctx))

                // ---- রাডার, ফ্লোটিং ডট, ভয়েস অ্যালার্ট ----
                "radarSample" -> bg(result) { Wow.radar(ctx) }
                "radarBlock" -> bg(result) { Wow.block(ctx, call.argument<String>("pkg") ?: "") }
                "wowState" -> bg(result) { Wow.state(ctx) }
                "wowSet" -> bg(result) {
                    Wow.setCfg(ctx, call.argument<String>("key") ?: "", call.argument<Boolean>("on") == true)
                    true
                }
                "wowTest" -> bg(result) { Wow.testVoice(ctx); true }

                // ---- লেখা তোলার ভাসমান বাটন ----
                "grabState" -> result.success(TextGrab.state(ctx))
                "grabSet" -> {
                    TextGrab.set(ctx, call.argument<Boolean>("on"), call.argument<Number>("style")?.toInt())
                    result.success(true)
                }
                "grabAccess" -> result.success(TextGrab.openAccess(ctx))

                // ---- নতুন তিন সার্ভিস: আলসে-লক, নেট-হার্টবিট, ডেটা-পোষা ----
                "buddyState" -> bg(result) { Buddy.state(ctx) }
                "buddySet" -> bg(result) {
                    Buddy.set(ctx, call.argument<String>("key") ?: "", call.argument<Boolean>("on") == true)
                }
                "buddyOpt" -> bg(result) {
                    Buddy.setOpt(ctx, call.argument<String>("key") ?: "", (call.argument<Number>("value") ?: 0).toInt())
                    true
                }
                "buddyAskPerm" -> result.success(Buddy.openPermission(ctx))
                "buddyCode" -> bg(result) { Buddy.applyCode(ctx, call.argument<String>("code") ?: "") }
                "buddyPinWidget" -> result.success(PetWidget.pin(ctx))

                // ---- মেনুর ব্যাজ ----
                "badges" -> bg(result) {
                    mapOf("scam" to Scam.unseen(ctx), "blackbox" to Triggers.unseen(ctx), "wifi_safety" to WifiGuard.unseen(ctx))
                }

                else -> result.notImplemented()
            }
        }
    }
}
