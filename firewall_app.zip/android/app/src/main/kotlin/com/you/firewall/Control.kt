package com.you.firewall

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * ধাপ ৪: কন্ট্রোল। তিনটা ফিচার, সবার অবস্থা আলাদা SharedPreferences-এ ("fw_ctl"),
 * তাই Dart-এর কনফিগ সেভে মুছে যায় না আর পুরনো Config-এ হাত পড়ে না।
 *  - অটোমেশন: ট্রিগার (Wi-Fi নাম / চার্জিং / সময়) -> অ্যাকশন (মোড চালু / "Wi-Fi-তে সব খোলা")
 *  - প্যারেন্টাল: বেছে দেওয়া অ্যাপে দৈনিক সময় আর ঘুমের সময় বন্ধ (GuardService ধরে)
 *  - ট্রেড ব্লকার: ট্রেডিং অ্যাপে দিনে খোলা/ট্রেড/লসের সীমা ছুঁলে ২৪ ঘণ্টা লক
 */
object Ctl {
    const val AUTO = "auto"
    const val PARENTAL = "parental"
    const val TRADE = "trade"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("fw_ctl", Context.MODE_PRIVATE)

    fun get(c: Context, name: String): String {
        val d = if (name == AUTO) "[]" else "{}"
        return sp(c).getString(name, d) ?: d
    }

    private fun obj(c: Context, name: String): JSONObject = try {
        JSONObject(get(c, name))
    } catch (e: Exception) {
        JSONObject()
    }

    private fun has(a: JSONArray?, v: String): Boolean {
        if (a == null) return false
        for (i in 0 until a.length()) if (a.optString(i) == v) return true
        return false
    }

    /** Dart থেকে সেভ। ট্রেড লক চলাকালে ট্রেড সেটিং বদলানো যায় না। ফেরত = সেভ হলো কিনা */
    fun set(c: Context, name: String, json: String): Boolean {
        return try {
            if (name == AUTO) JSONArray(json) else JSONObject(json)
            if (name == TRADE && tradeLockLeftMs(c) > 0) return false
            sp(c).edit().putString(name, json).apply()
            if (name == AUTO) {
                sp(c).edit().remove("autoState").apply()
                onTick(c)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ======================= অটোমেশন =======================

    private fun charging(c: Context): Boolean {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val s = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun nowMin(): Int {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    /** from..to মিনিট-অফ-ডে, রাত পেরোনো সময়সীমাও চলে (যেমন ২২:০০–০৬:০০) */
    private fun inWindow(from: Int, to: Int, now: Int): Boolean =
        if (from == to) false else if (from < to) now in from until to else (now >= from || now < to)

    /** true/false = শর্ত মিলল/মিলল না, null = বোঝা গেল না (Wi-Fi-র নাম পড়া যায়নি), অবস্থা বদলায় না */
    private fun cond(c: Context, t: JSONObject): Boolean? = when (t.optString("type")) {
        "charging" -> charging(c)
        "time" -> inWindow(t.optInt("from", 0), t.optInt("to", 0), nowMin())
        "wifi" -> {
            val want = t.optString("ssid")
            val s = WifiGuard.ssidNow(c)
            if (s == null) null else s == want
        }
        else -> null
    }

    /** অ্যাকশন চালু/বন্ধ। বন্ধের সময় আগের মান ফেরে। [prev]-এ আগের মান জমা থাকে */
    private fun apply(c: Context, id: String, a: JSONObject, on: Boolean) {
        val st = try { JSONObject(sp(c).getString("autoPrev", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        when (a.optString("type")) {
            "mode" -> {
                if (on) {
                    var old = ""
                    Store.edit(c) {
                        old = it.optString("activeMode")
                        it.put("activeMode", a.optString("value"))
                    }
                    st.put(id, old)
                } else {
                    val old = st.optString(id, "")
                    Store.edit(c) { if (it.optString("activeMode") == a.optString("value")) it.put("activeMode", old) }
                    st.remove(id)
                }
            }
            "wifiOpen" -> {
                if (on) {
                    var old = false
                    Store.edit(c) {
                        old = it.optBoolean("wifiOpen")
                        it.put("wifiOpen", a.optBoolean("value", true))
                    }
                    st.put(id, old)
                } else {
                    val old = st.optBoolean(id, false)
                    Store.edit(c) { it.put("wifiOpen", old) }
                    st.remove(id)
                }
            }
        }
        sp(c).edit().putString("autoPrev", st.toString()).apply()
        try { FirewallVpnService.reload(c) } catch (e: Exception) {}
    }

    /** VPN tick (৩০ সেকেন্ড) আর নেট বদলের সময়। শুধু অবস্থা বদলালে অ্যাকশন চলে */
    @Synchronized
    fun onTick(c: Context) {
        try {
            val ctx = c.applicationContext
            val arr = JSONArray(get(ctx, AUTO))
            val state = try { JSONObject(sp(ctx).getString("autoState", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
            val live = HashSet<String>()
            for (i in 0 until arr.length()) {
                val r = arr.optJSONObject(i) ?: continue
                val id = r.optString("id")
                live.add(id)
                val was = state.optBoolean(id, false)
                if (!r.optBoolean("on", true)) {
                    if (was) {
                        apply(ctx, id, r.optJSONObject("action") ?: JSONObject(), false)
                        state.put(id, false)
                    }
                    continue
                }
                val now = cond(ctx, r.optJSONObject("trigger") ?: continue) ?: continue
                if (now != was) {
                    apply(ctx, id, r.optJSONObject("action") ?: JSONObject(), now)
                    state.put(id, now)
                    if (now) XNotify.show(ctx, 7400 + (id.hashCode() and 0xff), "অটোমেশন: ${r.optString("name")}", "শর্ত মিলেছে, নিয়ম চালু হলো।", "automation")
                }
            }
            for (k in state.keys().asSequence().toList()) if (k !in live) state.remove(k)
            sp(ctx).edit().putString("autoState", state.toString()).apply()
        } catch (e: Exception) {
        }
    }

    /** পেজের জন্য: কোন নিয়ম এখন চালু */
    fun autoActive(c: Context): List<String> = try {
        val s = JSONObject(sp(c).getString("autoState", "{}") ?: "{}")
        s.keys().asSequence().filter { s.optBoolean(it) }.toList()
    } catch (e: Exception) {
        emptyList()
    }

    // ======================= প্যারেন্টাল =======================

    fun parentalHas(c: Context, pkg: String): Boolean {
        val p = obj(c, PARENTAL)
        return p.optBoolean("on") && has(p.optJSONArray("apps"), pkg)
    }

    /** "bed" = ঘুমের সময়, "parent" = দৈনিক সময় শেষ, null = ঠিক আছে */
    fun parentalReason(c: Context, pkg: String, usageMs: Long): String? {
        val p = obj(c, PARENTAL)
        if (!p.optBoolean("on") || !has(p.optJSONArray("apps"), pkg)) return null
        if (p.optBoolean("bedOn") && inWindow(p.optInt("bedFrom", 22 * 60), p.optInt("bedTo", 6 * 60), nowMin())) return "bed"
        val m = p.optInt("minutes", 0)
        if (m > 0 && usageMs >= m * 60000L) return "parent"
        return null
    }

    // ======================= ট্রেড ব্লকার =======================

    private fun today(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}${c.get(Calendar.DAY_OF_YEAR)}"
    }

    private fun tradeState(c: Context): JSONObject {
        val s = try { JSONObject(sp(c).getString("tradeState", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        if (s.optString("day") != today()) {
            val keepLock = s.optLong("lockUntil", 0L)
            return JSONObject().put("day", today()).put("trades", 0).put("losses", 0).put("opens", 0).put("lockUntil", keepLock)
        }
        return s
    }

    private fun saveTrade(c: Context, s: JSONObject) {
        sp(c).edit().putString("tradeState", s.toString()).apply()
    }

    fun tradeLockLeftMs(c: Context): Long {
        val s = try { JSONObject(sp(c).getString("tradeState", "{}") ?: "{}") } catch (e: Exception) { return 0L }
        return maxOf(0L, s.optLong("lockUntil", 0L) - System.currentTimeMillis())
    }

    fun tradeBlocked(c: Context, pkg: String): Boolean {
        val t = obj(c, TRADE)
        if (!t.optBoolean("on") || !has(t.optJSONArray("apps"), pkg)) return false
        return tradeLockLeftMs(c) > 0
    }

    private fun checkTradeLimits(c: Context, t: JSONObject, s: JSONObject) {
        val mt = t.optInt("maxTrades", 0)
        val ml = t.optInt("maxLosses", 0)
        val mo = t.optInt("maxOpens", 0)
        val hit = (mt > 0 && s.optInt("trades") >= mt) ||
            (ml > 0 && s.optInt("losses") >= ml) ||
            (mo > 0 && s.optInt("opens") > mo)
        if (hit && s.optLong("lockUntil", 0L) < System.currentTimeMillis()) {
            val h = t.optInt("lockHours", 24).coerceIn(1, 72)
            s.put("lockUntil", System.currentTimeMillis() + h * 3600000L)
            try {
                XNotify.show(c, 7410, "ট্রেড ব্লকার: লক হলো", "আজকের সীমা ছুঁয়েছে। ট্রেডিং অ্যাপ $h ঘণ্টা বন্ধ।", "trade_blocker")
            } catch (e: Exception) {
            }
        }
    }

    /** GuardService ডাকে: ট্রেডিং অ্যাপ নতুন করে সামনে এলে খোলার সংখ্যা বাড়ে */
    fun tradeOpened(c: Context, pkg: String) {
        try {
            val t = obj(c, TRADE)
            if (!t.optBoolean("on") || !has(t.optJSONArray("apps"), pkg)) return
            val s = tradeState(c)
            s.put("opens", s.optInt("opens") + 1)
            checkTradeLimits(c, t, s)
            saveTrade(c, s)
        } catch (e: Exception) {
        }
    }

    /** কাউন্ট বাড়ানো (হাতে): kind = "trade" | "loss"। ফেরত = পেজের অবস্থা */
    fun tradeAdd(c: Context, kind: String): Map<String, Any?> {
        val t = obj(c, TRADE)
        if (t.optBoolean("on")) {
            val s = tradeState(c)
            if (kind == "trade") s.put("trades", s.optInt("trades") + 1)
            if (kind == "loss") {
                s.put("losses", s.optInt("losses") + 1)
                s.put("trades", maxOf(s.optInt("trades"), s.optInt("losses")))
            }
            checkTradeLimits(c, t, s)
            saveTrade(c, s)
        }
        return tradeInfo(c)
    }

    fun tradeInfo(c: Context): Map<String, Any?> {
        val s = tradeState(c)
        return mapOf(
            "trades" to s.optInt("trades"), "losses" to s.optInt("losses"), "opens" to s.optInt("opens"),
            "lockLeftMs" to tradeLockLeftMs(c)
        )
    }
}
