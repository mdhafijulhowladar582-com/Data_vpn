package com.you.firewall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** সার্ভিসের ভেতর থেকে রেজিস্টার হয় (স্ক্রিন ইভেন্ট manifest-এ চলে না) */
class ScreenReceiver(private val onChange: (Boolean) -> Unit) : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        onChange(i.action == Intent.ACTION_SCREEN_ON)
    }
}
