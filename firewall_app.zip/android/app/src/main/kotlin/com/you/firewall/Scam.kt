package com.you.firewall

import android.content.ContentValues
import android.content.Context

/**
 * স্ক্যাম গার্ড: ইঞ্জিনের DNS-এ নকল/ফিশিং মনে হওয়া নাম আটকায়, ব্লক হলে আলাদা নোটিফিকেশন।
 * তিনটা নিয়ম (সবই অনুমান-ভিত্তিক, তাই সব নকল ধরা পড়বে না, আর কখনো ভুলও ধরতে পারে):
 *  ১. নিজের যোগ করা ডোমেইন (সাবডোমেইনসহ)
 *  ২. বিকাশ/নগদ/পেপ্যালের নাম আছে অথচ আসল ডোমেইন নয়
 *  ৩. ঝুঁকিপূর্ণ এক্সটেনশন (.xyz, .top ইত্যাদি) + "login", "verify", "bonus"-জাতীয় শব্দ
 * ভুল ধরা ডোমেইন পেজ থেকে "ছাড়ুন" দিলে আর আটকাবে না।
 * কাজ করে শুধু ইঞ্জিনের অ্যাপে (ব্রাউজার ও মেসেঞ্জার ইঞ্জিনে না থাকলে লিংক ধরা পড়বে না)।
 */
object Scam {
    private val BRANDS = mapOf(
        "bkash" to listOf("bkash.com", "bka.sh"),
        "nagad" to listOf("nagad.com.bd"),
        "paypal" to listOf("paypal.com", "paypal.me", "paypalobjects.com")
    )
    private val RISKY_TLD = setOf(
        "xyz", "top", "icu", "click", "cfd", "sbs", "buzz", "rest", "monster", "cyou", "work", "support"
    )
    private val BAIT = listOf(
        "login", "verify", "secure", "bonus", "prize", "gift", "claim", "wallet", "kyc", "reward", "giveaway"
    )

    private const val REFRESH_MS = 10_000L
    private const val NOTIFY_GAP_MS = 10L * 60 * 1000
    @Volatile private var at = 0L
    @Volatile private var on = false
    @Volatile private var block: Set<String> = emptySet()
    @Volatile private var allow: Set<String> = emptySet()
    private val lastNotify = HashMap<String, Long>()

    private fun refresh(c: Context) {
        val now = System.currentTimeMillis()
        if (now - at < REFRESH_MS) return
        at = now
        on = Store.load(c).optBoolean("scamGuard", false)
        val b = HashSet<String>()
        val a = HashSet<String>()
        try {
            XDb.get(c).readableDatabase.rawQuery("SELECT host, kind FROM scam_user", null).use {
                while (it.moveToNext()) {
                    if (it.getString(1) == "allow") a.add(it.getString(0)) else b.add(it.getString(0))
                }
            }
        } catch (e: Exception) {
        }
        block = b
        allow = a
    }

    private fun under(set: Set<String>, name: String): Boolean {
        if (set.isEmpty()) return false
        var n = name
        while (true) {
            if (set.contains(n)) return true
            val i = n.indexOf('.')
            if (i < 0) return false
            n = n.substring(i + 1)
        }
    }

    /** কারণ (বাংলা) বা null (আটকানোর দরকার নেই) */
    private fun verdict(name: String): String? {
        if (under(block, name)) return "আপনার নিজের ব্লক তালিকায় আছে"
        for ((brand, official) in BRANDS) {
            if (name.contains(brand) && official.none { name == it || name.endsWith(".$it") }) {
                return "\"$brand\"-এর নাম আছে, কিন্তু আসল ডোমেইন নয়"
            }
        }
        val tld = name.substringAfterLast('.')
        if (tld in RISKY_TLD) {
            val first = name.substringBeforeLast('.')
            val hit = BAIT.firstOrNull { first.contains(it) }
            if (hit != null) return "সন্দেহজনক এক্সটেনশন (.$tld) আর \"$hit\" শব্দ"
        }
        return null
    }

    /** true = এই নাম আটকাতে হবে (ইঞ্জিন NXDOMAIN দেবে)। DNS থ্রেড থেকে ডাকা হয়, তাই দ্রুত ও ত্রুটি-নিরাপদ */
    fun check(c: Context, rawName: String): Boolean {
        try {
            refresh(c)
            if (!on) return false
            val name = rawName.lowercase().trimEnd('.')
            if (name.isEmpty() || under(allow, name)) return false
            val why = verdict(name) ?: return false
            hit(c, name, why)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun hit(c: Context, host: String, why: String) {
        val now = System.currentTimeMillis()
        var notify = false
        synchronized(lastNotify) {
            val last = lastNotify[host] ?: 0L
            if (now - last > NOTIFY_GAP_MS) {
                lastNotify[host] = now
                notify = true
                if (lastNotify.size > 200) lastNotify.clear()
            }
        }
        if (!notify) return // একই নাম বারবার এলে একটাই সারি ও নোটিফিকেশন
        EngineStats.add("🛑 স্ক্যাম: $host")
        Thread {
            try {
                val v = ContentValues()
                v.put("t", now)
                v.put("host", host)
                v.put("why", why)
                XDb.get(c).writableDatabase.insert("scam_hits", null, v)
            } catch (e: Exception) {
            }
        }.also { it.isDaemon = true }.start()
        XNotify.show(
            c, 7001, "সন্দেহজনক সাইট আটকানো হয়েছে",
            "$host\n$why\nভুল হলে স্ক্যাম গার্ড পেজ থেকে ছাড় দিতে পারবেন।", "scam"
        )
    }

    // ---------------- পেজের জন্য ----------------

    fun hits(c: Context): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(c).readableDatabase.rawQuery(
            "SELECT id, t, host, why, seen FROM scam_hits ORDER BY t DESC LIMIT 100", null
        ).use {
            while (it.moveToNext()) {
                out.add(
                    mapOf(
                        "id" to it.getLong(0), "t" to it.getLong(1),
                        "host" to (it.getString(2) ?: ""), "why" to (it.getString(3) ?: ""),
                        "seen" to (it.getInt(4) != 0)
                    )
                )
            }
        }
        return out
    }

    fun unseen(c: Context): Int =
        XDb.get(c).readableDatabase.rawQuery("SELECT COUNT(*) FROM scam_hits WHERE seen = 0", null)
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun markSeen(c: Context) {
        val v = ContentValues()
        v.put("seen", 1)
        XDb.get(c).writableDatabase.update("scam_hits", v, "seen = 0", null)
    }

    fun clearHits(c: Context) {
        XDb.get(c).writableDatabase.delete("scam_hits", null, null)
    }

    /** kind = "block" বা "allow" */
    fun setUser(c: Context, host: String, kind: String) {
        val h = DomainFilter.norm(host)
        if (h.isEmpty() || !h.contains('.')) return
        val v = ContentValues()
        v.put("host", h)
        v.put("kind", kind)
        XDb.get(c).writableDatabase.insertWithOnConflict("scam_user", null, v, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
        at = 0L // পরের প্রশ্নেই নতুন তালিকা
    }

    fun removeUser(c: Context, host: String) {
        XDb.get(c).writableDatabase.delete("scam_user", "host = ?", arrayOf(host))
        at = 0L
    }

    fun users(c: Context): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        XDb.get(c).readableDatabase.rawQuery("SELECT host, kind FROM scam_user ORDER BY kind, host", null).use {
            while (it.moveToNext()) out.add(mapOf("host" to it.getString(0), "kind" to it.getString(1)))
        }
        return out
    }
}
