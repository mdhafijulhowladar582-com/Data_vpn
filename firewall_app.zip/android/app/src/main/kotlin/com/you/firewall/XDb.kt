package com.you.firewall

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * নতুন ফিচারের লগ রাখার ডেটাবেস। সেটিংস আগের মতোই Store (SharedPreferences)-এ থাকে,
 * এখানে শুধু বাড়তে থাকা ডেটা: কানেকশন লগ, স্যাম্পল, ইনসিডেন্ট, স্ক্যাম ব্লক, নেটের মান।
 * Room নয়: CI প্রতি বিল্ডে Gradle নতুন বানায়, তাই বাড়তি লাইব্রেরি/প্লাগিন প্যাচ এড়ানো হয়েছে।
 */
class XDb private constructor(c: Context) :
    SQLiteOpenHelper(c.applicationContext, "fw_x.db", null, VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        createV1(db)
        createV2(db)
    }

    private fun createV1(db: SQLiteDatabase) {
        // কোন অ্যাপ কোথায় কত বাইট (ধাপ ১: কানেকশন লগ)
        db.execSQL(
            "CREATE TABLE conn_log (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER NOT NULL, pkg TEXT, " +
                "host TEXT, ip TEXT, port INTEGER, up INTEGER, down INTEGER, fg INTEGER)"
        )
        db.execSQL("CREATE INDEX idx_conn_t ON conn_log(t)")
        db.execSQL("CREATE INDEX idx_conn_pkg_t ON conn_log(pkg, t)")

        // ফোনের অবস্থার স্যাম্পল (ধাপ ২: ব্ল্যাক বক্স)
        db.execSQL(
            "CREATE TABLE samples (" +
                "t INTEGER PRIMARY KEY, batt INTEGER, temp INTEGER, charging INTEGER, " +
                "mem_free INTEGER, low_mem INTEGER, thermal INTEGER, screen INTEGER, " +
                "fg TEXT, rx INTEGER, tx INTEGER)"
        )

        // ধরা পড়া ঘটনা ও তার আগের স্ন্যাপশট (ধাপ ২)
        db.execSQL(
            "CREATE TABLE incidents (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER NOT NULL, type TEXT, " +
                "title TEXT, detail TEXT, snapshot TEXT, seen INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX idx_inc_t ON incidents(t)")
    }

    private fun createV2(db: SQLiteDatabase) {
        // আটকানো নকল/স্ক্যাম ডোমেইন (ধাপ ১)
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS scam_hits (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER NOT NULL, host TEXT, " +
                "why TEXT, seen INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_scam_t ON scam_hits(t)")
        // নিজের যোগ করা ব্লক ডোমেইন (kind = 'block') আর ভুল ধরা ডোমেইনের ছাড় (kind = 'allow')
        db.execSQL("CREATE TABLE IF NOT EXISTS scam_user (host TEXT PRIMARY KEY, kind TEXT NOT NULL)")
        // নেটের মান: প্রতি ৩০ সেকেন্ডের পিং (ms), ok = 0 হলে পৌঁছায়নি
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS net_ping (" +
                "t INTEGER PRIMARY KEY, net TEXT, ms INTEGER, ok INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
        // পুরনো ডেটা না মুছে শুধু নতুন টেবিল যোগ
        if (oldV < 3) createV2(db) // IF NOT EXISTS, তাই আগের ভার্সন ২ থাকলেও নিরাপদ
    }

    /** পুরনো সারি মোছা: কানেকশন লগ ১৪ দিন, স্যাম্পল ২৪ ঘণ্টা, ইনসিডেন্ট ৯০ দিন */
    fun prune(now: Long) {
        try {
            val db = writableDatabase
            val day = 24L * 3600 * 1000
            db.delete("conn_log", "t < ?", arrayOf((now - 14 * day).toString()))
            db.delete("samples", "t < ?", arrayOf((now - day).toString()))
            db.delete("incidents", "t < ?", arrayOf((now - 90 * day).toString()))
            db.delete("scam_hits", "t < ?", arrayOf((now - 90 * day).toString()))
            db.delete("net_ping", "t < ?", arrayOf((now - 3 * day).toString()))
        } catch (e: Exception) {
        }
    }

    private fun count(db: SQLiteDatabase, table: String): Long =
        db.rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** ডেটাবেস ঠিকমতো খুলছে কিনা দেখার জন্য: টেবিলে কত সারি */
    fun info(): Map<String, Any> {
        val db = readableDatabase
        return mapOf(
            "ok" to true,
            "version" to VERSION,
            "conn_log" to count(db, "conn_log"),
            "samples" to count(db, "samples"),
            "incidents" to count(db, "incidents"),
            "scam_hits" to count(db, "scam_hits"),
            "net_ping" to count(db, "net_ping")
        )
    }

    companion object {
        const val VERSION = 3

        @Volatile private var inst: XDb? = null

        fun get(c: Context): XDb = inst ?: synchronized(this) {
            inst ?: XDb(c).also { inst = it }
        }
    }
}
