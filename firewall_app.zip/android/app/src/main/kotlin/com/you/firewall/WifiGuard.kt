package com.you.firewall

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager

/**
 * পাবলিক Wi-Fi সতর্কতা: নেটের নাম (SSID) বিশ্বস্ত তালিকায় না থাকলে সতর্ক করে, আর "কড়া মোড" চালু থাকলে
 * অচেনা Wi-Fi-তে "Wi-Fi-তে সব খোলা" সেটিং নিজে থেকে থামিয়ে দেয় (VPN সার্ভিস [untrustedNow] দেখে)।
 *
 * সীমা: Android SSID দেয় শুধু লোকেশন অনুমতি আর লোকেশন চালু থাকলে, আর অ্যাপ ব্যাকগ্রাউন্ডে থাকলে অনেক ফোনে
 * "unknown" ফেরায়। তাই নাম পড়া না গেলে কিছুই করে না (ভুল সতর্কতা নয়), আর অ্যাপ/পেজ খুললে ঠিকমতো পড়ে।
 */
object WifiGuard {
    @Volatile var untrustedNow = false
    @Volatile private var lastSeen = ""

    private fun sp(c: Context) = c.getSharedPreferences("fw_wifi", Context.MODE_PRIVATE)

    fun hasPerm(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun enabled(c: Context): Boolean = Store.load(c).optBoolean("wifiGuard", false)

    fun trusted(c: Context): Set<String> = HashSet(sp(c).getStringSet("trusted", emptySet()) ?: emptySet())

    fun setTrusted(c: Context, ssid: String, on: Boolean) {
        if (ssid.isEmpty()) return
        val s = trusted(c).toMutableSet()
        if (on) s.add(ssid) else s.remove(ssid)
        sp(c).edit().putStringSet("trusted", s).apply()
        onTick(c, true) // বদলের সাথে সাথে হিসাব মেলানো
    }

    fun unseen(c: Context): Int = sp(c).getInt("unseen", 0)
    fun markSeen(c: Context) { sp(c).edit().putInt("unseen", 0).apply() }

    private fun onWifi(c: Context): Boolean {
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val cap = cm.getNetworkCapabilities(n) ?: continue
                if (cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return true
            }
        } catch (e: Exception) {
        }
        return false
    }

    /** পড়া না গেলে null */
    @Suppress("DEPRECATION")
    private fun readSsid(c: Context): String? {
        if (!hasPerm(c)) return null
        return try {
            val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            var s = wm.connectionInfo?.ssid ?: return null
            if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
            if (s.isEmpty() || s == "<unknown ssid>" || s == "0x") null else s
        } catch (e: Exception) {
            null
        }
    }

    /** অটোমেশনের জন্য: Wi-Fi-তে থাকলে নাম, নইলে "" (মোবাইল ডেটা), পড়া না গেলে null */
    fun ssidNow(c: Context): String? {
        val ctx = c.applicationContext
        if (!onWifi(ctx)) return ""
        return readSsid(ctx)
    }

    /** VPN সার্ভিসের tick (৩০ সেকেন্ড) আর নেট বদলের সময় ডাকা হয় */
    fun onTick(c: Context, force: Boolean = false) {
        try {
            val ctx = c.applicationContext
            if (!enabled(ctx)) {
                setUntrusted(ctx, false)
                return
            }
            if (!onWifi(ctx)) {
                lastSeen = ""
                setUntrusted(ctx, false)
                return
            }
            val ssid = readSsid(ctx) ?: return // পড়া গেল না: আগের অবস্থা রেখে দিই
            val isTrusted = ssid in trusted(ctx)
            if (!isTrusted && ssid != lastSeen) {
                sp(ctx).edit().putInt("unseen", unseen(ctx) + 1).apply()
                XNotify.show(
                    ctx, 7120, "অচেনা Wi-Fi-তে যুক্ত",
                    "\"$ssid\" আপনার বিশ্বস্ত তালিকায় নেই। পাবলিক Wi-Fi-তে ব্যাংকিং বা পাসওয়ার্ড দেওয়া এড়ান।" +
                        if (Store.load(ctx).optBoolean("wifiStrict", true)) " কড়া মোড চালু, তাই \"Wi-Fi-তে সব খোলা\" এখানে বন্ধ।" else "",
                    "wifi_safety"
                )
            }
            lastSeen = ssid
            setUntrusted(ctx, !isTrusted)
        } catch (e: Exception) {
        }
    }

    /** অবস্থা বদলালে (আর কড়া মোড চালু থাকলে) VPN নতুন করে সাজায়, যাতে "সব খোলা" সেটিং ঠিক হয় */
    private fun setUntrusted(ctx: Context, v: Boolean) {
        if (untrustedNow == v) return
        untrustedNow = v
        try {
            if (FirewallVpnService.running && Store.load(ctx).optBoolean("wifiOpen")) FirewallVpnService.reload(ctx)
        } catch (e: Exception) {
        }
    }

    /** পেজের জন্য। অ্যাপ সামনে থাকে, তাই এখানে নাম পড়া যায় */
    fun state(c: Context): Map<String, Any?> {
        val ctx = c.applicationContext
        onTick(ctx, true)
        val wifi = onWifi(ctx)
        val ssid = if (wifi) readSsid(ctx) else null
        return mapOf(
            "perm" to hasPerm(ctx),
            "onWifi" to wifi,
            "ssid" to ssid,
            "trusted" to (ssid != null && ssid in trusted(ctx)),
            "list" to trusted(ctx).sorted()
        )
    }
}
