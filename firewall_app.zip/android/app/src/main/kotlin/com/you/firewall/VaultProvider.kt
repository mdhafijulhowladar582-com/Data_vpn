package com.you.firewall

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.FileNotFoundException

/** ভল্টের ডিক্রিপ্ট করা অস্থায়ী কপি অন্য অ্যাপকে দেখানোর জন্য। শুধু আমরা যে URI-তে অনুমতি দিই সেগুলোই খোলে। */
class VaultProvider : ContentProvider() {
    override fun onCreate() = true

    private fun idOf(uri: Uri): String {
        val id = uri.pathSegments.firstOrNull() ?: throw FileNotFoundException()
        if (!Regex("[0-9a-f]{32}").matches(id)) throw FileNotFoundException()
        return id
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw FileNotFoundException("read only")
        val ctx = context ?: throw FileNotFoundException()
        val f = VaultManager.prepareTemp(ctx, idOf(uri))
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val ctx = context ?: return null
        val e = try {
            VaultManager.meta(ctx, idOf(uri))
        } catch (ex: Exception) {
            null
        }
        if (e == null) return null
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        val row = cols.map {
            when (it) {
                OpenableColumns.DISPLAY_NAME -> e.optString("name")
                OpenableColumns.SIZE -> e.optLong("size")
                else -> null
            }
        }
        c.addRow(row)
        return c
    }

    override fun getType(uri: Uri): String? {
        val ctx = context ?: return null
        return try {
            VaultManager.meta(ctx, idOf(uri))?.optString("mime")
        } catch (e: Exception) {
            null
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(
        uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?
    ) = 0
}
