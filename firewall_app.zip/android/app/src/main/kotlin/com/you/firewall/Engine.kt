package com.you.firewall

import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.SocketChannel
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.SynchronousQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** ইঞ্জিনের গণনা ও লগ (ইঞ্জিন-পেজ এখান থেকে পড়ে) */
object EngineStats {
    @Volatile var running = false
    val queries = AtomicInteger(0)
    val blocked = AtomicInteger(0)
    val tcp = AtomicInteger(0)
    val udp = AtomicInteger(0)
    val errors = AtomicInteger(0)
    private val lines = ArrayDeque<String>()

    fun add(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        synchronized(lines) {
            lines.addFirst("$t $s")
            while (lines.size > 300) lines.removeLast()
        }
    }

    fun snapshot(): List<String> = synchronized(lines) { ArrayList(lines) }

    fun clear() {
        synchronized(lines) { lines.clear() }
        queries.set(0)
        blocked.set(0)
        tcp.set(0)
        udp.set(0)
        errors.set(0)
    }
}

/** ডোমেইন ও তার সাবডোমেইন মিলিয়ে আটকানোর তালিকা */
class DomainFilter(builtin: Boolean, custom: List<String>) {
    private val set = HashSet<String>()

    init {
        if (builtin) set.addAll(BUILTIN)
        for (d in custom) {
            val n = norm(d)
            if (n.isNotEmpty()) set.add(n)
        }
    }

    fun blocked(name: String): Boolean {
        var n = name.lowercase().trimEnd('.')
        while (true) {
            if (set.contains(n)) return true
            val i = n.indexOf('.')
            if (i < 0) return false
            n = n.substring(i + 1)
        }
    }

    companion object {
        fun norm(s: String): String {
            var d = s.trim().lowercase()
            d = d.removePrefix("http://").removePrefix("https://")
            val slash = d.indexOf('/')
            if (slash >= 0) d = d.substring(0, slash)
            val colon = d.indexOf(':')
            if (colon >= 0) d = d.substring(0, colon)
            d = d.removePrefix("*.").removePrefix(".").trimEnd('.')
            return d
        }

        // শুরুর তালিকা, আপনি নিজের ডোমেইন যোগ করতে পারবেন
        val BUILTIN = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "googletagservices.com", "googletagmanager.com", "google-analytics.com",
            "app-measurement.com", "adservice.google.com", "2mdn.net",
            "an.facebook.com", "applovin.com", "applvn.com", "unityads.unity3d.com",
            "ads.unity3d.com", "adcolony.com", "ironsrc.com", "ironsource.mobi",
            "supersonicads.com", "vungle.com", "chartboost.com", "inmobi.com",
            "mopub.com", "startapp.com", "mintegral.com", "mtgglobals.com",
            "tapjoy.com", "fyber.com", "smaato.net", "pubnative.net", "criteo.com",
            "criteo.net", "taboola.com", "outbrain.com", "adnxs.com",
            "rubiconproject.com", "pubmatic.com", "openx.net", "casalemedia.com",
            "scorecardresearch.com", "moatads.com", "adsrvr.org", "amazon-adsystem.com",
            "adform.net", "bidswitch.net", "appsflyer.com", "adjust.com", "adjust.io",
            "flurry.com", "mixpanel.com", "amplitude.com", "kochava.com", "singular.net",
            "pangleglobal.com", "popads.net", "propellerads.com", "exoclick.com",
            "trafficjunky.net", "mc.yandex.ru", "ads.yahoo.com", "advertising.com",
            "hotjar.com", "umeng.com", "umengcloud.com",
            "adsafeprotected.com", "doubleverify.com", "quantserve.com", "serving-sys.com",
            "smartadserver.com", "teads.tv", "sharethrough.com", "yieldmo.com",
            "ads.twitter.com", "ads-api.twitter.com", "analytics.tiktok.com",
            "ads.linkedin.com", "adcash.com", "revcontent.com", "mgid.com"
        )

        // জনপ্রিয় DoH সার্ভারের নাম। আটকালে অ্যাপ সাধারণ DNS-এ ফেরে (যেখানে ফিল্টার কাজ করে)।
        // সতর্কতা: ফোনের Private DNS-এ এদের কোনোটা দেওয়া থাকলে নেট বন্ধ হতে পারে, তাই ডিফল্টে বন্ধ
        val DOH = listOf(
            "dns.google", "dns.google.com", "cloudflare-dns.com", "mozilla.cloudflare-dns.com",
            "dns.quad9.net", "doh.opendns.com", "dns.adguard-dns.com", "dns.nextdns.io",
            "doh.dns.sb", "doh.cleanbrowsing.org"
        )
    }
}

private const val M32 = 0xFFFFFFFFL
private const val F_FIN = 1
private const val F_SYN = 2
private const val F_RST = 4
private const val F_ACK = 16
private const val MAXQ = 262144
private const val FAKE_DNS = 0x0A080001 // 10.8.0.1

internal data class FKey(val src: Int, val sp: Int, val dst: Int, val dp: Int)

internal class Seg(val seq: Long, val data: ByteArray, val fin: Boolean, var sentAt: Long, var tries: Int)

/**
 * বাছা অ্যাপের ট্রাফিক VPN-এর ভেতরে ধরে নিজে ইন্টারনেটে পৌঁছে দেয়।
 * DNS প্রশ্নে ডোমেইন দেখে আটকায়। শুধু IPv4 (IPv6 ফেলে দেয়, DNS-এ AAAA খালি উত্তর)।
 * fwdUids-এর বাইরের অ্যাপের ফ্লো onDrop-এ যায় (ব্লক)।
 */
class Engine(
    private val svc: VpnService,
    pfd: ParcelFileDescriptor,
    private val fwdUids: Set<Int>,
    private val cm: ConnectivityManager,
    private val filter: DomainFilter,
    private val upstream: () -> List<InetAddress>,
    private val onDrop: (ByteArray, Int) -> Unit,
    private val onFatal: () -> Unit
) {
    @Volatile private var alive = true
    private val inp = FileInputStream(pfd.fileDescriptor)
    private val out = FileOutputStream(pfd.fileDescriptor)
    private val outLock = Any()
    // আগের cached pool-এর মতোই, শুধু থ্রেড সর্বোচ্চ ১০২৪। ভরে গেলে নতুন কাজ বাদ (RejectedExecutionException)
    private val pool = ThreadPoolExecutor(
        0, 1024, 60L, TimeUnit.SECONDS, SynchronousQueue<Runnable>()
    ) { r -> Thread(r).also { it.isDaemon = true } }
    private val timer = Executors.newSingleThreadScheduledExecutor { r -> Thread(r).also { it.isDaemon = true } }
    private val tcp = ConcurrentHashMap<FKey, TcpFlow>()
    private val udp = ConcurrentHashMap<FKey, UdpFlow>()
    private val deny = HashMap<FKey, Long>() // শুধু রিডার থ্রেড ছোঁয়
    private val EOF = ByteArray(0)
    private val EMPTY = ByteArray(0)

    private var errStart = 0L
    private var errCnt = 0
    private var fatalDone = false

    val isAlive: Boolean get() = alive

    fun start() {
        EngineStats.running = true
        EngineStats.add("ইঞ্জিন চালু")
        Thread { readLoop() }.also { it.isDaemon = true }.start()
        timer.scheduleWithFixedDelay(Runnable { tick() }, 250, 250, TimeUnit.MILLISECONDS)
    }

    fun stop() {
        if (!alive) return
        alive = false
        EngineStats.running = false
        EngineStats.add("ইঞ্জিন বন্ধ")
        try { timer.shutdownNow() } catch (e: Exception) {}
        for (f in tcp.values.toList()) f.close(false)
        for (f in udp.values.toList()) {
            try { f.sock.close() } catch (e: Exception) {}
        }
        tcp.clear()
        udp.clear()
        try { pool.shutdownNow() } catch (e: Exception) {}
    }

    // ---------------- বাইট সহায়ক ----------------

    private fun u8(b: ByteArray, i: Int): Int = b[i].toInt() and 255
    private fun u16(b: ByteArray, i: Int): Int = (u8(b, i) shl 8) or u8(b, i + 1)
    private fun u32(b: ByteArray, i: Int): Long =
        (u16(b, i).toLong() shl 16) or u16(b, i + 2).toLong()
    private fun ip4(b: ByteArray, i: Int): Int =
        (u8(b, i) shl 24) or (u8(b, i + 1) shl 16) or (u8(b, i + 2) shl 8) or u8(b, i + 3)

    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v shr 8).toByte()
        b[i + 1] = v.toByte()
    }

    private fun put32(b: ByteArray, i: Int, v: Long) {
        b[i] = (v shr 24).toByte()
        b[i + 1] = (v shr 16).toByte()
        b[i + 2] = (v shr 8).toByte()
        b[i + 3] = v.toByte()
    }

    private fun putI(b: ByteArray, i: Int, v: Int) {
        b[i] = (v ushr 24).toByte()
        b[i + 1] = (v ushr 16).toByte()
        b[i + 2] = (v ushr 8).toByte()
        b[i + 3] = v.toByte()
    }

    private fun toAddr(v: Int): InetAddress = InetAddress.getByAddress(
        byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
    )

    private fun add(a: Long, n: Int): Long = (a + n) and M32

    private fun diff(a: Long, b: Long): Long {
        val d = (a - b) and M32
        return if (d >= 0x80000000L) d - 0x100000000L else d
    }

    private fun csum(b: ByteArray, off: Int, len: Int, init: Long): Int {
        var sum = init
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += u16(b, i).toLong()
            i += 2
        }
        if (i < end) sum += (u8(b, i) shl 8).toLong()
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun pseudo(src: Int, dst: Int, proto: Int, len: Int): Long =
        (src ushr 16).toLong() + (src and 0xFFFF).toLong() +
            (dst ushr 16).toLong() + (dst and 0xFFFF).toLong() + proto.toLong() + len.toLong()

    private fun newIp(src: Int, dst: Int, proto: Int, l4: Int): ByteArray {
        val p = ByteArray(20 + l4)
        p[0] = 0x45
        put16(p, 2, 20 + l4)
        put16(p, 6, 0x4000)
        p[8] = 64
        p[9] = proto.toByte()
        putI(p, 12, src)
        putI(p, 16, dst)
        put16(p, 10, csum(p, 0, 20, 0L))
        return p
    }

    private fun tcpPkt(
        src: Int, sp: Int, dst: Int, dp: Int, seq: Long, ack: Long,
        fl: Int, win: Int, data: ByteArray?, mss: Int
    ): ByteArray {
        val opt = if (mss > 0) 4 else 0
        val dl = data?.size ?: 0
        val l4 = 20 + opt + dl
        val p = newIp(src, dst, 6, l4)
        val o = 20
        put16(p, o, sp)
        put16(p, o + 2, dp)
        put32(p, o + 4, seq)
        put32(p, o + 8, ack)
        p[o + 12] = (((20 + opt) / 4) shl 4).toByte()
        p[o + 13] = fl.toByte()
        put16(p, o + 14, win)
        if (mss > 0) {
            p[o + 20] = 2
            p[o + 21] = 4
            put16(p, o + 22, mss)
        }
        if (data != null && dl > 0) System.arraycopy(data, 0, p, o + 20 + opt, dl)
        put16(p, o + 16, csum(p, o, l4, pseudo(src, dst, 6, l4)))
        return p
    }

    private fun udpPkt(src: Int, sp: Int, dst: Int, dp: Int, data: ByteArray): ByteArray {
        val l4 = 8 + data.size
        val p = newIp(src, dst, 17, l4)
        val o = 20
        put16(p, o, sp)
        put16(p, o + 2, dp)
        put16(p, o + 4, l4)
        System.arraycopy(data, 0, p, o + 8, data.size)
        var c = csum(p, o, l4, pseudo(src, dst, 17, l4))
        if (c == 0) c = 0xFFFF
        put16(p, o + 6, c)
        return p
    }

    private fun writeTun(p: ByteArray) {
        if (!alive) return
        try {
            synchronized(outLock) { out.write(p) }
        } catch (e: Exception) {
            err("tun লেখা", e)
        }
    }

    private fun err(what: String, e: Throwable) {
        if (!alive) return
        EngineStats.errors.incrementAndGet()
        EngineStats.add("⚠ $what: ${e.javaClass.simpleName}")
        val now = System.currentTimeMillis()
        var fire = false
        synchronized(this) {
            if (now - errStart > 10000) {
                errStart = now
                errCnt = 0
            }
            errCnt++
            if (errCnt > 200 && !fatalDone) {
                fatalDone = true
                fire = true
            }
        }
        if (fire) onFatal()
    }

    // ---------------- প্যাকেট পড়া ----------------

    private fun readLoop() {
        val buf = ByteArray(32767)
        try {
            while (alive) {
                val n = inp.read(buf)
                if (n < 0) break
                if (n >= 20) {
                    try {
                        handle(buf, n)
                    } catch (e: Exception) {
                        err("প্যাকেট", e)
                    }
                }
            }
        } catch (e: Exception) {
            // tun বন্ধ হয়েছে
        }
    }

    private fun handle(b: ByteArray, n: Int) {
        if ((u8(b, 0) shr 4) != 4) return // IPv6 ফেলে দেওয়া
        val ihl = (u8(b, 0) and 15) * 4
        if (ihl < 20 || n < ihl) return
        val total = u16(b, 2)
        val len = if (total in ihl..n) total else n
        if ((u16(b, 6) and 0x3FFF) != 0) return // ফ্র্যাগমেন্ট
        val proto = u8(b, 9)
        val src = ip4(b, 12)
        val dst = ip4(b, 16)
        when (proto) {
            6 -> handleTcp(b, n, ihl, len, src, dst)
            17 -> handleUdp(b, n, ihl, len, src, dst)
            else -> {}
        }
    }

    private fun ownerUid(proto: Int, k: FKey): Int {
        if (Build.VERSION.SDK_INT < 29) return -1
        for (i in 0 until 3) {
            try {
                val u = cm.getConnectionOwnerUid(
                    proto,
                    InetSocketAddress(toAddr(k.src), k.sp),
                    InetSocketAddress(toAddr(k.dst), k.dp)
                )
                if (u >= 0) return u
            } catch (e: Exception) {
                return -1
            }
            try { Thread.sleep(5) } catch (e: InterruptedException) {}
        }
        return -1
    }

    /** true = এই ফ্লো ইঞ্জিন পৌঁছে দেবে, false = ব্লক করা অ্যাপ, ফেলে দেবে */
    @Volatile private var lastUid = -1 // শুধু রিডার থ্রেড: decide-এর পরপর কানেকশন লগ যাতে মালিক জানে

    private fun decide(proto: Int, k: FKey): Boolean {
        lastUid = -1
        // DNS প্রশ্ন সবসময় ইঞ্জিন সামলায়: সিস্টেমের নিজের (netd) প্রশ্নের মালিক অ্যাপ নয়,
        // আর শুধু নাম খোঁজায় ব্লক করা অ্যাপও ডেটা পায় না
        if (k.dp == 53) return true
        val now = System.currentTimeMillis()
        val d = deny[k]
        if (d != null && now < d) return false
        val uid = ownerUid(proto, k)
        if (uid < 0) return false
        // Private DNS (DoT) সিস্টেম নিজেই করে, তাই সিস্টেম UID-এর 853 পোর্ট ছাড়
        if (proto == 6 && k.dp == 853 && uid in 0..9999) return true
        val ok = fwdUids.contains(uid)
        if (ok) lastUid = uid
        if (!ok) {
            deny[k] = now + 3000
            if (deny.size > 2000) deny.clear()
        }
        return ok
    }

    // ---------------- UDP ও DNS ----------------

    private inner class UdpFlow(val sock: DatagramSocket) {
        @Volatile var last = System.currentTimeMillis()
        @Volatile var log: ConnLog.Flow? = null // নতুন ফিচার: কানেকশন লগ
    }

    private fun handleUdp(b: ByteArray, n: Int, ihl: Int, len: Int, src: Int, dst: Int) {
        if (len < ihl + 8) return
        val sp = u16(b, ihl)
        val dp = u16(b, ihl + 2)
        val plen = minOf(u16(b, ihl + 4), len - ihl) - 8
        if (plen < 0) return
        val k = FKey(src, sp, dst, dp)
        val existing = udp[k]
        if (existing == null && !decide(17, k)) {
            onDrop(b, n)
            return
        }
        val uidNow = lastUid
        val payload = b.copyOfRange(ihl + 8, ihl + 8 + plen)
        if (dp == 53) {
            try {
                pool.execute { handleDns(k, payload) }
            } catch (e: RejectedExecutionException) {
            }
            return
        }
        if (existing != null) {
            existing.last = System.currentTimeMillis()
            existing.log?.addUp(payload.size)
            try {
                existing.sock.send(DatagramPacket(payload, payload.size))
            } catch (e: Exception) {
            }
            return
        }
        if ((dst ushr 24) >= 224) return // মাল্টিকাস্ট/ব্রডকাস্ট
        if (dst == FAKE_DNS || udp.size > 1000) return
        try {
            val s = DatagramSocket()
            svc.protect(s)
            s.connect(InetSocketAddress(toAddr(dst), dp))
            val f = UdpFlow(s)
            f.log = ConnLog.start(svc, uidNow, toAddr(dst).hostAddress, dp)
            f.log?.addUp(payload.size)
            udp[k] = f
            EngineStats.udp.incrementAndGet()
            s.send(DatagramPacket(payload, payload.size))
            try {
                pool.execute {
                val buf = ByteArray(2048) // ১৪৭২-এর বড় প্যাকেট নিচে ফেলাই হয়, তাই ২KB যথেষ্ট
                val pk = DatagramPacket(buf, buf.size)
                try {
                    while (alive) {
                        pk.length = buf.size
                        s.receive(pk)
                        f.last = System.currentTimeMillis()
                        f.log?.addDown(pk.length)
                        if (pk.length <= 1472) {
                            writeTun(udpPkt(k.dst, k.dp, k.src, k.sp, buf.copyOf(pk.length)))
                        }
                    }
                } catch (e: Exception) {
                } finally {
                    f.log?.finish()
                    try { s.close() } catch (e: Exception) {}
                    udp.remove(k)
                }
                }
            } catch (e: RejectedExecutionException) {
                f.log?.finish()
                try { s.close() } catch (x: Exception) {}
                udp.remove(k)
            }
        } catch (e: Exception) {
            err("UDP", e)
        }
    }

    private fun parseQuestion(q: ByteArray): Triple<String, Int, Int>? {
        if (q.size < 17) return null
        if ((u8(q, 2) and 0x80) != 0) return null
        if (u16(q, 4) != 1) return null
        var i = 12
        val sb = StringBuilder()
        while (true) {
            if (i >= q.size) return null
            val l = u8(q, i)
            if (l == 0) {
                i++
                break
            }
            if ((l and 0xC0) != 0) return null
            if (i + 1 + l > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, l, Charsets.ISO_8859_1))
            i += 1 + l
        }
        if (i + 4 > q.size) return null
        val type = u16(q, i)
        i += 4
        return Triple(sb.toString(), type, i)
    }

    private fun dnsReply(q: ByteArray, qend: Int, rcode: Int, trunc: Boolean): ByteArray {
        val r = ByteArray(qend)
        System.arraycopy(q, 0, r, 0, qend)
        val rd = u8(q, 2) and 1
        val opcode = (u8(q, 2) shr 3) and 15
        r[2] = (0x80 or (opcode shl 3) or (if (trunc) 2 else 0) or rd).toByte()
        r[3] = (0x80 or rcode).toByte()
        for (i in 6..11) r[i] = 0
        return r
    }

    private fun forwardDns(q: ByteArray): ByteArray? {
        var tried = 0
        for (ns in upstream()) {
            if (tried >= 2) break
            tried++
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket()
                svc.protect(s)
                s.soTimeout = 3000
                s.connect(InetSocketAddress(ns, 53)) // শুধু ওই সার্ভারের উত্তর নেবে
                s.send(DatagramPacket(q, q.size))
                val buf = ByteArray(4096)
                val rp = DatagramPacket(buf, buf.size)
                val until = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < until) {
                    rp.length = buf.size
                    s.receive(rp)
                    // প্রশ্নের ID না মিললে নকল উত্তর ধরে ফেলে দেওয়া
                    if (rp.length >= 12 && buf[0] == q[0] && buf[1] == q[1]) {
                        return buf.copyOf(rp.length)
                    }
                }
            } catch (e: Exception) {
            } finally {
                try { s?.close() } catch (e: Exception) {}
            }
        }
        return null
    }

    private class DnsEntry(val body: ByteArray, val exp: Long)
    private val dnsCache = ConcurrentHashMap<String, DnsEntry>()

    private fun skipName(b: ByteArray, from: Int): Int {
        var i = from
        while (i < b.size) {
            val l = u8(b, i)
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return i + 2
            i += 1 + l
        }
        return -1
    }

    /** উত্তরের সবচেয়ে ছোট TTL (সেকেন্ড)। উত্তর না থাকলে বা বোঝা না গেলে 0 */
    private fun minTtl(r: ByteArray, qend: Int): Int {
        if (r.size < 12 || (u8(r, 3) and 0x0F) != 0 || (u8(r, 2) and 0x02) != 0) return 0
        val an = u16(r, 6)
        if (an <= 0) return 0
        var i = qend
        var min = Int.MAX_VALUE
        for (n in 0 until an) {
            i = skipName(r, i)
            if (i < 0 || i + 10 > r.size) return 0
            val ttl = (u16(r, i + 4) shl 16) or u16(r, i + 6)
            if (ttl < min) min = ttl
            i += 10 + u16(r, i + 8)
            if (i > r.size) return 0
        }
        return if (min == Int.MAX_VALUE || min < 0) 0 else min
    }

    private fun handleDns(k: FKey, q: ByteArray) {
        try {
            val pq = parseQuestion(q)
            var reply: ByteArray? = null
            var fromUp = false
            var qend = q.size
            if (pq != null) {
                val name = pq.first
                val type = pq.second
                qend = pq.third
                EngineStats.queries.incrementAndGet()
                if (filter.blocked(name)) {
                    EngineStats.blocked.incrementAndGet()
                    EngineStats.add("✖ $name")
                    reply = dnsReply(q, qend, 3, false) // NXDOMAIN: "এই ঠিকানা নেই"
                } else if (Scam.check(svc, name)) {
                    EngineStats.blocked.incrementAndGet()
                    reply = dnsReply(q, qend, 3, false) // স্ক্যাম গার্ড: একইভাবে NXDOMAIN
                } else if (type == 28 || type == 65 || type == 64) {
                    reply = dnsReply(q, qend, 0, false) // IPv6/HTTPS: খালি উত্তর
                } else {
                    EngineStats.add("✔ $name")
                }
            }
            val ckey = if (pq != null) pq.first.lowercase() + "|" + pq.second else null
            if (reply == null && ckey != null) {
                val e = dnsCache[ckey]
                if (e != null) {
                    if (e.exp > System.currentTimeMillis()) {
                        reply = e.body.copyOf()
                        reply[0] = q[0] // প্রশ্নের নিজস্ব ID বসানো
                        reply[1] = q[1]
                    } else {
                        dnsCache.remove(ckey)
                    }
                }
            }
            if (reply == null) {
                reply = forwardDns(q)
                fromUp = reply != null
            }
            if (fromUp && ckey != null && reply != null && reply.size <= 1472) {
                // ব্লক-করা নাম এখানে পৌঁছায়ই না (আগে আটকানো), তাই ক্যাশে শুধু অনুমোদিত নামের উত্তর
                val ttl = minOf(minTtl(reply, qend), 120)
                if (ttl >= 5) {
                    if (dnsCache.size > 500) dnsCache.clear()
                    dnsCache[ckey] = DnsEntry(reply.copyOf(), System.currentTimeMillis() + ttl * 1000L)
                }
            }
            if (reply == null) {
                if (pq == null) return
                reply = dnsReply(q, qend, 2, false) // SERVFAIL
            }
            if (reply.size > 1472) reply = dnsReply(q, qend, 0, true) // বড় হলে TCP-তে আবার চাইবে
            if (pq != null && fromUp) ConnLog.onDns(pq.first, reply) // কানেকশন লগের জন্য IP→নাম
            writeTun(udpPkt(k.dst, k.dp, k.src, k.sp, reply))
        } catch (e: Exception) {
            err("DNS", e)
        }
    }

    // ---------------- TCP ----------------

    private fun parseMss(b: ByteArray, from: Int, to: Int): Int {
        var i = from
        while (i < to) {
            val kind = u8(b, i)
            if (kind == 0) break
            if (kind == 1) {
                i++
                continue
            }
            if (i + 1 >= to) break
            val l = u8(b, i + 1)
            if (l < 2) break
            if (kind == 2 && l == 4 && i + 3 < to) return u16(b, i + 2)
            i += l
        }
        return 0
    }

    private fun rstFor(k: FKey, seq: Long, ack: Long, fl: Int, dlen: Int) {
        if ((fl and F_ACK) != 0) {
            writeTun(tcpPkt(k.dst, k.dp, k.src, k.sp, ack, 0L, F_RST, 0, null, 0))
        } else {
            var extra = dlen
            if ((fl and F_SYN) != 0) extra++
            if ((fl and F_FIN) != 0) extra++
            writeTun(tcpPkt(k.dst, k.dp, k.src, k.sp, 0L, add(seq, extra), F_RST or F_ACK, 0, null, 0))
        }
    }

    private fun handleTcp(b: ByteArray, n: Int, ihl: Int, len: Int, src: Int, dst: Int) {
        if (len < ihl + 20) return
        val sp = u16(b, ihl)
        val dp = u16(b, ihl + 2)
        val seq = u32(b, ihl + 4)
        val ack = u32(b, ihl + 8)
        val doff = (u8(b, ihl + 12) shr 4) * 4
        val fl = u8(b, ihl + 13)
        val win = u16(b, ihl + 14)
        if (doff < 20 || ihl + doff > len) return
        val dataOff = ihl + doff
        val dlen = len - dataOff
        val k = FKey(src, sp, dst, dp)
        val f = tcp[k]
        if (f == null) {
            if ((fl and F_RST) != 0) return
            if ((fl and F_SYN) != 0 && (fl and F_ACK) == 0) {
                if (!decide(6, k)) {
                    onDrop(b, n)
                    return
                }
                if (tcp.size > 2000) {
                    rstFor(k, seq, ack, fl, dlen)
                    return
                }
                var target: InetAddress = toAddr(dst)
                if (dst == FAKE_DNS) {
                    // সিস্টেমের DNS-এ TCP: আসল DNS সার্ভারে পাঠাই। 853 (DoT) সাথে সাথে ফেরত
                    if (dp != 53) {
                        rstFor(k, seq, ack, fl, dlen)
                        return
                    }
                    val up = upstream()
                    if (up.isEmpty()) {
                        rstFor(k, seq, ack, fl, dlen)
                        return
                    }
                    target = up[0]
                }
                val mss = parseMss(b, ihl + 20, ihl + doff)
                val nf = TcpFlow(k, seq, mss, target, dp)
                if (dst != FAKE_DNS) nf.log = ConnLog.start(svc, lastUid, toAddr(dst).hostAddress, dp)
                tcp[k] = nf
                EngineStats.tcp.incrementAndGet()
                nf.start()
            } else {
                // অচেনা ফ্লো (ইঞ্জিন নতুন চালু বা পুরনো সংযোগ): সাথে সাথে RST, অ্যাপ নতুন করে চেষ্টা করবে
                rstFor(k, seq, ack, fl, dlen)
            }
            return
        }
        val data = if (dlen > 0) b.copyOfRange(dataOff, dataOff + dlen) else null
        f.onSegment(seq, ack, fl, win, data)
    }

    private inner class TcpFlow(
        val key: FKey,
        private val clientIsn: Long,
        clientMss: Int,
        private val target: InetAddress,
        private val targetPort: Int
    ) {
        private val lock = ReentrantLock()
        private val cond = lock.newCondition()
        private val sendMss = if (clientMss in 100..1400) clientMss else if (clientMss > 1400) 1400 else 536
        private val isn: Long = java.util.concurrent.ThreadLocalRandom.current().nextLong(0L, 0x100000000L)

        @Volatile var log: ConnLog.Flow? = null // নতুন ফিচার: কানেকশন লগ
        @Volatile var state = 0 // 0 সংযোগ হচ্ছে, 1 SYN-ACK গেছে, 2 চালু, 3 বন্ধ
        @Volatile private var chan: SocketChannel? = null
        @Volatile private var rcvNext: Long = (clientIsn + 1) and M32
        private var sndNext: Long = (isn + 1) and M32
        private var sndUna: Long = (isn + 1) and M32
        @Volatile private var appWin = 65535
        private val inflight = ArrayDeque<Seg>()
        private val wq = LinkedBlockingQueue<ByteArray>()
        private val queued = AtomicInteger(0)
        @Volatile private var lastWin = 65535
        @Volatile private var appFin = false
        private var remoteFin = false
        private var finSent = false
        @Volatile private var last = System.currentTimeMillis()
        private var synAt = 0L
        private var synTries = 0

        fun start() {
            try {
                startTask()
            } catch (e: RejectedExecutionException) {
                close(true)
            }
        }

        private fun startTask() {
            pool.execute {
                val ch: SocketChannel = try {
                    val c = SocketChannel.open()
                    try {
                        svc.protect(c.socket())
                        c.socket().connect(InetSocketAddress(target, targetPort), 8000)
                    } catch (e: Exception) {
                        try { c.close() } catch (x: Exception) {}
                        throw e
                    }
                    c
                } catch (e: Exception) {
                    if (state != 3) {
                        EngineStats.add("✖ সংযোগ হয়নি ${target.hostAddress}:$targetPort")
                        close(true)
                    }
                    return@execute
                }
                chan = ch
                if (state == 3) {
                    try { ch.close() } catch (x: Exception) {}
                    return@execute
                }
                lock.withLock {
                    state = 1
                    synAt = System.currentTimeMillis()
                }
                sendSynAck()
                try {
                    pool.execute { writerLoop(ch) }
                } catch (e: RejectedExecutionException) {
                    try { ch.close() } catch (x: Exception) {}
                    close(true)
                    return@execute
                }
                readerLoop(ch)
            }
        }

        private fun sendSynAck() {
            writeTun(
                tcpPkt(
                    key.dst, key.dp, key.src, key.sp, isn, add(clientIsn, 1),
                    F_SYN or F_ACK, 65535, null, 1400
                )
            )
        }

        fun sendAck() {
            var seq = 0L
            lock.withLock { seq = sndNext }
            val win = maxOf(0, 65535 - queued.get())
            lastWin = win
            writeTun(tcpPkt(key.dst, key.dp, key.src, key.sp, seq, rcvNext, F_ACK, win, null, 0))
        }

        private fun rstApp() {
            if (state == 0) {
                // সংযোগই হয়নি: SYN-এর উত্তরে RST
                writeTun(
                    tcpPkt(key.dst, key.dp, key.src, key.sp, 0L, add(clientIsn, 1), F_RST or F_ACK, 0, null, 0)
                )
                return
            }
            var seq = 0L
            lock.withLock { seq = sndNext }
            writeTun(tcpPkt(key.dst, key.dp, key.src, key.sp, seq, rcvNext, F_RST or F_ACK, 0, null, 0))
        }

        fun close(rst: Boolean) {
            lock.withLock {
                if (state == 3) return
                if (rst) rstApp() // state বদলানোর আগে, যাতে সঠিক ধরনের RST যায়
                state = 3
                cond.signalAll()
            }
            try { chan?.close() } catch (e: Exception) {}
            wq.offer(EOF)
            tcp.remove(key, this)
            log?.finish()
        }

        private fun maybeClose() {
            var done = false
            lock.withLock {
                if (appFin && remoteFin && diff(sndNext, sndUna) == 0L) done = true
            }
            if (done) close(false)
        }

        fun onSegment(seq: Long, ack: Long, fl: Int, win: Int, data: ByteArray?) {
            last = System.currentTimeMillis()
            if ((fl and F_RST) != 0) {
                close(false)
                return
            }
            if (state == 0) return
            if ((fl and F_SYN) != 0) {
                if (state == 1) sendSynAck()
                return
            }
            if ((fl and F_ACK) != 0) {
                lock.withLock {
                    if (state == 1 && ack == add(isn, 1)) state = 2
                    val adv = diff(ack, sndUna)
                    if (adv > 0 && diff(ack, sndNext) <= 0) {
                        sndUna = ack
                        while (true) {
                            val s = inflight.peekFirst() ?: break
                            val end = add(s.seq, s.data.size + (if (s.fin) 1 else 0))
                            if (diff(end, ack) <= 0) inflight.removeFirst() else break
                        }
                    }
                    appWin = win
                    cond.signalAll()
                }
            }
            val dlen = data?.size ?: 0
            if (dlen > 0 && data != null) {
                if (seq == rcvNext) {
                    if (queued.get() + dlen > MAXQ) {
                        sendAck()
                    } else {
                        queued.addAndGet(dlen)
                        rcvNext = add(rcvNext, dlen)
                        log?.addUp(dlen)
                        log?.onClientData(data)
                        wq.add(data)
                        sendAck()
                    }
                } else {
                    sendAck() // পুরনো বা আগাম সেগমেন্ট
                }
            }
            if ((fl and F_FIN) != 0 && add(seq, dlen) == rcvNext && !appFin) {
                appFin = true
                rcvNext = add(rcvNext, 1)
                wq.add(EOF)
                sendAck()
            }
            maybeClose()
        }

        private fun writerLoop(ch: SocketChannel) {
            try {
                while (true) {
                    val c = wq.take()
                    if (c === EOF) {
                        if (state != 3) {
                            try { ch.socket().shutdownOutput() } catch (e: Exception) {}
                        }
                        break
                    }
                    if (state == 3) break
                    try {
                        val bb = ByteBuffer.wrap(c)
                        while (bb.hasRemaining()) ch.write(bb)
                    } catch (e: Exception) {
                        if (state != 3) close(true)
                        break
                    }
                    val q = queued.addAndGet(-c.size)
                    if (lastWin < 32768 && q < 32768) sendAck()
                }
            } catch (e: InterruptedException) {
            }
        }

        private fun readerLoop(ch: SocketChannel) {
            val bb = ByteBuffer.allocate(sendMss)
            try {
                while (state != 3) {
                    bb.clear()
                    val r = ch.read(bb)
                    if (r < 0) break
                    if (r == 0) continue
                    log?.addDown(r)
                    if (!sendData(bb.array().copyOf(r))) return
                }
            } catch (e: Exception) {
                if (state != 3) close(true)
                return
            }
            if (state != 3) sendFin()
        }

        /** অ্যাপের উইন্ডো না থাকলে অপেক্ষা। false = ফ্লো বন্ধ */
        private fun sendData(data: ByteArray): Boolean {
            val deadline = System.currentTimeMillis() + 60000
            lock.withLock {
                while (true) {
                    if (state == 3) return false
                    val flight = diff(sndNext, sndUna)
                    val blocked = state < 2 || appWin == 0 ||
                        (flight > 0 && flight + data.size > appWin)
                    if (!blocked) break
                    if (System.currentTimeMillis() > deadline) {
                        close(true)
                        return false
                    }
                    cond.await(500, TimeUnit.MILLISECONDS)
                }
                val seq = sndNext
                inflight.addLast(Seg(seq, data, false, System.currentTimeMillis(), 0))
                sndNext = add(sndNext, data.size)
                val win = maxOf(0, 65535 - queued.get())
                writeTun(tcpPkt(key.dst, key.dp, key.src, key.sp, seq, rcvNext, F_ACK, win, data, 0))
            }
            return true
        }

        private fun sendFin() {
            lock.withLock {
                if (state == 3 || finSent) return
                finSent = true
                remoteFin = true
                val seq = sndNext
                inflight.addLast(Seg(seq, EMPTY, true, System.currentTimeMillis(), 0))
                sndNext = add(sndNext, 1)
                val win = maxOf(0, 65535 - queued.get())
                writeTun(tcpPkt(key.dst, key.dp, key.src, key.sp, seq, rcvNext, F_FIN or F_ACK, win, null, 0))
            }
            maybeClose()
        }

        /** সময়-নির্ভর কাজ: SYN-ACK আবার পাঠানো, হারানো সেগমেন্ট আবার, নিষ্ক্রিয় ফ্লো বন্ধ */
        fun tick(now: Long) {
            var kill = false
            lock.withLock {
                if (state == 1) {
                    if (now - synAt > 1000) {
                        synTries++
                        synAt = now
                        if (synTries > 5) kill = true else sendSynAck()
                    }
                } else if (state == 2) {
                    val s = inflight.peekFirst()
                    if (s != null) {
                        val rto = minOf(8000L, 1000L shl s.tries)
                        if (now - s.sentAt > rto) {
                            if (s.tries >= 8) {
                                kill = true
                            } else {
                                s.tries++
                                s.sentAt = now
                                val win = maxOf(0, 65535 - queued.get())
                                val fl = if (s.fin) (F_FIN or F_ACK) else F_ACK
                                writeTun(
                                    tcpPkt(
                                        key.dst, key.dp, key.src, key.sp, s.seq, rcvNext, fl, win,
                                        if (s.fin) null else s.data, 0
                                    )
                                )
                            }
                        }
                    }
                }
                if (now - last > 300000) kill = true
            }
            if (kill) close(true)
        }
    }

    private fun tick() {
        try {
            val now = System.currentTimeMillis()
            for (f in tcp.values) f.tick(now)
            for ((k, f) in udp.entries.toList()) {
                if (now - f.last > 60000) {
                    f.log?.finish()
                    try { f.sock.close() } catch (e: Exception) {}
                    udp.remove(k)
                }
            }
        } catch (e: Exception) {
            err("টাইমার", e)
        }
    }
}
