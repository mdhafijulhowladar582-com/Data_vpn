package com.you.firewall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PackageReceiver(private val onNew: (String) -> Unit) : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return // আপডেট নয়, নতুন ইনস্টল
        val pkg = i.data?.schemeSpecificPart ?: return
        onNew(pkg)
    }
}
